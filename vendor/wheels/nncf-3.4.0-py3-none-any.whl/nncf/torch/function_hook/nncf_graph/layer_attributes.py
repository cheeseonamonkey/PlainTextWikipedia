# Copyright (c) 2026 Intel Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#      http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from dataclasses import dataclass
from typing import Any, Callable

from nncf.common.graph.layer_attributes import BaseLayerAttributes


@dataclass(frozen=True)
class PT2OpLayerAttributes(BaseLayerAttributes):
    """
    This class stores information about operation.

    :param func: Function that the operation represents.
    :param op_args: Tuple of positional arguments for the operation.
    :param op_kwargs: Dictionary of keyword arguments for the operation.
    :param constant_port_ids: Set of input port indices with constants.
    """

    func: Callable[..., Any]
    op_args: tuple[Any, ...]
    op_kwargs: dict[str, Any]
    constant_port_ids: set[int]
