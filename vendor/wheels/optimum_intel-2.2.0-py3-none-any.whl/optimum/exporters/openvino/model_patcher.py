#  Copyright 2024 The HuggingFace Team. All rights reserved.
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.

import copy
import functools
import inspect
import json
import logging
import math
import os
import types
from dataclasses import dataclass
from types import SimpleNamespace
from typing import Any, Callable, Dict, List, Optional, Tuple, Union

import torch
import torch.nn.functional as F
import transformers
from huggingface_hub import hf_hub_download
from huggingface_hub.utils import EntryNotFoundError
from safetensors import safe_open
from torch import nn
from transformers import PreTrainedModel
from transformers.cache_utils import Cache, DynamicCache, EncoderDecoderCache
from transformers.configuration_utils import PretrainedConfig
from transformers.generation import GenerationMixin
from transformers.modeling_outputs import (
    BaseModelOutput,
    BaseModelOutputWithPast,
    BaseModelOutputWithPooling,
)
from transformers.models.llama.configuration_llama import LlamaConfig
from transformers.models.llama.modeling_llama import (
    LlamaAttention,
    LlamaMLP,
    LlamaPreTrainedModel,
    LlamaRMSNorm,
    LlamaRotaryEmbedding,
)
from transformers.models.phi3.modeling_phi3 import apply_rotary_pos_emb, repeat_kv
from transformers.models.speecht5.modeling_speecht5 import SpeechT5EncoderWithSpeechPrenet
from transformers.processing_utils import Unpack
from transformers.utils import ModelOutput

from optimum.exporters.openvino._ov_ops import convert_recurrent_attention_cell, convert_recurrent_selective_ssm_cell
from optimum.exporters.openvino.base import OpenVINOConfig
from optimum.exporters.openvino.patching_utils import (
    ModelPatcher,
    eager_mask_without_vmap,
    override_arguments,
    postprocess_past_key_values,
    preprocess_past_key_values,
)
from optimum.intel.utils.import_utils import (
    is_diffusers_version,
    is_openvino_version,
    is_torch_version,
    is_transformers_version,
)


if is_transformers_version(">=", "4.53"):
    from transformers.masking_utils import (
        ALL_MASK_ATTENTION_FUNCTIONS,
        eager_mask,
        sdpa_mask,
    )
    from transformers.models.qwen3_moe.modeling_qwen3_moe import Qwen3MoeSparseMoeBlock


if is_transformers_version(">=", "4.54"):
    from transformers.masking_utils import create_causal_mask
    from transformers.utils import TransformersKwargs
else:
    TransformersKwargs = object


if is_transformers_version(">=", "4.57"):
    from transformers.models.qwen3.modeling_qwen3 import (
        Qwen3Attention,
        Qwen3Config,
        Qwen3MLP,
        Qwen3PreTrainedModel,
        Qwen3RMSNorm,
        Qwen3RotaryEmbedding,
    )
    from transformers.models.qwen3.modeling_qwen3 import (
        eager_attention_forward as qwen3_eager_attention_forward,
    )
    from transformers.models.qwen3.modeling_qwen3 import (
        rotate_half as qwen3_rotate_half,
    )
else:
    Qwen3Config = PretrainedConfig
    Qwen3PreTrainedModel = PreTrainedModel
    Qwen3MLP = object
    Qwen3Attention = object
    Qwen3RMSNorm = object
    Qwen3RotaryEmbedding = object


if is_transformers_version(">=", "4.56"):
    import transformers.masking_utils


if is_transformers_version(">=", "4.57"):
    from transformers.models.qwen3_vl.modeling_qwen3_vl import Qwen3VLTextRotaryEmbedding


if is_transformers_version(">=", "5"):
    from transformers.modeling_rope_utils import RotaryEmbeddingConfigMixin


if is_diffusers_version(">=", "0.38.0"):
    from diffusers.models.transformers import transformer_ltx2


logger = logging.getLogger(__name__)


class SAMModelPatcher(ModelPatcher):
    def __init__(
        self,
        config: "OpenVINOConfig",
        model: PreTrainedModel,
        model_kwargs: dict[str, Any] | None = None,
    ):
        super().__init__(config, model, model_kwargs)

        def patched_forward(
            pixel_values=None,
            input_points=None,
            input_labels=None,
            image_embeddings=None,
            image_positional_embeddings=None,
            return_dict=True,
            **kwargs,
        ):
            if config.variant == "monolith":
                return self.orig_forward(
                    pixel_values=pixel_values,
                    input_points=input_points,
                    input_labels=input_labels,
                    image_embeddings=image_embeddings,
                    return_dict=return_dict,
                    **kwargs,
                )
            elif config.variant == "split":
                # return_dict = get_argument(args, kwargs, signature, "return_dict")
                if config.vision_encoder:
                    # pixel_values = get_argument(args, kwargs, signature, "pixel_values")
                    image_positional_embeddings = model.get_image_wide_positional_embeddings()

                    # repeat with batch size
                    batch_size = pixel_values.shape[0]
                    image_positional_embeddings = image_positional_embeddings.repeat(batch_size, 1, 1, 1)

                    vision_outputs = model.vision_encoder(
                        pixel_values,
                        output_attentions=False,
                        output_hidden_states=False,
                        return_dict=return_dict,
                    )
                    image_embeddings = vision_outputs[0]

                    if not return_dict:
                        return (image_embeddings, image_positional_embeddings)
                    else:
                        return {
                            "image_embeddings": image_embeddings,
                            "image_positional_embeddings": image_positional_embeddings,
                        }
                else:
                    if input_points is None:
                        raise ValueError("input_points is required to export the prompt encoder / mask decoder.")

                    sparse_embeddings, dense_embeddings = model.prompt_encoder(
                        input_points=input_points,
                        input_labels=input_labels,
                        input_boxes=None,  # Not supported in the OpenVINO export
                        input_masks=None,  # Not supported in the OpenVINO export
                    )
                    outputs = model.mask_decoder(
                        image_embeddings=image_embeddings,
                        image_positional_embeddings=image_positional_embeddings,
                        sparse_prompt_embeddings=sparse_embeddings,
                        dense_prompt_embeddings=dense_embeddings,
                        multimask_output=True,  # Not supported in the OpenVINO export
                        attention_similarity=None,  # Not supported in the OpenVINO export
                        target_embedding=None,  # Not supported in the OpenVINO export
                    )
                    low_res_masks, iou_predictions = outputs[:2]

                    if not return_dict:
                        return (iou_predictions, low_res_masks)
                    else:
                        return {"iou_scores": iou_predictions, "pred_masks": low_res_masks}

        self.patched_forward = patched_forward


class SentenceTransformersTransformerPatcher(ModelPatcher):
    def __init__(
        self,
        config: "OpenVINOConfig",
        model: PreTrainedModel,
        model_kwargs: dict[str, Any],
    ):
        super().__init__(config, model, model_kwargs)

        def patched_forward(input_ids, attention_mask):
            result = self.orig_forward({"input_ids": input_ids, "attention_mask": attention_mask})

            if "input_ids" in result:
                del result["input_ids"]
            if "attention_mask" in result:
                del result["attention_mask"]
            if "all_layer_embeddings" in result:
                del result["all_layer_embeddings"]

            return result

        self.patched_forward = patched_forward


def _get_model_attribute(model, name):
    target = getattr(model, "model", model) if is_transformers_version(">=", "5") else model
    return getattr(target, name)


# Original code: https://github.com/huggingface/transformers/blob/v5.0.0/src/transformers/integrations/moe.py#L98
# Method needs to be patched to match the pattern that OpenVINO MoE optimization transformation expect.
# The difference is that this method packs hidden states and routing weight to dense representation,
# instead of usage of indexed tensors.
# Also, original method adds squeeze/unsqueeze operations around MatMul's which also break expected pattern.
def batched_mm_experts_forward_patched(
    self: torch.nn.Module,
    hidden_states: torch.Tensor,
    top_k_index: torch.Tensor,
    top_k_weights: torch.Tensor,
) -> torch.Tensor:
    num_tokens = hidden_states.size(0)
    hidden_dim = hidden_states.size(-1)
    num_experts = self.gate_up_proj.size(0)

    if not self.is_transposed:
        gate_up_proj = self.gate_up_proj.transpose(1, 2)
        down_proj = self.down_proj.transpose(1, 2)
    else:
        gate_up_proj = self.gate_up_proj
        down_proj = self.down_proj

    dense_routing_weights = torch.zeros(
        num_tokens,
        num_experts,
        device=hidden_states.device,
        dtype=hidden_states.dtype,
    )
    dense_routing_weights.scatter_(dim=1, index=top_k_index, src=top_k_weights)
    hidden_states_expanded = hidden_states.repeat(num_experts, 1)  # (num_experts * num_tokens, hidden_dim)
    hidden_states_expanded = hidden_states_expanded.view(
        num_experts, -1, hidden_dim
    )  # (num_experts, num_tokens, hidden_dim)

    # --- Up projection per expert (batched) ---
    gate_up_out = torch.bmm(hidden_states_expanded, gate_up_proj)
    # (S, 2 * intermediate_dim)

    if self.has_bias:
        gate_up_out = gate_up_out + self.gate_up_proj_bias[..., None, :]

    # Apply gating
    # gate, up = gate_up_out[..., ::2], gate_up_out[..., 1::2]
    # gate = gate.clamp(min=None, max=self.limit)
    # up = up.clamp(min=-self.limit, max=self.limit)
    # gated_out = gate * torch.sigmoid(gate * self.alpha)
    gated_out = self._apply_gate(gate_up_out)

    # --- Down projection per expert (batched) ---
    next_states = torch.bmm(gated_out, down_proj)  # (S, hidden_dim)

    if self.has_bias:
        next_states = next_states + self.down_proj_bias[..., None, :]

    next_states = next_states.view(num_experts, num_tokens, -1, hidden_dim)

    # Apply routing weights
    next_states = next_states * dense_routing_weights.transpose(0, 1).view(num_experts, num_tokens, -1)[..., None]
    next_states = next_states.sum(dim=0)

    return next_states


# Original code: https://github.com/huggingface/transformers/blob/v5.0.0/src/transformers/modeling_utils.py#L1930
# The patch is needed to add "ov_batched_mm" to the applicable_experts list.
def get_correct_experts_implementation_patched(self, requested_experts: str | None) -> str:
    applicable_experts = "grouped_mm" if requested_experts is None else requested_experts
    if applicable_experts not in ["eager", "grouped_mm", "batched_mm", "ov_batched_mm"]:
        message = (
            f'Specified `experts_implementation="{applicable_experts}"` is not supported. The only possible arguments are '
            '`experts_implementation="eager"`, `"experts_implementation=grouped_mm"` and `"experts_implementation=batched_mm"`.'
        )
        raise ValueError(message)

    # Perform relevant checks
    if applicable_experts == "grouped_mm":
        try:
            self._grouped_mm_can_dispatch()
        except (ValueError, ImportError) as e:
            if requested_experts == "grouped_mm":
                raise e
            applicable_experts = "eager"

    return applicable_experts


def register_ov_batched_mm(patcher):
    from transformers.integrations.moe import ALL_EXPERTS_FUNCTIONS

    if is_transformers_version("<", "5.7"):
        patcher.get_correct_experts_implementation_orig = patcher._model.get_correct_experts_implementation
        patcher._model.get_correct_experts_implementation = types.MethodType(
            get_correct_experts_implementation_patched, patcher._model
        )

    ALL_EXPERTS_FUNCTIONS.register("ov_batched_mm", batched_mm_experts_forward_patched)
    patcher._model.set_experts_implementation("ov_batched_mm")


def patch_update_causal_mask(
    model, transformers_version, inner_model_name="model", patch_fn=None, patch_extrnal_model=False
):
    if is_transformers_version(">=", transformers_version):
        inner_model = getattr(model, inner_model_name, None) if not patch_extrnal_model else model
        if inner_model is not None:
            if hasattr(inner_model, "_update_causal_mask"):
                inner_model._orig_update_causal_mask = inner_model._update_causal_mask
            patch_fn = patch_fn or _update_causal_mask_patched
            inner_model._update_causal_mask = types.MethodType(patch_fn, inner_model)


# adopted from https://github.com/huggingface/transformers/blob/f4014e75db0190792b3feeccfc5dc5b5f9f0ce7b/src/transformers/models/llama/modeling_llama.py#L1036
def _update_causal_mask_patched(
    self,
    attention_mask,
    input_tensor,
    cache_position,
    past_key_values,
    output_attentions,
):
    from transformers.cache_utils import StaticCache
    from transformers.modeling_attn_mask_utils import AttentionMaskConverter

    # TODO: As of torch==2.2.0, the `attention_mask` passed to the model in `generate` is 2D and of dynamic length even when the static
    # KV cache is used. This is an issue for torch.compile which then recaptures cudagraphs at each decode steps due to the dynamic shapes.
    # (`recording cudagraph tree for symint key 13`, etc.), which is VERY slow. A workaround is `@torch.compiler.disable`, but this prevents using
    # `fullgraph=True`. See more context in https://github.com/huggingface/transformers/pull/29114

    if self.config._attn_implementation == "flash_attention_2":
        if attention_mask is not None and 0.0 in attention_mask:
            return attention_mask
        return None

    # For SDPA, when possible, we will rely on its `is_causal` argument instead of its `attn_mask` argument, in
    # order to dispatch on Flash Attention 2. This feature is not compatible with static cache, as SDPA will fail
    # to infer the attention mask.
    past_seen_tokens = past_key_values.get_seq_length() if past_key_values is not None else 0
    using_static_cache = isinstance(past_key_values, StaticCache)

    # When output attentions is True, sdpa implementation's forward method calls the eager implementation's forward
    if self.config._attn_implementation == "sdpa" and not using_static_cache and not output_attentions:
        if AttentionMaskConverter._ignore_causal_mask_sdpa(
            attention_mask,
            inputs_embeds=input_tensor,
            past_key_values_length=past_seen_tokens,
            is_training=self.training,
        ):
            return None

    dtype, device = input_tensor.dtype, input_tensor.device
    # difference with original modeling
    # using minimum from dtype with larger bandwidth (float32) may lead to overflow
    # during execution on platforms with default lower precision (bfloat16, float16)
    min_dtype = torch.finfo(torch.float16).min

    sequence_length = input_tensor.shape[1]
    if using_static_cache:
        target_length = past_key_values.get_max_length()
    else:
        target_length = (
            attention_mask.shape[-1]
            if isinstance(attention_mask, torch.Tensor)
            else past_seen_tokens + sequence_length + 1
        )

    if attention_mask is not None and attention_mask.dim() == 4:
        # in this case we assume that the mask comes already in inverted form and requires no inversion or slicing
        if attention_mask.max() != 0:
            raise ValueError("Custom 4D attention mask should be passed in inverted form with max==0`")
        causal_mask = attention_mask
    else:
        # difference with original modeling
        causal_mask = (
            torch.full((sequence_length, target_length), fill_value=1, dtype=dtype, device=device) * min_dtype
        )

        if sequence_length != 1:
            causal_mask = torch.triu(causal_mask, diagonal=1)
        causal_mask *= torch.arange(target_length, device=device) > cache_position.reshape(-1, 1)
        causal_mask = causal_mask[None, None, :, :].expand(input_tensor.shape[0], 1, -1, -1)
        if attention_mask is not None:
            causal_mask = causal_mask.clone()  # copy to contiguous memory for in-place edit
            mask_length = attention_mask.shape[-1]
            padding_mask = causal_mask[:, :, :, :mask_length] + attention_mask[:, None, None, :]
            padding_mask = padding_mask == 0
            causal_mask[:, :, :, :mask_length] = causal_mask[:, :, :, :mask_length].masked_fill(
                padding_mask, min_dtype
            )
    if (
        self.config._attn_implementation == "sdpa"
        and attention_mask is not None
        and attention_mask.device.type == "cuda"
        and not output_attentions
    ):
        # Attend to all tokens in fully masked rows in the causal_mask, for example the relevant first rows when
        # using left padding. This is required by F.scaled_dot_product_attention memory-efficient attention path.
        # Details: https://github.com/pytorch/pytorch/issues/110213
        causal_mask = AttentionMaskConverter._unmask_unattended(causal_mask, min_dtype)

    return causal_mask


# TODO: this is a numerical issue in OpenVINO, let's open an issue to track it
# initialization of sin/cos cached in bf16/fp16 leads to accuracy loss
# reinitialize them to save in float32 before export
def patch_cos_sin_cached_fp32(model):
    if (
        hasattr(model, "layers")
        and hasattr(model.layers[0], "self_attn")
        and hasattr(model.layers[0].self_attn, "rotary_emb")
        and hasattr(model.layers[0].self_attn.rotary_emb, "dtype")
        and hasattr(model.layers[0].self_attn.rotary_emb, "inv_freq")
        and hasattr(model.layers[0].self_attn.rotary_emb, "max_position_embeddings")
        and hasattr(model.layers[0].self_attn.rotary_emb, "_set_cos_sin_cache")
    ):
        for layer in model.layers:
            if layer.self_attn.rotary_emb.dtype != torch.float32:
                layer.self_attn.rotary_emb._set_cos_sin_cache(
                    seq_len=layer.self_attn.rotary_emb.max_position_embeddings,
                    device=layer.self_attn.rotary_emb.inv_freq.device,
                    dtype=torch.float32,
                )


# Adapted from https://github.com/huggingface/transformers/blob/3c307e380ad07ca16903a39e09a47d532cb782d9/src/transformers/models/phimoe/modular_phimoe.py#L57
def _longrope_forward(self, x, position_ids=None, layer_type=None, **kwargs):
    # _compute_longrope_parameters https://github.com/huggingface/transformers/blob/v5.0.0/src/transformers/modeling_rope_utils.py#L391
    # transformers >= 5 stores RoPE settings under config.rope_parameters; transformers < 5 (e.g. 4.57) stores
    # them under config.rope_scaling and as plain attributes on the config.
    if hasattr(self.config, "rope_parameters") and self.config.rope_parameters is not None:
        rope_parameters = (
            self.config.rope_parameters[layer_type] if layer_type is not None else self.config.rope_parameters
        )
    else:
        rope_scaling = getattr(self.config, "rope_scaling", None) or {}
        rope_parameters = dict(rope_scaling)
        rope_parameters.setdefault("rope_theta", getattr(self.config, "rope_theta", 10000.0))
        rope_parameters.setdefault(
            "original_max_position_embeddings",
            getattr(self.config, "original_max_position_embeddings", self.config.max_position_embeddings),
        )
        rope_parameters.setdefault("partial_rotary_factor", getattr(self.config, "partial_rotary_factor", 1.0))

    rope_theta = rope_parameters["rope_theta"]
    long_factor = rope_parameters["long_factor"]
    short_factor = rope_parameters["short_factor"]
    original_max = rope_parameters["original_max_position_embeddings"]
    partial_rotary_factor = rope_parameters.get("partial_rotary_factor", 1.0)
    long_mscale = rope_parameters.get("long_mscale")
    short_mscale = rope_parameters.get("short_mscale")
    head_dim = getattr(self.config, "head_dim", self.config.hidden_size // self.config.num_attention_heads)
    dim = int(head_dim * partial_rotary_factor)

    # needed for transformers < v5 for phimoe
    seq_len = kwargs.get("seq_len", None)
    _seq_len = seq_len if position_ids is None else torch.max(position_ids) + 1
    # bool tensor to avoid only one path getting traced
    is_long = _seq_len > original_max

    # Compute the inverse frequencies -- scaled based on the target sequence length
    long_factors = torch.tensor(long_factor, dtype=torch.float32, device=x.device)
    short_factors = torch.tensor(short_factor, dtype=torch.float32, device=x.device)
    ext_factors = torch.where(is_long, long_factors, short_factors)
    inv_freq_shape = torch.arange(0, dim, 2, dtype=torch.int64, device=x.device).float() / dim
    inv_freq = 1.0 / (ext_factors * rope_theta**inv_freq_shape)

    # https://github.com/huggingface/transformers/blob/v5.0.0/src/transformers/models/phimoe/modular_phimoe.py#L64-L71
    if long_mscale is not None and short_mscale is not None:
        long_mscale = torch.tensor(long_mscale, dtype=x.dtype, device=x.device)
        short_mscale = torch.tensor(short_mscale, dtype=x.dtype, device=x.device)
        mscale = torch.where(is_long, long_mscale, short_mscale)
    else:
        # https://github.com/huggingface/transformers/blob/v5.0.0/src/transformers/modeling_rope_utils.py#L461
        factor = rope_parameters.get("factor") or self.config.max_position_embeddings / original_max
        attention_factor = rope_parameters.get("attention_factor")
        if attention_factor is None:
            attention_factor = 1.0 if factor <= 1.0 else math.sqrt(1 + math.log(factor) / math.log(original_max))
        mscale = attention_factor

    if is_transformers_version(">=", "5") or position_ids is not None:
        # https://github.com/huggingface/transformers/blob/v5.0.0/src/transformers/models/phimoe/modeling_phimoe.py#L116
        inv_freq_expanded = inv_freq[None, :, None].float().expand(position_ids.shape[0], -1, 1).to(x.device)
        position_ids_expanded = position_ids[:, None, :].float()
        device_type = x.device.type if isinstance(x.device.type, str) and x.device.type != "mps" else "cpu"
        with torch.autocast(device_type=device_type, enabled=False):
            freqs = (inv_freq_expanded.float() @ position_ids_expanded.float()).transpose(1, 2)
            emb = torch.cat((freqs, freqs), dim=-1)
            cos = emb.cos() * mscale
            sin = emb.sin() * mscale
    else:
        # needed for transformers < v5 for phimoe
        t = torch.arange(_seq_len, device=x.device, dtype=torch.float32)
        freqs = torch.outer(t, inv_freq)
        emb = torch.cat((freqs, freqs), dim=-1)
        cos = emb.cos() * mscale
        sin = emb.sin() * mscale
    return cos.to(x.dtype), sin.to(x.dtype)


class OVDecoderModelPatcher(ModelPatcher):
    def __enter__(self):
        super().__enter__()

        patch_cos_sin_cached_fp32(self._model)
        if hasattr(self._model, "model"):
            patch_cos_sin_cached_fp32(self._model.model)

        if is_transformers_version("<", "4.53.0") and hasattr(self._model, "_update_causal_mask"):
            self._model._update_causal_mask_original = self._model._update_causal_mask
            self._model._update_causal_mask = types.MethodType(_update_causal_mask_patched, self._model)

        if is_transformers_version(">=", "4.53.0"):
            # for OpenVINO, we use torch.finfo(torch.float16).min instead of torch.finfo(dtype).min
            # Although I'm not sure this is the right way to handle this, we are basically pretending that -65,504 is -inf
            ALL_MASK_ATTENTION_FUNCTIONS.register("eager", eager_mask_without_vmap)

            # for decoder models, we use eager mask without vmap for sdpa as well
            # to avoid a nan output issue in OpenVINO that only happens in case of:
            # non-stateful models on cpu and stateful models on npu
            ALL_MASK_ATTENTION_FUNCTIONS.register("sdpa", eager_mask_without_vmap)

        for module in self._model.modules():
            rope_type = getattr(module, "rope_type", None)
            if rope_type == "longrope" and (
                is_transformers_version("<", "5")
                or isinstance(getattr(module, "config", None), RotaryEmbeddingConfigMixin)
            ):
                module._rope_orig_forward = module.forward
                module.forward = types.MethodType(_longrope_forward, module)

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)

        if is_transformers_version("<", "4.53") and hasattr(self._model, "_update_causal_mask_original"):
            self._model._update_causal_mask = self._model._update_causal_mask_original
            del self._model._update_causal_mask_original

        if is_transformers_version(">=", "4.53"):
            ALL_MASK_ATTENTION_FUNCTIONS.register("sdpa", sdpa_mask)
            ALL_MASK_ATTENTION_FUNCTIONS.register("eager", eager_mask)

        for module in self._model.modules():
            if hasattr(module, "_rope_orig_forward"):
                module.forward = module._rope_orig_forward
                del module._rope_orig_forward


def _mixtral_sparse_moe_block_forward(self, hidden_states: torch.Tensor) -> torch.Tensor:
    batch_size, sequence_length, hidden_dim = hidden_states.shape
    hidden_states = hidden_states.view(-1, hidden_dim)
    # router_logits: (batch * sequence_length, n_experts)
    router_logits = self.gate(hidden_states)

    routing_weights = F.softmax(router_logits, dim=1, dtype=torch.float)
    routing_weights, selected_experts = torch.topk(routing_weights, self.top_k, dim=-1)
    routing_weights /= routing_weights.sum(dim=-1, keepdim=True)
    # we cast back to the input dtype
    routing_weights = routing_weights.to(hidden_states.dtype)

    final_hidden_states = torch.zeros(
        (batch_size * sequence_length, hidden_dim), dtype=hidden_states.dtype, device=hidden_states.device
    )

    # One hot encode the selected experts to create an expert mask
    # this will be used to easily index which expert is going to be sollicitated
    expert_mask = torch.nn.functional.one_hot(selected_experts, num_classes=self.num_experts).permute(2, 1, 0)

    # Loop over all available experts in the model and perform the computation on each expert
    for expert_idx in range(self.num_experts):
        expert_layer = self.experts[expert_idx]
        idx, top_x = torch.where(expert_mask[expert_idx])

        # Index the correct hidden states and compute the expert hidden state for
        # the current expert. We need to make sure to multiply the output hidden
        # states by `routing_weights` on the corresponding tokens (top-1 and top-2)
        current_state = hidden_states[None, top_x].reshape(-1, hidden_dim)
        current_hidden_states = expert_layer(current_state) * routing_weights[top_x, idx, None]

        final_hidden_states.index_add_(0, top_x, current_hidden_states.to(hidden_states.dtype))
    final_hidden_states = final_hidden_states.reshape(batch_size, sequence_length, hidden_dim)
    return final_hidden_states, router_logits


class MixtralModelPatcher(OVDecoderModelPatcher):
    def __enter__(self):
        super().__enter__()
        if is_transformers_version("<", "5"):
            for layer in self._model.model.layers:
                layer.block_sparse_moe._unpatched_forward = layer.block_sparse_moe.forward
                layer.block_sparse_moe.forward = types.MethodType(
                    _mixtral_sparse_moe_block_forward, layer.block_sparse_moe
                )
        else:
            from transformers.models.mixtral.modeling_mixtral import MixtralExperts

            self.original_moe_forward = MixtralExperts.forward
            MixtralExperts.forward = lfm2_moe_experts_forward

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)

        if is_transformers_version("<", "5"):
            for layer in self._model.model.layers:
                layer.block_sparse_moe.forward = layer.block_sparse_moe._unpatched_forward
        else:
            from transformers.models.mixtral.modeling_mixtral import MixtralExperts

            MixtralExperts.forward = self.original_moe_forward


class ArcticModelPatcher(MixtralModelPatcher):
    def __enter__(self):
        # model initialize some weights for matrix multiplication in bfloat16, that lead to inconsistency of dtype
        try:
            self._model.to(torch.float32)
        except Exception:
            pass

        super().__enter__()


def _chatglm_transformer_forward(
    self,
    input_ids,
    position_ids: Optional[torch.Tensor] = None,
    attention_mask: Optional[torch.BoolTensor] = None,
    full_attention_mask: Optional[torch.BoolTensor] = None,
    past_key_values: Optional[Tuple[Tuple[torch.Tensor, torch.Tensor], ...]] = None,
    inputs_embeds: Optional[torch.Tensor] = None,
    use_cache: Optional[bool] = None,
    output_hidden_states: Optional[bool] = None,
    return_dict: Optional[bool] = None,
):
    output_hidden_states = (
        output_hidden_states if output_hidden_states is not None else self.config.output_hidden_states
    )
    use_cache = use_cache if use_cache is not None else self.config.use_cache
    return_dict = return_dict if return_dict is not None else self.config.use_return_dict

    batch_size, seq_length = input_ids.shape

    if inputs_embeds is None:
        inputs_embeds = self.embedding(input_ids)

    if getattr(self, "pre_seq_len", None) is not None:
        if past_key_values is None:
            past_key_values = self.get_prompt(
                batch_size=batch_size,
                device=input_ids.device,
                dtype=inputs_embeds.dtype,
            )
        if attention_mask is not None:
            attention_mask = torch.cat(
                [
                    attention_mask.new_ones((batch_size, self.pre_seq_len)),
                    attention_mask,
                ],
                dim=-1,
            )

    if full_attention_mask is None:
        if past_key_values is not None:
            full_attention_mask = torch.ones(
                batch_size,
                seq_length,
                seq_length,
                device=input_ids.device,
                dtype=torch.float,
            ) * float("-inf")
            full_attention_mask.triu_(diagonal=1)
            past_length = 0
            if past_key_values:
                past_length = past_key_values[0][0].shape[0]
            if past_length:
                full_attention_mask = torch.cat(
                    (
                        torch.zeros(batch_size, seq_length, past_length, device=input_ids.device),
                        full_attention_mask,
                    ),
                    dim=-1,
                )
            full_attention_mask.unsqueeze_(1)

    # Rotary positional embeddings
    rotary_pos_emb = self.rotary_pos_emb(self.seq_length)
    if position_ids is not None:
        rotary_pos_emb = rotary_pos_emb[position_ids]
    else:
        rotary_pos_emb = rotary_pos_emb[None, :seq_length]
    rotary_pos_emb = rotary_pos_emb.transpose(0, 1).contiguous()

    # Run encoder.
    hidden_states, presents, all_hidden_states, all_self_attentions = self.encoder(
        inputs_embeds,
        full_attention_mask,
        rotary_pos_emb=rotary_pos_emb,
        kv_caches=past_key_values,
        use_cache=use_cache,
        output_hidden_states=output_hidden_states,
    )

    if not return_dict:
        return tuple(v for v in [hidden_states, presents, all_hidden_states, all_self_attentions] if v is not None)

    return BaseModelOutputWithPast(
        last_hidden_state=hidden_states,
        past_key_values=presents,
        hidden_states=all_hidden_states,
        attentions=all_self_attentions,
    )


def _chatglm2_get_context_layer(query_layer: torch.Tensor, key_layer: torch.Tensor, value_layer: torch.Tensor):
    mask = torch.zeros((query_layer.shape[-2], key_layer.shape[-2]), dtype=query_layer.dtype)
    if query_layer.shape[2] == key_layer.shape[2]:
        tmp_mask = torch.ones((query_layer.shape[-2], key_layer.shape[-2]), dtype=torch.bool).triu(diagonal=1)
        mask.masked_fill_(tmp_mask, float("-inf"))

    context_layer = torch.nn.functional.scaled_dot_product_attention(
        query_layer, key_layer, value_layer, attn_mask=mask
    )
    return context_layer


def _chatglm2_core_attention_forward(self, query_layer, key_layer, value_layer, attention_mask):
    query_layer, key_layer, value_layer = [k.permute(1, 2, 0, 3) for k in [query_layer, key_layer, value_layer]]
    if attention_mask is None:
        context_layer = _chatglm2_get_context_layer(query_layer, key_layer, value_layer)
    else:
        context_layer = torch.nn.functional.scaled_dot_product_attention(
            query_layer, key_layer, value_layer, attention_mask
        )
    context_layer = context_layer.permute(2, 0, 1, 3)
    new_context_layer_shape = context_layer.size()[:-2] + (self.hidden_size_per_partition,)
    context_layer = context_layer.reshape(*new_context_layer_shape)

    return context_layer


def _glm4_core_attention_forward(self, query_layer, key_layer, value_layer, attention_mask):
    causal_mask = torch.zeros_like(attention_mask, dtype=torch.float32)
    causal_mask.masked_fill_(attention_mask, float("-inf"))
    context_layer = torch.nn.functional.scaled_dot_product_attention(query_layer, key_layer, value_layer, causal_mask)
    context_layer = context_layer.transpose(1, 2).contiguous()
    new_context_layer_shape = context_layer.size()[:-2] + (self.hidden_size_per_partition,)
    context_layer = context_layer.reshape(*new_context_layer_shape)
    return context_layer


class ChatGLMModelPatcher(OVDecoderModelPatcher):
    def __init__(
        self,
        config: "OpenVINOConfig",
        model: "PreTrainedModel",
        model_kwargs: Dict[str, Any],
    ):
        super().__init__(config, model, model_kwargs)
        self.is_v4 = hasattr(self._model.config, "rope_ratio")

    def __enter__(self):
        super().__enter__()

        if not self.is_v4:
            self._model.transformer._orig_forward = self._model.transformer.forward
            self._model.transformer.forward = types.MethodType(_chatglm_transformer_forward, self._model.transformer)
        for block in self._model.transformer.encoder.layers:
            block.self_attention.core_attention._orig_forward = block.self_attention.core_attention.forward
            block.self_attention.core_attention.forward = types.MethodType(
                _chatglm2_core_attention_forward if not self.is_v4 else _glm4_core_attention_forward,
                block.self_attention.core_attention,
            )

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)
        if hasattr(self._model.transformer, "_orig_forward"):
            self._model.transformer.forward = self._model.transformer._orig_forward
        for block in self._model.transformer.encoder.layers:
            block.self_attention.core_attention.forward = block.self_attention.core_attention._orig_forward


# what does this patch exactly ?
def llama_gemma_rotary_emb_forward(self, x, position_ids, seq_len=None):
    # adopted from https://github.com/huggingface/transformers/blob/main/src/transformers/models/gemma/modeling_gemma.py#L104
    _seq_len = torch.max(position_ids) + 1 if seq_len is None else seq_len
    if _seq_len > self.embed_positions.shape[0]:
        if seq_len is None:
            return self._orig_forward(x, position_ids)
        else:
            return self._orig_forward(x, position_ids, seq_len)
    sincos = self.embed_positions[position_ids]
    sin, cos = torch.split(sincos, sincos.shape[-1] // 2, dim=-1)
    return cos, sin


def create_sinusoidal_positions(num_pos: int, dim: int, base: int = 10000, inv_freq=None) -> torch.Tensor:
    # adopted from https://github.com/huggingface/transformers/blob/main/src/transformers/models/llama/modeling_llama.py#L101
    if inv_freq is None:
        inv_freq = 1.0 / (base ** (torch.arange(0, dim, 2, dtype=torch.int64) / dim))

    sinusoid_inp = torch.einsum("i , j -> i j", torch.arange(num_pos, dtype=torch.int64).float(), inv_freq).float()
    emb = torch.cat((sinusoid_inp, sinusoid_inp), dim=-1)
    return torch.cat((torch.sin(emb), torch.cos(emb)), dim=1)


# cos/sin for rotary position embeddings also having issues with bf16 and efficiency due to calculation on each step, use precomputed
def create_embed_positions_buffer(rotary_emb, max_position_embeddings: int = None):
    inv_freq = getattr(rotary_emb, "inv_freq", None)

    dim, base = None, None
    if inv_freq is None:
        base = rotary_emb.base
        dim = rotary_emb.dim

    return create_sinusoidal_positions(max_position_embeddings, dim, base, inv_freq)


class MistralModelPatcher(OVDecoderModelPatcher):
    def __enter__(self):
        super().__enter__()

        if hasattr(self._model, "model") and hasattr(self._model.model, "layers"):
            for layer in self._model.model.layers:
                if hasattr(layer.self_attn, "rotary_emb"):
                    embed_positions = create_embed_positions_buffer(
                        rotary_emb=layer.self_attn.rotary_emb,
                        max_position_embeddings=self._model.config.max_position_embeddings,
                    )
                    layer.self_attn.rotary_emb.register_buffer("embed_positions", embed_positions)
                    layer.self_attn.rotary_emb._orig_forward = layer.self_attn.rotary_emb.forward
                    layer.self_attn.rotary_emb.forward = types.MethodType(
                        llama_gemma_rotary_emb_forward, layer.self_attn.rotary_emb
                    )

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)

        if hasattr(self._model.model, "model") and hasattr(self._model.model.model, "layers"):
            for layer in self._model.model.layers:
                if hasattr(layer.self_attn, "rotary_emb"):
                    layer.self_attn.rotary_emb.forward = layer.self_attn.rotary_emb._orig_forward
                    del layer.self_attn.rotary_emb._orig_forward


SUPPORT_SDPA = is_torch_version(">", "2.1.0")


# TODO: why
def _qwen_rotate_half(x):
    from einops import rearrange

    x = rearrange(x, "... (j d) -> ... j d", j=2)
    x1, x2 = x.unbind(dim=-2)
    return torch.cat((-x2, x1), dim=-1)


# TODO: why
def _qwen_apply_rotary_pos_emb(t, freqs):
    cos, sin = freqs
    rot_dim = freqs[0].shape[-1]
    cos, sin = freqs
    t_, t_pass_ = t[..., :rot_dim], t[..., rot_dim:]
    t_ = t_.float()
    t_pass_ = t_pass_.float()
    t_ = (t_ * cos) + (_qwen_rotate_half(t_) * sin)
    return torch.cat((t_, t_pass_), dim=-1).type_as(t)


# TODO: why
def _qwen_quantize_cache_v(fdata, bits, qmax, qmin):
    # b, s, head, h-dim->b, head, s, h-dim
    qtype = torch.uint8
    device = fdata.device
    shape = fdata.shape

    fdata_cal = torch.flatten(fdata, 2)
    fmax = torch.amax(fdata_cal, dim=-1, keepdim=True)
    fmin = torch.amin(fdata_cal, dim=-1, keepdim=True)
    # Compute params
    if qmax.device != fmax.device:
        qmax = qmax.to(device)
        qmin = qmin.to(device)
    scale = (fmax - fmin) / (qmax - qmin)
    zero = qmin - fmin / scale
    scale = scale.unsqueeze(-1).repeat(1, 1, shape[2], 1).contiguous()
    zero = zero.unsqueeze(-1).repeat(1, 1, shape[2], 1).contiguous()
    # Quantize
    res_data = fdata / scale + zero
    qdata = torch.clamp(res_data, qmin, qmax).to(qtype)
    return qdata.contiguous(), scale, zero


# TODO: why
def _qwen_attention_forward(
    self,
    hidden_states: Optional[Tuple[torch.FloatTensor]],
    rotary_pos_emb_list: Optional[List[List[torch.Tensor]]] = None,
    layer_past: Optional[Tuple[torch.Tensor]] = None,
    attention_mask: Optional[torch.FloatTensor] = None,
    head_mask: Optional[torch.FloatTensor] = None,
    encoder_hidden_states: Optional[torch.Tensor] = None,
    encoder_attention_mask: Optional[torch.FloatTensor] = None,
    output_attentions: Optional[bool] = False,
    use_cache: Optional[bool] = False,
):
    mixed_x_layer = self.c_attn(hidden_states)

    query, key, value = mixed_x_layer.split(self.split_size, dim=2)

    query = self._split_heads(query, self.num_heads, self.head_dim)
    key = self._split_heads(key, self.num_heads, self.head_dim)
    value = self._split_heads(value, self.num_heads, self.head_dim)

    if rotary_pos_emb_list is not None:
        cur_len = query.shape[1]
        if len(rotary_pos_emb_list) == 1:
            rotary_pos_emb = rotary_pos_emb_list[0]
            rotary_pos_emb = [i[:, -cur_len:, :, :] for i in rotary_pos_emb]
            rotary_pos_emb = (rotary_pos_emb,) * 2
            q_pos_emb, k_pos_emb = rotary_pos_emb
            # Slice the pos emb for current inference
            query = _qwen_apply_rotary_pos_emb(query, q_pos_emb)
            key = _qwen_apply_rotary_pos_emb(key, k_pos_emb)
        else:
            query_list = []
            key_list = []
            for i, rotary_pos_emb in enumerate(rotary_pos_emb_list):
                rotary_pos_emb = [i[:, -cur_len:, :, :] for i in rotary_pos_emb]
                rotary_pos_emb = (rotary_pos_emb,) * 2
                q_pos_emb, k_pos_emb = rotary_pos_emb
                # Slice the pos emb for current inference
                query_list += [_qwen_apply_rotary_pos_emb(query[i : i + 1, :, :], q_pos_emb)]
                key_list += [_qwen_apply_rotary_pos_emb(key[i : i + 1, :, :], k_pos_emb)]
            query = torch.cat(query_list, dim=0)
            key = torch.cat(key_list, dim=0)

    if self.use_cache_quantization:
        key = _qwen_quantize_cache_v(key.permute(0, 2, 1, 3), bits=8, qmin=self.cache_qmin, qmax=self.cache_qmax)
        value = _qwen_quantize_cache_v(value.permute(0, 2, 1, 3), bits=8, qmin=self.cache_qmin, qmax=self.cache_qmax)

    if layer_past is not None:
        past_key, past_value = layer_past[0], layer_past[1]
        if self.use_cache_quantization:
            # use_cache_quantization:
            # present=((q_key,key_scale,key_zero_point),
            #          (q_value,value_scale,value_zero_point))
            key = (
                torch.cat((past_key[0], key[0]), dim=2),
                torch.cat((past_key[1], key[1]), dim=2),
                torch.cat((past_key[2], key[2]), dim=2),
            )
            value = (
                torch.cat((past_value[0], value[0]), dim=2),
                torch.cat((past_value[1], value[1]), dim=2),
                torch.cat((past_value[2], value[2]), dim=2),
            )
        else:
            # not use_cache_quantization:
            # present=(key,value)
            key = torch.cat((past_key, key), dim=1)
            value = torch.cat((past_value, value), dim=1)

    if use_cache:
        present = (key, value)
    else:
        present = None

    if self.use_logn_attn and not self.training:
        if self.use_cache_quantization:
            seq_start = key[0].size(2) - query.size(1)
            seq_end = key[0].size(2)
        else:
            seq_start = key.size(1) - query.size(1)
            seq_end = key.size(1)
        logn_tensor = self.logn_tensor[:, seq_start:seq_end, :, :].type_as(query)
        query = query * logn_tensor.expand_as(query)

    if self.use_flash_attn and not self.is_fp32 and query.is_cuda:
        q, k, v = query, key, value
        attn_output = self.core_attention_flash(q, k, v, attention_mask=attention_mask)
    else:
        registered_causal_mask = torch.tril(
            torch.ones((key.size(1), key.size(1)), dtype=torch.bool, device=key.device)
        ).view(1, 1, key.size(1), key.size(1))
        query = query.permute(0, 2, 1, 3)
        if not self.use_cache_quantization:
            key = key.permute(0, 2, 1, 3)
            value = value.permute(0, 2, 1, 3)

        if not self.use_cache_quantization and SUPPORT_SDPA:
            # For performance, using constant tril to generate causal_mask
            causal_mask = self.bias[:, :, key.size(-2) - query.size(-2) : key.size(-2), : key.size(-2)]
            if attention_mask is not None:
                attention_mask = attention_mask.expand(-1, -1, query.size(2), -1).masked_fill(
                    ~causal_mask, torch.finfo(query.dtype).min
                )
            else:
                attention_mask = causal_mask
            attn_output = F.scaled_dot_product_attention(query, key, value, attn_mask=attention_mask).transpose(1, 2)
            attn_weight = None
        else:
            attn_output, attn_weight = self._attn(query, key, value, registered_causal_mask, attention_mask, head_mask)
    context_layer = self._merge_heads(attn_output, self.num_heads, self.head_dim)

    attn_output = self.c_proj(context_layer)

    outputs = (attn_output, present)
    if output_attentions:
        if self.use_flash_attn and not self.is_fp32:
            raise ValueError("Cannot output attentions while using flash-attn")
        else:
            outputs += (attn_weight,)
    return outputs


class QwenModelPatcher(OVDecoderModelPatcher):
    def __init__(
        self,
        config: "OpenVINOConfig",
        model: "PreTrainedModel",
        model_kwargs: Dict[str, Any],
    ):
        super().__init__(config, model, model_kwargs)

        self.original_fp16 = model.config.fp16
        self.original_bf16 = model.config.bf16
        model.config.bf16 = False
        model.config.fp16 = False
        if self.original_fp16 or self.original_bf16:
            # GPTQ models does to support casting to dtype
            try:
                model.to(torch.float32)
            except Exception:
                pass
        model.transformer.rotary_emb(2048)

    def __enter__(self):
        super().__enter__()
        max_positions = self._model.config.seq_length
        for block in self._model.transformer.h:
            block.attn._orig_forward = block.attn.forward
            # For performance, using constant tril to generate causal_mask
            block.attn.register_buffer(
                "bias",
                torch.tril(torch.ones((max_positions, max_positions), dtype=torch.bool)).view(
                    1, 1, max_positions, max_positions
                ),
                persistent=False,
            )
            block.attn.forward = types.MethodType(_qwen_attention_forward, block.attn)

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)
        for block in self._model.transformer.h:
            block.attn.forward = block.attn._orig_forward
        self._model.config.bf16 = self.original_bf16
        self._model.config.fp16 = self.original_fp16


def _baichuan13b_atten_forward(
    self,
    hidden_states: torch.Tensor,
    attention_mask: Optional[torch.Tensor] = None,
    past_key_value: Optional[Tuple[torch.Tensor]] = None,
    output_attentions: bool = False,
    use_cache: bool = True,
) -> Tuple[torch.Tensor, Optional[torch.Tensor], Optional[Tuple[torch.Tensor]]]:
    bsz, q_len, _ = hidden_states.size()

    proj = self.W_pack(hidden_states)
    proj = proj.unflatten(-1, (3, self.hidden_size)).unsqueeze(0).transpose(0, -2).squeeze(-2)
    query_states = proj[0].view(bsz, q_len, self.num_heads, self.head_dim).transpose(1, 2)
    key_states = proj[1].view(bsz, q_len, self.num_heads, self.head_dim).transpose(1, 2)
    value_states = proj[2].view(bsz, q_len, self.num_heads, self.head_dim).transpose(1, 2)

    kv_seq_len = key_states.shape[-2]
    if past_key_value is not None:
        kv_seq_len += past_key_value[0].shape[-2]

    if past_key_value is not None:
        # reuse k, v, self_attention
        if attention_mask is not None:
            attention_mask = attention_mask[:, :, -key_states.shape[-2] :, :]
        key_states = torch.cat([past_key_value[0], key_states], dim=2)
        value_states = torch.cat([past_key_value[1], value_states], dim=2)
    if not output_attentions:
        past_key_value = (key_states, value_states) if use_cache else None
        attn_output = F.scaled_dot_product_attention(query_states, key_states, value_states, attn_mask=attention_mask)
        attn_weights = None
    else:
        attn_weights = torch.matmul(query_states, key_states.transpose(2, 3)) / math.sqrt(self.head_dim)

        if attention_mask is not None:
            if q_len == 1:  # inference with cache
                if len(attention_mask.size()) == 4:
                    attention_mask = attention_mask[:, :, -1:, :]
                else:
                    attention_mask = attention_mask[:, -1:, :]
            attn_weights = attn_weights + attention_mask
        attn_weights = torch.max(attn_weights, torch.tensor(torch.finfo(attn_weights.dtype).min))
        attn_weights = torch.nn.functional.softmax(attn_weights, dim=-1)
        attn_output = torch.matmul(attn_weights, value_states)

    attn_output = attn_output.transpose(1, 2)
    attn_output = attn_output.reshape(bsz, q_len, self.hidden_size)
    attn_output = self.o_proj(attn_output)

    return attn_output, attn_weights, past_key_value


# Adapted from https://huggingface.co/baichuan-inc/Baichuan-7B/blob/262c8cb58b6d3615c208d9230baa869fddee2adb/modeling_baichuan.py#L181
def _baichuan7b_attn_forward(
    self,
    hidden_states: torch.Tensor,
    attention_mask: Optional[torch.Tensor] = None,
    position_ids: Optional[torch.LongTensor] = None,
    past_key_value: Optional[Tuple[torch.Tensor]] = None,
    output_attentions: bool = False,
    use_cache: bool = False,
) -> Tuple[torch.Tensor, Optional[torch.Tensor], Optional[Tuple[torch.Tensor]]]:
    def rotate_half(x):
        """Rotates half the hidden dims of the input."""
        x1 = x[..., : x.shape[-1] // 2]
        x2 = x[..., x.shape[-1] // 2 :]
        return torch.cat((-x2, x1), dim=-1)

    def apply_rotary_pos_emb(q, k, cos, sin, position_ids):
        # The first two dimensions of cos and sin are always 1, so we can `squeeze` them.
        cos = cos.squeeze(1).squeeze(0)  # [seq_len, dim]
        sin = sin.squeeze(1).squeeze(0)  # [seq_len, dim]
        cos = cos[position_ids].unsqueeze(1)  # [bs, 1, seq_len, dim]
        sin = sin[position_ids].unsqueeze(1)  # [bs, 1, seq_len, dim]
        q_embed = (q * cos) + (rotate_half(q) * sin)
        k_embed = (k * cos) + (rotate_half(k) * sin)
        return q_embed, k_embed

    bsz, q_len, _ = hidden_states.size()

    proj = self.W_pack(hidden_states)
    proj = proj.unflatten(-1, (3, self.hidden_size)).unsqueeze(0).transpose(0, -2).squeeze(-2)
    query_states = proj[0].view(bsz, q_len, self.num_heads, self.head_dim).transpose(1, 2)
    key_states = proj[1].view(bsz, q_len, self.num_heads, self.head_dim).transpose(1, 2)
    value_states = proj[2].view(bsz, q_len, self.num_heads, self.head_dim).transpose(1, 2)

    kv_seq_len = key_states.shape[-2]
    if past_key_value is not None:
        kv_seq_len += past_key_value[0].shape[-2]
    cos, sin = self.rotary_emb(value_states, seq_len=kv_seq_len)
    query_states, key_states = apply_rotary_pos_emb(query_states, key_states, cos, sin, position_ids)
    # [bsz, nh, t, hd]

    if past_key_value is not None:
        # reuse k, v, self_attention
        key_states = torch.cat([past_key_value[0], key_states], dim=2)
        value_states = torch.cat([past_key_value[1], value_states], dim=2)

    past_key_value = (key_states, value_states) if use_cache else None
    if not output_attentions:
        attn_weights = None
        attn_output = F.scaled_dot_product_attention(
            query_states, key_states, value_states, attn_mask=attention_mask, scale=1 / math.sqrt(self.head_dim)
        )
    else:
        attn_weights = torch.matmul(query_states, key_states.transpose(2, 3)) / math.sqrt(self.head_dim)
        if attention_mask is not None:
            attn_weights = attn_weights + attention_mask
        attn_weights = torch.nn.functional.softmax(attn_weights, dim=-1, dtype=torch.float32).to(query_states.dtype)
        attn_output = torch.matmul(attn_weights, value_states)

    attn_output = attn_output.transpose(1, 2)
    attn_output = attn_output.reshape(bsz, q_len, self.hidden_size)
    attn_output = self.o_proj(attn_output)

    return attn_output, attn_weights, past_key_value


class BaichuanModelPatcher(OVDecoderModelPatcher):
    def __init__(
        self,
        config: "OpenVINOConfig",
        model: "PreTrainedModel",
        model_kwargs: Dict[str, Any],
    ):
        super().__init__(config, model, model_kwargs)
        # model has first inference buffers initialization
        if hasattr(self._model.lm_head, "first_flag"):
            self._model(torch.ones((1, 10), dtype=torch.int64), torch.ones((1, 10), dtype=torch.int64))

    def __enter__(self):
        super().__enter__()
        # override signature to have position_ids
        if "position_ids" not in inspect.signature(self._model.forward).parameters:
            self._model._orig_forward = self._model.forward

            def forward(
                self,
                input_ids: torch.LongTensor = None,
                attention_mask: Optional[torch.Tensor] = None,
                past_key_values: Optional[Tuple[torch.FloatTensor]] = None,
                inputs_embeds: Optional[torch.FloatTensor] = None,
                labels: Optional[torch.LongTensor] = None,
                use_cache: Optional[bool] = None,
                output_attentions: Optional[bool] = False,
                output_hidden_states: Optional[bool] = False,
                return_dict: Optional[bool] = True,
                position_ids: Optional[torch.LongTensor] = None,
            ):
                return self._orig_forward(
                    input_ids=input_ids,
                    attention_mask=attention_mask,
                    past_key_values=past_key_values,
                    inputs_embeds=inputs_embeds,
                    labels=labels,
                    use_cache=past_key_values is not None,
                    output_attentions=output_attentions,
                    output_hidden_states=output_hidden_states,
                    return_dict=self.config.return_dict,
                )

            self._model.forward = types.MethodType(forward, self._model)
            for layer in self._model.model.layers:
                layer.self_attn._orig_forward = layer.self_attn.forward
                layer.self_attn.forward = types.MethodType(_baichuan13b_atten_forward, layer.self_attn)
        else:
            for layer in self._model.model.layers:
                layer.self_attn._orig_forward = layer.self_attn.forward
                layer.self_attn.forward = types.MethodType(_baichuan7b_attn_forward, layer.self_attn)

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)
        if hasattr(self._model, "_orig_forward"):
            self._model.forward = self._model._orig_forward

        for layer in self._model.model.layers:
            if hasattr(layer.self_attn, "_orig_forward"):
                layer.self_attn.forward = layer.self_attn._orig_forward


# Modified from https://github.com/huggingface/transformers/blob/v4.48.0/src/transformers/models/mpt/modeling_mpt.py#L90
def _mpt_sdpa_attention_forward(
    self,
    hidden_states: torch.Tensor,
    position_bias: torch.Tensor,
    past_key_value: Optional[Tuple[torch.Tensor]] = None,
    attention_mask: Optional[torch.Tensor] = None,
    cache_position: Optional[torch.Tensor] = None,
):
    batch_size, seq_length = hidden_states.shape[:2]

    mixed_qkv = self.Wqkv(hidden_states)
    query_states, key_states, value_states = mixed_qkv.chunk(3, dim=2)
    query_states = query_states.reshape(batch_size, seq_length, self.n_heads, self.head_dim).transpose(1, 2)
    key_states = key_states.reshape(batch_size, seq_length, self.n_heads, self.head_dim).transpose(1, 2)
    value_states = value_states.reshape(batch_size, seq_length, self.n_heads, self.head_dim).transpose(1, 2)

    if past_key_value is not None:
        # starting from v4.54 https://github.com/huggingface/transformers/blob/v4.54.0/src/transformers/models/mpt/modeling_mpt.py#L362
        cache_kwargs = {"cache_position": cache_position}
        key_states, value_states = past_key_value.update(key_states, value_states, self.layer_idx, cache_kwargs)
        pkv_seq_length = past_key_value.get_seq_length()

    key_length = key_states.shape[-2]
    query_length = seq_length if past_key_value is None else seq_length + pkv_seq_length
    attention_mask_sdpa = torch.ones(
        (query_states.shape[0], query_states.shape[1], query_states.shape[2], key_states.shape[2]),
        dtype=query_states.dtype,
    )
    if position_bias is not None:
        position_bias_query_index = max(0, position_bias.size(1) - query_length)
        position_bias_key_index = max(0, position_bias.size(2) - key_length)

        position_bias = position_bias[:, position_bias_query_index:, position_bias_key_index:]
        attention_mask_sdpa += position_bias
    attention_mask_sdpa.masked_fill_(attention_mask, torch.finfo(query_states.dtype).min)
    context_states = torch.nn.functional.scaled_dot_product_attention(
        query_states,
        key_states,
        value_states,
        attn_mask=attention_mask_sdpa,
        dropout_p=self.attn_dropout_p,
        scale=self.softmax_scale,
    )

    context_states = context_states.permute(0, 2, 1, 3).contiguous().view(batch_size, seq_length, -1)
    attn_output = self.out_proj(context_states)

    outputs = (attn_output, None)

    return outputs


# Mofied from https://github.com/huggingface/transformers/blob/v4.48.0/src/transformers/models/mpt/modeling_mpt.py#L188
def _mpt_block_forward(
    self,
    hidden_states: torch.Tensor,
    position_bias: torch.Tensor,
    attention_mask: torch.Tensor,
    layer_past: Optional[Tuple[torch.Tensor, torch.Tensor]] = None,
    use_cache: bool = False,
    output_attentions: bool = False,
    cache_position: Optional[torch.Tensor] = None,
):
    # hidden_states: [batch_size, seq_length, hidden_size]
    # Layer norm at the beginning of the transformer layer.
    layernorm_output = self.norm_1(hidden_states)

    residual = hidden_states

    if not output_attentions:
        # Self attention.
        attn_out = self.attn(
            layernorm_output,
            position_bias=position_bias,
            attention_mask=attention_mask,
            past_key_value=layer_past,
            cache_position=cache_position,
        )
    else:
        attn_out = self.attn._orig_forward(
            layernorm_output,
            position_bias=position_bias,
            attention_mask=attention_mask,
            past_key_value=layer_past,
            cache_position=cache_position,
        )

    hidden_states = self.resid_attn_dropout(attn_out[0]) + residual

    layernorm_output = self.norm_2(hidden_states)

    # Get residual
    residual = hidden_states

    # MLP.
    output = self.ffn(layernorm_output, residual)
    outputs = (output,)

    if output_attentions:
        outputs += (attn_out[1],)

    return outputs


class MPTModelPatcher(OVDecoderModelPatcher):
    def __enter__(self):
        super().__enter__()

        if is_torch_version(">=", "2.1.0"):
            for block in self._model.transformer.blocks:
                block._orig_forward = block.forward
                block.forward = types.MethodType(_mpt_block_forward, block)
                block.attn._orig_forward = block.attn.forward
                block.attn.forward = types.MethodType(_mpt_sdpa_attention_forward, block.attn)

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)
        for block in self._model.transformer.blocks:
            if hasattr(block, "_orig_forward"):
                block.forward = block._orig_forward
            if hasattr(block.attn, "_orig_forward"):
                block.attn.forward = block.attn._orig_forward


def _internlm2_attention_forward(
    self,
    hidden_states: torch.Tensor,
    attention_mask: Optional[torch.Tensor] = None,
    position_ids: Optional[torch.LongTensor] = None,
    past_key_value: Optional[Tuple[torch.Tensor]] = None,
    output_attentions: bool = False,
    use_cache: bool = False,
    **kwargs,
) -> Tuple[torch.Tensor, Optional[torch.Tensor], Optional[Tuple[torch.Tensor]]]:
    # from transformers.models.llama.modeling_llama import apply_rotary_pos_emb, repeat_kv
    from einops import rearrange

    def rotate_half(x):
        """Rotates half the hidden dims of the input."""
        x1 = x[..., : x.shape[-1] // 2]
        x2 = x[..., x.shape[-1] // 2 :]
        return torch.cat((-x2, x1), dim=-1)

    def apply_rotary_pos_emb(q, k, cos, sin, position_ids=None, unsqueeze_dim=1):
        """Applies Rotary Position Embedding to the query and key tensors."""
        if position_ids is not None:
            cos = cos[position_ids]
            sin = sin[position_ids]
        cos = cos.unsqueeze(unsqueeze_dim)
        sin = sin.unsqueeze(unsqueeze_dim)
        q_embed = (q * cos) + (rotate_half(q) * sin)
        k_embed = (k * cos) + (rotate_half(k) * sin)
        return q_embed, k_embed

    def repeat_kv(hidden_states: torch.Tensor, n_rep: int) -> torch.Tensor:
        """
        This is the equivalent of torch.repeat_interleave(x, dim=1, repeats=n_rep). The hidden states go from (batch,
        num_key_value_heads, seqlen, head_dim) to (batch, num_attention_heads, seqlen, head_dim)
        """
        batch, num_key_value_heads, slen, head_dim = hidden_states.shape
        if n_rep == 1:
            return hidden_states
        hidden_states = hidden_states[:, :, None, :, :].expand(batch, num_key_value_heads, n_rep, slen, head_dim)
        return hidden_states.reshape(batch, num_key_value_heads * n_rep, slen, head_dim)

    bsz, q_len, _ = hidden_states.size()

    qkv_states = self.wqkv(hidden_states)

    qkv_states = rearrange(
        qkv_states,
        "b q (h gs d) -> b q h gs d",
        gs=2 + self.num_key_value_groups,
        d=self.head_dim,
    )

    query_states = qkv_states[..., : self.num_key_value_groups, :]
    query_states = rearrange(query_states, "b q h gs d -> b q (h gs) d")
    key_states = qkv_states[..., -2, :]
    value_states = qkv_states[..., -1, :]

    query_states = query_states.transpose(1, 2)
    key_states = key_states.transpose(1, 2)
    value_states = value_states.transpose(1, 2)

    kv_seq_len = key_states.shape[-2]
    is_legacy = not hasattr(self, "layer_idx")

    if is_legacy:
        if past_key_value is not None:
            kv_seq_len += past_key_value[0].shape[-2]
        cos, sin = self.rotary_emb(value_states, seq_len=kv_seq_len)
        query_states, key_states = apply_rotary_pos_emb(query_states, key_states, cos, sin, position_ids)
        if past_key_value is not None:
            key_states = torch.cat([past_key_value[0], key_states], dim=2)
            value_states = torch.cat([past_key_value[1], value_states], dim=2)
        past_key_value = (key_states, value_states) if use_cache else None
    else:
        cos, sin = self.rotary_emb(value_states, position_ids)
        query_states, key_states = apply_rotary_pos_emb(query_states, key_states, cos, sin)

        if past_key_value is not None:
            cache_kwargs = {"sin": sin, "cos": cos, "cache_position": kwargs.get("cache_position")}
            key_states, value_states = past_key_value.update(key_states, value_states, self.layer_idx, cache_kwargs)

    key_states = repeat_kv(key_states, self.num_key_value_groups)
    value_states = repeat_kv(value_states, self.num_key_value_groups)
    if not output_attentions:
        attn_output = torch.nn.functional.scaled_dot_product_attention(
            query_states, key_states, value_states, attention_mask, scale=(1 / math.sqrt(self.head_dim))
        )
        attn_weights = None
    else:
        attn_weights = torch.matmul(query_states, key_states.transpose(2, 3)) / math.sqrt(self.head_dim)
        attn_weights = torch.nn.functional.softmax(attn_weights, dim=-1, dtype=torch.float32).to(query_states.dtype)
        attn_output = torch.matmul(attn_weights, value_states)

    attn_output = attn_output.transpose(1, 2).contiguous()
    attn_output = attn_output.reshape(bsz, q_len, self.hidden_size)

    attn_output = self.wo(attn_output)

    return attn_output, attn_weights, past_key_value


class InternLM2Patcher(OVDecoderModelPatcher):
    def __enter__(self):
        super().__enter__()

        if is_torch_version(">=", "2.1.0"):
            for block in self._model.model.layers:
                block.attention._orig_forward = block.attention.forward
                block.attention.forward = types.MethodType(_internlm2_attention_forward, block.attention)

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)
        for block in self._model.model.layers:
            if hasattr(block.attention, "_orig_forward"):
                block.attention.forward = block.attention._orig_forward


# Adapted from https://github.com/huggingface/transformers/blob/ccdabc5642bf84849af93f591e207dc625c8e1e1/src/transformers/models/phi3/modeling_phi3.py#L729
def _phi3_self_attn_sdpa_forward(
    self,
    hidden_states: torch.Tensor,
    attention_mask: Optional[torch.Tensor] = None,
    position_ids: Optional[torch.LongTensor] = None,
    past_key_value: Optional[Tuple[torch.Tensor]] = None,
    output_attentions: bool = False,
    use_cache: bool = False,
    cache_position: Optional[torch.LongTensor] = None,
) -> Tuple[torch.Tensor, Optional[torch.Tensor], Optional[Tuple[torch.Tensor]]]:
    if output_attentions:
        return self._orig_forward(
            hidden_states=hidden_states,
            attention_mask=attention_mask,
            position_ids=position_ids,
            past_key_value=past_key_value,
            output_attentions=output_attentions,
            use_cache=use_cache,
        )

    bsz, q_len, _ = hidden_states.size()

    qkv = self.qkv_proj(hidden_states)
    query_pos = self.num_heads * self.head_dim
    query_states = qkv[..., :query_pos]
    key_states = qkv[..., query_pos : query_pos + self.num_key_value_heads * self.head_dim]
    value_states = qkv[..., query_pos + self.num_key_value_heads * self.head_dim :]

    query_states = query_states.view(bsz, q_len, self.num_heads, self.head_dim).transpose(1, 2)
    key_states = key_states.view(bsz, q_len, self.num_key_value_heads, self.head_dim).transpose(1, 2)
    value_states = value_states.view(bsz, q_len, self.num_key_value_heads, self.head_dim).transpose(1, 2)
    kv_seq_len = key_states.shape[-2]
    if past_key_value is not None:
        kv_seq_len += past_key_value.get_usable_length(kv_seq_len, self.layer_idx)
    cos, sin = self.rotary_emb(value_states, position_ids, seq_len=kv_seq_len)

    query_states, key_states = apply_rotary_pos_emb(query_states, key_states, cos, sin, position_ids)

    if past_key_value is not None:
        cache_kwargs = {"sin": sin, "cos": cos}  # Specific to RoPE models
        key_states, value_states = past_key_value.update(key_states, value_states, self.layer_idx, cache_kwargs)

    key_states = repeat_kv(key_states, self.num_key_value_groups)
    value_states = repeat_kv(value_states, self.num_key_value_groups)

    causal_mask = attention_mask
    if attention_mask is not None:
        causal_mask = attention_mask[:, :, :, : key_states.shape[-2]]

    # SDPA with memory-efficient backend is currently (torch==2.1.2) bugged with non-contiguous inputs with custom attn_mask,
    # Reference: https://github.com/pytorch/pytorch/issues/112577.
    if query_states.device.type == "cuda" and attention_mask is not None:
        query_states = query_states.contiguous()
        key_states = key_states.contiguous()
        value_states = value_states.contiguous()

    attn_output = torch.nn.functional.scaled_dot_product_attention(
        query_states,
        key_states,
        value_states,
        attn_mask=causal_mask,
        dropout_p=self.attention_dropout if self.training else 0.0,
        # The q_len > 1 is necessary to match with AttentionMaskConverter.to_causal_4d that does not create a causal mask in case q_len == 1.
        is_causal=self.is_causal and attention_mask is None and q_len > 1,
    )

    attn_output = attn_output.transpose(1, 2).contiguous()
    attn_output = attn_output.view(bsz, q_len, self.hidden_size)

    attn_output = self.o_proj(attn_output)

    return attn_output, None, past_key_value


class Phi3ModelPatcher(OVDecoderModelPatcher):
    def __enter__(self):
        super().__enter__()

        # LongRoPE is handled via _longrope_forward in OVDecoderModelPatcher for both transformers >= 5 and < 5,
        # so keep the original max_position_embeddings to preserve the correct attention scaling factor.

        # https://github.com/huggingface/transformers/blob/30ee508c6c92a1c0aa0281d193c7c0fb815b8d2f/src/transformers/models/phi3/modeling_phi3.py#L113
        # init inv_freq for torchscript tracing
        # 4.48 transformers version phi3 fixed, but issue still visible with trust_remote_true=True (trust_remote_code has _support_sdpa = False)
        for layer in self._model.model.layers:
            if not getattr(self._model, "_supports_sdpa", False):
                orig_self_attn_fwd = layer.self_attn.forward
                layer.self_attn.forward = types.MethodType(_phi3_self_attn_sdpa_forward, layer.self_attn)
                layer.self_attn._orig_forward = orig_self_attn_fwd

            if (
                hasattr(layer.self_attn, "rotary_emb")
                and getattr(layer.self_attn.rotary_emb, "inv_freq", None) is None
            ):
                rotary_emb = layer.self_attn.rotary_emb
                layer.self_attn.rotary_emb.inv_freq = 1.0 / (
                    rotary_emb.base ** (torch.arange(0, rotary_emb.dim, 2, dtype=torch.int64).float() / rotary_emb.dim)
                )

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)
        if hasattr(self._model.model, "_orig_forward"):
            self._model.model.forward = self._model.model._orig_forward
        if hasattr(self._model.model, "_orig_update_causal_mask"):
            self._model.model._update_causal_mask = self._model.model._orig_update_causal_mask
        for layer in self._model.model.layers:
            if hasattr(layer.self_attn, "_orig_forward"):
                layer.self_attn.forward = layer.self_attn._orig_forward


# Modified from https://github.com/huggingface/transformers/blob/v4.50.2/src/transformers/models/phimoe/modeling_phimoe.py#L756
# removed usage nonfriendly for tracing operation continue
def _phi_moe_sparse_moe_block_forward(self, hidden_states: torch.Tensor) -> torch.Tensor:
    from transformers.models.phimoe.modeling_phimoe import sparsemixer

    batch_size, sequence_length, hidden_dim = hidden_states.shape
    if self.training and self.input_jitter_noise > 0:
        hidden_states *= torch.empty_like(hidden_states).uniform_(
            1.0 - self.input_jitter_noise, 1.0 + self.input_jitter_noise
        )
    hidden_states = hidden_states.view(-1, hidden_dim)
    router_logits = self.gate(hidden_states)

    routing_weights, selected_experts = sparsemixer(
        router_logits,
        jitter_eps=self.router_jitter_noise,
        training=self.training,
    )

    final_hidden_states = torch.zeros(
        (batch_size * sequence_length, hidden_dim), dtype=hidden_states.dtype, device=hidden_states.device
    )

    # One hot encode the selected experts to create an expert mask
    # this will be used to easily index which expert is going to be sollicitated
    expert_mask = torch.nn.functional.one_hot(selected_experts, num_classes=self.num_experts).permute(2, 1, 0)

    # Loop over all available experts in the model and perform the computation on each expert
    for expert_idx in range(self.num_experts):
        expert_layer = self.experts[expert_idx]
        idx, top_x = torch.where(expert_mask[expert_idx])

        # if top_x.shape[0] == 0:
        #     continue

        # Index the correct hidden states and compute the expert hidden state for
        # the current expert. We need to make sure to multiply the output hidden
        # states by `routing_weights` on the corresponding tokens (top-1 and top-2)
        current_state = hidden_states[None, top_x].reshape(-1, hidden_dim)
        current_hidden_states = expert_layer(current_state) * routing_weights[top_x, idx, None]

        # However `index_add_` only support torch tensors for indexing so we'll use
        # the `top_x` tensor here.
        final_hidden_states.index_add_(0, top_x, current_hidden_states.to(hidden_states.dtype))
    final_hidden_states = final_hidden_states.reshape(batch_size, sequence_length, hidden_dim)
    return final_hidden_states, router_logits


class PhiMoEModelPatcher(Phi3ModelPatcher):
    def __enter__(self):
        super().__enter__()

        if is_transformers_version("<", "5"):
            for layer in self._model.model.layers:
                layer.block_sparse_moe._orig_forward = layer.block_sparse_moe.forward
                layer.block_sparse_moe.forward = types.MethodType(
                    _phi_moe_sparse_moe_block_forward, layer.block_sparse_moe
                )
        else:
            from transformers.models.phimoe.modeling_phimoe import PhimoeExperts

            self.original_moe_forward = PhimoeExperts.forward
            PhimoeExperts.forward = lfm2_moe_experts_forward

        # fixed in https://github.com/huggingface/transformers/pull/43445, still needed for v5.0
        if is_transformers_version("==", "5.0"):
            self._model.model.rotary_emb.short_mscale = self._model.model.rotary_emb.config.rope_parameters.get(
                "short_mscale", None
            )
            self._model.model.rotary_emb.long_mscale = self._model.model.rotary_emb.config.rope_parameters.get(
                "long_mscale", None
            )

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)

        if is_transformers_version("<", "5"):
            for layer in self._model.model.layers:
                layer.block_sparse_moe.forward = layer.block_sparse_moe._orig_forward
        else:
            from transformers.models.phimoe.modeling_phimoe import PhimoeExperts

            PhimoeExperts.forward = self.original_moe_forward


def _aquila_self_attn_sdpa_forward(
    self,
    hidden_states: torch.Tensor,
    attention_mask: Optional[torch.Tensor] = None,
    position_ids: Optional[torch.LongTensor] = None,
    past_key_value: Optional[Tuple[torch.Tensor]] = None,
    output_attentions: bool = False,
    use_cache: bool = False,
) -> Tuple[torch.Tensor, Optional[torch.Tensor], Optional[Tuple[torch.Tensor]]]:
    def repeat_kv(hidden_states: torch.Tensor, n_rep: int) -> torch.Tensor:
        """
        This is the equivalent of torch.repeat_interleave(x, dim=1, repeats=n_rep). The hidden states go from (batch,
        num_key_value_heads, seqlen, head_dim) to (batch, num_attention_heads, seqlen, head_dim)
        """
        batch, num_key_value_heads, slen, head_dim = hidden_states.shape
        if n_rep == 1:
            return hidden_states
        hidden_states = hidden_states[:, :, None, :, :].expand(batch, num_key_value_heads, n_rep, slen, head_dim)
        return hidden_states.reshape(batch, num_key_value_heads * n_rep, slen, head_dim)

    def rotate_half(x):
        """Rotates half the hidden dims of the input."""
        x1 = x[..., : x.shape[-1] // 2]
        x2 = x[..., x.shape[-1] // 2 :]
        return torch.cat((-x2, x1), dim=-1)

    def apply_rotary_pos_emb(q, k, cos, sin, position_ids):
        # The first two dimensions of cos and sin are always 1, so we can `squeeze` them.
        cos = cos.squeeze(1).squeeze(0)  # [seq_len, dim]
        sin = sin.squeeze(1).squeeze(0)  # [seq_len, dim]
        cos = cos[position_ids].unsqueeze(1)  # [bs, 1, seq_len, dim]
        sin = sin[position_ids].unsqueeze(1)  # [bs, 1, seq_len, dim]
        q_embed = (q * cos) + (rotate_half(q) * sin)
        k_embed = (k * cos) + (rotate_half(k) * sin)
        return q_embed, k_embed

    if output_attentions:
        return self._orig_forward(
            hidden_states, attention_mask, position_ids, past_key_value, output_attentions, use_cache
        )
    bsz, q_len, _ = hidden_states.size()

    if hasattr(self.config, "pretraining_tp") and self.config.pretraining_tp > 1:
        key_value_slicing = (self.num_key_value_heads * self.head_dim) // self.config.pretraining_tp
        query_slices = self.q_proj.weight.split((self.num_heads * self.head_dim) // self.config.pretraining_tp, dim=0)
        key_slices = self.k_proj.weight.split(key_value_slicing, dim=0)
        value_slices = self.v_proj.weight.split(key_value_slicing, dim=0)

        query_states = [F.linear(hidden_states, query_slices[i]) for i in range(self.config.pretraining_tp)]
        query_states = torch.cat(query_states, dim=-1)

        key_states = [F.linear(hidden_states, key_slices[i]) for i in range(self.config.pretraining_tp)]
        key_states = torch.cat(key_states, dim=-1)

        value_states = [F.linear(hidden_states, value_slices[i]) for i in range(self.config.pretraining_tp)]
        value_states = torch.cat(value_states, dim=-1)

    else:
        query_states = self.q_proj(hidden_states)
        key_states = self.k_proj(hidden_states)
        value_states = self.v_proj(hidden_states)

    query_states = query_states.view(bsz, q_len, self.num_heads, self.head_dim).transpose(1, 2)
    key_states = key_states.view(
        bsz, q_len, getattr(self, "num_key_value_heads", self.num_heads), self.head_dim
    ).transpose(1, 2)
    value_states = value_states.view(
        bsz, q_len, getattr(self, "num_key_value_heads", self.num_heads), self.head_dim
    ).transpose(1, 2)

    kv_seq_len = key_states.shape[-2]
    if past_key_value is not None:
        kv_seq_len += past_key_value[0].shape[-2]
    cos, sin = self.rotary_emb(value_states, seq_len=kv_seq_len)
    query_states, key_states = apply_rotary_pos_emb(query_states, key_states, cos, sin, position_ids)

    if past_key_value is not None:
        # reuse k, v, self_attention
        key_states = torch.cat([past_key_value[0], key_states], dim=2)
        value_states = torch.cat([past_key_value[1], value_states], dim=2)

    past_key_value = (key_states, value_states) if use_cache else None

    if hasattr(self, "num_key_value_groups"):
        # repeat k/v heads if n_kv_heads < n_heads
        key_states = repeat_kv(key_states, self.num_key_value_groups)
        value_states = repeat_kv(value_states, self.num_key_value_groups)

    attn_output = torch.nn.functional.scaled_dot_product_attention(
        query_states, key_states, value_states, attention_mask, scale=(1 / math.sqrt(self.head_dim))
    )
    attn_weights = None

    attn_output = attn_output.transpose(1, 2).contiguous()
    attn_output = attn_output.reshape(bsz, q_len, self.hidden_size)

    if hasattr(self.config, "pretraining_tp") and self.config.pretraining_tp > 1:
        attn_output = attn_output.split(self.hidden_size // self.config.pretraining_tp, dim=2)
        o_proj_slices = self.o_proj.weight.split(self.hidden_size // self.config.pretraining_tp, dim=1)
        attn_output = sum([F.linear(attn_output[i], o_proj_slices[i]) for i in range(self.config.pretraining_tp)])
    else:
        attn_output = self.o_proj(attn_output)

    return attn_output, attn_weights, past_key_value


class AquilaModelPatcher(OVDecoderModelPatcher):
    def __enter__(self):
        super().__enter__()
        for layer in self._model.model.layers:
            if is_torch_version(">=", "2.1.0"):
                orig_self_attn_fwd = layer.self_attn.forward
                layer.self_attn.forward = types.MethodType(_aquila_self_attn_sdpa_forward, layer.self_attn)
                layer.self_attn._orig_forward = orig_self_attn_fwd

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)
        for layer in self._model.model.layers:
            if hasattr(layer.self_attn, "_orig_forward"):
                layer.self_attn.forward = layer.self_attn._orig_forward


def _xverse_self_attn_sdpa_forward(
    self,
    hidden_states: torch.Tensor,
    attention_mask: Optional[torch.Tensor] = None,
    position_ids: Optional[torch.LongTensor] = None,
    past_key_value: Optional[Tuple[torch.Tensor]] = None,
    output_attentions: bool = False,
    use_cache: bool = False,
) -> Tuple[torch.Tensor, Optional[torch.Tensor], Optional[Tuple[torch.Tensor]]]:
    def rotate_half(x):
        """Rotates half the hidden dims of the input."""
        x1 = x[..., : x.shape[-1] // 2]
        x2 = x[..., x.shape[-1] // 2 :]
        return torch.cat((-x2, x1), dim=-1)

    def apply_rotary_pos_emb(q, k, cos, sin, position_ids):
        # The first two dimensions of cos and sin are always 1, so we can `squeeze` them.
        cos = cos.squeeze(1).squeeze(0)  # [seq_len, dim]
        sin = sin.squeeze(1).squeeze(0)  # [seq_len, dim]
        cos = cos[position_ids].unsqueeze(1)  # [bs, 1, seq_len, dim]
        sin = sin[position_ids].unsqueeze(1)  # [bs, 1, seq_len, dim]
        q_embed = (q * cos) + (rotate_half(q) * sin)
        k_embed = (k * cos) + (rotate_half(k) * sin)
        return q_embed, k_embed

    if output_attentions:
        return self._orig_forward(
            hidden_states, attention_mask, position_ids, past_key_value, output_attentions, use_cache
        )
    bsz, q_len, _ = hidden_states.size()

    query_states = self.q_proj(hidden_states).view(bsz, q_len, self.num_heads, self.head_dim).transpose(1, 2)
    key_states = self.k_proj(hidden_states).view(bsz, q_len, self.num_heads, self.head_dim).transpose(1, 2)
    value_states = self.v_proj(hidden_states).view(bsz, q_len, self.num_heads, self.head_dim).transpose(1, 2)

    kv_seq_len = key_states.shape[-2]
    if past_key_value is not None:
        kv_seq_len += past_key_value[0].shape[-2]
    cos, sin = self.rotary_emb(value_states, seq_len=kv_seq_len)
    query_states, key_states = apply_rotary_pos_emb(query_states, key_states, cos, sin, position_ids)
    # [bsz, nh, t, hd]

    if past_key_value is not None:
        # reuse k, v, self_attention
        key_states = torch.cat([past_key_value[0], key_states], dim=2)
        value_states = torch.cat([past_key_value[1], value_states], dim=2)

    past_key_value = (key_states, value_states) if use_cache else None

    attn_output = torch.nn.functional.scaled_dot_product_attention(
        query_states, key_states, value_states, attention_mask, scale=(1 / math.sqrt(self.head_dim))
    )
    attn_weights = None

    attn_output = attn_output.transpose(1, 2).contiguous()
    attn_output = attn_output.reshape(bsz, q_len, self.hidden_size)

    attn_output = self.o_proj(attn_output)

    return attn_output, attn_weights, past_key_value


def _internlm_self_attn_sdpa_forward(
    self,
    hidden_states: torch.Tensor,
    attention_mask: Optional[torch.Tensor] = None,
    position_ids: Optional[torch.LongTensor] = None,
    past_key_value: Optional[Tuple[torch.Tensor]] = None,
    output_attentions: bool = False,
    use_cache: bool = False,
) -> Tuple[torch.Tensor, Optional[torch.Tensor], Optional[Tuple[torch.Tensor]]]:
    def rotate_half(x):
        """Rotates half the hidden dims of the input."""
        x1 = x[..., : x.shape[-1] // 2]
        x2 = x[..., x.shape[-1] // 2 :]
        return torch.cat((-x2, x1), dim=-1)

    def apply_rotary_pos_emb(q, k, cos, sin, position_ids):
        cos = cos[position_ids].unsqueeze(1)
        sin = sin[position_ids].unsqueeze(1)
        q_embed = (q * cos) + (rotate_half(q) * sin)
        k_embed = (k * cos) + (rotate_half(k) * sin)
        return q_embed, k_embed

    if output_attentions:
        return self._orig_forward(
            hidden_states, attention_mask, position_ids, past_key_value, output_attentions, use_cache
        )

    bsz, q_len, _ = hidden_states.size()
    query_states = self.q_proj(hidden_states).view(bsz, q_len, self.num_heads, self.head_dim).transpose(1, 2)
    key_states = self.k_proj(hidden_states).view(bsz, q_len, self.num_heads, self.head_dim).transpose(1, 2)
    value_states = self.v_proj(hidden_states).view(bsz, q_len, self.num_heads, self.head_dim).transpose(1, 2)
    kv_seq_len = key_states.shape[-2]
    if past_key_value is not None:
        kv_seq_len += past_key_value[0].shape[-2]

    cos, sin = self.rotary_emb(value_states, seq_len=kv_seq_len)
    query_states, key_states = apply_rotary_pos_emb(query_states, key_states, cos, sin, position_ids)

    if past_key_value is not None:
        # reuse k, v, self_attention
        key_states = torch.cat([past_key_value[0], key_states], dim=2)
        value_states = torch.cat([past_key_value[1], value_states], dim=2)

    past_key_value = (key_states, value_states) if use_cache else None

    attn_output = torch.nn.functional.scaled_dot_product_attention(
        query_states, key_states, value_states, attention_mask, scale=(1 / math.sqrt(self.head_dim))
    )
    attn_weights = None

    attn_output = attn_output.transpose(1, 2)
    attn_output = attn_output.reshape(bsz, q_len, self.hidden_size)

    attn_output = self.o_proj(attn_output)
    return attn_output, attn_weights, past_key_value


class XverseModelPatcher(OVDecoderModelPatcher):
    def __enter__(self):
        super().__enter__()
        for layer in self._model.model.layers:
            if is_torch_version(">=", "2.1.0"):
                orig_self_attn_fwd = layer.self_attn.forward
                layer.self_attn.forward = types.MethodType(_xverse_self_attn_sdpa_forward, layer.self_attn)
                layer.self_attn._orig_forward = orig_self_attn_fwd

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)
        for layer in self._model.model.layers:
            if hasattr(layer.self_attn, "_orig_forward"):
                layer.self_attn.forward = layer.self_attn._orig_forward


class InternLMModelPatcher(OVDecoderModelPatcher):
    def __enter__(self):
        super().__enter__()
        for layer in self._model.model.layers:
            if is_torch_version(">=", "2.1.0"):
                orig_self_attn_fwd = layer.self_attn.forward
                layer.self_attn.forward = types.MethodType(_internlm_self_attn_sdpa_forward, layer.self_attn)
                layer.self_attn._orig_forward = orig_self_attn_fwd

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)
        for layer in self._model.model.layers:
            if hasattr(layer.self_attn, "_orig_forward"):
                layer.self_attn.forward = layer.self_attn._orig_forward


# Adapted from https://github.com/huggingface/optimum/blob/3adbe7c75e3c41c1a3b945cf085e74ece7f8e192/optimum/bettertransformer/models/attention.py#L234
def codegen_wrapped_scaled_dot_product(
    self,
    query: torch.Tensor,
    key: torch.Tensor,
    value: torch.Tensor,
    attention_mask: Optional[torch.Tensor] = None,
    head_mask: Optional[torch.Tensor] = None,
):
    batch_size = query.shape[0]
    mask_value = torch.finfo(value.dtype).min
    mask_value = torch.full([], mask_value, dtype=value.dtype)

    # in codegen the query and key are always in fp32 regardless of the dtype of the model
    # https://github.com/huggingface/transformers/blob/5b28b7833297adf65c5160a685425ddb1eee5ce2/src/transformers/models/codegen/modeling_codegen.py#L226
    query = query.to(value.dtype)
    key = key.to(value.dtype)

    dropout_p = self.dropout_prob_attn if self.training else 0.0
    if batch_size == 1 or self.training:
        if query.shape[2] > 1:
            # first step of the decoding
            sdpa_result = torch.nn.functional.scaled_dot_product_attention(
                query, key, value, attn_mask=None, dropout_p=dropout_p, is_causal=True
            )
        else:
            # in this case, which is the later decoding steps, the `causal_mask` in
            # https://github.com/huggingface/transformers/blob/ae54e3c3b18bac0832ad62ea9b896dfd52a09850/src/transformers/models/gpt2/modeling_gpt2.py#L195
            # is [True, ..., True] so actually not causal
            sdpa_result = torch.nn.functional.scaled_dot_product_attention(
                query, key, value, attn_mask=None, dropout_p=dropout_p, is_causal=False
            )
    else:
        query_length = query.size(-2)
        # causal_mask is always [True, ..., True] otherwise, so executing this
        # is unnecessary
        if query_length > 1:
            attention_mask = attention_mask[:, :, :, : key.shape[-2]]

        sdpa_result = torch.nn.functional.scaled_dot_product_attention(
            query, key, value, attn_mask=attention_mask, dropout_p=dropout_p, is_causal=False
        )

    return sdpa_result, None


# copied from  https://github.com/huggingface/optimum/blob/2112e99122d7f23a1da1a9d263fef64301050ea7/optimum/bettertransformer/models/attention.py#L168
# for preserving backward compatibility between outdated codegen remote code and new transformers
def _codegen_wrapped_scaled_dot_product_legacy(
    self,
    query: torch.Tensor,
    key: torch.Tensor,
    value: torch.Tensor,
    attention_mask: Optional[torch.Tensor] = None,
    head_mask: Optional[torch.Tensor] = None,
):
    if head_mask is not None:
        raise ValueError("`head_mask` input argument is not supported")
    batch_size = query.shape[0]
    mask_value = torch.finfo(value.dtype).min
    mask_value = torch.full([], mask_value, dtype=value.dtype)

    if batch_size == 1 and attention_mask is not None and attention_mask[0, 0, -1, -1] < -1:
        raise ValueError("BetterTransformer does not support padding='max_length' with a batch size of 1.")

    # in codegen the query and key are always in fp32 regardless of the dtype of the model
    # https://github.com/huggingface/transformers/blob/5b28b7833297adf65c5160a685425ddb1eee5ce2/src/transformers/models/codegen/modeling_codegen.py#L226
    query = query.to(value.dtype)
    key = key.to(value.dtype)

    dropout_p = self.dropout_prob_attn if self.training else 0.0
    if batch_size == 1 or self.training:
        if query.shape[2] > 1:
            # first step of the decoding
            sdpa_result = torch.nn.functional.scaled_dot_product_attention(
                query, key, value, attn_mask=None, dropout_p=dropout_p, is_causal=True
            )
        else:
            # in this case, which is the later decoding steps, the `causal_mask`` in
            # https://github.com/huggingface/transformers/blob/ae54e3c3b18bac0832ad62ea9b896dfd52a09850/src/transformers/models/gpt2/modeling_gpt2.py#L195
            # is [True, ..., True] so actually not causal
            sdpa_result = torch.nn.functional.scaled_dot_product_attention(
                query, key, value, attn_mask=None, dropout_p=dropout_p, is_causal=False
            )
    else:
        query_length, key_length = query.size(-2), key.size(-2)

        # causal_mask is always [True, ..., True] otherwise, so executing this is unnecessary
        if query_length > 1:
            causal_mask = self.causal_mask[:, :, key_length - query_length : key_length, :key_length].to(torch.bool)

            causal_mask = torch.where(causal_mask, 0, mask_value)

            # torch.Tensor.expand does no memory copy
            causal_mask = causal_mask.expand(batch_size, -1, -1, -1)

            # we use torch.min to avoid having tensor(-inf)
            attention_mask = torch.min(causal_mask, attention_mask)

        sdpa_result = torch.nn.functional.scaled_dot_product_attention(
            query, key, value, attn_mask=attention_mask, dropout_p=dropout_p, is_causal=False
        )

    return sdpa_result, None


class CodeGenModelPatcher(OVDecoderModelPatcher):
    def __enter__(self):
        super().__enter__()

        # TODO: why is this needed again ? it's too convoluted
        attn_fn = codegen_wrapped_scaled_dot_product
        if is_torch_version(">=", "2.1.0"):
            # in transformers 4.45 causal_mask const buffer was removed from the model
            # if it still exists, it means legacy remote code was loaded
            if hasattr(self._model.transformer.h[0].attn, "causal_mask"):
                attn_fn = _codegen_wrapped_scaled_dot_product_legacy

        for layer in self._model.transformer.h:
            if is_torch_version(">=", "2.1.0") and not self._model.config.output_attentions:
                orig_self_attn_fwd = layer.attn._attn
                layer.attn._attn = types.MethodType(attn_fn, layer.attn)
                layer.attn._orig_attn = orig_self_attn_fwd

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)

        for layer in self._model.transformer.h:
            if hasattr(layer.attn, "_orig_attn"):
                layer.attn._attn = layer.attn._orig_attn


# Adapted from https://github.com/huggingface/transformers/blob/v4.40.2/src/transformers/models/dbrx/modeling_dbrx.py#L763
def _dbrx_experts_forward(
    self, x: torch.Tensor, weights: torch.Tensor, top_weights: torch.Tensor, top_experts: torch.LongTensor
):
    bsz, q_len, hidden_size = x.shape
    x = x.view(-1, hidden_size)
    out = torch.zeros_like(x)

    expert_mask = torch.nn.functional.one_hot(top_experts, num_classes=self.moe_num_experts).permute(2, 1, 0)
    # Chunk experts at once to avoid storing full parameter multiple times in autograd
    w1_chunked = self.mlp.w1.view(self.mlp.moe_num_experts, self.mlp.ffn_hidden_size, self.mlp.hidden_size).chunk(
        self.moe_num_experts, dim=0
    )
    v1_chunked = self.mlp.v1.view(self.mlp.moe_num_experts, self.mlp.ffn_hidden_size, self.mlp.hidden_size).chunk(
        self.moe_num_experts, dim=0
    )
    w2_chunked = self.mlp.w2.view(self.mlp.moe_num_experts, self.mlp.ffn_hidden_size, self.mlp.hidden_size).chunk(
        self.moe_num_experts, dim=0
    )
    w1_chunked = [w1.squeeze(dim=0) for w1 in w1_chunked]
    v1_chunked = [v1.squeeze(dim=0) for v1 in v1_chunked]
    w2_chunked = [w2.squeeze(dim=0) for w2 in w2_chunked]
    for expert_idx in range(0, self.moe_num_experts):
        topk_idx, token_idx = torch.where(expert_mask[expert_idx])

        # Difference with original: removal
        # if token_idx.shape[0] == 0:
        #     continue
        # loop interruption depends on input data and may affect torchscript tracing

        token_list = token_idx
        topk_list = topk_idx

        expert_tokens = x[None, token_list].reshape(-1, hidden_size)
        expert_out = (
            self.mlp(expert_tokens, w1_chunked[expert_idx], v1_chunked[expert_idx], w2_chunked[expert_idx])
            * top_weights[token_list, topk_list, None]
        )

        out.index_add_(0, token_idx, expert_out)

    out = out.reshape(bsz, q_len, hidden_size)
    return out


# adopted from https://github.com/huggingface/transformers/blob/1b3dba9417eebe16b7c206d1dfca6a4c7f11dbec/src/transformers/models/dbrx/modeling_dbrx.py#L1204
def _dbrx_update_causal_mask(
    self,
    attention_mask: torch.Tensor,
    input_tensor: torch.Tensor,
    cache_position: torch.Tensor,
    past_key_values: "Cache",
    output_attentions: bool,
):
    from transformers.cache_utils import StaticCache
    from transformers.modeling_attn_mask_utils import AttentionMaskConverter

    # TODO: As of torch==2.2.0, the `attention_mask` passed to the model in `generate` is 2D and of dynamic length even when the static
    # KV cache is used. This is an issue for torch.compile which then recaptures cudagraphs at each decode steps due to the dynamic shapes.
    # (`recording cudagraph tree for symint key 13`, etc.), which is VERY slow. A workaround is `@torch.compiler.disable`, but this prevents using
    # `fullgraph=True`. See more context in https://github.com/huggingface/transformers/pull/29114

    if self.config._attn_implementation == "flash_attention_2":
        if attention_mask is not None and 0.0 in attention_mask:
            return attention_mask
        return None

    # For SDPA, when possible, we will rely on its `is_causal` argument instead of its `attn_mask` argument, in
    # order to dispatch on Flash Attention 2. This feature is not compatible with static cache, as SDPA will fail
    # to infer the attention mask.
    past_seen_tokens = past_key_values.get_seq_length() if past_key_values is not None else 0
    using_static_cache = isinstance(past_key_values, StaticCache)

    # When output attentions is True, sdpa implementation's forward method calls the eager implementation's forward
    if self.config._attn_implementation == "sdpa" and not using_static_cache and not output_attentions:
        if AttentionMaskConverter._ignore_causal_mask_sdpa(
            attention_mask,
            inputs_embeds=input_tensor,
            past_key_values_length=past_seen_tokens,
            is_training=self.training,
        ):
            return None

    dtype, device = input_tensor.dtype, input_tensor.device
    # difference with original modeling
    # using minimum from dtype with larger bandwidth (float32) may lead to overflow
    # during execution on platforms with default lower precision (bfloat16, float16)
    min_dtype = torch.finfo(torch.float16).min
    sequence_length = input_tensor.shape[1]
    if using_static_cache:
        target_length = past_key_values.get_max_length()
    else:
        target_length = (
            attention_mask.shape[-1]
            if isinstance(attention_mask, torch.Tensor)
            else past_seen_tokens + sequence_length + 1
        )

    if attention_mask is not None and attention_mask.dim() == 4:
        # in this case we assume that the mask comes already in inverted form and requires no inversion or slicing
        if attention_mask.max() != 0:
            raise ValueError("Custom 4D attention mask should be passed in inverted form with max==0`")
        causal_mask = attention_mask
    else:
        # difference with original modeling
        causal_mask = (
            torch.full((sequence_length, target_length), fill_value=1, dtype=dtype, device=device) * min_dtype
        )
        if sequence_length != 1:
            causal_mask = torch.triu(causal_mask, diagonal=1)
        causal_mask *= torch.arange(target_length, device=device) > cache_position.reshape(-1, 1)
        causal_mask = causal_mask[None, None, :, :].expand(input_tensor.shape[0], 1, -1, -1)
        if attention_mask is not None:
            causal_mask = causal_mask.clone()  # copy to contiguous memory for in-place edit
            mask_length = attention_mask.shape[-1]
            padding_mask = causal_mask[:, :, :, :mask_length] + attention_mask[:, None, None, :]
            padding_mask = padding_mask == 0
            causal_mask[:, :, :, :mask_length] = causal_mask[:, :, :, :mask_length].masked_fill(
                padding_mask, min_dtype
            )
    if (
        self.config._attn_implementation == "sdpa"
        and attention_mask is not None
        and attention_mask.device.type == "cuda"
        and not output_attentions
    ):
        # Attend to all tokens in fully masked rows in the causal_mask, for example the relevant first rows when
        # using left padding. This is required by F.scaled_dot_product_attention memory-efficient attention path.
        # Details: https://github.com/pytorch/pytorch/issues/110213
        causal_mask = AttentionMaskConverter._unmask_unattended(causal_mask, min_dtype)

    return causal_mask


class DBRXModelPatcher(OVDecoderModelPatcher):
    def __enter__(self):
        super().__enter__()
        # dbrx has some accuracy issues with bf16 with transformers >= 4.40
        # fill causal mask in slightly different way for avoid overflow on some platforms
        self._model.transformer._orig_update_causal_mask = self._model.transformer._update_causal_mask
        self._model.transformer._update_causal_mask = types.MethodType(
            _dbrx_update_causal_mask, self._model.transformer
        )

        inv_freq = getattr(self._model.transformer.blocks[0].norm_attn_norm.attn.rotary_emb, "inv_freq")
        dim, base = None, None
        if inv_freq is None:
            dim = self._model.transformer.blocks[0].norm_attn_norm.attn.rotary_emb.dim
            base = self._model.transformer.blocks[0].norm_attn_norm.attn.rotary_emb.base
        max_positions = self._model.config.max_seq_len
        embed_positions = create_sinusoidal_positions(max_positions, dim, base, inv_freq)

        for block in self._model.transformer.blocks:
            rotary_emb = block.norm_attn_norm.attn.rotary_emb
            # initialize inv_freq for torchscript tracing
            if rotary_emb.inv_freq is None:
                inv_freq = 1.0 / (
                    rotary_emb.base ** (torch.arange(0, rotary_emb.dim, 2, dtype=torch.int64).float() / rotary_emb.dim)
                )
                rotary_emb.inv_freq = inv_freq

            rotary_emb.register_buffer("embed_positions", embed_positions)
            rotary_emb._orig_forward = rotary_emb.forward
            rotary_emb.forward = types.MethodType(llama_gemma_rotary_emb_forward, rotary_emb)

            # remove continue-operator from iteration loop over experts
            block.ffn.experts._orig_forward = block.ffn.experts.forward
            block.ffn.experts.forward = types.MethodType(_dbrx_experts_forward, block.ffn.experts)

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)
        self._model.transformer._update_causal_mask = self._model.transformer._orig_update_causal_mask
        for block in self._model.transformer.blocks:
            block.ffn.experts.forward = block.ffn.experts._orig_forward

            if hasattr(block.norm_attn_norm.attn.rotary_emb, "_orig_forward"):
                block.norm_attn_norm.attn.rotary_emb.forward = block.norm_attn_norm.attn.rotary_emb._orig_forward


def _jais_attn_forward(
    self,
    hidden_states: Optional[Tuple[torch.FloatTensor]],
    layer_past: Optional[Tuple[torch.Tensor]] = None,
    attention_mask: Optional[torch.FloatTensor] = None,
    head_mask: Optional[torch.FloatTensor] = None,
    encoder_hidden_states: Optional[torch.Tensor] = None,
    encoder_attention_mask: Optional[torch.FloatTensor] = None,
    use_cache: Optional[bool] = False,
    output_attentions: Optional[bool] = False,
    position_bias: Optional[torch.FloatTensor] = None,
) -> Tuple[Union[torch.Tensor, Tuple[torch.Tensor]], ...]:
    if encoder_hidden_states is not None:
        if not hasattr(self, "q_attn"):
            raise ValueError(
                "If class is used as cross attention, the weights `q_attn` have to be defined. "
                "Please make sure to instantiate class with `JAISAttention(..., is_cross_attention=True)`."
            )

        query = self.q_attn(hidden_states)
        key, value = self.c_attn(encoder_hidden_states).split(self.split_size, dim=2)
        attention_mask = encoder_attention_mask
    else:
        query, key, value = self.c_attn(hidden_states).split(self.split_size, dim=2)

    query = self._split_heads(query, self.num_heads, self.head_dim)
    key = self._split_heads(key, self.num_heads, self.head_dim)
    value = self._split_heads(value, self.num_heads, self.head_dim)

    if layer_past is not None:
        past_key, past_value = layer_past
        key = torch.cat((past_key, key), dim=-2)
        value = torch.cat((past_value, value), dim=-2)

    if use_cache is True:
        present = (key, value)
    else:
        present = None

    if self.reorder_and_upcast_attn:
        attn_output, attn_weights = self._upcast_and_reordered_attn(
            query, key, value, attention_mask, head_mask, position_bias
        )
    else:
        # Difference with original: override attn realization with sdpa if not output_attentions
        if not output_attentions:
            attn_output, attn_weights = self._attn(query, key, value, attention_mask, head_mask, position_bias)
        else:
            attn_output, attn_weights = self._orig_attn(query, key, value, attention_mask, head_mask, position_bias)

    attn_output = self._merge_heads(attn_output, self.num_heads, self.head_dim)
    attn_output = self.c_proj(attn_output)
    attn_output = self.resid_dropout(attn_output)

    outputs = (attn_output, present)
    if output_attentions:
        outputs += (attn_weights,)

    return outputs


def _jais_attn(self, query, key, value, attention_mask=None, head_mask=None, position_bias=None):
    scale = 1.0
    if self.scale_attn_weights:
        scale = 1 / self.head_dim**self.attn_scale_power

    # Layer-wise attention scaling
    if self.scale_attn_by_inverse_layer_idx:
        scale = scale / float(self.layer_idx + 1)

    query_length = query.size(-2)
    attention_mask_sdpa = torch.ones(
        (query.shape[0], query.shape[1], query.shape[2], key.shape[2]),
        dtype=query.dtype,
    )

    if not self.is_cross_attention:
        # if only "normal" attention layer implements causal mask
        query_length, key_length = query.size(-2), key.size(-2)
        causal_mask = self.bias[:, :, key_length - query_length : key_length, :key_length]
        mask_value = torch.finfo(torch.float16).min
        attention_mask_sdpa.masked_fill_(~causal_mask, mask_value)

    if attention_mask is not None:
        # Apply the attention mask
        attention_mask_sdpa = attention_mask_sdpa + attention_mask

    if position_bias is not None:
        attention_mask_sdpa += position_bias.type_as(attention_mask_sdpa).unsqueeze(0)

    # Mask heads if we want to
    if head_mask is not None:
        attention_mask_sdpa = attention_mask_sdpa * head_mask

    attn_output = F.scaled_dot_product_attention(
        query, key, value, attention_mask_sdpa, dropout_p=self.attn_dropout.p, scale=scale
    )

    return attn_output, None


class JaisModelPatcher(OVDecoderModelPatcher):
    def __enter__(self):
        super().__enter__()

        for layer in self._model.transformer.h:
            if is_torch_version(">=", "2.1.0"):
                orig_self_attn_fwd = layer.attn._attn
                layer.attn._attn = types.MethodType(_jais_attn, layer.attn)
                layer.attn._orig_attn = orig_self_attn_fwd
                layer.attn._orig_forward = layer.attn.forward
                layer.attn.forward = types.MethodType(_jais_attn_forward, layer.attn)

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)
        for layer in self._model.transformer.h:
            if hasattr(layer.attn, "_orig_attn"):
                layer.attn._attn = layer.attn._orig_attn
                layer.attn.forward = layer.attn._orig_forward


class FalconModelPatcher(OVDecoderModelPatcher):
    def __enter__(self):
        super().__enter__()
        patch_cos_sin_cached_fp32(self._model.transformer)

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)


# Adopted from https://github.com/huggingface/optimum/blob/v1.24.0/optimum/bettertransformer/models/attention.py#L96
def _gptj_attn(self, query, key, value, attention_mask=None, head_mask=None):
    if head_mask is not None:
        return self._orig_attn(query, key, value, attention_mask, head_mask)

    batch_size = query.shape[0]

    mask_value = torch.finfo(value.dtype).min
    mask_value = torch.full([], mask_value, dtype=value.dtype)

    # in gpt-neo-x and gpt-j the query and keys are always in fp32
    # thus we need to cast them to the value dtype
    if getattr(self, "downcast_qk", False):
        query = query.to(value.dtype)
        key = key.to(value.dtype)

    if batch_size == 1 and attention_mask is not None and attention_mask[0, 0, -1, -1] < -1:
        return self._orig_attn(query, key, value, attention_mask, head_mask)

    dropout_p = self.dropout_prob_attn if self.training else 0.0
    if batch_size == 1 or self.training:
        if query.shape[2] > 1:
            sdpa_result = torch.nn.functional.scaled_dot_product_attention(
                query, key, value, attn_mask=None, dropout_p=dropout_p, is_causal=True
            )
        else:
            sdpa_result = torch.nn.functional.scaled_dot_product_attention(
                query, key, value, attn_mask=None, dropout_p=dropout_p, is_causal=False
            )
    else:
        query_length = query.size(-2)
        # causal_mask is always [True, ..., True] otherwise, so executing this
        # is unnecessary
        if query_length > 1:
            attention_mask = attention_mask[:, :, :, : key.shape[-2]]

        sdpa_result = torch.nn.functional.scaled_dot_product_attention(
            query, key, value, attn_mask=attention_mask, dropout_p=dropout_p, is_causal=False
        )

    # in gpt-neo-x and gpt-j the query and keys are always in fp32
    # thus we need to cast them to the value dtype
    if getattr(self, "downcast_qk", False):
        sdpa_result = sdpa_result.to(value.dtype)

    return sdpa_result, None


def gptj_attn_forward(
    self,
    hidden_states: torch.FloatTensor,
    layer_past: Optional[Tuple[torch.FloatTensor, torch.FloatTensor]] = None,
    attention_mask: Optional[torch.FloatTensor] = None,
    position_ids: Optional[torch.LongTensor] = None,
    head_mask: Optional[torch.FloatTensor] = None,
    use_cache: Optional[bool] = False,
    output_attentions: Optional[bool] = False,
    cache_position: Optional[torch.LongTensor] = None,
):
    if output_attentions:
        self._attn = self._orig_attn

    kwargs = {}
    if is_transformers_version("<", "5"):
        kwargs["head_mask"] = head_mask

    return self._orig_forward(
        hidden_states,
        layer_past,
        attention_mask,
        position_ids,
        use_cache=use_cache,
        output_attentions=output_attentions,
        cache_position=cache_position,
        **kwargs,
    )


class GptJModelPatcher(OVDecoderModelPatcher):
    def __enter__(self):
        super().__enter__()

        self._model.config._orig_attn_implementation = self._model.config._attn_implementation
        self._model.config._attn_implementation = "sdpa"
        for block in self._model.transformer.h:
            block.attn._orig_forward = block.attn.forward
            block.attn.forward = types.MethodType(gptj_attn_forward, block.attn)
            block.attn._orig_attn = block.attn._attn
            block.attn._attn = types.MethodType(_gptj_attn, block.attn)

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)
        self._model.config._attn_implementation = self._model.config._orig_attn_implementation
        for block in self._model.transformer.h:
            block.attn.forward = block.attn._orig_forward
            block.attn._attn = block.attn._orig_attn


# Adopted from https://github.com/huggingface/optimum/blob/main/optimum/bettertransformer/models/attention.py#L721
def _bloom_attn_forward(
    self,
    hidden_states: torch.Tensor,
    residual: torch.Tensor,
    alibi: torch.Tensor,
    attention_mask: torch.Tensor,
    layer_past=None,
    use_cache: bool = False,
    output_attentions: bool = False,
    **kwargs,
):
    from transformers.models.bloom.modeling_bloom import dropout_add

    head_mask = kwargs.get("head_mask", None)
    if head_mask is not None or output_attentions:
        return self._orig_forward(
            hidden_states,
            residual,
            alibi,
            attention_mask,
            layer_past=layer_past,
            use_cache=use_cache,
            output_attentions=output_attentions,
            **kwargs,
        )
    batch_size, q_length, _ = hidden_states.shape
    # [batch_size, seq_length, 3 x hidden_size]
    fused_qkv = self.query_key_value(hidden_states)
    # 3 x [batch_size, num_heads, seq_length, head_dim]
    query_layer, key_layer, value_layer = self._reshape(fused_qkv)

    if layer_past is not None:
        cache_kwargs = {k: kwargs[k] for k in ("cache_position",) if k in kwargs}
        key_layer, value_layer = layer_past.update(key_layer, value_layer, self.layer_idx, cache_kwargs or None)

    alibi = alibi.reshape(batch_size, -1, *alibi.shape[1:])

    if attention_mask is not None:  # no matter the length, we just slice it
        kv_length = key_layer.shape[-2]
        causal_mask = attention_mask[:, :, :, :kv_length]
        alibi = torch.masked_fill(alibi, causal_mask.bool(), torch.finfo(alibi.dtype).min)

    context_layer = torch.nn.functional.scaled_dot_product_attention(
        query_layer,
        key_layer,
        value_layer,
        attn_mask=alibi,
        dropout_p=self.dropout_prob_attn if self.training else 0.0,
    )

    # Transform [batch_size, num_heads, seq_length, head_dim] to [batch_size, seq_length, num_heads * head_dim]
    context_layer = context_layer.transpose(1, 2)
    context_layer = context_layer.reshape(batch_size, q_length, self.hidden_size)

    # aggregate results across tp ranks. See here: https://github.com/pytorch/pytorch/issues/76232
    if self.pretraining_tp > 1 and self.slow_but_exact:
        slices = self.hidden_size / self.pretraining_tp
        output_tensor = torch.zeros_like(context_layer)
        for i in range(self.pretraining_tp):
            output_tensor = output_tensor + F.linear(
                context_layer[:, :, int(i * slices) : int((i + 1) * slices)],
                self.dense.weight[:, int(i * slices) : int((i + 1) * slices)],
            )
    else:
        output_tensor = self.dense(context_layer)

    output_tensor = dropout_add(output_tensor, residual, self.hidden_dropout, self.training)

    outputs = (output_tensor, layer_past)

    return outputs


class BloomModelPatcher(OVDecoderModelPatcher):
    def __enter__(self):
        super().__enter__()
        self._model.config._orig_attn_implementation = self._model.config._attn_implementation
        self._model.config._attn_implementation = "sdpa"
        for block in self._model.transformer.h:
            block.self_attention._orig_forward = block.self_attention.forward
            block.self_attention.forward = types.MethodType(_bloom_attn_forward, block.self_attention)

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)
        self._model.config._attn_implementation = self._model.config._orig_attn_implementation
        for block in self._model.transformer.h:
            block.self_attention.forward = block.self_attention._orig_forward


def _gpt_neo_attn_forward(
    self,
    hidden_states,
    attention_mask=None,
    layer_past=None,
    head_mask=None,
    use_cache=False,
    output_attentions=False,
    cache_position=None,
):
    if output_attentions:
        self._attn = self._orig_attn

    return self._orig_forward(
        hidden_states,
        attention_mask=attention_mask,
        layer_past=layer_past,
        head_mask=head_mask,
        use_cache=use_cache,
        output_attentions=output_attentions,
        cache_position=cache_position,
    )


# Adopted from https://github.com/huggingface/optimum/blob/main/optimum/bettertransformer/models/attention.py#L185
def _gpt_neo_attn_sdpa(
    self,
    query: torch.Tensor,
    key: torch.Tensor,
    value: torch.Tensor,
    attention_mask: Optional[torch.Tensor] = None,
    head_mask: Optional[torch.Tensor] = None,
):
    batch_size = query.shape[0]

    mask_value = torch.finfo(torch.float16).min
    mask_value = torch.full([], mask_value, dtype=value.dtype)

    dropout_p = float(self.config.attention_dropout) if self.training else 0.0
    if (batch_size == 1 or self.training) and self.attention_type == "global":
        if query.shape[2] > 1:
            sdpa_result = torch.nn.functional.scaled_dot_product_attention(
                query, key, value, attn_mask=None, dropout_p=dropout_p, is_causal=True
            )
        else:
            sdpa_result = torch.nn.functional.scaled_dot_product_attention(
                query, key, value, attn_mask=None, dropout_p=dropout_p, is_causal=False, scale=1.0
            )
    else:
        query_length, key_length = query.size(-2), key.size(-2)

        causal_mask = self.bias[:, :, key_length - query_length : key_length, :key_length]

        causal_mask = torch.where(causal_mask, 0, mask_value)
        if batch_size > 1:
            # torch.Tensor.expand does no memory copy
            causal_mask = causal_mask.expand(batch_size, -1, -1, -1)

        if attention_mask is not None:
            attention_mask = causal_mask + attention_mask

        sdpa_result = torch.nn.functional.scaled_dot_product_attention(
            query, key, value, attn_mask=attention_mask, dropout_p=dropout_p, is_causal=False, scale=1.0
        )

    return sdpa_result, None


class GptNeoModelPatcher(OVDecoderModelPatcher):
    def __enter__(self):
        super().__enter__()
        if is_torch_version(">=", "2.1.0"):
            self._model.config._orig_attn_implementation = self._model.config._attn_implementation
            self._model.config._attn_implementation = "sdpa"
            for layer in self._model.transformer.h:
                self_attn = layer.attn.attention
                self_attn._orig_attn = self_attn._attn
                self_attn._attn = types.MethodType(_gpt_neo_attn_sdpa, self_attn)
                self_attn._orig_forward = types.MethodType(_gpt_neo_attn_forward, self_attn)

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)
        if hasattr(self._model.config, "_orig_attn_implementation"):
            self._model.config._attn_implementation = self._model.config._orig_attn_implementation
            for layer in self._model.transformer.h:
                for layer in self._model.transformer.h:
                    layer.attn.attention.forward = layer.attn.attention._orig_forward
                    layer.attn.attention._attn = layer.attn.attention._orig_attn


class Gemma2ModelPatcher(OVDecoderModelPatcher):
    def __init__(
        self,
        config: "OpenVINOConfig",
        model: "PreTrainedModel",
        model_kwargs: Optional[Dict[str, Any]] = None,
    ):
        super().__init__(config, model, model_kwargs)

        @functools.wraps(self.orig_forward)
        def patched_forward(*args, **kwargs):
            signature = inspect.signature(self.orig_forward)
            args, kwargs = override_arguments(args, kwargs, signature, model_kwargs=self.model_kwargs)
            return_legacy_cache = False
            pkv_in_args = False
            legacy_pkv = None
            if "past_key_values" in kwargs:
                legacy_pkv = kwargs.pop("past_key_values", None)
            sign_names = list(signature.parameters.keys())
            pkv_argument_index = sign_names.index("past_key_values")
            cache_position_index = sign_names.index("cache_position") if "cache_position" in sign_names else -1
            input_ids_index = sign_names.index("input_ids" if "input_ids" in sign_names else "inputs_embeds")
            if legacy_pkv is None and len(args) > pkv_argument_index:
                legacy_pkv = args[pkv_argument_index]
                pkv_in_args = True
            if legacy_pkv is not None:
                if is_transformers_version("<", "5"):
                    pkv = DynamicCache.from_legacy_cache(legacy_pkv)
                else:
                    pkv = DynamicCache(legacy_pkv)

                return_legacy_cache = True
                if not pkv_in_args:
                    kwargs["past_key_values"] = pkv
                else:
                    args[pkv_argument_index] = pkv

            if (
                return_legacy_cache
                and cache_position_index != -1
                and (cache_position_index > len(args) and "cache_position" not in kwargs)
            ):
                past_seen_tokens = legacy_pkv[0][0].shape[-2]
                input_ids = args[input_ids_index] if "input_ids" not in kwargs else kwargs["input_ids"]
                cache_position = torch.arange(
                    past_seen_tokens, past_seen_tokens + input_ids.shape[1], device=input_ids.device
                )
                kwargs["cache_position"] = cache_position

            outputs = self.orig_forward(*args, **kwargs)
            if return_legacy_cache:
                outputs.past_key_values = postprocess_past_key_values(outputs.past_key_values)

            return outputs

        self.patched_forward = patched_forward


def _decilm_attn_forward(
    self,
    hidden_states: torch.Tensor,
    attention_mask: Optional[torch.Tensor] = None,
    position_ids: Optional[torch.LongTensor] = None,
    past_key_value: Optional[Tuple[torch.Tensor]] = None,
    output_attentions: bool = False,
    use_cache: bool = False,
    **kwargs,
) -> Tuple[torch.Tensor, Optional[torch.Tensor], Optional[Tuple[torch.Tensor]]]:
    # decilm contains bug in attention calculation for case if past key values is not None
    def rotate_half(x):
        """Rotates half the hidden dims of the input."""
        x1 = x[..., : x.shape[-1] // 2]
        x2 = x[..., x.shape[-1] // 2 :]
        return torch.cat((-x2, x1), dim=-1)

    def apply_rotary_pos_emb(q, k, cos, sin, position_ids, unsqueeze_dim=1):
        """Applies Rotary Position Embedding to the query and key tensors.

        Args:
            q (`torch.Tensor`): The query tensor.
            k (`torch.Tensor`): The key tensor.
            cos (`torch.Tensor`): The cosine part of the rotary embedding.
            sin (`torch.Tensor`): The sine part of the rotary embedding.
            position_ids (`torch.Tensor`):
                The position indices of the tokens corresponding to the query and key tensors. For example, this can be
                used to pass offsetted position ids when working with a KV-cache.
            unsqueeze_dim (`int`, *optional*, defaults to 1):
                The 'unsqueeze_dim' argument specifies the dimension along which to unsqueeze cos[position_ids] and
                sin[position_ids] so that they can be properly broadcasted to the dimensions of q and k. For example, note
                that cos[position_ids] and sin[position_ids] have the shape [batch_size, seq_len, head_dim]. Then, if q and
                k have the shape [batch_size, heads, seq_len, head_dim], then setting unsqueeze_dim=1 makes
                cos[position_ids] and sin[position_ids] broadcastable to the shapes of q and k. Similarly, if q and k have
                the shape [batch_size, seq_len, heads, head_dim], then set unsqueeze_dim=2.
        Returns:
            `tuple(torch.Tensor)` comprising of the query and key tensors rotated using the Rotary Position Embedding.
        """
        cos = cos[position_ids].unsqueeze(unsqueeze_dim)
        sin = sin[position_ids].unsqueeze(unsqueeze_dim)
        q_embed = (q * cos) + (rotate_half(q) * sin)
        k_embed = (k * cos) + (rotate_half(k) * sin)
        return q_embed, k_embed

    def repeat_kv(hidden_states: torch.Tensor, n_rep: int) -> torch.Tensor:
        """
        This is the equivalent of torch.repeat_interleave(x, dim=1, repeats=n_rep). The hidden states go from (batch,
        num_key_value_heads, seqlen, head_dim) to (batch, num_attention_heads, seqlen, head_dim)
        """
        batch, num_key_value_heads, slen, head_dim = hidden_states.shape
        if n_rep == 1:
            return hidden_states
        hidden_states = hidden_states[:, :, None, :, :].expand(batch, num_key_value_heads, n_rep, slen, head_dim)
        return hidden_states.reshape(batch, num_key_value_heads * n_rep, slen, head_dim)

    bsz, q_len, _ = hidden_states.size()
    if self.pretraining_tp > 1:
        key_value_slicing = (self.num_key_value_heads * self.head_dim) // self.pretraining_tp
        query_slices = self.q_proj.weight.split((self.num_heads * self.head_dim) // self.pretraining_tp, dim=0)
        key_slices = self.k_proj.weight.split(key_value_slicing, dim=0)
        value_slices = self.v_proj.weight.split(key_value_slicing, dim=0)

        query_states = [F.linear(hidden_states, query_slices[i]) for i in range(self.pretraining_tp)]
        query_states = torch.cat(query_states, dim=-1)

        key_states = [F.linear(hidden_states, key_slices[i]) for i in range(self.pretraining_tp)]
        key_states = torch.cat(key_states, dim=-1)

        value_states = [F.linear(hidden_states, value_slices[i]) for i in range(self.pretraining_tp)]
        value_states = torch.cat(value_states, dim=-1)

    else:
        query_states = self.q_proj(hidden_states)
        key_states = self.k_proj(hidden_states)
        value_states = self.v_proj(hidden_states)

    query_states = query_states.view(bsz, q_len, self.num_heads, self.head_dim).transpose(1, 2)
    key_states = key_states.view(bsz, q_len, self.num_key_value_heads, self.head_dim).transpose(1, 2)
    value_states = value_states.view(bsz, q_len, self.num_key_value_heads, self.head_dim).transpose(1, 2)

    kv_seq_len = key_states.shape[-2]
    if past_key_value is not None:
        kv_seq_len += past_key_value[0].shape[-2]
    cos, sin = self.rotary_emb(value_states, seq_len=kv_seq_len)

    query_states, key_states = apply_rotary_pos_emb(query_states, key_states, cos, sin, position_ids)

    if past_key_value is not None:
        # reuse k, v, self_attention
        key_states = torch.cat([past_key_value[0], key_states], dim=2)
        value_states = torch.cat([past_key_value[1], value_states], dim=2)

    past_key_value = (key_states, value_states) if use_cache else None

    # repeat k/v heads if n_kv_heads < n_heads
    key_states = repeat_kv(key_states, self.num_key_value_groups)
    value_states = repeat_kv(value_states, self.num_key_value_groups)
    attn_output = F.scaled_dot_product_attention(
        query_states, key_states, value_states, is_causal=attention_mask is None, attn_mask=attention_mask
    )

    # modified, in original implementation .transpose(1, 2) missed
    attn_output = attn_output.transpose(1, 2).contiguous().view(bsz, q_len, self.hidden_size)

    if self.pretraining_tp > 1:
        attn_output = attn_output.split(self.hidden_size // self.pretraining_tp, dim=2)
        o_proj_slices = self.o_proj.weight.split(self.hidden_size // self.pretraining_tp, dim=1)
        attn_output = sum([F.linear(attn_output[i], o_proj_slices[i]) for i in range(self.pretraining_tp)])
    else:
        attn_output = self.o_proj(attn_output)

    attn_weights = None

    return attn_output, attn_weights, past_key_value


class DeciLMModelPatcher(OVDecoderModelPatcher):
    def __enter__(self):
        super().__enter__()

        for layer in self._model.model.layers:
            layer.self_attn._orig_forward = layer.self_attn.forward
            layer.self_attn.forward = types.MethodType(_decilm_attn_forward, layer.self_attn)

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)

        for layer in self._model.model.layers:
            layer.self_attn.forward = layer.self_attn._orig_forward


class IBertModelPatcher(ModelPatcher):
    def __init__(
        self,
        config: "OpenVINOConfig",
        model: "PreTrainedModel",
        model_kwargs: Dict[str, Any],
    ):
        super().__init__(config, model, model_kwargs)

        if getattr(self._model, "ibert"):
            embeddings = self._model.ibert.embeddings
        else:
            embeddings = self._model.embeddings
        # model has first inference buffers initialization, it may breaks tracing
        if getattr(embeddings.LayerNorm, "dim_sqrt") is None:
            self._model(torch.ones([1, 1], dtype=torch.long))


class InternVLChatImageEmbeddingModelPatcher(ModelPatcher):
    def __init__(
        self,
        config: "OpenVINOConfig",
        model: "PreTrainedModel",
        model_kwargs: Dict[str, Any],
    ):
        model.__orig_forward = model.forward
        model.forward = model.extract_feature

        if model.vision_model.encoder.layers[0].attn.use_flash_attn:
            for layer in model.vision_model.encoder.layers:
                layer.attn._orig_use_flash_attn = layer.attn.use_flash_attn
                layer.attn.use_flash_attn = False

        super().__init__(config, model, model_kwargs)

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)
        self._model.forward = self._model.__orig_forward
        if hasattr(self._model.vision_model.encoder.layers[0].attn, "_orig_use_flash_attn"):
            for layer in self._model.vision_model.encoder.layers:
                layer.attn.use_flash_attn = layer.attn._orig_use_flash_attn


class InternVL2ChatLangModelPatcher(OVDecoderModelPatcher):
    def __init__(self, config: "OpenVINOConfig", model: "PreTrainedModel", model_kwargs: Dict[str, Any]):
        model_type = model.config.model_type
        patcher_for_model_type = {
            "llama": OVDecoderModelPatcher,
            "qwen2": OVDecoderModelPatcher,
            "internlm2": InternLM2Patcher,
            "phi3": Phi3ModelPatcher,
        }
        self._internal_patcher = None
        self._patched_forward = None
        internal_patcher_cls = patcher_for_model_type.get(model_type)
        if internal_patcher_cls is not None:
            self._internal_patcher = internal_patcher_cls(config, model, model_kwargs)
            self._patched_forward = self._internal_patcher.patched_forward
        super().__init__(config, model, model_kwargs)

    @property
    def patched_forward(self):
        if self._internal_patcher is not None:
            return self._internal_patcher.patched_forward
        return self._patched_forward

    @patched_forward.setter
    def patched_forward(self, fn):
        self._patched_forward = fn
        if self._internal_patcher is not None:
            self._internal_patcher.patched_forward = fn

    def __enter__(self):
        if is_torch_version(">=", "2.1.0"):
            if (
                self._model.config.model_type in ["qwen2", "llama"]
                and self._model.config._attn_implementation != "sdpa"
            ):
                self._model.config._orig_attn_implementation = self._model.config._attn_implementation
                self._model.config._attn_implementation = "sdpa"

        if self._internal_patcher is not None:
            return self._internal_patcher.__enter__()
        return super().__enter__()

    def __exit__(self, exc_type, exc_value, traceback):
        if self._internal_patcher:
            self._internal_patcher.__exit__(exc_type, exc_value, traceback)
        else:
            super().__exit__(exc_type, exc_value, traceback)

        if hasattr(self._model.config, "_orig_attn_implementation"):
            self._model.config._attn_implementation = self._model.config._orig_attn_implementation
            for layer in self._model.model.layers:
                if hasattr(layer.self_attn, "_orig_forward"):
                    layer.self_attn.forward = layer.self_attn._orig_forward


def llava_vision_embed_forward(self, pixel_values):
    # copied from https://github.com/huggingface/transformers/blob/v4.44.2/src/transformers/models/llava/modeling_llava.py#L428-L441
    # these changes does not bring any difference from original, it only packs model subcomponent inference together
    # that allow us avoid memory overheads and their inference results handling on code-level
    image_outputs = _get_model_attribute(self, "vision_tower")(pixel_values, output_hidden_states=True)
    # this is not memory efficient at all (output_hidden_states=True) will save all the hidden stated.
    selected_image_feature = image_outputs.hidden_states[self.config.vision_feature_layer]

    if self.config.vision_feature_select_strategy == "default":
        selected_image_feature = selected_image_feature[:, 1:]
    elif self.config.vision_feature_select_strategy == "full":
        selected_image_feature = selected_image_feature
    else:
        raise ValueError(f"Unexpected select feature strategy: {self.config.vision_feature_select_strategy}")

    image_features = _get_model_attribute(self, "multi_modal_projector")(selected_image_feature)
    return image_features


def llava_next_video_vision_embed_forward(self, pixel_values):
    # copied from https://github.com/huggingface/transformers/blob/v4.49.0/src/transformers/models/llava_next_video/modeling_llava_next_video.py#L519
    # these changes does not bring any difference from original, it only packs model subcomponent inference together
    # that allow us avoid memory overheads and their inference results handling on code-level
    image_features = _get_model_attribute(self, "vision_tower")(pixel_values, output_hidden_states=True)
    vision_feature_layer = self.config.vision_feature_layer
    if isinstance(vision_feature_layer, int):
        selected_image_feature = image_features.hidden_states[vision_feature_layer]
    else:
        hs_pool = [image_features.hidden_states[layer_idx] for layer_idx in vision_feature_layer]
        selected_image_feature = torch.cat(hs_pool, dim=-1)

    if self.config.vision_feature_select_strategy == "default":
        selected_image_feature = selected_image_feature[:, 1:]
    elif self.config.vision_feature_select_strategy == "full":
        selected_image_feature = selected_image_feature
    else:
        raise ValueError(f"Unexpected select feature strategy: {self.config.vision_feature_select_strategy}")
    return selected_image_feature


# Modified from https://huggingface.co/microsoft/maira-2/blob/main/modeling_maira2.py#L68
def maira_vision_embed_forward(self, pixel_values):
    vision_feature_select_strategy = self.config.vision_feature_select_strategy
    vision_feature_layer = self.config.vision_feature_layer
    return self.get_image_features(pixel_values, vision_feature_layer, vision_feature_select_strategy)


class LlavaImageEmbeddingModelPatcher(ModelPatcher):
    def __init__(
        self,
        config: "OpenVINOConfig",
        model: "PreTrainedModel",
        model_kwargs: Dict[str, Any],
    ):
        model.__orig_forward = model.forward
        model.forward = types.MethodType(llava_vision_embed_forward, model)
        super().__init__(config, model, model_kwargs)

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)
        self._model.forward = self._model.__orig_forward


class MairaImageEmbeddingModelPatcher(ModelPatcher):
    def __init__(
        self,
        config: "OpenVINOConfig",
        model: "PreTrainedModel",
        model_kwargs: Dict[str, Any],
    ):
        model.__orig_forward = model.forward
        model.forward = types.MethodType(maira_vision_embed_forward, model)

        super().__init__(config, model, model_kwargs)

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)
        self._model.forward = self._model.__orig_forward


class LlavaNextVideoImageEmbeddingModelPatcher(ModelPatcher):
    def __init__(
        self,
        config: "OpenVINOConfig",
        model: "PreTrainedModel",
        model_kwargs: Dict[str, Any],
    ):
        model.__orig_forward = model.forward
        # TODO: use get_image_features instead and add image_sizes as input when exporting
        # https://github.com/huggingface/transformers/blob/v4.48.0/src/transformers/models/llava_next_video/modeling_llava_next_video.py#L746
        model.forward = types.MethodType(llava_next_video_vision_embed_forward, model)
        super().__init__(config, model, model_kwargs)

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)
        self._model.forward = self._model.__orig_forward


# Adopted from https://github.com/huggingface/transformers/blob/v5.2.0/src/transformers/models/mistral3/modeling_mistral3.py#L223-L248
# Mistral3Model.get_image_features() with only projector.norm() applied instead of full projector forward,
# as the patch_merger cycle block (unfold loop) cannot be traced to OpenVINO IR.
def mistral3_vision_embed_forward(self, pixel_values):
    vision_tower = _get_model_attribute(self, "vision_tower")
    multi_modal_projector = _get_model_attribute(self, "multi_modal_projector")

    if pixel_values.is_floating_point():
        pixel_values = pixel_values.to(next(vision_tower.parameters()).dtype)

    image_features = vision_tower(pixel_values, output_hidden_states=True)

    vision_feature_layer = self.config.vision_feature_layer
    if isinstance(vision_feature_layer, int):
        selected_image_feature = image_features.hidden_states[vision_feature_layer]
    else:
        hs_pool = [image_features.hidden_states[layer_idx] for layer_idx in vision_feature_layer]
        selected_image_feature = torch.cat(hs_pool, dim=-1)

    if selected_image_feature.is_floating_point():
        selected_image_feature = selected_image_feature.to(multi_modal_projector.norm.weight.dtype)

    image_features = multi_modal_projector.norm(selected_image_feature.squeeze(0))
    return image_features


# Adopted from https://github.com/huggingface/transformers/blob/v5.2.0/src/transformers/models/mistral3/modeling_mistral3.py#L76-L94
# and https://github.com/huggingface/transformers/blob/v5.2.0/src/transformers/models/mistral3/modeling_mistral3.py#L118-L124
# Mistral3MultiModalProjector.forward() and Mistral3PatchMerger.forward() with norm and cycle block excluded.
# norm is moved to vision_embed_forward, cycle block runs in PyTorch at runtime.
def mistral3_multi_modal_projector_forward(self, image_features):
    hidden_states = self.patch_merger.merging_layer(image_features)
    hidden_states = self.linear_1(hidden_states)
    hidden_states = self.act(hidden_states)
    hidden_states = self.linear_2(hidden_states)
    return hidden_states


class Mistral3ImageEmbeddingModelPatcher(ModelPatcher):
    def __init__(
        self,
        config: "OpenVINOConfig",
        model: "PreTrainedModel",
        model_kwargs: Dict[str, Any],
    ):
        model.__orig_forward = model.forward
        model.forward = types.MethodType(mistral3_vision_embed_forward, model)

        super().__init__(config, model, model_kwargs)

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)
        self._model.forward = self._model.__orig_forward


class Mistral3MultiModalProjectorPatcher(ModelPatcher):
    def __init__(
        self,
        config: "OpenVINOConfig",
        model: "PreTrainedModel",
        model_kwargs: Dict[str, Any],
    ):
        model.__orig_forward = model.forward
        model.forward = types.MethodType(mistral3_multi_modal_projector_forward, model)

        super().__init__(config, model, model_kwargs)

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)
        self._model.forward = self._model.__orig_forward


def _embednb_forward(self, ids: torch.Tensor) -> torch.Tensor:
    def rope(pos: torch.Tensor, dim: int, theta: int) -> torch.Tensor:
        assert dim % 2 == 0, "The dimension must be even."

        scale = torch.arange(0, dim, 2, dtype=torch.float32, device=pos.device) / dim
        omega = 1.0 / (theta**scale)

        batch_size, seq_length = pos.shape
        out = pos.unsqueeze(-1) * omega.unsqueeze(0).unsqueeze(0)
        cos_out = torch.cos(out)
        sin_out = torch.sin(out)

        stacked_out = torch.stack([cos_out, -sin_out, sin_out, cos_out], dim=-1)
        out = stacked_out.view(batch_size, -1, dim // 2, 2, 2)
        return out.float()

    n_axes = ids.shape[-1]
    emb = torch.cat(
        [rope(ids[..., i], self.axes_dim[i], self.theta) for i in range(n_axes)],
        dim=-3,
    )
    return emb.unsqueeze(1)


class FluxTransformerModelPatcher(ModelPatcher):
    def __enter__(self):
        super().__enter__()
        if is_diffusers_version("<", "0.31.0"):
            self._model.pos_embed._orig_forward = self._model.pos_embed.forward
            self._model.pos_embed.forward = types.MethodType(_embednb_forward, self._model.pos_embed)

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)
        if hasattr(self._model.pos_embed, "_orig_forward"):
            self._model.pos_embed.forward = self._model.pos_embed._orig_forward


# Patching is needed, as OpenVINO PyTorch frontend fails to trace torch.cat with Complex tensors,
# so the Rotary embeddings related calculations are rewritten in float values.
# Original code: https://github.com/huggingface/diffusers/blob/f27949dad9f88a34eb22ff80956bbbb940cdbd2b/src/diffusers/models/transformers/transformer_qwenimage.py#L94
def _qwenimage_apply_rotary_emb(x, freqs):
    # Real-valued equivalent of the complex rotary embedding used by QwenImage, written so that the
    # traced subgraph is recognized by OpenVINO's GPT-NeoX `RoPEFusion` matcher and collapsed into the
    # dedicated `ov::op::internal::RoPE` operation at compile time.
    #
    # QwenImage rotates *interleaved* pairs (dims 2j, 2j+1) with frequency j. That matcher only accepts
    # the *contiguous* rotate-half convention (first half vs. second half, dims j and j+D/2). The two are
    # related by the fixed "de-interleave" permutation P that sends even dims to the first half and odd
    # dims to the second half. Applying P to `x` up front and rotating contiguously reproduces the
    # interleaved rotation exactly, and because the identical permutation is applied to both query and
    # key (and never undone) it cancels in the q.k^T attention score, leaving the model numerically
    # unchanged while exposing a fusable subgraph.
    #
    # The matched region is: `xp` (de-interleaved) fed into both `xp * cos` and the two half-slices, with
    # the rotate expressed as Slice + Multiply(-1) + Concat, then `xp * cos + rotate_half(xp) * sin`.
    # Note the negation must be `x2 * -1.0` (an Eltwise Multiply); a unary `-x` traces to a `Negative`
    # op which the matcher does not recognize.
    cos, sin = freqs  # each [1, seq, 1, head_dim] with the half-width table duplicated onto both halves
    x_even = x[..., 0::2]  # even dims -> first contiguous half
    x_odd = x[..., 1::2]  # odd dims  -> second contiguous half
    xp = torch.cat([x_even, x_odd], dim=-1)  # de-interleaved [batch, seq, heads, head_dim]
    half = xp.shape[-1] // 2
    x1 = xp[..., :half]
    x2 = xp[..., half:]
    rot = torch.cat([x2 * -1.0, x1], dim=-1)  # contiguous rotate-half
    return (xp * cos + rot * sin).type_as(x)


# Patching is needed to use _qwenimage_apply_rotary_emb instead of original method that uses complex values.
# Original code: https://github.com/huggingface/diffusers/blob/v0.35.0/src/diffusers/models/transformers/transformer_qwenimage.py#L270
def _qwenimage_attn_processor_call(
    self,
    attn,
    hidden_states,
    encoder_hidden_states=None,
    encoder_hidden_states_mask=None,
    attention_mask=None,
    image_rotary_emb=None,
):
    # Patched QwenDoubleStreamAttnProcessor2_0 that consumes precomputed real rotary embeddings
    # (image and text cos/sin tensors) instead of complex tensors so the model can be traced for OpenVINO.
    seq_txt = encoder_hidden_states.shape[1]

    img_query = attn.to_q(hidden_states).unflatten(-1, (attn.heads, -1))
    img_key = attn.to_k(hidden_states).unflatten(-1, (attn.heads, -1))
    img_value = attn.to_v(hidden_states).unflatten(-1, (attn.heads, -1))

    txt_query = attn.add_q_proj(encoder_hidden_states).unflatten(-1, (attn.heads, -1))
    txt_key = attn.add_k_proj(encoder_hidden_states).unflatten(-1, (attn.heads, -1))
    txt_value = attn.add_v_proj(encoder_hidden_states).unflatten(-1, (attn.heads, -1))

    if attn.norm_q is not None:
        img_query = attn.norm_q(img_query)
    if attn.norm_k is not None:
        img_key = attn.norm_k(img_key)
    if attn.norm_added_q is not None:
        txt_query = attn.norm_added_q(txt_query)
    if attn.norm_added_k is not None:
        txt_key = attn.norm_added_k(txt_key)

    img_freqs, txt_freqs = image_rotary_emb
    img_query = _qwenimage_apply_rotary_emb(img_query, img_freqs)
    img_key = _qwenimage_apply_rotary_emb(img_key, img_freqs)
    txt_query = _qwenimage_apply_rotary_emb(txt_query, txt_freqs)
    txt_key = _qwenimage_apply_rotary_emb(txt_key, txt_freqs)

    joint_query = torch.cat([txt_query, img_query], dim=1).transpose(1, 2)
    joint_key = torch.cat([txt_key, img_key], dim=1).transpose(1, 2)
    joint_value = torch.cat([txt_value, img_value], dim=1).transpose(1, 2)

    joint_hidden_states = F.scaled_dot_product_attention(joint_query, joint_key, joint_value, attn_mask=attention_mask)
    joint_hidden_states = joint_hidden_states.transpose(1, 2).flatten(2, 3).to(joint_query.dtype)

    txt_attn_output = joint_hidden_states[:, :seq_txt, :]
    img_attn_output = joint_hidden_states[:, seq_txt:, :]

    img_attn_output = attn.to_out[0](img_attn_output)
    if len(attn.to_out) > 1:
        img_attn_output = attn.to_out[1](img_attn_output)
    txt_attn_output = attn.to_add_out(txt_attn_output)

    return img_attn_output, txt_attn_output


# Patching is needed, as OpenVINO PyTorch frontend fails to trace torch.cat with Complex tensors,
# so the Rotary embeddings related calculations are rewritten in float values.
# Original code: https://github.com/huggingface/diffusers/blob/v0.35.0/src/diffusers/models/transformers/transformer_qwenimage.py#L237
def _qwenimage_rope_freqs(positions, inv_freq):
    # positions: (seq,) float tensor of per-token positions along one axis
    # inv_freq:  (dim // 2,) constant tensor of inverse frequencies
    # returns real (cos, sin) of shape (seq, dim // 2), matching the real part / imaginary part
    # of the complex `torch.polar(1, outer(positions, inv_freq))` used by diffusers' QwenEmbedRope.
    # NOTE: use an explicit broadcast multiply instead of `torch.outer`. `torch.outer` traces to a
    # MatMul whose constant `inv_freq` input is treated as a weight and gets int8-quantized by the
    # default weight compression applied to models > 1B params. Quantizing `inv_freq` (values spanning
    # 1.0 down to ~1e-4) destroys the low-magnitude frequencies and corrupts the rotary embeddings. An
    # elementwise multiply is an Eltwise op, which weight compression leaves untouched.
    angles = positions.float().unsqueeze(-1) * inv_freq.unsqueeze(0)
    return torch.cos(angles), torch.sin(angles)


# Patching is needed, as OpenVINO PyTorch frontend fails to trace torch.cat with Complex tensors,
# so the Rotary embeddings related calculations are rewritten in float values.
# Original code: https://github.com/huggingface/diffusers/blob/v0.35.0/src/diffusers/models/transformers/transformer_qwenimage.py#L196
def _qwenimage_expand_rope_freq(freq):
    # Turn a half-width per-position table `freq` [seq, head_dim // 2] into the full-width table
    # [1, seq, 1, head_dim] consumed by `_qwenimage_apply_rotary_emb`. Because the rotary apply
    # de-interleaves `x` into two contiguous halves (see that function), each frequency must land at
    # position j and position j + head_dim // 2, i.e. the half-width table is simply duplicated onto both
    # halves. The singleton batch/head axes broadcast over the [batch, seq, heads, head_dim] tensor.
    full = torch.cat([freq, freq], dim=-1)  # [seq, head_dim]
    return full[None, :, None, :]  # [1, seq, 1, head_dim]


def _qwenimage_build_rotary_emb(axes_dim, theta, image_seq_len, height, width, txt_seq_len, device):
    # Reproduces diffusers' QwenEmbedRope (scale_rope=True, single image block, frame=1) using real
    # trigonometric math instead of complex arithmetic, so it can be traced for OpenVINO while keeping
    # the image resolution (`height`/`width`) as runtime tensor inputs rather than baked-in constants.
    inv_freqs = [
        1.0 / torch.pow(torch.tensor(float(theta), device=device), torch.arange(0, d, 2, device=device).float() / d)
        for d in axes_dim
    ]

    # Per-token (frame, height, width) index arithmetic over the packed image sequence. Avoiding
    # `view`/`expand` with tensor-derived sizes keeps `height`/`width` as genuine dynamic inputs.
    hw = height * width
    token = torch.arange(image_seq_len, device=device)
    frame_idx = torch.div(token, hw, rounding_mode="floor")
    rem = token % hw
    height_idx = torch.div(rem, width, rounding_mode="floor")
    width_idx = rem % width

    h_half = height // 2
    w_half = width // 2
    # scale_rope centered positions: value - (size - size // 2)
    pos_frame = frame_idx.float()
    pos_height = height_idx.float() - (height - h_half).float()
    pos_width = width_idx.float() - (width - w_half).float()

    img_cos_parts, img_sin_parts = [], []
    for pos, inv_freq in zip((pos_frame, pos_height, pos_width), inv_freqs):
        cos, sin = _qwenimage_rope_freqs(pos, inv_freq)
        img_cos_parts.append(cos)
        img_sin_parts.append(sin)
    img_cos = torch.cat(img_cos_parts, dim=-1)
    img_sin = torch.cat(img_sin_parts, dim=-1)

    # Text tokens share a single position across all three axes, offset by the max image index.
    max_vid_index = torch.maximum(h_half, w_half)
    txt_pos = torch.arange(txt_seq_len, device=device).float() + max_vid_index.float()
    txt_cos_parts, txt_sin_parts = [], []
    for inv_freq in inv_freqs:
        cos, sin = _qwenimage_rope_freqs(txt_pos, inv_freq)
        txt_cos_parts.append(cos)
        txt_sin_parts.append(sin)
    txt_cos = torch.cat(txt_cos_parts, dim=-1)
    txt_sin = torch.cat(txt_sin_parts, dim=-1)

    # Expand to the full-width, broadcast layout so the rotary apply traces to a RoPE-fusable subgraph.
    img_cos = _qwenimage_expand_rope_freq(img_cos)
    img_sin = _qwenimage_expand_rope_freq(img_sin)
    txt_cos = _qwenimage_expand_rope_freq(txt_cos)
    txt_sin = _qwenimage_expand_rope_freq(txt_sin)

    return (img_cos, img_sin), (txt_cos, txt_sin)


# Patching is needed to use [height, width] instead of original img_shapes, that fails to be scripted with torch.script.
# Only first element is used, so it is valid to use only one shape: https://github.com/huggingface/diffusers/blob/v0.35.0/src/diffusers/models/transformers/transformer_qwenimage.py#L206
# Original code: https://github.com/huggingface/diffusers/blob/v0.35.0/src/diffusers/models/transformers/transformer_qwenimage.py#L545
def _qwenimage_transformer_forward(
    self,
    hidden_states,
    encoder_hidden_states,
    encoder_hidden_states_mask,
    timestep,
    height,
    width,
    guidance=None,
):
    # Patched QwenImageTransformer2DModel forward. The original forward builds the rotary embeddings
    # from python-list `img_shapes` using complex arithmetic inside `self.pos_embed`, which bakes a
    # fixed resolution into the trace. Here the embeddings are computed inside the model from the
    # `height`/`width` runtime tensor inputs using real math, so a single exported model serves any
    # resolution while matching the original implementation numerically.
    hidden_states = self.img_in(hidden_states)
    timestep = timestep.to(hidden_states.dtype)

    encoder_hidden_states = self.txt_norm(encoder_hidden_states)
    encoder_hidden_states = self.txt_in(encoder_hidden_states)

    if guidance is not None:
        guidance = guidance.to(hidden_states.dtype) * 1000

    temb = (
        self.time_text_embed(timestep, hidden_states)
        if guidance is None
        else self.time_text_embed(timestep, guidance, hidden_states)
    )

    image_rotary_emb = _qwenimage_build_rotary_emb(
        list(self.config.axes_dims_rope),
        10000,
        hidden_states.shape[1],
        height,
        width,
        encoder_hidden_states.shape[1],
        hidden_states.device,
    )

    batch_size, image_seq_len = hidden_states.shape[:2]
    image_mask = torch.ones((batch_size, image_seq_len), dtype=torch.bool, device=hidden_states.device)
    joint_attention_mask = torch.cat([encoder_hidden_states_mask.to(torch.bool), image_mask], dim=1)
    attention_mask = joint_attention_mask[:, None, None, :]

    for block in self.transformer_blocks:
        encoder_hidden_states, hidden_states = block(
            hidden_states=hidden_states,
            encoder_hidden_states=encoder_hidden_states,
            encoder_hidden_states_mask=None,
            temb=temb,
            image_rotary_emb=image_rotary_emb,
            joint_attention_kwargs={"attention_mask": attention_mask},
        )

    hidden_states = self.norm_out(hidden_states, temb)
    output = self.proj_out(hidden_states)
    return output


class QwenImageTransformerModelPatcher(ModelPatcher):
    def __enter__(self):
        super().__enter__()
        self._model._orig_forward = self._model.forward
        self._model.forward = types.MethodType(_qwenimage_transformer_forward, self._model)
        # Python resolves __call__ on the type, so the attention processor class (shared by all blocks)
        # is patched at the class level rather than per-instance.
        processor_cls = type(self._model.transformer_blocks[0].attn.processor)
        self._processor_cls = processor_cls
        self._orig_processor_call = processor_cls.__call__
        processor_cls.__call__ = _qwenimage_attn_processor_call

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)
        self._model.forward = self._model._orig_forward
        del self._model._orig_forward
        self._processor_cls.__call__ = self._orig_processor_call


class QwenImageVaeModelPatcher(ModelPatcher):
    def __enter__(self):
        super().__enter__()
        from diffusers.models.autoencoders.autoencoder_kl_qwenimage import QwenImageUpsample

        # OpenVINO has no "nearest-exact" upsampling op; "nearest" is identical for the integer
        # scale factor of 2 used here.
        # Original code: https://github.com/huggingface/diffusers/blob/v0.35.0/src/diffusers/models/autoencoders/autoencoder_kl_qwenimage.py#L151
        self._patched_upsamplers = []
        for module in self._model.modules():
            if isinstance(module, QwenImageUpsample) and module.mode == "nearest-exact":
                module.mode = "nearest"
                self._patched_upsamplers.append(module)

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)
        for module in self._patched_upsamplers:
            module.mode = "nearest-exact"


class QwenImageTextEncoderModelPatcher(ModelPatcher):
    def __enter__(self):
        super().__enter__()
        self._model.config._orig_attn_implementation = self._model.config._attn_implementation
        self._model.config._attn_implementation = "sdpa"
        if is_transformers_version(">=", "4.53"):
            # starting from 4.53, we get unmatching outputs if we use the boolean mask
            # (an OpenVINO inconsistency between boolean and float masks)
            ALL_MASK_ATTENTION_FUNCTIONS.register("sdpa", eager_mask_without_vmap)

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)
        self._model.config._attn_implementation = self._model.config._orig_attn_implementation
        del self._model.config._orig_attn_implementation
        if is_transformers_version(">=", "4.53"):
            ALL_MASK_ATTENTION_FUNCTIONS.register("sdpa", sdpa_mask)


def _minicpmv_resampler_forward(self, image_feature, pos_embed, key_padding_mask):
    bs = image_feature.shape[0]
    image_feature = self.kv_proj(image_feature)  # B * L * D
    image_feature = self.ln_kv(image_feature).permute(1, 0, 2)  # L * B * D

    q = self.ln_q(self.query)  # Q * D

    q_bs = q.unsqueeze(1).repeat(1, bs, 1)

    out = self.attn(q_bs, image_feature + pos_embed, image_feature, key_padding_mask=key_padding_mask)[
        0
    ]  # Q * B * D  # L * B * D +  L * B * D
    #  out: Q * B * D
    x = out.permute(1, 0, 2)  # B * Q * D

    x = self.ln_post(x)
    x = x @ self.proj
    return x


def _minicpmv_siglip_vis_embed_forward(
    self,
    pixel_values: torch.FloatTensor,
    patch_attention_mask: torch.BoolTensor,
    tgt_sizes: Optional[torch.IntTensor] = None,
    position_ids: Optional[torch.FloatTensor] = None,
) -> torch.Tensor:
    patch_embeds = self.patch_embedding(pixel_values)
    embeddings = patch_embeds.flatten(2).transpose(1, 2)

    if position_ids is None:
        batch_size = pixel_values.size(0)
        max_im_h, max_im_w = pixel_values.size(2), pixel_values.size(3)
        max_nb_patches_h, max_nb_patches_w = max_im_h // self.patch_size, max_im_w // self.patch_size
        boundaries = torch.arange(1 / self.num_patches_per_side, 1.0, 1 / self.num_patches_per_side)
        position_ids = torch.full(
            size=(
                batch_size,
                max_nb_patches_h * max_nb_patches_w,
            ),
            fill_value=0,
        )

        for batch_idx, p_attn_mask in enumerate(patch_attention_mask):
            if tgt_sizes is not None:
                nb_patches_h = tgt_sizes[batch_idx][0]
                nb_patches_w = tgt_sizes[batch_idx][1]
            else:
                nb_patches_h = p_attn_mask[:, 0].sum()
                nb_patches_w = p_attn_mask[0].sum()

            fractional_coords_h = torch.arange(0, 1 - 1e-6, 1 / nb_patches_h)
            fractional_coords_w = torch.arange(0, 1 - 1e-6, 1 / nb_patches_w)

            bucket_coords_h = torch.bucketize(fractional_coords_h, boundaries, right=True)
            bucket_coords_w = torch.bucketize(fractional_coords_w, boundaries, right=True)

            pos_ids = (bucket_coords_h[:, None] * self.num_patches_per_side + bucket_coords_w).flatten()
            position_ids[batch_idx][p_attn_mask.view(-1).cpu()] = pos_ids

    position_ids = position_ids.to(self.position_embedding.weight.device)

    embeddings = embeddings + self.position_embedding(position_ids)
    return embeddings


def _minicpmv_siglip_attn_forward(
    self,
    hidden_states: torch.Tensor,
    attention_mask: Optional[torch.Tensor] = None,
    output_attentions: Optional[bool] = False,
) -> Tuple[torch.Tensor, Optional[torch.Tensor], Optional[Tuple[torch.Tensor]]]:
    """Input shape: Batch x Time x Channel"""

    batch_size, q_len, _ = hidden_states.size()

    query_states = self.q_proj(hidden_states)
    key_states = self.k_proj(hidden_states)
    value_states = self.v_proj(hidden_states)

    query_states = query_states.view(batch_size, q_len, self.num_heads, self.head_dim).transpose(1, 2)
    key_states = key_states.view(batch_size, q_len, self.num_heads, self.head_dim).transpose(1, 2)
    value_states = value_states.view(batch_size, q_len, self.num_heads, self.head_dim).transpose(1, 2)

    attn_output = torch.nn.functional.scaled_dot_product_attention(
        query_states, key_states, value_states, attention_mask, is_causal=attention_mask is None
    )

    attn_output = attn_output.transpose(1, 2).contiguous()
    attn_output = attn_output.reshape(batch_size, q_len, self.embed_dim)

    attn_output = self.out_proj(attn_output)

    return attn_output, None


def _minicpmv_siglip_transformer_forward(
    self,
    pixel_values,
    patch_attention_mask: Optional[torch.BoolTensor] = None,
    tgt_sizes: Optional[torch.IntTensor] = None,
    position_ids: Optional[torch.FloatTensor] = None,
    output_attentions: Optional[bool] = None,
    output_hidden_states: Optional[bool] = None,
    return_dict: Optional[bool] = None,
) -> Union[Tuple, BaseModelOutputWithPooling]:
    from transformers.modeling_attn_mask_utils import _prepare_4d_attention_mask

    output_attentions = output_attentions if output_attentions is not None else self.config.output_attentions
    output_hidden_states = (
        output_hidden_states if output_hidden_states is not None else self.config.output_hidden_states
    )
    return_dict = return_dict if return_dict is not None else self.config.use_return_dict

    batch_size = pixel_values.size(0)
    if patch_attention_mask is None:
        patch_attention_mask = torch.ones(
            size=(
                batch_size,
                pixel_values.size(2) // self.config.patch_size,
                pixel_values.size(3) // self.config.patch_size,
            ),
            dtype=torch.bool,
            device=pixel_values.device,
        )

    hidden_states = self.embeddings(
        pixel_values=pixel_values,
        patch_attention_mask=patch_attention_mask,
        tgt_sizes=tgt_sizes,
        position_ids=position_ids,
    )

    patch_attention_mask = patch_attention_mask.view(batch_size, -1)
    attention_mask = (
        _prepare_4d_attention_mask(patch_attention_mask, hidden_states.dtype)
        if not getattr(self, "_use_flash_attention_2", False)
        else patch_attention_mask
    )

    encoder_outputs = self.encoder(
        inputs_embeds=hidden_states,
        attention_mask=attention_mask,
        output_attentions=output_attentions,
        output_hidden_states=output_hidden_states,
        return_dict=return_dict,
    )

    last_hidden_state = encoder_outputs[0]
    last_hidden_state = self.post_layernorm(last_hidden_state)

    if not return_dict:
        return (last_hidden_state, None) + encoder_outputs[1:]

    return BaseModelOutputWithPooling(
        last_hidden_state=last_hidden_state,
        pooler_output=None,
        hidden_states=encoder_outputs.hidden_states,
        attentions=encoder_outputs.attentions,
    )


class MiniCPMVResamplerModelPatcher(ModelPatcher):
    def __init__(
        self,
        config: "OpenVINOConfig",
        model: "PreTrainedModel",
        model_kwargs: Dict[str, Any],
    ):
        model.__orig_forward = model.forward
        model.forward = types.MethodType(_minicpmv_resampler_forward, model)

        super().__init__(config, model, model_kwargs)

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)
        self._model.forward = self._model.__orig_forward


class MiniCPMVImageEmbeddingsModelPatcher(ModelPatcher):
    def __init__(
        self,
        config: "OpenVINOConfig",
        model: "PreTrainedModel",
        model_kwargs: Dict[str, Any],
    ):
        model.__orig_forward = model.forward
        model.forward = types.MethodType(_minicpmv_siglip_transformer_forward, model)

        super().__init__(config, model, model_kwargs)

    def __enter__(self):
        super().__enter__()
        self._model.embeddings._orig_forward = self._model.embeddings.forward
        self._model.embeddings.forward = types.MethodType(_minicpmv_siglip_vis_embed_forward, self._model.embeddings)

        if is_torch_version(">=", "2.0.0"):
            for layer in self._model.encoder.layers:
                layer.self_attn._orig_forward = layer.self_attn.forward
                layer.self_attn.forward = types.MethodType(_minicpmv_siglip_attn_forward, layer.self_attn)

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)
        self._model.forward = self._model.__orig_forward
        self._model.embeddings.forward = self._model.embeddings._orig_forward
        if is_torch_version(">=", "2.0.0"):
            for layer in self._model.encoder.layers:
                layer.self_attn.forward = layer.self_attn._orig_forward


class LlavaQwen2ImageEmbeddingsModelPatcher(ModelPatcher):
    def __init__(
        self,
        config: "OpenVINOConfig",
        model: "PreTrainedModel",
        model_kwargs: Dict[str, Any],
    ):
        model.__orig_forward = model.forward
        model.forward = model.encode_images
        super().__init__(config, model, model_kwargs)
        if not self._model.get_vision_tower().is_loaded:
            self._model.get_vision_tower().load_model()

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)
        self._model.forward = self._model.__orig_forward


class InputEmbeddingPatcher(ModelPatcher):
    def __init__(
        self,
        config: "OpenVINOConfig",
        model: "PreTrainedModel",
        model_kwargs: Dict[str, Any],
    ):
        model.__orig_forward = model.forward

        def forward(self, input):
            return self.__orig_forward(input)

        model.forward = types.MethodType(forward, model)

        super().__init__(config, model, model_kwargs)

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)
        self._model.forward = self._model.__orig_forward


def phi3_vision_embeddings_forward(self, pixel_values: torch.FloatTensor):
    return self.get_img_features(pixel_values)


class Phi3VisionImageEmbeddingsPatcher(ModelPatcher):
    def __init__(
        self,
        config: "OpenVINOConfig",
        model: "PreTrainedModel",
        model_kwargs: Dict[str, Any],
    ):
        model.__orig_forward = model.forward
        model.forward = types.MethodType(phi3_vision_embeddings_forward, model)
        super().__init__(config, model, model_kwargs)

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)
        self._model.forward = self._model.__orig_forward


def minicpm3_attn_forward(
    self,
    hidden_states: torch.Tensor,
    attention_mask: Optional[torch.Tensor] = None,
    position_ids: Optional[torch.LongTensor] = None,
    past_key_value=None,
    output_attentions: bool = False,
    use_cache: bool = False,
) -> Tuple[torch.Tensor, Optional[torch.Tensor], Optional[Tuple[torch.Tensor]]]:
    def rotate_half(x):
        """Rotates half the hidden dims of the input."""
        x1 = x[..., : x.shape[-1] // 2]
        x2 = x[..., x.shape[-1] // 2 :]
        return torch.cat((-x2, x1), dim=-1)

    def apply_rotary_pos_emb(q, k, cos, sin, position_ids, unsqueeze_dim=1):
        """Applies Rotary Position Embedding to the query and key tensors.
        Args:
            q (`torch.Tensor`): The query tensor.
            k (`torch.Tensor`): The key tensor.
            cos (`torch.Tensor`): The cosine part of the rotary embedding.
            sin (`torch.Tensor`): The sine part of the rotary embedding.
            position_ids (`torch.Tensor`):
                The position indices of the tokens corresponding to the query and key tensors. For example, this can be
                used to pass offsetted position ids when working with a KV-cache.
            unsqueeze_dim (`int`, *optional*, defaults to 1):
                The 'unsqueeze_dim' argument specifies the dimension along which to unsqueeze cos[position_ids] and
                sin[position_ids] so that they can be properly broadcasted to the dimensions of q and k. For example, note
                that cos[position_ids] and sin[position_ids] have the shape [batch_size, seq_len, head_dim]. Then, if q and
                k have the shape [batch_size, heads, seq_len, head_dim], then setting unsqueeze_dim=1 makes
                cos[position_ids] and sin[position_ids] broadcastable to the shapes of q and k. Similarly, if q and k have
                the shape [batch_size, seq_len, heads, head_dim], then set unsqueeze_dim=2.
        Returns:
            `tuple(torch.Tensor)` comprising of the query and key tensors rotated using the Rotary Position Embedding.
        """
        orig_dtype = k.dtype
        cos = cos[position_ids].unsqueeze(unsqueeze_dim)  # [bs, 1, seq_len, dim]
        sin = sin[position_ids].unsqueeze(unsqueeze_dim)  # [bs, 1, seq_len, dim]
        q_fp32 = q.to(dtype=torch.float32, device=q.device)
        k_fp32 = k.to(dtype=torch.float32, device=k.device)
        q_embed = (q_fp32 * cos) + (rotate_half(q_fp32) * sin)
        k_embed = (k_fp32 * cos) + (rotate_half(k_fp32) * sin)
        return q_embed.to(dtype=orig_dtype), k_embed.to(dtype=orig_dtype)

    if output_attentions:
        return self._orig_forward(
            hidden_states=hidden_states,
            attention_mask=attention_mask,
            position_ids=position_ids,
            past_key_value=past_key_value,
            output_attentions=output_attentions,
            use_cache=use_cache,
        )

    bsz, q_len, _ = hidden_states.shape

    q = self.q_b_proj(self.q_a_layernorm(self.q_a_proj(hidden_states)))
    q = q.view(hidden_states.shape[0], hidden_states.shape[1], self.num_heads, self.q_head_dim).transpose(1, 2)
    q_nope, q_pe = torch.split(q, [self.qk_nope_head_dim, self.qk_rope_head_dim], dim=-1)

    compressed_kv = self.kv_a_proj_with_mqa(hidden_states)
    compressed_kv, k_pe = torch.split(compressed_kv, [self.kv_lora_rank, self.qk_rope_head_dim], dim=-1)
    k_pe = k_pe.view(hidden_states.shape[0], hidden_states.shape[1], 1, self.qk_rope_head_dim).transpose(1, 2)
    kv = (
        self.kv_b_proj(self.kv_a_layernorm(compressed_kv))
        .view(hidden_states.shape[0], hidden_states.shape[1], self.num_heads, self.qk_nope_head_dim + self.v_head_dim)
        .transpose(1, 2)
    )

    k_nope, value_states = torch.split(kv, [self.qk_nope_head_dim, self.v_head_dim], dim=-1)

    kv_seq_len = value_states.shape[-2]
    if past_key_value is not None:
        if self.layer_idx is None:
            raise ValueError(
                f"The cache structure has changed since version v4.36. If you are using {self.__class__.__name__} "
                "for auto-regressive decoding with k/v caching, please make sure to initialize the attention class "
                "with a layer index."
            )
        kv_seq_len += past_key_value.get_usable_length(kv_seq_len, self.layer_idx)
    cos, sin = self.rotary_emb(value_states, seq_len=kv_seq_len)

    q_pe, k_pe = apply_rotary_pos_emb(q_pe, k_pe, cos, sin, position_ids)

    # Difference with original code, k_pe.new_empty create constant tensor in torchscript
    query_states = torch.concat([q_nope, q_pe], dim=-1)
    # query_states = k_pe.new_empty(bsz, self.num_heads, q_len, self.q_head_dim)
    # query_states[:, :, :, : self.qk_nope_head_dim] = q_nope
    # query_states[:, :, :, self.qk_nope_head_dim :] = q_pe
    key_states = torch.concat([k_nope, k_pe.expand(-1, self.num_heads, -1, -1)], dim=-1)
    # key_states = k_pe.new_empty(bsz, self.num_heads, q_len, self.q_head_dim)
    # key_states[:, :, :, : self.qk_nope_head_dim] = k_nope
    # key_states[:, :, :, self.qk_nope_head_dim :] = k_pe
    if past_key_value is not None:
        cache_kwargs = {"sin": sin, "cos": cos}  # Specific to RoPE models
        key_states, value_states = past_key_value.update(key_states, value_states, self.layer_idx, cache_kwargs)

    if attention_mask is not None:
        if attention_mask.size() != (bsz, 1, q_len, kv_seq_len):
            raise ValueError(
                f"Attention mask should be of size {(bsz, 1, q_len, kv_seq_len)}, but is {attention_mask.size()}"
            )

    # SDPA with memory-efficient backend is currently (torch==2.1.2) bugged with non-contiguous inputs with custom attn_mask,
    # Reference: https://github.com/pytorch/pytorch/issues/112577.
    if query_states.device.type == "cuda" and attention_mask is not None:
        query_states = query_states.contiguous()
        key_states = key_states.contiguous()
        value_states = value_states.contiguous()

    attn_output = torch.nn.functional.scaled_dot_product_attention(
        query_states,
        key_states,
        value_states,
        attn_mask=attention_mask,
        dropout_p=self.attention_dropout if self.training else 0.0,
        # The q_len > 1 is necessary to match with AttentionMaskConverter.to_causal_4d that does not create a causal mask in case q_len == 1.
        is_causal=self.is_causal and attention_mask is None and q_len > 1,
    )

    attn_output = attn_output.transpose(1, 2).contiguous()
    attn_output = attn_output.reshape(hidden_states.shape[0], hidden_states.shape[1], self.hidden_size)

    attn_output = self.o_proj(attn_output)

    return attn_output, None, past_key_value


class MiniCPM3Patcher(OVDecoderModelPatcher):
    def __enter__(self):
        super().__enter__()
        for block in self._model.model.layers:
            block.self_attn._orig_forward = block.self_attn.forward
            block.self_attn.forward = types.MethodType(minicpm3_attn_forward, block.self_attn)

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)
        for block in self._model.model.layers:
            block.self_attn.forward = block.self_attn._orig_forward


class DeepseekPatcher(OVDecoderModelPatcher):
    def __enter__(self):
        super().__enter__()
        self_attn = {
            "deepseek_v3": deepseek_v3_attn_forward,
            "deepseek_v2": deepseek_v2_attn_forward,
            "deepseek": minicpm3_attn_forward,
        }

        self_attn_fwd = self_attn.get(self._model.config.model_type)
        for block in self._model.model.layers:
            if self_attn_fwd is not None:
                block.self_attn._orig_forward = block.self_attn.forward
                block.self_attn.forward = types.MethodType(self_attn_fwd, block.self_attn)
            if hasattr(block.mlp, "moe_infer"):
                block.mlp._org_moe_infer = block.mlp.moe_infer
                block.mlp.moe_infer = types.MethodType(deepseek_moe_infer, block.mlp)

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)
        for block in self._model.model.layers:
            block.self_attn.forward = block.self_attn._orig_forward
            if hasattr(block.mlp, "_orig_moe_infer"):
                block.mlp.moe_infer = block.mlp._orig_moe_infer


def deepseek_v3_attn_forward(
    self,
    hidden_states: torch.Tensor,
    attention_mask: Optional[torch.Tensor] = None,
    position_ids: Optional[torch.LongTensor] = None,
    past_key_value=None,
    output_attentions: bool = False,
    use_cache: bool = False,
) -> Tuple[torch.Tensor, Optional[torch.Tensor], Optional[Tuple[torch.Tensor]]]:
    # modified from https://huggingface.co/deepseek-ai/DeepSeek-V3/blob/main/modeling_deepseek.py#L751
    def rotate_half(x):
        """Rotates half the hidden dims of the input."""
        x1 = x[..., : x.shape[-1] // 2]
        x2 = x[..., x.shape[-1] // 2 :]
        return torch.cat((-x2, x1), dim=-1)

    def apply_rotary_pos_emb(q, k, cos, sin, position_ids, unsqueeze_dim=1):
        orig_dtype = k.dtype
        cos = cos[position_ids].unsqueeze(unsqueeze_dim)  # [bs, 1, seq_len, dim]
        sin = sin[position_ids].unsqueeze(unsqueeze_dim)  # [bs, 1, seq_len, dim]
        q_fp32 = q.to(dtype=torch.float32, device=q.device)
        k_fp32 = k.to(dtype=torch.float32, device=k.device)
        q_embed = (q_fp32 * cos) + (rotate_half(q_fp32) * sin)
        k_embed = (k_fp32 * cos) + (rotate_half(k_fp32) * sin)
        return q_embed.to(dtype=orig_dtype), k_embed.to(dtype=orig_dtype)

    if output_attentions:
        return self._orig_forward(
            hidden_states=hidden_states,
            attention_mask=attention_mask,
            position_ids=position_ids,
            past_key_value=past_key_value,
            output_attentions=output_attentions,
            use_cache=use_cache,
        )

    bsz, q_len, _ = hidden_states.size()

    if self.q_lora_rank is None:
        q = self.q_proj(hidden_states)
    else:
        q = self.q_b_proj(self.q_a_layernorm(self.q_a_proj(hidden_states)))
    q = q.view(bsz, q_len, self.num_heads, self.q_head_dim).transpose(1, 2)
    q_nope, q_pe = torch.split(q, [self.qk_nope_head_dim, self.qk_rope_head_dim], dim=-1)

    compressed_kv = self.kv_a_proj_with_mqa(hidden_states)
    compressed_kv, k_pe = torch.split(compressed_kv, [self.kv_lora_rank, self.qk_rope_head_dim], dim=-1)
    k_pe = k_pe.view(bsz, q_len, 1, self.qk_rope_head_dim).transpose(1, 2)
    kv = (
        self.kv_b_proj(self.kv_a_layernorm(compressed_kv))
        .view(bsz, q_len, self.num_heads, self.qk_nope_head_dim + self.v_head_dim)
        .transpose(1, 2)
    )

    k_nope, value_states = torch.split(kv, [self.qk_nope_head_dim, self.v_head_dim], dim=-1)
    kv_seq_len = value_states.shape[-2]
    if past_key_value is not None:
        if self.layer_idx is None:
            raise ValueError(
                f"The cache structure has changed since version v4.36. If you are using {self.__class__.__name__} "
                "for auto-regressive decoding with k/v caching, please make sure to initialize the attention class "
                "with a layer index."
            )
        kv_seq_len += past_key_value.get_usable_length(kv_seq_len, self.layer_idx)
    cos, sin = self.rotary_emb(value_states, seq_len=kv_seq_len)

    q_pe, k_pe = apply_rotary_pos_emb(q_pe, k_pe, cos, sin, position_ids)

    # Difference with original code, k_pe.new_empty create constant tensor in torchscript
    query_states = torch.concat([q_nope, q_pe], dim=-1)
    # query_states = k_pe.new_empty(bsz, self.num_heads, q_len, self.q_head_dim)
    # query_states[:, :, :, : self.qk_nope_head_dim] = q_nope
    # query_states[:, :, :, self.qk_nope_head_dim :] = q_pe
    key_states = torch.concat([k_nope, k_pe.expand(-1, self.num_heads, -1, -1)], dim=-1)
    # key_states = k_pe.new_empty(bsz, self.num_heads, q_len, self.q_head_dim)
    # key_states[:, :, :, : self.qk_nope_head_dim] = k_nope
    # key_states[:, :, :, self.qk_nope_head_dim :] = k_pe
    if past_key_value is not None:
        cache_kwargs = {"sin": sin, "cos": cos}  # Specific to RoPE models
        key_states, value_states = past_key_value.update(key_states, value_states, self.layer_idx, cache_kwargs)

    if attention_mask is not None:
        if attention_mask.size() != (bsz, 1, q_len, kv_seq_len):
            raise ValueError(
                f"Attention mask should be of size {(bsz, 1, q_len, kv_seq_len)}, but is {attention_mask.size()}"
            )

    # SDPA with memory-efficient backend is currently (torch==2.1.2) bugged with non-contiguous inputs with custom attn_mask,
    # Reference: https://github.com/pytorch/pytorch/issues/112577.
    if query_states.device.type == "cuda" and attention_mask is not None:
        query_states = query_states.contiguous()
        key_states = key_states.contiguous()
        value_states = value_states.contiguous()

    attn_output = torch.nn.functional.scaled_dot_product_attention(
        query_states,
        key_states,
        value_states,
        attn_mask=attention_mask,
        dropout_p=self.attention_dropout if self.training else 0.0,
        # The q_len > 1 is necessary to match with AttentionMaskConverter.to_causal_4d that does not create a causal mask in case q_len == 1.
        is_causal=self.is_causal and attention_mask is None and q_len > 1,
    )

    attn_output = attn_output.transpose(1, 2).contiguous()

    attn_output = attn_output.reshape(bsz, q_len, self.num_heads * self.v_head_dim)

    attn_output = self.o_proj(attn_output)

    return attn_output, None, past_key_value


def deepseek_v2_attn_forward(
    self,
    hidden_states: torch.Tensor,
    attention_mask: Optional[torch.Tensor] = None,
    position_ids: Optional[torch.LongTensor] = None,
    past_key_value=None,
    output_attentions: bool = False,
    use_cache: bool = False,
    **kwargs,
) -> Tuple[torch.Tensor, Optional[torch.Tensor], Optional[Tuple[torch.Tensor]]]:
    # modified from https://huggingface.co/deepseek-ai/DeepSeek-V2-Lite/blob/main/modeling_deepseek.py#L806
    def rotate_half(x):
        """Rotates half the hidden dims of the input."""
        x1 = x[..., : x.shape[-1] // 2]
        x2 = x[..., x.shape[-1] // 2 :]
        return torch.cat((-x2, x1), dim=-1)

    def apply_rotary_pos_emb(q, k, cos, sin, position_ids, unsqueeze_dim=1):
        cos = cos[position_ids].unsqueeze(unsqueeze_dim)
        sin = sin[position_ids].unsqueeze(unsqueeze_dim)

        b, h, s, d = q.shape
        q = q.view(b, h, s, d // 2, 2).transpose(4, 3).reshape(b, h, s, d)

        b, h, s, d = k.shape
        k = k.view(b, h, s, d // 2, 2).transpose(4, 3).reshape(b, h, s, d)

        q_embed = (q * cos) + (rotate_half(q) * sin)
        k_embed = (k * cos) + (rotate_half(k) * sin)
        return q_embed, k_embed

    if output_attentions:
        return self._orig_forward(
            hidden_states=hidden_states,
            attention_mask=attention_mask,
            position_ids=position_ids,
            past_key_value=past_key_value,
            output_attentions=output_attentions,
            use_cache=use_cache,
        )

    bsz, q_len, _ = hidden_states.shape

    if self.q_lora_rank is None:
        q = self.q_proj(hidden_states)
    else:
        q = self.q_b_proj(self.q_a_layernorm(self.q_a_proj(hidden_states)))
    q = q.view(bsz, q_len, self.num_heads, self.q_head_dim).transpose(1, 2)
    q_nope, q_pe = torch.split(q, [self.qk_nope_head_dim, self.qk_rope_head_dim], dim=-1)

    compressed_kv = self.kv_a_proj_with_mqa(hidden_states)
    compressed_kv, k_pe = torch.split(compressed_kv, [self.kv_lora_rank, self.qk_rope_head_dim], dim=-1)
    k_pe = k_pe.view(bsz, q_len, 1, self.qk_rope_head_dim).transpose(1, 2)
    kv = (
        self.kv_b_proj(self.kv_a_layernorm(compressed_kv))
        .view(bsz, q_len, self.num_heads, self.qk_nope_head_dim + self.v_head_dim)
        .transpose(1, 2)
    )

    k_nope, value_states = torch.split(kv, [self.qk_nope_head_dim, self.v_head_dim], dim=-1)
    kv_seq_len = value_states.shape[-2]
    if past_key_value is not None:
        if self.layer_idx is None:
            raise ValueError(
                f"The cache structure has changed since version v4.36. If you are using {self.__class__.__name__} "
                "for auto-regressive decoding with k/v caching, please make sure to initialize the attention class "
                "with a layer index."
            )
        kv_seq_len += past_key_value.get_usable_length(kv_seq_len, self.layer_idx)
    cos, sin = self.rotary_emb(value_states, seq_len=kv_seq_len)

    q_pe, k_pe = apply_rotary_pos_emb(q_pe, k_pe, cos, sin, position_ids)

    # Difference with original code, k_pe.new_empty create constant tensor in torchscript
    query_states = torch.concat([q_nope, q_pe], dim=-1)
    # query_states = k_pe.new_empty(bsz, self.num_heads, q_len, self.q_head_dim)
    # query_states[:, :, :, : self.qk_nope_head_dim] = q_nope
    # query_states[:, :, :, self.qk_nope_head_dim :] = q_pe
    key_states = torch.concat([k_nope, k_pe.expand(-1, self.num_heads, -1, -1)], dim=-1)
    # key_states = k_pe.new_empty(bsz, self.num_heads, q_len, self.q_head_dim)
    # key_states[:, :, :, : self.qk_nope_head_dim] = k_nope
    # key_states[:, :, :, self.qk_nope_head_dim :] = k_pe
    if past_key_value is not None:
        cache_kwargs = {"sin": sin, "cos": cos}  # Specific to RoPE models
        key_states, value_states = past_key_value.update(key_states, value_states, self.layer_idx, cache_kwargs)

    if attention_mask is not None:
        if attention_mask.size() != (bsz, 1, q_len, kv_seq_len):
            raise ValueError(
                f"Attention mask should be of size {(bsz, 1, q_len, kv_seq_len)}, but is {attention_mask.size()}"
            )

    if attention_mask is not None:
        if attention_mask.size() != (bsz, 1, q_len, kv_seq_len):
            raise ValueError(
                f"Attention mask should be of size {(bsz, 1, q_len, kv_seq_len)}, but is {attention_mask.size()}"
            )
    # SDPA with memory-efficient backend is currently (torch==2.1.2) bugged with non-contiguous inputs with custom attn_mask,
    # Reference: https://github.com/pytorch/pytorch/issues/112577.
    if query_states.device.type == "cuda" and attention_mask is not None:
        query_states = query_states.contiguous()
        key_states = key_states.contiguous()
        value_states = value_states.contiguous()

    attn_output = torch.nn.functional.scaled_dot_product_attention(
        query_states,
        key_states,
        value_states,
        attn_mask=attention_mask,
        dropout_p=self.attention_dropout if self.training else 0.0,
        # The q_len > 1 is necessary to match with AttentionMaskConverter.to_causal_4d that does not create a causal mask in case q_len == 1.
        is_causal=self.is_causal and attention_mask is None and q_len > 1,
    )
    attn_output = attn_output.transpose(1, 2).contiguous()

    attn_output = attn_output.reshape(bsz, q_len, self.num_heads * self.v_head_dim)

    attn_output = self.o_proj(attn_output)

    return attn_output, None, past_key_value


def deepseek_moe_infer(self, x, topk_ids, topk_weight):
    cnts = torch.zeros((topk_ids.shape[0], len(self.experts)))
    cnts.scatter_(1, topk_ids, 1)
    tokens_per_expert = cnts.sum(dim=0).to(torch.long)
    idxs = torch.argsort(topk_ids.view(-1))
    sorted_tokens = x[idxs // topk_ids.shape[1]]

    outputs = []
    start_idx = torch.tensor(0, dtype=torch.long)
    for i, num_tokens in enumerate(tokens_per_expert):
        end_idx = start_idx + num_tokens
        # difference with original: removed skiping expert if empty num_tokens
        expert_id = i + self.ep_rank * self.experts_per_rank
        expert = self.experts[expert_id]
        tokens_for_this_expert = sorted_tokens[start_idx:end_idx]
        expert_out = expert(tokens_for_this_expert)
        outputs.append(expert_out)
        start_idx = end_idx

    # difference with original: removed usage torch.new_empty if outputs empty
    outs = torch.cat(outputs, dim=0)

    new_x = torch.zeros_like(outs)
    new_x[idxs] = outs
    final_out = (
        new_x.view(*topk_ids.shape, -1)
        .to(topk_weight.dtype)
        .mul_(topk_weight.unsqueeze(dim=-1))
        .sum(dim=1)
        .to(new_x.dtype)
    )
    return final_out


class Qwen2VLLanguageModelPatcher(OVDecoderModelPatcher):
    def __init__(
        self,
        config: "OpenVINOConfig",
        model: "PreTrainedModel",
        model_kwargs: Dict[str, Any] = None,
    ):
        model.__orig_forward = model.forward

        def forward_wrap(
            self,
            attention_mask,
            position_ids=None,
            past_key_values=None,
            inputs_embeds=None,
            input_ids=None,
            use_cache=True,
        ):
            if is_transformers_version("<", "5"):
                new_past_key_values = DynamicCache.from_legacy_cache(past_key_values)
            else:
                new_past_key_values = DynamicCache(past_key_values)

            result = self.__orig_forward(
                input_ids=input_ids,
                attention_mask=attention_mask,
                position_ids=position_ids,
                past_key_values=new_past_key_values,
                inputs_embeds=inputs_embeds,
                use_cache=use_cache,
            )
            if past_key_values is not None:
                result["past_key_values"] = postprocess_past_key_values(result["past_key_values"])
            return result

        model.forward = types.MethodType(forward_wrap, model)
        super().__init__(config, model, model_kwargs)

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)
        self._model.forward = self._model.__orig_forward


# Replacement for _deepstack_process that avoids `hidden_states[mask]` boolean indexing —
# the data-dependent shape breaks OpenVINO tracing. Uses cumsum + index_select + masked add instead.
# Original: https://github.com/huggingface/transformers/blob/v5.0.0/src/transformers/models/qwen3_omni_moe/modeling_qwen3_omni_moe.py#L1840
def _deepstack_process_patched(self, hidden_states, visual_pos_masks, visual_embeds):
    visual_pos_masks = visual_pos_masks.to(hidden_states.device)
    visual_embeds = visual_embeds.to(hidden_states.device, hidden_states.dtype)
    batch, seq_len, dim = hidden_states.shape
    flat_mask = visual_pos_masks.reshape(-1)
    indices = torch.cumsum(flat_mask.long(), dim=0) - 1
    indices = torch.clamp(indices, min=0)
    full_visual = torch.index_select(visual_embeds, 0, indices).reshape(batch, seq_len, dim)
    mask_3d = flat_mask.to(hidden_states.dtype).reshape(batch, seq_len, 1)
    hidden_states = hidden_states + full_visual * mask_3d
    return hidden_states


class Qwen3VLLanguageModelPatcher(OVDecoderModelPatcher):
    def __init__(
        self,
        config: "OpenVINOConfig",
        model: Union["PreTrainedModel"],
        model_kwargs: Optional[Dict[str, Any]] = None,
    ):
        # Adopted from https://github.com/huggingface/transformers/blob/v4.51.3/src/transformers/models/phi4_multimodal/modeling_phi4_multimodal.py#L2156-L2178
        # moved audio and vision features processing outside model
        # This method in original model: https://github.com/huggingface/transformers/blob/v4.57.6/src/transformers/models/qwen3_vl/modeling_qwen3_vl.py#L1344-L1362
        def lm_forward(
            self,
            attention_mask,
            position_ids,
            past_key_values,
            inputs_embeds,
            visual_pos_masks,
            deepstack_visual_embeds,
            use_cache=True,
        ):
            if is_transformers_version("<", "5"):
                pkv = DynamicCache.from_legacy_cache(past_key_values)
            else:
                pkv = DynamicCache(past_key_values)
            if hasattr(self, "model"):
                outputs = self.model.language_model(
                    inputs_embeds=inputs_embeds,
                    attention_mask=attention_mask,
                    position_ids=position_ids,
                    use_cache=use_cache,
                    past_key_values=pkv,
                    visual_pos_masks=visual_pos_masks,
                    deepstack_visual_embeds=deepstack_visual_embeds,
                )
            else:
                outputs = self.language_model(
                    inputs_embeds=inputs_embeds,
                    attention_mask=attention_mask,
                    position_ids=position_ids,
                    use_cache=use_cache,
                    past_key_values=pkv,
                    visual_pos_masks=visual_pos_masks,
                    deepstack_visual_embeds=deepstack_visual_embeds,
                )
            # Only compute necessary logits, and do not upcast them to float if we are not computing the loss
            if hasattr(self, "lm_head"):
                logits = self.lm_head(outputs[0])
            else:
                return ModelOutput(
                    last_hidden_state=outputs["last_hidden_state"],
                    past_key_values=postprocess_past_key_values(outputs.past_key_values),
                )
            return ModelOutput(logits=logits, past_key_values=postprocess_past_key_values(outputs.past_key_values))

        model.__orig_forward = model.forward
        model.forward = types.MethodType(lm_forward, model)

        # Qwen3-VL exposes the text stack as `model.language_model` on the bare `Qwen3VLModel`
        # (used for feature-extraction/embedding) but nested under `model.model.language_model`
        # on the conditional-generation wrapper. Mirror the guard used in `lm_forward` above.
        language_model = model.model.language_model if hasattr(model, "model") else model.language_model
        language_model.__orig_deepstack_process = language_model._deepstack_process
        language_model._deepstack_process = types.MethodType(_deepstack_process_patched, language_model)

        super().__init__(config, model, model_kwargs)

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)
        self._model.forward = self._model.__orig_forward
        language_model = (
            self._model.model.language_model if hasattr(self._model, "model") else self._model.language_model
        )
        language_model._deepstack_process = language_model.__orig_deepstack_process


def patch_qwen2vl_vision_blocks(model, force_new_behaviour=False):
    # Modified from https://github.com/huggingface/transformers/blob/v4.49.0/src/transformers/models/qwen2_vl/modeling_qwen2_vl.py#L391
    # added attention_mask input instead of internal calculation (unsupported by tracing due to cycle with dynamic len)
    def sdpa_attn_forward(
        self,
        hidden_states: torch.Tensor,
        attention_mask: torch.Tensor,
        rotary_pos_emb: torch.Tensor = None,
        position_embeddings: Optional[Tuple[torch.Tensor, torch.Tensor]] = None,
    ):
        def rotate_half(x):
            """Rotates half the hidden dims of the input."""
            x1 = x[..., : x.shape[-1] // 2]
            x2 = x[..., x.shape[-1] // 2 :]
            return torch.cat((-x2, x1), dim=-1)

        def apply_rotary_pos_emb_vision(
            q: torch.Tensor, k: torch.Tensor, cos: torch.Tensor, sin: torch.Tensor
        ) -> Tuple[torch.Tensor, torch.Tensor]:
            orig_q_dtype = q.dtype
            orig_k_dtype = k.dtype
            q, k = q.float(), k.float()
            cos, sin = cos.unsqueeze(-2), sin.unsqueeze(-2)
            q_embed = (q * cos) + (rotate_half(q) * sin)
            k_embed = (k * cos) + (rotate_half(k) * sin)
            q_embed = q_embed.to(orig_q_dtype)
            k_embed = k_embed.to(orig_k_dtype)
            return q_embed, k_embed

        seq_length = hidden_states.shape[0]
        q, k, v = self.qkv(hidden_states).reshape(seq_length, 3, self.num_heads, -1).permute(1, 0, 2, 3).unbind(0)
        if position_embeddings is None:
            emb = torch.cat((rotary_pos_emb, rotary_pos_emb), dim=-1)
            cos = emb.cos().float()
            sin = emb.sin().float()
        else:
            cos, sin = position_embeddings
        q, k = apply_rotary_pos_emb_vision(q, k, cos, sin)
        q = q.transpose(0, 1)
        k = k.transpose(0, 1)
        v = v.transpose(0, 1)
        attn_output = torch.nn.functional.scaled_dot_product_attention(q, k, v, attention_mask, dropout_p=0.0)
        attn_output = attn_output.transpose(0, 1)
        attn_output = attn_output.reshape(seq_length, -1)
        attn_output = self.proj(attn_output)
        return attn_output

    # Modified from https://github.com/huggingface/transformers/blob/v4.49.0/src/transformers/models/qwen2_vl/modeling_qwen2_vl.py#L446
    # added attention_mask input propagation to self.attn
    def block_forward(
        self,
        hidden_states,
        attention_mask,
        rotary_pos_emb: Optional[torch.Tensor] = None,
        position_embeddings: Optional[Tuple[torch.Tensor, torch.Tensor]] = None,
    ) -> torch.Tensor:
        hidden_states = hidden_states + self.attn(
            self.norm1(hidden_states),
            attention_mask=attention_mask,
            rotary_pos_emb=rotary_pos_emb,
            position_embeddings=position_embeddings,
        )
        hidden_states = hidden_states + self.mlp(self.norm2(hidden_states))
        return hidden_states

    for block in model.blocks:
        block._orig_forward = block.forward
        block.forward = types.MethodType(block_forward, block)
        block.attn._orig_forward = block.attn.forward
        block.attn.forward = types.MethodType(sdpa_attn_forward, block.attn)


class Qwen2VLVisionEmbMergerPatcher(ModelPatcher):
    def __init__(
        self,
        config: "OpenVINOConfig",
        model: "PreTrainedModel",
        model_kwargs: Dict[str, Any] = None,
    ):
        model.__orig_forward = model.forward

        # Modified from https://github.com/huggingface/transformers/blob/v4.45.2/src/transformers/models/qwen2_vl/modeling_qwen2_vl.py#L1118
        # added attention_mask input instead cu_lens for its internal calculation model (unsupported by tracing due to cycle with dynamic len)
        # separated patch_embed and rot_pos_emb calls for performing as part of another model
        def image_embed_forward(
            self, hidden_states: torch.Tensor, attention_mask: torch.Tensor, rotary_pos_emb: torch.Tensor
        ) -> torch.Tensor:
            for blk in self.blocks:
                hidden_states = blk(hidden_states, attention_mask=attention_mask, rotary_pos_emb=rotary_pos_emb)
            return self.merger(hidden_states)

        model.forward = types.MethodType(image_embed_forward, model)
        super().__init__(config, model, model_kwargs)

    def __enter__(self):
        patch_qwen2vl_vision_blocks(self._model)
        super().__enter__()

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)
        self._model.forward = self._model.__orig_forward
        for block in self._model.blocks:
            block.forward = block._orig_forward
            block.attn.forward = block.attn._orig_forward


class Qwen2_5_VLVisionEmbMergerPatcher(ModelPatcher):
    def __init__(
        self,
        config: "OpenVINOConfig",
        model: "PreTrainedModel",
        model_kwargs: Dict[str, Any] = None,
    ):
        super().__init__(config, model, model_kwargs)

        model.__orig_forward = model.forward

        # Modified from https://github.com/huggingface/transformers/blob/v4.49.0/src/transformers/models/qwen2_5_vl/modeling_qwen2_5_vl.py#L405
        # added attention_mask and window_attention_mask inputs instead cu_lens and window_cu_lens processing for its internal calculation model
        # (unsupported by tracing due to cycle with dynamic len)
        # separated patch_embed and rot_pos_emb calls for performing as part of another model
        def image_embed_forward(
            self,
            hidden_states: torch.Tensor,
            attention_mask: torch.Tensor,
            window_attention_mask: torch.Tensor,
            window_index: torch.Tensor,
            rotary_pos_emb: torch.Tensor,
        ) -> torch.Tensor:
            seq_len = hidden_states.shape[0]
            hidden_states = hidden_states.reshape(seq_len // self.spatial_merge_unit, self.spatial_merge_unit, -1)
            hidden_states = hidden_states[window_index, :, :]
            hidden_states = hidden_states.reshape(seq_len, -1)
            rotary_pos_emb = rotary_pos_emb.reshape(seq_len // self.spatial_merge_unit, self.spatial_merge_unit, -1)
            rotary_pos_emb = rotary_pos_emb[window_index, :, :]
            rotary_pos_emb = rotary_pos_emb.reshape(seq_len, -1)
            emb = torch.cat((rotary_pos_emb, rotary_pos_emb), dim=-1)
            position_embeddings = (emb.cos(), emb.sin())
            for layer_num, blk in enumerate(self.blocks):
                if layer_num in self.fullatt_block_indexes:
                    attention_mask_now = attention_mask
                else:
                    attention_mask_now = window_attention_mask
                hidden_states = blk(
                    hidden_states, attention_mask=attention_mask_now, position_embeddings=position_embeddings
                )

            hidden_states = self.merger(hidden_states)
            reverse_indices = torch.argsort(window_index)
            hidden_states = hidden_states[reverse_indices, :]

            return hidden_states

        model.forward = types.MethodType(image_embed_forward, model)
        super().__init__(config, model, model_kwargs)

    def __enter__(self):
        patch_qwen2vl_vision_blocks(self._model, force_new_behaviour=True)
        super().__enter__()

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)
        self._model.forward = self._model.__orig_forward
        for block in self._model.blocks:
            block.forward = block._orig_forward
            block.attn.forward = block.attn._orig_forward


class Qwen3VLVisionEmbMergerPatcher(ModelPatcher):
    def __init__(
        self,
        config: "OpenVINOConfig",
        model: Union["PreTrainedModel"],
        model_kwargs: Dict[str, Any] = None,
    ):
        model.__orig_forward = model.forward

        # Modified from https://github.com/huggingface/transformers/blob/v4.45.2/src/transformers/models/qwen2_vl/modeling_qwen2_vl.py#L1118
        # added attention_mask input instead cu_lens for its internal calculation model (unsupported by tracing due to cycle with dynamic len)
        # separated patch_embed and rot_pos_emb calls for performing as part of another model
        # This code part in original model: https://github.com/huggingface/transformers/blob/main/src/transformers/models/qwen3_vl/modeling_qwen3_vl.py#L794-L808
        def image_embed_forward(
            self, hidden_states: torch.Tensor, attention_mask: torch.Tensor, rotary_pos_emb: torch.Tensor
        ) -> torch.Tensor:
            deepstack_feature_lists = []
            for layer_num, blk in enumerate(self.blocks):
                hidden_states = blk(hidden_states, attention_mask=attention_mask, rotary_pos_emb=rotary_pos_emb)
                if layer_num in self.deepstack_visual_indexes:
                    deepstack_feature = self.deepstack_merger_list[self.deepstack_visual_indexes.index(layer_num)](
                        hidden_states
                    )
                    deepstack_feature_lists.append(deepstack_feature)
            last_hidden_state = self.merger(hidden_states)
            return last_hidden_state, torch.stack(deepstack_feature_lists, dim=0)

        model.forward = types.MethodType(image_embed_forward, model)
        super().__init__(config, model, model_kwargs)

    def __enter__(self):
        patch_qwen2vl_vision_blocks(self._model)
        super().__enter__()

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)
        self._model.forward = self._model.__orig_forward
        for block in self._model.blocks:
            block.forward = block._orig_forward
            block.attn.forward = block.attn._orig_forward


class Qwen3OmniMoeVisionMergerPatcher(ModelPatcher):
    # Patches Qwen3OmniMoeVisionMerger.forward to return both last_hidden_state and stacked deepstack features
    # Original: https://github.com/huggingface/transformers/blob/v5.0.0/src/transformers/models/qwen3_omni_moe/modeling_qwen3_omni_moe.py#L1542
    def __init__(
        self,
        config: "OpenVINOConfig",
        model: "PreTrainedModel",
        model_kwargs: Optional[Dict[str, Any]] = None,
    ):
        model.__orig_forward = model.forward

        def image_embed_forward(
            self,
            hidden_states: torch.Tensor,
            pos_embeds: torch.Tensor,
            attention_mask: torch.Tensor,
            rotary_pos_emb: torch.Tensor,
        ) -> torch.Tensor:
            hidden_states = self.patch_embed(hidden_states)
            hidden_states = hidden_states + pos_embeds
            deepstack_feature_lists = []
            for layer_num, blk in enumerate(self.blocks):
                hidden_states = blk(hidden_states, attention_mask=attention_mask, rotary_pos_emb=rotary_pos_emb)
                if layer_num in self.deepstack_visual_indexes:
                    deepstack_feature = self.merger_list[self.deepstack_visual_indexes.index(layer_num)](hidden_states)
                    deepstack_feature_lists.append(deepstack_feature)
            last_hidden_state = self.merger(hidden_states)
            return last_hidden_state, torch.stack(deepstack_feature_lists, dim=0)

        model.forward = types.MethodType(image_embed_forward, model)
        super().__init__(config, model, model_kwargs)

    def __enter__(self):
        patch_qwen2vl_vision_blocks(self._model)
        super().__enter__()

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)
        self._model.forward = self._model.__orig_forward
        for block in self._model.blocks:
            block.forward = block._orig_forward
            block.attn.forward = block.attn._orig_forward


class Qwen3OmniMoeAudioEncoderPatcher(ModelPatcher):
    def __init__(
        self,
        config: "OpenVINOConfig",
        model: "PreTrainedModel",
        model_kwargs: Optional[Dict[str, Any]] = None,
    ):
        model.__orig_forward = model.forward

        encoder = model

        # Force eager attention to avoid cu_seqlens dependency (follows Qwen3ASR pattern).
        # Save the previous value on each config we touch so __exit__ can restore it. Layers may
        # share the encoder config object, so guard the save to keep the true original value.
        if not hasattr(encoder.config, "_orig_attn_implementation"):
            encoder.config._orig_attn_implementation = encoder.config._attn_implementation
        encoder.config._attn_implementation = "eager"

        for layer in encoder.layers:
            if not hasattr(layer.self_attn.config, "_orig_attn_implementation"):
                layer.self_attn.config._orig_attn_implementation = layer.self_attn.config._attn_implementation
            layer.self_attn.config._attn_implementation = "eager"

            attn = layer.self_attn
            attn._orig_forward = attn.forward

            def make_patched_attn_forward(attn_module):
                def patched_attn_forward(hidden_states, cu_seqlens=None, attention_mask=None, **kwargs):
                    bsz, seq_length, _ = hidden_states.size()

                    query_states = (
                        attn_module.q_proj(hidden_states)
                        .reshape(bsz, seq_length, attn_module.num_heads, -1)
                        .transpose(1, 2)
                    )
                    key_states = (
                        attn_module.k_proj(hidden_states)
                        .reshape(bsz, seq_length, attn_module.num_heads, -1)
                        .transpose(1, 2)
                    )
                    value_states = (
                        attn_module.v_proj(hidden_states)
                        .reshape(bsz, seq_length, attn_module.num_heads, -1)
                        .transpose(1, 2)
                    )

                    attn_weights = torch.matmul(query_states, key_states.transpose(2, 3)) * attn_module.scaling

                    if attention_mask is not None:
                        attn_weights = attn_weights + attention_mask

                    attn_weights = torch.nn.functional.softmax(attn_weights, dim=-1, dtype=torch.float32).to(
                        query_states.dtype
                    )

                    attn_output = torch.matmul(attn_weights, value_states)
                    attn_output = attn_output.transpose(1, 2).contiguous().reshape(bsz, seq_length, -1)
                    attn_output = attn_module.out_proj(attn_output)
                    return attn_output

                return patched_attn_forward

            attn.forward = make_patched_attn_forward(attn)

            layer._orig_forward = layer.forward

            def make_patched_layer_forward(enc_layer):
                def patched_layer_forward(hidden_states, cu_seqlens=None, attention_mask=None, **kwargs):
                    residual = hidden_states
                    hidden_states = enc_layer.self_attn_layer_norm(hidden_states)
                    hidden_states = enc_layer.self_attn(hidden_states=hidden_states, attention_mask=attention_mask)
                    hidden_states = residual + hidden_states
                    residual = hidden_states
                    hidden_states = enc_layer.final_layer_norm(hidden_states)
                    hidden_states = enc_layer.fc1(hidden_states)
                    hidden_states = enc_layer.activation_fn(hidden_states)
                    hidden_states = enc_layer.fc2(hidden_states)
                    hidden_states = residual + hidden_states
                    return (hidden_states,)

                return patched_layer_forward

            layer.forward = make_patched_layer_forward(layer)

        def audio_forward(
            self,
            padded_feature: torch.Tensor,
            padded_mask_after_cnn: torch.Tensor,
            aftercnn_lens: torch.Tensor,
            cu_seqlens: torch.Tensor = None,
        ) -> torch.Tensor:
            # Uses 3D batched attention with masks instead of cu_seqlens (Qwen3ASR pattern).
            # This avoids the correctness bug where cu_seqlens calculated for compacted
            # representation was applied to flattened padded embeddings.
            padded_feature = padded_feature.unsqueeze(1)
            padded_embed = torch.nn.functional.gelu(self.conv2d1(padded_feature))
            padded_embed = torch.nn.functional.gelu(self.conv2d2(padded_embed))
            padded_embed = torch.nn.functional.gelu(self.conv2d3(padded_embed))
            b, c, f, t = padded_embed.size()
            padded_embed = self.conv_out(padded_embed.permute(0, 3, 1, 2).contiguous().view(b, t, c * f))

            positional_embedding = (
                self.positional_embedding.positional_embedding[: padded_embed.shape[1], :]
                .unsqueeze(0)
                .to(padded_embed.dtype)
            )
            padded_embed = padded_embed + positional_embedding

            hidden_states = padded_embed

            # Create attention mask from padding mask: masked positions get -inf
            # Shape: (batch, 1, 1, time) for broadcasting across heads and query positions
            attention_mask = (~padded_mask_after_cnn.bool()).float()
            attention_mask = attention_mask.masked_fill(attention_mask.bool(), float("-inf"))
            attention_mask = attention_mask.unsqueeze(1).unsqueeze(2)

            for encoder_layer in self.layers:
                layer_outputs = encoder_layer(hidden_states, attention_mask=attention_mask)
                hidden_states = layer_outputs[0]

            hidden_states = self.ln_post(hidden_states)
            hidden_states = self.proj1(hidden_states)
            hidden_states = self.act(hidden_states)
            hidden_states = self.proj2(hidden_states)

            # Zero out padding positions as defense-in-depth
            hidden_states = hidden_states * padded_mask_after_cnn.to(hidden_states.dtype).unsqueeze(-1)
            return hidden_states

        model.forward = types.MethodType(audio_forward, model)
        super().__init__(config, model, model_kwargs)

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)
        self._model.forward = self._model.__orig_forward

        if hasattr(self._model.config, "_orig_attn_implementation"):
            self._model.config._attn_implementation = self._model.config._orig_attn_implementation
            del self._model.config._orig_attn_implementation

        for layer in self._model.layers:
            if hasattr(layer, "_orig_forward"):
                layer.forward = layer._orig_forward
                del layer._orig_forward
            if hasattr(layer.self_attn, "_orig_forward"):
                layer.self_attn.forward = layer.self_attn._orig_forward
                del layer.self_attn._orig_forward
            if hasattr(layer.self_attn.config, "_orig_attn_implementation"):
                layer.self_attn.config._attn_implementation = layer.self_attn.config._orig_attn_implementation
                del layer.self_attn.config._orig_attn_implementation


class _Qwen3OmniMoeLMPatcherMixin:
    # Subclasses assign `_moe_block_cls` and `_patched_moe_forward` in their own __init__
    # before calling super().__init__ — referenced class-body values wouldn't resolve because
    # the transformers MoE block classes live behind a version gate and the patched forward
    # functions are defined later in this module.

    def __enter__(self):
        super().__enter__()
        # Patch MoE forward to avoid .nonzero() which breaks tracing.
        self._original_moe_forward = self._moe_block_cls.forward
        self._moe_block_cls.forward = self._patched_moe_forward

    def __exit__(self, exc_type, exc_value, traceback):
        self._moe_block_cls.forward = self._original_moe_forward
        super().__exit__(exc_type, exc_value, traceback)


class Qwen3OmniMoeLanguageModelPatcher(_Qwen3OmniMoeLMPatcherMixin, OVDecoderModelPatcher):
    def __init__(
        self,
        config: "OpenVINOConfig",
        model: "PreTrainedModel",
        model_kwargs: Optional[Dict[str, Any]] = None,
    ):
        # Transformers 5.0 fuses the routed experts into a single `Qwen3OmniMoeThinkerTextExperts`
        # module backed by parameter tensors, so we patch it with the batched-matmul (bmm) forward
        # that avoids the untraceable `.nonzero()` / Python expert loop.
        from transformers.models.qwen3_omni_moe.modeling_qwen3_omni_moe import (
            Qwen3OmniMoeThinkerTextExperts,
        )

        self._moe_block_cls = Qwen3OmniMoeThinkerTextExperts
        self._patched_moe_forward = lfm2_moe_experts_forward

        # Talker consumes one intermediate layer's hidden state; layer index comes from talker_config.
        # Modified from: https://github.com/huggingface/transformers/blob/v5.0.0/src/transformers/models/qwen3_omni_moe/modeling_qwen3_omni_moe.py#L2603
        # (changed to return logits, hidden_states, intermediate_hidden_states, past_key_values)
        accept_hidden_layer = model.config.talker_config.accept_hidden_layer

        def lm_forward(
            self,
            attention_mask,
            position_ids,
            past_key_values,
            inputs_embeds,
            visual_pos_masks,
            deepstack_visual_embeds,
            use_cache=True,
        ):
            pkv = DynamicCache(past_key_values)
            outputs = self.thinker.model(
                inputs_embeds=inputs_embeds,
                attention_mask=attention_mask,
                position_ids=position_ids,
                use_cache=use_cache,
                past_key_values=pkv,
                visual_pos_masks=visual_pos_masks,
                deepstack_visual_embeds=deepstack_visual_embeds,
                output_hidden_states=True,
            )
            hidden_states = outputs[0]
            logits = self.thinker.lm_head(hidden_states)
            pkv_tuple = postprocess_past_key_values(outputs.past_key_values)
            intermediate_hidden_states = outputs.hidden_states[accept_hidden_layer]
            return (logits, hidden_states, intermediate_hidden_states, pkv_tuple)

        model.__orig_forward = model.forward
        model.forward = types.MethodType(lm_forward, model)

        thinker_model = model.thinker.model
        thinker_model.__orig_deepstack_process = thinker_model._deepstack_process
        thinker_model._deepstack_process = types.MethodType(_deepstack_process_patched, thinker_model)

        super().__init__(config, model, model_kwargs)

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)
        self._model.forward = self._model.__orig_forward
        thinker_model = self._model.thinker.model
        thinker_model._deepstack_process = thinker_model.__orig_deepstack_process


class Qwen3OmniMoeTalkerLanguageModelPatcher(_Qwen3OmniMoeLMPatcherMixin, OVDecoderModelPatcher):
    def __init__(
        self,
        config: "OpenVINOConfig",
        model: "PreTrainedModel",
        model_kwargs: Optional[Dict[str, Any]] = None,
    ):
        from transformers.models.qwen3_omni_moe.modeling_qwen3_omni_moe import (
            Qwen3OmniMoeTalkerTextExperts,
        )

        self._moe_block_cls = Qwen3OmniMoeTalkerTextExperts
        self._patched_moe_forward = lfm2_moe_experts_forward

        # Modified from: https://github.com/huggingface/transformers/blob/v5.0.0/src/transformers/models/qwen3_omni_moe/modeling_qwen3_omni_moe.py#L2390
        # (changed to return logits, hidden_states, past_key_values tuple)
        def lm_forward(self, inputs_embeds, attention_mask, position_ids, past_key_values, use_cache=True):
            pkv = DynamicCache(past_key_values)
            outputs = self.talker.model(
                inputs_embeds=inputs_embeds,
                attention_mask=attention_mask,
                position_ids=position_ids,
                use_cache=use_cache,
                past_key_values=pkv,
            )
            hidden_states = outputs[0]
            logits = self.talker.codec_head(hidden_states)
            return (logits, hidden_states, postprocess_past_key_values(outputs.past_key_values))

        model.__orig_forward = model.forward
        model.forward = types.MethodType(lm_forward, model)
        super().__init__(config, model, model_kwargs)

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)
        self._model.forward = self._model.__orig_forward


class Qwen3OmniMoeCodePredictorPatcher(OVDecoderModelPatcher):
    # Single-step CodePredictor graph: one call runs one inner step and grows the KV cache.
    # The Python-side loop (OVCodePredictorDecoder) invokes it num_code_groups-1 times.
    # This replaces the earlier fully-unrolled graph, whose num_code_groups-1 inlined transformer
    # forwards each allocated their own FP32 activations, ballooning peak device memory (~4.5 GiB
    # for a single component). A single-step stateful graph keeps peak activations at ~1x.
    # Sampling stays in-graph via the Gumbel-max trick (argmax(logits + Gumbel(0,1)) ~ Categorical),
    # because the sampled code must be turned back into a codec embedding within the same call to
    # feed the next step; a per-call int64 seed keeps runs reproducible.
    # Based on: https://github.com/huggingface/transformers/blob/v5.0.0/src/transformers/models/qwen3_omni_moe/modeling_qwen3_omni_moe.py#L2229
    # (modified for OpenVINO: single-step stateful graph + in-graph sampling)

    def __init__(
        self,
        config: "OpenVINOConfig",
        model: "PreTrainedModel",
        model_kwargs: Optional[Dict[str, Any]] = None,
    ):
        code_predictor = model.talker.code_predictor
        # Dummy inputs are float32; upcasting the module avoids dtype mismatches during tracing.
        code_predictor.float()

        # Per-step lm_head / codec_embedding are selected by a runtime `step` index, so their
        # weights are stacked into a single tensor that index_select can gather from during tracing.
        stacked_heads = torch.stack([head.weight for head in code_predictor.lm_head])
        stacked_codec_embeds = torch.stack([emb.weight for emb in code_predictor.model.codec_embedding])

        def _seeded_uniform(seed, shape, dtype, device):
            # Traceable PRNG: pure arithmetic on the seed tensor, no CPU fallback.
            # Emits a (0, 1) uniform tensor of the requested shape; identical seeds
            # produce identical draws run to run, independent of batch or device state.
            idx = torch.arange(shape[-1], device=device, dtype=torch.float32)
            seed_f = seed.to(torch.float32)
            # Two-term hash keeps correlations low across adjacent indices.
            raw = torch.sin(seed_f * 12.9898 + idx * 78.233) * 43758.5453
            u = raw - torch.floor(raw)  # fractional part ~ uniform(0, 1)
            return u.clamp(min=1e-20, max=1.0 - 1e-20).to(dtype).expand(shape)

        def _gumbel_sample(logits, top_k, seed):
            # argmax(logits + Gumbel(0,1)) ~ Categorical(softmax(logits)). Top-k masking uses
            # sort + index_select so top_k can be a runtime int64 tensor (torch.topk requires
            # a Python int for k, which breaks tracing).
            sorted_logits, _ = torch.sort(logits, dim=-1, descending=True)
            top_k_idx = torch.clamp(top_k.reshape(1) - 1, min=0)
            threshold = torch.index_select(sorted_logits, -1, top_k_idx)
            logits = torch.where(logits < threshold, torch.full_like(logits, float("-inf")), logits)
            u = _seeded_uniform(seed, logits.shape, logits.dtype, logits.device)
            gumbel = -torch.log(-torch.log(u))
            return (logits + gumbel).argmax(dim=-1)

        def cp_forward(
            self,
            inputs_embeds,
            attention_mask,
            position_ids,
            step,
            seed,
            temperature,
            top_k,
            past_key_values=None,
            **kwargs,
        ):
            # inputs_embeds: prefill [B, 2, hidden] = concat(prefix_hidden[:, -1:], first_code_embed),
            #                decode  [B, 1, hidden] = previous step's codec embedding.
            # step: scalar int64 index into lm_head / codec_embedding; seed: scalar int64;
            # temperature: scalar float32; top_k: scalar int64.

            # KV cache passed in as legacy tuples; wrapped for the Transformers 5.x DynamicCache API.
            pkv = DynamicCache(past_key_values)

            outputs = self.talker.code_predictor.model(
                inputs_embeds=inputs_embeds,
                attention_mask=attention_mask,
                position_ids=position_ids,
                use_cache=True,
                past_key_values=pkv,
            )
            hidden_states = outputs.last_hidden_state
            present = postprocess_past_key_values(outputs.past_key_values)

            # Gather the per-step lm_head / codec_embedding weights via the runtime step index.
            step_idx = step.reshape(1)
            head_weight = torch.index_select(stacked_heads, 0, step_idx).squeeze(0)
            embed_weight = torch.index_select(stacked_codec_embeds, 0, step_idx).squeeze(0)

            # Original: self.lm_head[step](hidden_states), then torch.multinomial() sampling.
            step_logits = torch.nn.functional.linear(hidden_states[:, -1, :], head_weight)
            step_logits = step_logits / torch.clamp(temperature, min=1e-6)
            token = _gumbel_sample(step_logits, top_k, seed)

            # Original: self.model.codec_embedding[step](token). Emitted so the caller can both
            # feed it as the next step's input and accumulate it into codec_hiddens_sum.
            token_embed = torch.nn.functional.embedding(token, embed_weight).unsqueeze(1)
            code = token.unsqueeze(-1)  # [B, 1]
            return (code, token_embed, present)

        model.__orig_forward = model.forward
        model.forward = types.MethodType(cp_forward, model)
        super().__init__(config, model, model_kwargs)

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)
        self._model.forward = self._model.__orig_forward


class DeepseekOCR2LMPatcher(OVDecoderModelPatcher):
    """Language-model patcher for DeepSeek-OCR-2 (model_type ``deepseek_ocr2``).

    The exported model is ``DeepseekOcr2ForConditionalGeneration`` whose ``forward`` runs the
    vision branch and merges image features. For the text-generation part we drive only the
    underlying ``DeepseekOcr2TextModel`` (a standard MHA/GQA decoder with cos/sin RoPE) from
    ``inputs_embeds`` and apply ``lm_head``, bypassing the vision code entirely.
    """

    def __init__(
        self,
        config: "OpenVINOConfig",
        model: "PreTrainedModel",
        model_kwargs: Dict[str, Any] = None,
    ):
        def lm_forward(
            self,
            attention_mask,
            position_ids=None,
            past_key_values=None,
            inputs_embeds=None,
            input_ids=None,
            use_cache=True,
        ):
            pkv = DynamicCache(past_key_values)
            outputs = self.model.language_model(
                input_ids=None,
                inputs_embeds=inputs_embeds,
                attention_mask=attention_mask,
                position_ids=position_ids,
                past_key_values=pkv,
                use_cache=use_cache,
            )
            hidden_states = outputs[0]
            logits = self.lm_head(hidden_states)
            return (logits, postprocess_past_key_values(outputs.past_key_values))

        model.__orig_forward = model.forward
        model.forward = types.MethodType(lm_forward, model)
        super().__init__(config, model, model_kwargs)

    def __enter__(self):
        super().__enter__()
        # Route the MoE experts through the OpenVINO-friendly batched-matmul implementation.
        register_ov_batched_mm(self)
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)
        self._model.forward = self._model.__orig_forward


class DeepseekOCR2VisionEmbeddingsPatcher(ModelPatcher):
    """Vision-encoder patcher for DeepSeek-OCR-2 (model_type ``deepseek_ocr2``).

    Exposes the composed ``multi_modal_projector(vision_tower(pixel_values))`` pipeline as the
    traced forward, returning ``{"last_hidden_state": embeds}``. Two streams exist with
    different (static) input sizes: the 1024x1024 global view (256 query tokens) and the
    768x768 crop tiles (144 query tokens).
    """

    def __init__(
        self,
        config: "OpenVINOConfig",
        model: "PreTrainedModel",
        model_kwargs: Dict[str, Any],
    ):
        super().__init__(config, model, model_kwargs)
        vision_root = model.model if hasattr(model, "model") else model
        output_name = list(config.outputs.keys())[0]

        def patched_forward(pixel_values):
            vision_outputs = vision_root.vision_tower(pixel_values)
            embeds = vision_root.multi_modal_projector(vision_outputs.last_hidden_state)
            return {output_name: embeds}

        self.patched_forward = patched_forward


class Qwen3OmniMoeCode2WavPatcher(ModelPatcher):
    def __init__(
        self,
        config: "OpenVINOConfig",
        model: "PreTrainedModel",
        model_kwargs: Optional[Dict[str, Any]] = None,
    ):
        super().__init__(config, model, model_kwargs=model_kwargs or {})
        self._orig_get_extra_padding = None

    def __enter__(self):
        super().__enter__()
        # Override Qwen3OmniMoeCausalConvNet._get_extra_padding_for_conv1d: the original uses math.ceil
        # on dynamic shapes which can't be traced. For every Code2Wav conv config, extra_padding == 0.
        # Original: https://github.com/huggingface/transformers/blob/v5.0.0/src/transformers/models/qwen3_omni_moe/modeling_qwen3_omni_moe.py#L1127
        import transformers.models.qwen3_omni_moe.modeling_qwen3_omni_moe as qwen3_omni_moe_module

        self._orig_get_extra_padding = qwen3_omni_moe_module.Qwen3OmniMoeCausalConvNet._get_extra_padding_for_conv1d
        qwen3_omni_moe_module.Qwen3OmniMoeCausalConvNet._get_extra_padding_for_conv1d = lambda self, hidden_state: 0
        # Code2Wav extends ModelPatcher (not OVDecoderModelPatcher), so the 5.x-safe mask wrappers
        # that handle the transformers 5.x `q_length`/`q_offset` signature are not registered by the
        # base class. Register them here so the Code2Wav attention layers trace under 5.x.
        ALL_MASK_ATTENTION_FUNCTIONS.register("eager", eager_mask_without_vmap)
        ALL_MASK_ATTENTION_FUNCTIONS.register("sdpa", eager_mask_without_vmap)

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)
        if self._orig_get_extra_padding is not None:
            import transformers.models.qwen3_omni_moe.modeling_qwen3_omni_moe as qwen3_omni_moe_module

            qwen3_omni_moe_module.Qwen3OmniMoeCausalConvNet._get_extra_padding_for_conv1d = (
                self._orig_get_extra_padding
            )


# copied from https://github.com/huggingface/transformers/blob/v4.47.1/src/transformers/models/granitemoe/modeling_granitemoe.py#L321
def _granite_moe_topk_gating_forward(self, hidden_states):
    # compute the top_k routing decision
    logits = self.layer(hidden_states).float()  # [batch_size x seq_len, num_experts]
    top_k_logits, top_k_indices = logits.topk(self.top_k, dim=1)  # [num_tokens, top_k]
    top_k_gates = torch.softmax(top_k_logits, dim=1).type_as(hidden_states)  # [num_tokens, top_k]

    # compute number of input given to each expert
    zeros = torch.zeros(
        [top_k_gates.size(0), self.num_experts], dtype=top_k_gates.dtype, device=top_k_gates.device
    )  # [num_tokens, num_experts]
    gates = zeros.scatter(1, top_k_indices, 1)  # [num_tokens, num_experts]
    expert_size = gates.long().sum(0)  # [num_experts,]
    # difference with original, removed expert_size = expert_size.tolist() due to incorrect tracing

    # sort and group input tokens according to expert assignment
    top_k_experts = top_k_indices.flatten()  # [num_tokens * top_k]
    _, index_sorted_experts = top_k_experts.sort(0)  # [num_tokens * top_k]
    batch_index = index_sorted_experts.div(self.top_k, rounding_mode="trunc")  # [num_tokens * top_k]

    # gather the gate values for grouped input tokens
    top_k_gates = top_k_gates.flatten()  # [num_tokens * top_k]
    batch_gates = top_k_gates[index_sorted_experts]  # [num_tokens * top_k]

    return index_sorted_experts, batch_index, batch_gates, expert_size, logits


# copied from https://github.com/huggingface/transformers/blob/v4.47.1/src/transformers/models/granitemoe/modeling_granitemoe.py#L281
def _granite_moe_parallel_experts_forward(self, inputs, expert_size):
    output_list = []
    # difference with original
    # 1) expert_size is tensor instead of list of ints after gating patching, that does not allow use original inputs.split(expert_size)
    # 2) use index_start:next_index for obtaining expert inputs splits one by one instead of precomputed splits once before cycle
    index_start = torch.tensor(0, dtype=torch.int64)
    for i in range(self.num_experts):
        next_index = index_start + expert_size[i]
        output_list.append(F.linear(inputs[index_start:next_index], self.weight[i]))
        index_start = next_index
    results = torch.cat(output_list, dim=0)
    return results


class GraniteMoEModelPatcher(OVDecoderModelPatcher):
    def __enter__(self):
        super().__enter__()

        for layer in self._model.model.layers:
            block_sparse_moe = layer.block_sparse_moe
            block_sparse_moe.router._orig_forward = block_sparse_moe.router.forward
            block_sparse_moe.router.forward = types.MethodType(
                _granite_moe_topk_gating_forward, block_sparse_moe.router
            )
            block_sparse_moe.input_linear._orig_forward = block_sparse_moe.input_linear.forward
            block_sparse_moe.input_linear.forward = types.MethodType(
                _granite_moe_parallel_experts_forward, block_sparse_moe.input_linear
            )
            block_sparse_moe.output_linear._orig_forward = block_sparse_moe.output_linear.forward
            block_sparse_moe.output_linear.forward = types.MethodType(
                _granite_moe_parallel_experts_forward, block_sparse_moe.output_linear
            )

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)

        for layer in self._model.model.layers:
            block_sparse_moe = layer.block_sparse_moe
            block_sparse_moe.router.forward = block_sparse_moe.router._orig_forward
            block_sparse_moe.input_linear.forward = block_sparse_moe.input_linear._orig_forward
            block_sparse_moe.output_linear.forward = block_sparse_moe.output_linear._orig_forward


class OVSeq2SeqModelPatcher(ModelPatcher):
    def __init__(
        self,
        config: "OpenVINOConfig",
        model: "PreTrainedModel",
        model_kwargs: Optional[Dict[str, Any]] = None,
    ):
        super().__init__(config, model, model_kwargs)

        # re-use the patched forward method from the parent class
        self.super_patched_forward = self.patched_forward

        @functools.wraps(self.super_patched_forward)
        def patched_forward(*args, **kwargs):
            signature = inspect.signature(self.super_patched_forward)
            args, kwargs = override_arguments(args, kwargs, signature, model_kwargs=self.model_kwargs)

            # with statful decoder, we always return the self attn only, cross attn is part of the state
            if (
                getattr(self.real_config, "stateful", False)
                and self.real_config._behavior == "decoder"
                and "past_key_values" in signature.parameters
            ):
                pkv = None
                pkv_arg_index = list(signature.parameters.keys()).index("past_key_values")

                if "past_key_values" in kwargs:
                    pkv = kwargs["past_key_values"]
                elif len(args) > pkv_arg_index:
                    pkv = args[pkv_arg_index]

                if pkv is not None:
                    if isinstance(pkv, EncoderDecoderCache):
                        pkv = postprocess_past_key_values(pkv.self_attention_cache)
                    else:
                        pkv = [pkv_item[:2] for pkv_item in pkv]

                    if is_transformers_version("<", "5"):
                        pkv = EncoderDecoderCache.from_legacy_cache(pkv)
                    else:
                        pkv = EncoderDecoderCache(DynamicCache(pkv), DynamicCache())

                    if "past_key_values" in kwargs:
                        kwargs["past_key_values"] = pkv
                    elif len(args) > pkv_arg_index:
                        args[pkv_arg_index] = pkv

            outputs = self.super_patched_forward(*args, **kwargs)

            # the seq2seq model patcher only converts to tuple starting from 4.48
            if isinstance(outputs.get("past_key_values"), (DynamicCache, EncoderDecoderCache)):
                outputs["past_key_values"] = postprocess_past_key_values(outputs["past_key_values"])

            # we still need to filter out cross attention in the case of non-stateful decoder
            filtered_outputs = {}
            for name, value in outputs.items():
                if (
                    self.real_config._behavior == "decoder"
                    and self.real_config.use_past_in_inputs
                    and name.startswith("past_key_values")
                ):
                    filtered_outputs[name] = tuple([v[:2] for v in value])
                else:
                    filtered_outputs[name] = value
            return filtered_outputs

        self.patched_forward = patched_forward

    def __enter__(self):
        super().__enter__()

        # for OpenVINO, we use torch.finfo(torch.float16).min instead of torch.finfo(dtype).min
        # to avoid overflow issues on some hardware (e.g. Intel NPU)
        ALL_MASK_ATTENTION_FUNCTIONS.register("eager", eager_mask_without_vmap)

        # for decoder models, we use eager mask without vmap for sdpa as well
        # to avoid a nan output issue in OpenVINO that only happens in case of:
        # non-stateful models on cpu and stateful models on npu
        ALL_MASK_ATTENTION_FUNCTIONS.register("sdpa", eager_mask_without_vmap)

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)

        ALL_MASK_ATTENTION_FUNCTIONS.register("sdpa", sdpa_mask)
        ALL_MASK_ATTENTION_FUNCTIONS.register("eager", eager_mask)


class SanaTextEncoderModelPatcher(ModelPatcher):
    def __enter__(self):
        super().__enter__()

        self._model.config._orig_attn_implementation = self._model.config._attn_implementation
        self._model.config._attn_implementation = "sdpa"

        # starting from 4.53, we get unmatching outputs if we use the boolean mask
        # TODO: This is an openvino issue (inconsistency between boolean and float masks)
        ALL_MASK_ATTENTION_FUNCTIONS.register("sdpa", eager_mask_without_vmap)

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)

        self._model.config._attn_implementation = self._model.config._orig_attn_implementation
        del self._model.config._orig_attn_implementation

        # remove the eager_mask_without_vmap from the ALL_MASK_ATTENTION_FUNCTIONS
        ALL_MASK_ATTENTION_FUNCTIONS.register("sdpa", sdpa_mask)


class MiniCPMModelPatcher(OVDecoderModelPatcher):
    def __init__(
        self,
        config: "OpenVINOConfig",
        model: "PreTrainedModel",
        model_kwargs: Optional[Dict[str, Any]] = None,
    ):
        for layer in model.model.layers:
            if hasattr(layer, "scale_depth"):
                layer.self_attn.o_proj.to(torch.float32)
                layer.mlp.down_proj.to(torch.float32)

        super().__init__(config, model, model_kwargs)


class CommonImageEmbeddingsModelPatcher(ModelPatcher):
    def __init__(
        self,
        config: "OpenVINOConfig",
        model: "PreTrainedModel",
        model_kwargs: Dict[str, Any],
    ):
        super().__init__(config, model, model_kwargs)

        @functools.wraps(self.orig_forward)
        def patched_forward(*args, **kwargs):
            # Adapted from https://github.com/huggingface/transformers/blob/v4.49.0/src/transformers/models/got_ocr2/modeling_got_ocr2.py#L835
            # Adapted from https://github.com/huggingface/transformers/blob/v4.49.0-Gemma-3/src/transformers/models/gemma3/modeling_gemma3.py#L1321
            if (
                hasattr(self._model, "model")
                and hasattr(self._model.model, "get_image_features")
                and is_transformers_version("<", "5")
            ):
                get_image_features = self._model.model.get_image_features
            else:
                get_image_features = self._model.get_image_features

            outputs = get_image_features(*args, **kwargs)

            # we should be able to specify pooler_output as output_name, not supported here as pooler_output key does not exist
            if is_transformers_version(">=", "5") and hasattr(outputs, "pooler_output"):
                outputs = outputs.pooler_output

            output_names = list(config.outputs.keys())
            return {output_names[0]: outputs}

        self.patched_forward = patched_forward


class Gemma3LMModelPatcher(OVDecoderModelPatcher):
    def __init__(
        self,
        config: "OpenVINOConfig",
        model: "PreTrainedModel",
        model_kwargs: Optional[Dict[str, Any]] = None,
    ):
        super().__init__(config, model, model_kwargs)

        model_forward = self.orig_forward

        # precompute the token_type_ids bidirectional (image) mask since transformers v5.6
        # (https://github.com/huggingface/transformers/pull/45454) is_first_iteration removed
        # in create_causal_mask_mapping
        @functools.wraps(model_forward)
        def forward_with_precomputed_mask(*args, **kwargs):
            bound_args = inspect.signature(model_forward).bind(*args, **kwargs)
            bound_args.apply_defaults()
            inputs_embeds = bound_args.arguments.get("inputs_embeds")
            token_type_ids = bound_args.arguments.get("token_type_ids")
            attention_mask = bound_args.arguments.get("attention_mask")
            if token_type_ids is not None and isinstance(attention_mask, torch.Tensor):
                sliding_window = self._model.config.get_text_config().sliding_window
                bound_args.arguments["attention_mask"] = _create_gemma4_unified_bidirectional_mask_dict(
                    attention_mask, token_type_ids, inputs_embeds, sliding_window
                )
            return model_forward(*bound_args.args, **bound_args.kwargs)

        self.orig_forward = forward_with_precomputed_mask

    def __enter__(self):
        super().__enter__()

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)


# Forward method of the language model of Gemma3n, needs to be patched to pass 'per_layer_inputs',
# as original code fails to create per_layer_inputs without the providing of input_ids,
# while OV language model expects only inputs_embeds without input_ids.
# Original code: https://github.com/huggingface/transformers/blob/v5.0.0/src/transformers/models/gemma3n/modeling_gemma3n.py#L2016
def gemma3n_language_model_forward(
    self,
    input_ids: Optional[torch.LongTensor] = None,  # text inputs
    pixel_values: Optional[torch.FloatTensor] = None,  # vision inputs
    input_features: Optional[torch.FloatTensor] = None,  # audio inputs
    attention_mask: Optional[torch.Tensor] = None,
    input_features_mask: Optional[torch.Tensor] = None,
    position_ids: Optional[torch.LongTensor] = None,
    past_key_values: Optional[Cache] = None,
    mm_token_type_ids: Optional[torch.LongTensor] = None,
    cache_position: Optional[torch.LongTensor] = None,
    inputs_embeds: Optional[torch.FloatTensor] = None,
    labels: Optional[torch.LongTensor] = None,
    use_cache: Optional[bool] = None,
    output_attentions: Optional[bool] = None,
    output_hidden_states: Optional[bool] = None,
    per_layer_inputs=None,
    **lm_kwargs,
):
    if (input_ids is None) ^ (inputs_embeds is not None):
        raise ValueError("You must specify exactly one of input_ids or inputs_embeds")

    output_attentions = output_attentions if output_attentions is not None else self.config.output_attentions
    output_hidden_states = (
        output_hidden_states if output_hidden_states is not None else self.config.output_hidden_states
    )

    # Merge text and images
    if pixel_values is not None:
        image_features = self.get_image_features(pixel_values)
        image_features = image_features.to(inputs_embeds.device, inputs_embeds.dtype)
        special_image_mask, _ = self.get_placeholder_mask(
            input_ids, inputs_embeds=inputs_embeds, image_features=image_features
        )
        inputs_embeds = inputs_embeds.masked_scatter(special_image_mask, image_features)

    # Merge text and audio
    if input_features is not None and input_features_mask is not None:
        audio_features, audio_mask = self.get_audio_features(input_features, ~input_features_mask)

        # The Gemma3nProcessor expects all audio to be 30s in length and inserts 188 audio soft tokens into the
        # text to account for this. However, the audio preprocessing and encoder do not guarantee they will
        # produce 188 soft tokens; they will produce at most that many tokens, but they may produce fewer tokens
        # depending on the length of the longest audio input in the batch. When we encounter this situation, we pad
        # the audio feature out to 188 soft tokens with the embedding of the last token in the embed_audio vocab.
        audio_padding_toks = torch.tensor([[self.vocab_size - 1]], dtype=torch.long, device=audio_features.device)
        audio_padding_embs = self.embed_audio(input_ids=audio_padding_toks)
        audio_features = torch.where(audio_mask.unsqueeze(-1), audio_padding_embs, audio_features)

        audio_batch_size, audio_seq_len, audio_embed_dim = audio_features.shape
        extra_padding_tokens = self.config.audio_soft_tokens_per_image - audio_seq_len
        extra_padding_features = audio_padding_embs.expand(audio_batch_size, extra_padding_tokens, audio_embed_dim)

        audio_features = torch.cat((audio_features, extra_padding_features), dim=1)
        audio_features = audio_features.to(inputs_embeds.device, inputs_embeds.dtype)
        _, special_audio_mask = self.get_placeholder_mask(
            input_ids, inputs_embeds=inputs_embeds, audio_features=audio_features
        )
        inputs_embeds = inputs_embeds.masked_scatter(special_audio_mask, audio_features)

    language_model = self.language_model if hasattr(self, "language_model") else self.model.language_model
    outputs = language_model(
        input_ids=None,
        per_layer_inputs=per_layer_inputs,
        attention_mask=attention_mask,
        position_ids=position_ids,
        past_key_values=past_key_values,
        inputs_embeds=inputs_embeds,
        use_cache=use_cache,
        output_attentions=output_attentions,
        output_hidden_states=output_hidden_states,
        cache_position=cache_position,
        **lm_kwargs,
    )
    return outputs


# Creates a dict of causal masks with bidirectional attention for vision tokens
# on sliding_attention layers, matching the behavior of transformers
# create_causal_mask_mapping when use_bidirectional_attention == "vision".
# Needs to be patched to pass proper 'sliding_mask' for prefill stage.
# Original code: https://github.com/huggingface/transformers/blob/v5.5.0/src/transformers/models/gemma4/modeling_gemma4.py#L1986
def _create_gemma4_bidirectional_mask_dict(attention_mask_2d, mm_token_type_ids, inputs_embeds, sliding_window):
    dtype = inputs_embeds.dtype
    device = inputs_embeds.device
    min_dtype = torch.finfo(dtype).min

    batch_size = inputs_embeds.shape[0]
    seq_len = inputs_embeds.shape[1]
    target_len = attention_mask_2d.shape[-1]
    past_len = target_len - seq_len

    # Standard causal mask [seq_len, target_len]
    causal_mask = torch.full((seq_len, target_len), min_dtype, dtype=dtype, device=device)
    causal_mask = torch.triu(causal_mask, diagonal=past_len + 1)

    # Apply padding from attention_mask_2d
    padding_mask = (1.0 - attention_mask_2d[:, None, None, :].to(dtype=dtype, device=device)) * min_dtype
    full_mask = causal_mask[None, None, :, :].expand(batch_size, 1, -1, -1) + padding_mask
    mm_token_type_ids = torch.nn.functional.pad(
        mm_token_type_ids, (0, target_len - mm_token_type_ids.shape[-1]), value=0
    )

    # Sliding window causal mask
    sliding_mask = full_mask.clone()
    row_pos = torch.arange(seq_len, device=device).unsqueeze(1) + past_len
    col_pos = torch.arange(target_len, device=device).unsqueeze(0)
    beyond_window = (row_pos - col_pos) >= sliding_window
    sliding_mask = sliding_mask.masked_fill(beyond_window[None, None, :, :], min_dtype)

    # Apply bidirectional masking for vision tokens (only on sliding_attention mask)
    # mm_token_type_ids: [batch, total_len] - 0=text, 1=image, 2=video/audio
    is_vision = (mm_token_type_ids == 1) | (mm_token_type_ids == 2)

    # Group contiguous vision tokens (trace-friendly, no in-place ops)
    # Shift is_vision right by 1 position, padding with False on the left
    is_prev_vision = torch.nn.functional.pad(is_vision[:, :-1].to(dtype=torch.int32), (1, 0), value=0).bool()
    new_vision_starts = is_vision & ~is_prev_vision
    vision_group_ids = torch.cumsum(new_vision_starts.to(dtype=torch.int32), dim=1) - 1
    vision_group_ids = torch.where(is_vision, vision_group_ids, torch.tensor(-1, dtype=torch.int32, device=device))

    # Query group IDs correspond to positions [past_len : past_len + seq_len]
    query_groups = vision_group_ids[:, past_len : past_len + seq_len]  # [batch, seq_len]
    key_groups = vision_group_ids  # [batch, total_len]

    # same_group[b, q, k] = True iff query and key are in the same non-text vision group
    same_group = (query_groups.unsqueeze(2) == key_groups.unsqueeze(1)) & (key_groups.unsqueeze(1) >= 0)
    same_group = same_group.unsqueeze(1)  # [batch, 1, seq_len, total_len]

    # Undo masking for same-group vision tokens in sliding mask
    sliding_mask = sliding_mask.masked_fill(same_group, 0.0)

    return {
        "full_attention": full_mask,
        "sliding_attention": sliding_mask,
    }


# Forward method of the language model of Gemma4, needs to be patched to pass 'per_layer_inputs',
# as original code fails to create per_layer_inputs without the providing of input_ids,
# while OV language model expects only inputs_embeds without input_ids.
# Original code: https://github.com/huggingface/transformers/blob/v5.5.0/src/transformers/models/gemma4/modeling_gemma4.py#L2152
def gemma4_language_model_forward(
    self,
    input_ids: Optional[torch.LongTensor] = None,
    pixel_values: Optional[torch.FloatTensor] = None,
    pixel_values_videos: Optional[torch.FloatTensor] = None,
    input_features: Optional[torch.FloatTensor] = None,
    attention_mask: Optional[torch.Tensor] = None,
    input_features_mask: Optional[torch.Tensor] = None,
    position_ids: Optional[torch.LongTensor] = None,
    past_key_values: Optional[Cache] = None,
    mm_token_type_ids: Optional[torch.LongTensor] = None,
    cache_position: Optional[torch.LongTensor] = None,
    inputs_embeds: Optional[torch.FloatTensor] = None,
    labels: Optional[torch.LongTensor] = None,
    use_cache: Optional[bool] = None,
    output_attentions: Optional[bool] = None,
    output_hidden_states: Optional[bool] = None,
    per_layer_inputs=None,
    **lm_kwargs,
):
    from transformers.models.gemma4.modeling_gemma4 import Gemma4ModelOutputWithPast

    if (input_ids is None) ^ (inputs_embeds is not None):
        raise ValueError("You must specify exactly one of input_ids or inputs_embeds")

    output_attentions = output_attentions if output_attentions is not None else self.config.output_attentions
    output_hidden_states = (
        output_hidden_states if output_hidden_states is not None else self.config.output_hidden_states
    )

    # Merge text and images
    if pixel_values is not None:
        image_features = self.get_image_features(pixel_values)
        if hasattr(image_features, "pooler_output"):
            image_features = image_features.pooler_output
        image_features = image_features.to(inputs_embeds.device, inputs_embeds.dtype)
        _, special_image_mask, _, _ = self.model.get_placeholder_mask(mm_token_type_ids, input_ids, inputs_embeds)
        special_image_mask_expanded = special_image_mask.unsqueeze(-1).expand_as(inputs_embeds)
        inputs_embeds = inputs_embeds.masked_scatter(special_image_mask_expanded, image_features)

    # Create bidirectional causal mask mapping when use_bidirectional_attention == "vision"
    use_bidirectional = getattr(self.config.get_text_config(), "use_bidirectional_attention", None) == "vision"
    if use_bidirectional and mm_token_type_ids is not None:
        attention_mask = _create_gemma4_bidirectional_mask_dict(
            attention_mask,
            mm_token_type_ids,
            inputs_embeds,
            self.model.language_model.config.sliding_window,
        )

    outputs = self.model.language_model(
        input_ids=None,
        per_layer_inputs=per_layer_inputs,
        attention_mask=attention_mask,
        position_ids=position_ids,
        past_key_values=past_key_values,
        inputs_embeds=inputs_embeds,
        use_cache=use_cache,
        output_attentions=output_attentions,
        output_hidden_states=output_hidden_states,
        cache_position=cache_position,
        **lm_kwargs,
    )

    return Gemma4ModelOutputWithPast(
        last_hidden_state=outputs.last_hidden_state,
        past_key_values=outputs.past_key_values if use_cache else None,
        hidden_states=outputs.hidden_states,
        attentions=outputs.attentions,
        image_hidden_states=image_features if pixel_values is not None else None,
    )


# Gemma4 model forward, needs to be patched to pass 'per_layer_inputs',
# Original code: https://github.com/huggingface/transformers/blob/v5.5.0/src/transformers/models/gemma4/modeling_gemma4.py#L2396
def gemma4_lm_forward(
    self,
    attention_mask: Optional[torch.Tensor] = None,
    position_ids: Optional[torch.LongTensor] = None,
    past_key_values: Optional[Cache] = None,
    inputs_embeds: Optional[torch.FloatTensor] = None,
    per_layer_inputs=None,
    token_type_ids: Optional[torch.LongTensor] = None,
    input_ids: Optional[torch.LongTensor] = None,
    pixel_values: Optional[torch.FloatTensor] = None,
    pixel_values_videos: Optional[torch.FloatTensor] = None,
    input_features: Optional[torch.FloatTensor] = None,
    input_features_mask: Optional[torch.Tensor] = None,
    cache_position: Optional[torch.LongTensor] = None,
    labels: Optional[torch.LongTensor] = None,
    use_cache: Optional[bool] = None,
    output_attentions: Optional[bool] = None,
    output_hidden_states: Optional[bool] = None,
    logits_to_keep: Union[int, torch.Tensor] = 0,
    **lm_kwargs,
):
    output_attentions = output_attentions if output_attentions is not None else self.config.output_attentions
    output_hidden_states = (
        output_hidden_states if output_hidden_states is not None else self.config.output_hidden_states
    )
    use_cache = False

    if past_key_values is not None:
        use_cache = True
        past_key_values = preprocess_past_key_values(past_key_values)

    outputs = self.model(
        input_ids=input_ids,
        pixel_values=pixel_values,
        pixel_values_videos=pixel_values_videos,
        input_features=input_features,
        attention_mask=attention_mask,
        input_features_mask=input_features_mask,
        position_ids=position_ids,
        past_key_values=past_key_values,
        mm_token_type_ids=token_type_ids,
        cache_position=cache_position,
        inputs_embeds=inputs_embeds,
        labels=labels,
        use_cache=use_cache,
        output_attentions=output_attentions,
        output_hidden_states=output_hidden_states,
        return_dict=True,
        per_layer_inputs=per_layer_inputs,
        **lm_kwargs,
    )

    hidden_states = outputs.last_hidden_state
    slice_indices = slice(-logits_to_keep, None) if isinstance(logits_to_keep, int) else logits_to_keep
    tmp_logits = self.lm_head(hidden_states[:, slice_indices, :])
    if (final_logit_softcapping := self.config.get_text_config().final_logit_softcapping) is not None:
        tmp_logits = tmp_logits / final_logit_softcapping
        tmp_logits = torch.tanh(tmp_logits)
        tmp_logits = tmp_logits * final_logit_softcapping

    outputs_dict = {
        "logits": tmp_logits,
    }

    if use_cache:
        key_values = outputs.past_key_values
        present_key_values = postprocess_past_key_values(key_values)
        outputs_dict["past_key_values"] = present_key_values
    return tuple([value if not isinstance(value, list) else tuple(value) for value in outputs_dict.values()])


# Needs to be patched to reshape 'attention_mask' to match attention weights
# Original code: https://github.com/huggingface/transformers/blob/v5.5.0/src/transformers/models/gemma4/modeling_gemma4.py#L768
def gemma4_eager_attention_forward_patched(
    module: nn.Module,
    query: torch.Tensor,
    key: torch.Tensor,
    value: torch.Tensor,
    attention_mask: Optional[torch.Tensor],
    dropout: float = 0.0,
    scaling: Optional[float] = None,
    softcap: Optional[float] = None,
    **kwargs,
) -> tuple:
    if scaling is None:
        scaling = module.head_dim**-0.5

    key_states = repeat_kv(key, module.num_key_value_groups)
    value_states = repeat_kv(value, module.num_key_value_groups)

    attn_weights = torch.matmul(query, key_states.transpose(2, 3)) * scaling

    if softcap is not None:
        attn_weights = attn_weights / softcap
        attn_weights = torch.tanh(attn_weights)
        attn_weights = attn_weights * softcap
    if attention_mask is not None:
        causal_mask = attention_mask[:, :, :, : key_states.shape[-2]]
        attn_weights = attn_weights + causal_mask

    attn_weights = nn.functional.softmax(attn_weights, dim=-1, dtype=torch.float32).to(query.dtype)
    attn_weights = nn.functional.dropout(attn_weights, p=dropout, training=module.training)
    attn_output = torch.matmul(attn_weights, value_states)
    attn_output = attn_output.transpose(1, 2).contiguous()
    return attn_output, attn_weights


# Needs to be patched to run methods 'gemma4_eager_attention_forward_patched' instead of original one
# Original code: https://github.com/huggingface/transformers/blob/v5.5.0/src/transformers/models/gemma4/modeling_gemma4.py#L1179
def gemma4_text_attention_forward(
    self,
    hidden_states: torch.Tensor,
    position_embeddings: torch.Tensor,
    attention_mask: Optional[torch.Tensor],
    past_key_values: Optional[Cache] = None,
    cache_position: Optional[torch.LongTensor] = None,
    **kwargs,
) -> tuple:
    from transformers.models.gemma4.modeling_gemma4 import apply_rotary_pos_emb as apply_rotary_pos_emb_gemma4

    input_shape = hidden_states.shape[:-1]
    hidden_shape = (*input_shape, -1, self.head_dim)

    cos, sin = position_embeddings

    query_states = self.q_proj(hidden_states).view(hidden_shape)
    query_states = self.q_norm(query_states)
    query_states = apply_rotary_pos_emb_gemma4(query_states, cos, sin, unsqueeze_dim=2)
    query_states = query_states.transpose(1, 2)

    if self.is_kv_shared_layer and past_key_values is not None:
        key_states, value_states = past_key_values.shared_layers[self.kv_shared_layer_index]
        key_states = key_states.to(query_states.device)
        value_states = value_states.to(query_states.device)
    else:
        key_states = self.k_proj(hidden_states).view(hidden_shape)
        value_states = self.v_proj(hidden_states).view(hidden_shape) if self.v_proj is not None else key_states

        key_states = self.k_norm(key_states)
        key_states = apply_rotary_pos_emb_gemma4(key_states, cos, sin, unsqueeze_dim=2)
        key_states = key_states.transpose(1, 2)

        value_states = self.v_norm(value_states)
        value_states = value_states.transpose(1, 2)

    if past_key_values is not None:
        cache_kwargs = {
            "sin": sin,
            "cos": cos,
            "cache_position": cache_position,
            "sliding_window": self.sliding_window,
        }
        if not self.is_kv_shared_layer:
            key_states, value_states = past_key_values.update(key_states, value_states, self.layer_idx, cache_kwargs)
        if self.store_full_length_kv:
            if not hasattr(past_key_values, "shared_layers"):
                past_key_values.shared_layers = {}
            past_key_values.shared_layers[self.layer_idx] = key_states, value_states

    attention_interface = gemma4_eager_attention_forward_patched

    attn_output, attn_weights = attention_interface(
        self,
        query_states,
        key_states,
        value_states,
        attention_mask,
        dropout=self.attention_dropout if self.training else 0.0,
        scaling=self.scaling,
        sliding_window=self.sliding_window,
        **kwargs,
    )

    attn_output = attn_output.reshape(*input_shape, -1).contiguous()
    attn_output = self.o_proj(attn_output)
    return attn_output, attn_weights


# This patching is needed as *= operation triggers segfault in PyTorch frontend during Frontend:Pytorch:normalize::no_val transformation
# Original code: https://github.com/huggingface/transformers/blob/v5.0.0/src/transformers/models/gemma3n/modeling_gemma3n.py#L1758
def _project_per_layer_inputs(
    self,
    inputs_embeds: torch.Tensor,
    per_layer_inputs: Optional[torch.Tensor] = None,
) -> torch.Tensor:
    per_layer_projection: torch.Tensor = self.per_layer_model_projection(inputs_embeds)
    per_layer_projection = (
        self.per_layer_projection_scale.to(dtype=inputs_embeds.dtype, device=per_layer_projection.device)
        * per_layer_projection
    )

    per_layer_projection = per_layer_projection.reshape(
        *inputs_embeds.shape[:-1],
        self.config.num_hidden_layers,
        self.hidden_size_per_layer_input,
    )
    per_layer_projection = self.per_layer_projection_norm(per_layer_projection)

    if per_layer_inputs is None:
        return per_layer_projection

    if per_layer_projection.shape != per_layer_inputs.shape:
        # per-layer inputs are sometimes padded with zeros, slice the relevant embeddings.
        per_layer_inputs = per_layer_inputs[..., : self.config.num_hidden_layers, :]

    return (per_layer_projection + per_layer_inputs) * self.per_layer_input_scale.to(
        dtype=inputs_embeds.dtype, device=per_layer_projection.device
    )


class Gemma3nLMModelPatcher(Gemma3LMModelPatcher):
    def __init__(self, config, model, model_kwargs):
        super().__init__(config, model, model_kwargs)

        self.patched_forward = gemma4_lm_forward
        self.model_orig_forward = self.orig_forward
        self.orig_forward = gemma4_lm_forward

        self.model_orig_language_model_forward = self._model.model.forward

    def __enter__(self):
        super().__enter__()

        setattr(self._model, self.orig_forward_name, types.MethodType(gemma4_lm_forward, self._model))
        setattr(self._model.model, "forward", types.MethodType(gemma3n_language_model_forward, self._model))

        self._model.model.language_model._orig_project_per_layer_inputs = (
            self._model.model.language_model.project_per_layer_inputs
        )
        self._model.model.language_model.project_per_layer_inputs = types.MethodType(
            _project_per_layer_inputs, self._model.model.language_model
        )

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)
        setattr(self._model, self.orig_forward_name, self.model_orig_forward)
        setattr(self._model.model, "forward", self.model_orig_language_model_forward)

        self._model.model.language_model.project_per_layer_inputs = (
            self._model.model.language_model._orig_project_per_layer_inputs
        )


class Gemma4LMModelPatcher(Gemma3LMModelPatcher):
    def __init__(self, config, model, model_kwargs):
        super().__init__(config, model, model_kwargs)

        self.patched_forward = gemma4_lm_forward
        self.model_orig_forward = self.orig_forward
        self.orig_forward = gemma4_lm_forward

        self.model_orig_language_model_forward = self._model.model.forward

    def __enter__(self):
        super().__enter__()

        setattr(self._model, self.orig_forward_name, types.MethodType(gemma4_lm_forward, self._model))
        setattr(self._model.model, "forward", types.MethodType(gemma4_language_model_forward, self._model))
        for decoder_layer in self._model.model.language_model.layers:
            decoder_layer.self_attn.orig_forward = decoder_layer.self_attn.forward
            decoder_layer.self_attn.forward = types.MethodType(gemma4_text_attention_forward, decoder_layer.self_attn)
            if hasattr(decoder_layer, "experts"):
                decoder_layer.experts._orig_forward = decoder_layer.experts.forward
                decoder_layer.experts.forward = types.MethodType(lfm2_moe_experts_forward, decoder_layer.experts)

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)

        for decoder_layer in self._model.model.language_model.layers:
            decoder_layer.self_attn.forward = decoder_layer.self_attn.orig_forward
            if hasattr(decoder_layer, "experts") and hasattr(decoder_layer.experts, "_orig_forward"):
                decoder_layer.experts.forward = decoder_layer.experts._orig_forward

        setattr(self._model, self.orig_forward_name, self.model_orig_forward)
        setattr(self._model.model, "forward", self.model_orig_language_model_forward)


class Idefics3ImageEmbeddingsModelPatcher(ModelPatcher):
    def __init__(
        self,
        config: "OpenVINOConfig",
        model: "PreTrainedModel",
        model_kwargs: Optional[Dict[str, Any]] = None,
    ):
        # Adopted from https://github.com/huggingface/transformers/blob/v4.49.0-SmolVLM-2/src/transformers/models/idefics3/modeling_idefics3.py#L999-L1005
        def get_image_features(self, pixel_values, patch_attention_mask, patch_position_ids):
            image_hidden_states = self.vision_model(
                pixel_values=pixel_values,
                patch_attention_mask=patch_attention_mask,
                patch_position_ids=patch_position_ids,
            ).last_hidden_state

            # Modality projection & resampling
            image_hidden_states = self.connector(image_hidden_states)
            return image_hidden_states

        model.__orig_forward = model.forward
        model.forward = types.MethodType(get_image_features, model)
        super().__init__(config, model, model_kwargs)

    def __enter__(self):
        super().__enter__()

        # The difference from original code is only in getting patch_position_ids as input and propagating it into embeddings instead of calculation inside based on patch_attention_mask
        # method for calculation position_ids is not pytorch tracing friendly due to cycle over batch size.
        def transformer_forward(
            self,
            pixel_values,
            patch_attention_mask: Optional[torch.BoolTensor] = None,
            patch_position_ids: Optional[torch.IntTensor] = None,
            output_attentions: Optional[bool] = None,
            output_hidden_states: Optional[bool] = None,
            return_dict: Optional[bool] = None,
        ):
            from transformers.modeling_attn_mask_utils import _prepare_4d_attention_mask

            output_attentions = output_attentions if output_attentions is not None else self.config.output_attentions
            output_hidden_states = (
                output_hidden_states if output_hidden_states is not None else self.config.output_hidden_states
            )
            return_dict = return_dict if return_dict is not None else self.config.use_return_dict

            batch_size = pixel_values.size(0)
            if patch_attention_mask is None:
                patch_size = self.patch_size
                patch_attention_mask = torch.ones(
                    (
                        batch_size,
                        pixel_values.size(2) // patch_size,
                        pixel_values.size(3) // patch_size,
                    )
                )
                patch_attention_mask = patch_attention_mask.to(dtype=torch.bool, device=pixel_values.device)

            hidden_states = self.embeddings(
                pixel_values=pixel_values,
                patch_attention_mask=patch_attention_mask,
                patch_position_ids=patch_position_ids,
            )

            patch_attention_mask = patch_attention_mask.view(batch_size, -1)
            # The call to `_upad_input` in `_flash_attention_forward` is expensive
            # So when the `patch_attention_mask` is full of 1s (i.e. attending to the whole sequence),
            # avoiding passing the attention_mask, which is equivalent to attending to the full sequence
            if not torch.any(~patch_attention_mask):
                patch_attention_mask = None
            elif not getattr(self, "_use_flash_attention_2", False):
                patch_attention_mask = _prepare_4d_attention_mask(patch_attention_mask, hidden_states.dtype)

            encoder_outputs = self.encoder(
                inputs_embeds=hidden_states,
                attention_mask=patch_attention_mask,
            )

            last_hidden_state = encoder_outputs[0]
            last_hidden_state = self.post_layernorm(last_hidden_state)

            if not return_dict:
                return (last_hidden_state,) + encoder_outputs[1:]

            return BaseModelOutput(
                last_hidden_state=last_hidden_state,
                hidden_states=encoder_outputs.hidden_states,
                attentions=encoder_outputs.attentions,
            )

        def embeddings_forward(
            self,
            pixel_values: torch.FloatTensor,
            patch_attention_mask: torch.BoolTensor,
            patch_position_ids: Optional[torch.IntTensor] = None,
        ) -> torch.Tensor:
            batch_size, _, max_im_h, max_im_w = pixel_values.shape

            patch_embeds = self.patch_embedding(pixel_values)
            embeddings = patch_embeds.flatten(2).transpose(1, 2)

            if patch_position_ids is None:
                max_nb_patches_h, max_nb_patches_w = max_im_h // self.patch_size, max_im_w // self.patch_size
                boundaries = torch.arange(1 / self.num_patches_per_side, 1.0, 1 / self.num_patches_per_side)
                position_ids = torch.full(size=(batch_size, max_nb_patches_h * max_nb_patches_w), fill_value=0)

                for batch_idx, p_attn_mask in enumerate(patch_attention_mask):
                    nb_patches_h = p_attn_mask[:, 0].sum()
                    nb_patches_w = p_attn_mask[0].sum()

                    h_indices = torch.arange(nb_patches_h, device=pixel_values.device, dtype=pixel_values.dtype)
                    w_indices = torch.arange(nb_patches_w, device=pixel_values.device, dtype=pixel_values.dtype)
                    fractional_coords_h = h_indices / nb_patches_h * (1 - 1e-6)
                    fractional_coords_w = w_indices / nb_patches_w * (1 - 1e-6)

                    bucket_coords_h = torch.bucketize(fractional_coords_h, boundaries, right=True)
                    bucket_coords_w = torch.bucketize(fractional_coords_w, boundaries, right=True)

                    pos_ids = (bucket_coords_h[:, None] * self.num_patches_per_side + bucket_coords_w).flatten()
                    position_ids[batch_idx][p_attn_mask.view(-1).cpu()] = pos_ids
            else:
                position_ids = patch_position_ids

            position_ids = position_ids.to(self.position_embedding.weight.device)
            embeddings = embeddings + self.position_embedding(position_ids)
            return embeddings

        def attn_forward(
            self,
            hidden_states: torch.Tensor,
            attention_mask: Optional[torch.Tensor] = None,
            output_attentions: Optional[bool] = False,
        ) -> Tuple[torch.Tensor, Optional[torch.Tensor], Optional[Tuple[torch.Tensor]]]:
            if output_attentions:
                return super().forward(
                    hidden_states=hidden_states,
                    attention_mask=attention_mask,
                    output_attentions=output_attentions,
                )

            batch_size, q_len, _ = hidden_states.size()

            query_states = self.q_proj(hidden_states)
            key_states = self.k_proj(hidden_states)
            value_states = self.v_proj(hidden_states)

            query_states = query_states.view(batch_size, q_len, self.num_heads, self.head_dim).transpose(1, 2)
            key_states = key_states.view(batch_size, q_len, self.num_heads, self.head_dim).transpose(1, 2)
            value_states = value_states.view(batch_size, q_len, self.num_heads, self.head_dim).transpose(1, 2)

            # SDPA with memory-efficient backend is currently (torch==2.1.2) bugged with non-contiguous inputs with custom attn_mask,
            # Reference: https://github.com/pytorch/pytorch/issues/112577.
            if query_states.device.type == "cuda" and attention_mask is not None:
                query_states = query_states.contiguous()
                key_states = key_states.contiguous()
                value_states = value_states.contiguous()

            # We dispatch to SDPA's Flash Attention or Efficient kernels via this `is_causal` if statement instead of an inline conditional assignment
            # in SDPA to support both torch.compile's dynamic shapes and full graph options. An inline conditional prevents dynamic shapes from compiling.
            is_causal = False

            attn_output = torch.nn.functional.scaled_dot_product_attention(
                query_states,
                key_states,
                value_states,
                attn_mask=attention_mask,
                dropout_p=self.dropout if self.training else 0.0,
                is_causal=is_causal,
                scale=self.scale,
            )

            attn_output = attn_output.transpose(1, 2).contiguous()
            attn_output = attn_output.view(batch_size, q_len, self.embed_dim)

            attn_output = self.out_proj(attn_output)

            return attn_output, None

        self._model.vision_model._orig_forward = self._model.vision_model.forward
        self._model.vision_model.forward = types.MethodType(transformer_forward, self._model.vision_model)
        self._model.vision_model.embeddings._orig_forward = self._model.vision_model.embeddings.forward
        self._model.vision_model.embeddings.forward = types.MethodType(
            embeddings_forward, self._model.vision_model.embeddings
        )

        for layer in self._model.vision_model.encoder.layers:
            layer.self_attn._orig_forward = layer.self_attn.forward
            layer.self_attn.forward = types.MethodType(attn_forward, layer.self_attn)

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)

        self._model.forward = self._model.__orig_forward
        self._model.vision_model.forward = self._model.vision_model._orig_forward
        self._model.vision_model.embeddings.forward = self._model.vision_model.embeddings._orig_forward
        for layer in self._model.vision_model.encoder.layers:
            layer.self_attn.forward = layer.self_attn._orig_forward


def modulewise_patch(model, module_cls, patch_forward):
    for _, module in model.named_children():
        if isinstance(module, module_cls):
            module._orig_forward = module.forward
            module.forward = types.MethodType(patch_forward, module)
            return
        else:
            if len(list(module.children())) > 0:
                modulewise_patch(module, module_cls, patch_forward)


def modulewise_unpatch(model, module_cls):
    for _, module in model.named_children():
        if isinstance(module, module_cls):
            if hasattr(module, "_orig_forward"):
                module.forward = module._orig_forward
        else:
            if len(list(module.children())) > 0:
                modulewise_unpatch(module, module_cls)


# Copied from https://github.com/huggingface/transformers/blob/v4.51.3/src/transformers/models/qwen2_moe/modeling_qwen2_moe.py#L596
# In 4.52.0, the loop is only over hitted experts, but we need to loop over all experts for tracing
def _qwen2moe_sparse_block_forward(self, hidden_states: torch.Tensor) -> torch.Tensor:
    batch_size, sequence_length, hidden_dim = hidden_states.shape
    hidden_states = hidden_states.view(-1, hidden_dim)
    # router_logits: (batch * sequence_length, n_experts)
    router_logits = self.gate(hidden_states)

    routing_weights = F.softmax(router_logits, dim=1, dtype=torch.float)
    routing_weights, selected_experts = torch.topk(routing_weights, self.top_k, dim=-1)
    if self.norm_topk_prob:
        routing_weights /= routing_weights.sum(dim=-1, keepdim=True)
    # we cast back to the input dtype
    routing_weights = routing_weights.to(hidden_states.dtype)

    final_hidden_states = torch.zeros(
        (batch_size * sequence_length, hidden_dim), dtype=hidden_states.dtype, device=hidden_states.device
    )

    # One hot encode the selected experts to create an expert mask
    # this will be used to easily index which expert is going to be sollicitated
    expert_mask = torch.nn.functional.one_hot(selected_experts, num_classes=self.num_experts).permute(2, 1, 0)

    # Loop over all available experts in the model and perform the computation on each expert
    for expert_idx in range(self.num_experts):
        expert_layer = self.experts[expert_idx]
        idx, top_x = torch.where(expert_mask[expert_idx])

        # Index the correct hidden states and compute the expert hidden state for
        # the current expert. We need to make sure to multiply the output hidden
        # states by `routing_weights` on the corresponding tokens (top-1 and top-2)
        current_state = hidden_states[None, top_x].reshape(-1, hidden_dim)
        current_hidden_states = expert_layer(current_state) * routing_weights[top_x, idx, None]

        # However `index_add_` only support torch tensors for indexing so we'll use
        # the `top_x` tensor here.
        final_hidden_states.index_add_(0, top_x, current_hidden_states.to(hidden_states.dtype))

    shared_expert_output = self.shared_expert(hidden_states)
    shared_expert_output = F.sigmoid(self.shared_expert_gate(hidden_states)) * shared_expert_output

    final_hidden_states = final_hidden_states + shared_expert_output

    final_hidden_states = final_hidden_states.reshape(batch_size, sequence_length, hidden_dim)
    return final_hidden_states, router_logits


class Qwen2MoEPatcher(OVDecoderModelPatcher):
    def __enter__(self):
        super().__enter__()

        if is_transformers_version("<", "5"):
            from transformers.models.qwen2_moe.modeling_qwen2_moe import Qwen2MoeSparseMoeBlock

            modulewise_patch(self._model, Qwen2MoeSparseMoeBlock, _qwen2moe_sparse_block_forward)
        else:
            from transformers.models.qwen2_moe.modeling_qwen2_moe import Qwen2MoeExperts

            self.original_moe_forward = Qwen2MoeExperts.forward
            Qwen2MoeExperts.forward = lfm2_moe_experts_forward

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)
        if is_transformers_version("<", "5"):
            from transformers.models.qwen2_moe.modeling_qwen2_moe import Qwen2MoeSparseMoeBlock

            modulewise_unpatch(self._model, Qwen2MoeSparseMoeBlock)
        else:
            from transformers.models.qwen2_moe.modeling_qwen2_moe import Qwen2MoeExperts

            Qwen2MoeExperts.forward = self.original_moe_forward


# Adopted from https://github.com/huggingface/transformers/blob/v4.51.3/src/transformers/models/speecht5/modeling_speecht5.py#L698
# this is a patch to avoid PyTorch FE issue
# with the same tensor names on input and intermediate tensor for speaker_embeddings
def speecht5_decoder_prenet_forward(
    self,
    input_values: torch.Tensor,
    speaker_embeddings: Optional[torch.Tensor] = None,
):
    inputs_embeds = input_values
    for layer in self.layers:
        inputs_embeds = torch.nn.functional.relu(layer(inputs_embeds))
        inputs_embeds = self._consistent_dropout(inputs_embeds, self.config.speech_decoder_prenet_dropout)

    inputs_embeds = self.final_layer(inputs_embeds)
    inputs_embeds = self.encode_positions(inputs_embeds)

    if speaker_embeddings is not None:
        # this is a patch to avoid for PyTorch FE issue!!!
        # with the same tensor names on input and intermediate tensor in a model
        speaker_embeddings_norm = torch.nn.functional.normalize(speaker_embeddings)
        speaker_embeddings_unsqueeze = speaker_embeddings_norm.unsqueeze(1).expand(-1, inputs_embeds.size(1), -1)
        inputs_embeds = torch.cat([inputs_embeds, speaker_embeddings_unsqueeze], dim=-1)
        inputs_embeds = torch.nn.functional.relu(self.speaker_embeds_layer(inputs_embeds))

    return inputs_embeds


class SpeechT5ModelPatcher(ModelPatcher):
    def __enter__(self):
        if self.real_config._behavior != "vocoder":
            super().__enter__()
        if self.real_config._behavior == "decoder":
            self._model.speecht5.decoder.prenet.__orig_forward = self._model.speecht5.decoder.prenet.forward
            self._model.speecht5.decoder.prenet.forward = types.MethodType(
                speecht5_decoder_prenet_forward, self._model.speecht5.decoder.prenet
            )

    def __exit__(self, exc_type, exc_value, traceback):
        if self.real_config._behavior != "vocoder":
            super().__exit__(exc_type, exc_value, traceback)
        if self.real_config._behavior == "decoder":
            self._model.speecht5.decoder.prenet.forward = types.MethodType(
                self._model.speecht5.decoder.prenet.__orig_forward, self._model.speecht5.decoder.prenet
            )

    def __init__(
        self,
        config: "OpenVINOConfig",
        model: "PreTrainedModel",
        model_kwargs: Dict[str, Any],
    ):
        super().__init__(config, model, model_kwargs)

        def patched_encoder_forward(
            input_ids: torch.FloatTensor = None,
        ):
            encoder_attention_mask = torch.ones_like(input_ids)

            hidden_states = self._model.prenet(input_ids)

            encoder_out = self._model.wrapped_encoder(
                hidden_states=hidden_states,
                attention_mask=encoder_attention_mask,
                return_dict=True,
            )
            # downsample encoder attention mask
            if isinstance(model, SpeechT5EncoderWithSpeechPrenet):
                encoder_attention_mask = model.prenet._get_feature_vector_attention_mask(
                    encoder_out[0].shape[1], encoder_attention_mask
                )

            result = {
                "encoder_outputs": encoder_out.last_hidden_state,
                "encoder_attention_mask": encoder_attention_mask,
            }
            return result

        def patched_decoder_forward(
            inputs_embeds=None,
            speaker_embeddings=None,
            encoder_hidden_states=None,
            encoder_attention_mask=None,
            past_key_values=None,
        ):
            if past_key_values is not None:
                past_key_values = [cache_item[:2] for cache_item in past_key_values]
                if is_transformers_version(">=", "4.56"):
                    if is_transformers_version("<", "5"):
                        past_key_values = EncoderDecoderCache.from_legacy_cache(past_key_values)
                    else:
                        past_key_values = EncoderDecoderCache(DynamicCache(past_key_values), DynamicCache())

            output_sequence = inputs_embeds
            output_cross_attentions = False
            bsz = output_sequence.size(0)

            # Run the decoder prenet on the entire output sequence.
            decoder_hidden_states = model.speecht5.decoder.prenet(output_sequence, speaker_embeddings)
            # Run the decoder layers on the last element of the prenet output.
            decoder_out = model.speecht5.decoder.wrapped_decoder(
                hidden_states=decoder_hidden_states[:, -1:],
                encoder_hidden_states=encoder_hidden_states,
                encoder_attention_mask=encoder_attention_mask,
                past_key_values=past_key_values,
                use_cache=True,
                output_attentions=output_cross_attentions,
                return_dict=True,
            )
            last_decoder_output = decoder_out.last_hidden_state.squeeze(1)

            # Predict the new mel spectrum for this step in the sequence.
            spectrum = model.speech_decoder_postnet.feat_out(last_decoder_output)
            spectrum = spectrum.view(bsz, model.config.reduction_factor, model.config.num_mel_bins)

            # Extend the output sequence with the new mel spectrum.
            new_spectrogram = spectrum[:, -1, :].view(bsz, 1, model.config.num_mel_bins)
            output_sequence_out = torch.cat((output_sequence, new_spectrogram), dim=1)
            # Predict the probability that this is the stop token.
            prob = torch.sigmoid(model.speech_decoder_postnet.prob_out(last_decoder_output))

            past_key_values = decoder_out.past_key_values
            if past_key_values is not None:
                if isinstance(past_key_values, EncoderDecoderCache):
                    past_key_values = postprocess_past_key_values(past_key_values.self_attention_cache)
                else:
                    past_key_values = [cache_item[:2] for cache_item in past_key_values]

            result = {
                "output_sequence_out": output_sequence_out,
                "spectrum": spectrum,
                "prob": prob,
                "past_key_values": past_key_values,
            }
            return result

        def patched_postnet_forward(raw_spectrogram: torch.FloatTensor):
            raw_spectrogram = raw_spectrogram.transpose(0, 1).flatten(1, 2)
            spectrogram = model.speech_decoder_postnet.postnet(raw_spectrogram)
            result = {"postnet_spectrogram": spectrogram}
            return result

        def patched_vocoder_forward(spectrogram: torch.FloatTensor):
            waveform = model(spectrogram)
            result = {"waveform": waveform}
            return result

        if self.real_config._behavior == "encoder":
            self.patched_forward = patched_encoder_forward
        elif self.real_config._behavior == "decoder":
            self.patched_forward = patched_decoder_forward
        elif self.real_config._behavior == "postnet":
            self.patched_forward = patched_postnet_forward
        elif self.real_config._behavior == "vocoder":
            self.patched_forward = patched_vocoder_forward
        else:
            raise ValueError("Unknown ")
        self.orig_forward = self.patched_forward


class Phi4MMLanguageModelPatcher(OVDecoderModelPatcher):
    def __init__(
        self,
        config: "OpenVINOConfig",
        model: "PreTrainedModel",
        model_kwargs: Optional[Dict[str, Any]] = None,
    ):
        if hasattr(model.config, "vision_lora") and model.config.vision_lora is not None:
            model.set_lora_adapter("vision")
        if hasattr(model.config, "speech_lora") and model.config.speech_lora is not None:
            model.set_lora_adapter("speech")

        # Adopted from https://github.com/huggingface/transformers/blob/v4.51.3/src/transformers/models/phi4_multimodal/modeling_phi4_multimodal.py#L2156-L2178
        # moved audio and vision features processing outside model
        def lm_forward(self, inputs_embeds, attention_mask, position_ids, past_key_values, use_cache=True):
            if is_transformers_version("<", "5"):
                pkv = DynamicCache.from_legacy_cache(past_key_values)
            else:
                pkv = DynamicCache(past_key_values)

            outputs = self.model(
                inputs_embeds=inputs_embeds,
                attention_mask=attention_mask,
                position_ids=position_ids,
                use_cache=use_cache,
                past_key_values=pkv,
            )
            hidden_states = outputs[0]
            # Only compute necessary logits, and do not upcast them to float if we are not computing the loss
            logits = self.lm_head(hidden_states)
            return (logits, postprocess_past_key_values(outputs.past_key_values))

        model.__orig_forward = model.forward
        model.forward = types.MethodType(lm_forward, model)
        super().__init__(config, model, model_kwargs)

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)
        self._model.forward = self._model.__orig_forward


class Phi4MMAudioForwardEmbeddingsPatcher(ModelPatcher):
    def __init__(
        self,
        config: "OpenVINOConfig",
        model: "PreTrainedModel",
        model_kwargs: Optional[Dict[str, Any]] = None,
    ):
        # Adopted from https://github.com/huggingface/transformers/blob/v4.51.3/src/transformers/models/phi4_multimodal/modeling_phi4_multimodal.py#L1121
        def forward(self, audio_input):
            if hasattr(self, "_forward_embeddings_code"):
                audio_input, masks = self._forward_embeddings_core(audio_input, None)
            else:
                audio_input, masks = self.embed(audio_input, None)
            return audio_input

        model.__orig_forward = model.forward
        model.forward = types.MethodType(forward, model)
        super().__init__(config, model, model_kwargs)

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)
        self._model.forward = self._model.__orig_forward


class Phi4MMAudioEncoderPatcher(ModelPatcher):
    def __init__(
        self,
        config: "OpenVINOConfig",
        model: "PreTrainedModel",
        model_kwargs: Optional[Dict[str, Any]] = None,
    ):
        # Adopted from https://github.com/huggingface/transformers/blob/v4.51.3/src/transformers/models/phi4_multimodal/modeling_phi4_multimodal.py#L1201-L1212
        def forward(self, audio_feature, audio_mask):
            if hasattr(self, "init_relative_attention_bias"):
                relative_attention_bias = self.init_relative_attention_bias(audio_feature)

                _simplified_path = self.extra_layer_output_idx == -1 and relative_attention_bias is None

                if _simplified_path:
                    audio_feature, *_ = self.encoders(audio_feature, None, None, audio_mask)
                else:
                    for layer in self.encoders:
                        audio_feature, _, _, _ = layer(
                            audio_feature,
                            None,
                            None,
                            audio_mask,
                            relative_attention_bias=relative_attention_bias,
                        )
            else:
                relative_attention_bias = self.relative_attention_bias_layer(audio_feature)
                attention_mask = audio_mask.unsqueeze(1) + relative_attention_bias
                for layer in self.encoders:
                    audio_feature = layer(audio_feature, attention_mask)
            return audio_feature

        model.__orig_forward = model.forward
        model.forward = types.MethodType(forward, model)
        super().__init__(config, model, model_kwargs)

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)
        self._model.forward = self._model.__orig_forward


class Phi4MMVisionEmbeddingsPatcher(ModelPatcher):
    def __init__(
        self,
        config: "OpenVINOConfig",
        model: "PreTrainedModel",
        model_kwargs: Optional[Dict[str, Any]] = None,
    ):
        def get_img_features_legacy(
            self, pixel_values: torch.FloatTensor, patch_attention_mask=None, patch_position_ids=None
        ) -> torch.FloatTensor:
            LAYER_IDX = self.layer_idx
            TYPE_FEATURE = self.type_feature

            if self.freeze_img_processor:
                with torch.no_grad():
                    if patch_attention_mask is not None:
                        img_processor_output = self.img_processor(
                            pixel_values,
                            output_hidden_states=True,
                            patch_attention_mask=patch_attention_mask,
                            position_ids=patch_position_ids,
                        )
                    else:
                        img_processor_output = self.img_processor(
                            pixel_values, output_hidden_states=True, position_ids=patch_position_ids
                        )
                    img_feature = img_processor_output.hidden_states[LAYER_IDX]
            else:
                if patch_attention_mask is not None:
                    img_processor_output = self.img_processor(
                        pixel_values,
                        output_hidden_states=True,
                        patch_attention_mask=patch_attention_mask,
                        position_ids=patch_position_ids,
                    )
                else:
                    img_processor_output = self.img_processor(
                        pixel_values, output_hidden_states=True, position_ids=patch_position_ids
                    )
                img_feature = img_processor_output.hidden_states[LAYER_IDX]

            if TYPE_FEATURE == "patch":
                patch_feature = img_feature
                if self.image_token_compression is not None:
                    # reshape to 2D tensor
                    width = int(math.sqrt(patch_feature.size(1)))
                    patch_feature = patch_feature.view(-1, width, width, patch_feature.size(-1))
                    # convert to NCHW
                    patch_feature = patch_feature.permute(0, 3, 1, 2)
                    if getattr(self, "img_processor_padding", None) is not None:
                        patch_feature = self.img_processor_padding(patch_feature)
                    patch_feature = self.image_token_compression(patch_feature)
                    # convert to NHWC
                    patch_feature = patch_feature.permute(0, 2, 3, 1)
                    patch_feature = patch_feature.view(
                        -1, patch_feature.size(1) * patch_feature.size(2), patch_feature.size(-1)
                    )
                elif getattr(self, "img_processor_padding", None) is not None:
                    width = int(math.sqrt(patch_feature.size(1)))
                    patch_feature = patch_feature.view(-1, width, width, patch_feature.size(-1))
                    # convert to NCHW
                    patch_feature = patch_feature.permute(0, 3, 1, 2)
                    patch_feature = self.img_processor_padding(patch_feature)
                    # convert to NHWC
                    patch_feature = patch_feature.permute(0, 2, 3, 1)
                    patch_feature = patch_feature.view(
                        -1, patch_feature.size(1) * patch_feature.size(2), patch_feature.size(-1)
                    )
                return patch_feature

            if TYPE_FEATURE == "cls_patch":
                if self.image_token_compression is not None:
                    # reshape to 2D tensor
                    patch_feature = img_feature[:, 1:]
                    cls_feature = img_feature[:, 0]
                    width = math.sqrt(patch_feature.size(1))
                    patch_feature = patch_feature.view(-1, width, width, patch_feature.size(-1))
                    patch_feature = self.image_token_compression(patch_feature)
                    patch_feature = patch_feature.view(-1, patch_feature.size(-2) * patch_feature.size(-1))
                    img_feature = torch.cat([cls_feature, patch_feature], dim=1)
                return img_feature

        # Adopted from https://github.com/huggingface/transformers/blob/v4.51.3/src/transformers/models/phi4_multimodal/modeling_phi4_multimodal.py#L649
        # added possibility to provide patch_position_ids
        def get_img_features(
            self, pixel_values: torch.FloatTensor, patch_attention_mask=None, patch_position_ids=None
        ):
            img_processor_output = self.img_processor(
                pixel_values,
                patch_attention_mask=patch_attention_mask,
                output_hidden_states=True,
                position_ids=patch_position_ids,
            )
            img_feature = img_processor_output.hidden_states[self.layer_idx]

            patch_feature = img_feature
            # reshape to 2D tensor
            width = int(math.sqrt(patch_feature.size(1)))
            patch_feature = patch_feature.view(-1, width, width, patch_feature.size(-1))
            # convert to NCHW
            patch_feature = patch_feature.permute(0, 3, 1, 2)
            if getattr(self, "img_processor_padding", None) is not None:
                patch_feature = self.img_processor_padding(patch_feature)
            patch_feature = self.image_token_compression(patch_feature)
            # convert to NHWC
            patch_feature = patch_feature.permute(0, 2, 3, 1)
            patch_feature = patch_feature.view(
                -1, patch_feature.size(1) * patch_feature.size(2), patch_feature.size(-1)
            )
            return patch_feature

        model.__orig_forward = model.forward
        model.forward = types.MethodType(
            get_img_features_legacy if hasattr(model, "type_feature") else get_img_features, model
        )
        super().__init__(config, model, model_kwargs)

    def __enter__(self):
        super().__enter__()

        # Adopted from https://github.com/huggingface/transformers/blob/v4.51.3/src/transformers/models/phi4_multimodal/modeling_phi4_multimodal.py#L563
        # added possibility calculate position_ids outside
        def transformer_fwd(
            self,
            pixel_values,
            patch_attention_mask: Optional[torch.BoolTensor] = None,
            position_ids: Optional[torch.FloatTensor] = None,
            output_attentions: Optional[bool] = None,
            output_hidden_states: Optional[bool] = None,
            return_dict: Optional[bool] = None,
        ) -> Union[Tuple, BaseModelOutputWithPooling]:
            from transformers.modeling_attn_mask_utils import _prepare_4d_attention_mask

            output_attentions = output_attentions if output_attentions is not None else self.config.output_attentions
            output_hidden_states = (
                output_hidden_states if output_hidden_states is not None else self.config.output_hidden_states
            )
            return_dict = return_dict if return_dict is not None else self.config.use_return_dict

            batch_size = pixel_values.size(0)
            if patch_attention_mask is None:
                patch_attention_mask = torch.ones(
                    size=(
                        batch_size,
                        pixel_values.size(2) // self.config.patch_size,
                        pixel_values.size(3) // self.config.patch_size,
                    ),
                    dtype=torch.bool,
                    device=pixel_values.device,
                )

            hidden_states = self.embeddings(
                pixel_values=pixel_values, patch_attention_mask=patch_attention_mask, position_ids=position_ids
            )

            patch_attention_mask = patch_attention_mask.view(batch_size, -1)
            # The call to `_upad_input` in `_flash_attention_forward` is expensive
            # So when the `patch_attention_mask` is full of 1s (i.e. attending to the whole sequence),
            # avoiding passing the attention_mask, which is equivalent to attending to the full sequence
            if not torch.any(~patch_attention_mask):
                attention_mask = None
            else:
                attention_mask = _prepare_4d_attention_mask(patch_attention_mask, hidden_states.dtype)

            encoder_outputs = self.encoder(
                inputs_embeds=hidden_states,
                attention_mask=attention_mask,
                output_attentions=output_attentions,
                output_hidden_states=output_hidden_states,
                return_dict=return_dict,
            )

            last_hidden_state = encoder_outputs[0]
            last_hidden_state = self.post_layernorm(last_hidden_state)

            pooled_output = self.head(
                hidden_state=last_hidden_state,
                attention_mask=patch_attention_mask,
            )

            if not return_dict:
                return (last_hidden_state, pooled_output) + encoder_outputs[1:]

            return BaseModelOutputWithPooling(
                last_hidden_state=last_hidden_state,
                pooler_output=pooled_output,
                hidden_states=encoder_outputs.hidden_states,
                attentions=encoder_outputs.attentions,
            )

        # Adopted from https://github.com/huggingface/transformers/blob/v4.51.3/src/transformers/models/phi4_multimodal/modeling_phi4_multimodal.py#L76
        # used SDPA instead of eager attention
        def attn_forward(
            self,
            hidden_states: torch.Tensor,
            attention_mask: Optional[torch.Tensor] = None,
            output_attentions: Optional[bool] = False,
        ) -> Tuple[torch.Tensor, Optional[torch.Tensor], Optional[Tuple[torch.Tensor]]]:
            if output_attentions:
                return super().forward(
                    hidden_states=hidden_states,
                    attention_mask=attention_mask,
                    output_attentions=output_attentions,
                )

            batch_size, q_len, _ = hidden_states.size()

            query_states = self.q_proj(hidden_states)
            key_states = self.k_proj(hidden_states)
            value_states = self.v_proj(hidden_states)

            query_states = query_states.view(batch_size, q_len, self.num_heads, self.head_dim).transpose(1, 2)
            key_states = key_states.view(batch_size, q_len, self.num_heads, self.head_dim).transpose(1, 2)
            value_states = value_states.view(batch_size, q_len, self.num_heads, self.head_dim).transpose(1, 2)

            # SDPA with memory-efficient backend is currently (torch==2.1.2) bugged with non-contiguous inputs with custom attn_mask,
            # Reference: https://github.com/pytorch/pytorch/issues/112577.
            if query_states.device.type == "cuda" and attention_mask is not None:
                query_states = query_states.contiguous()
                key_states = key_states.contiguous()
                value_states = value_states.contiguous()

            # We dispatch to SDPA's Flash Attention or Efficient kernels via this `is_causal` if statement instead of an inline conditional assignment
            # in SDPA to support both torch.compile's dynamic shapes and full graph options. An inline conditional prevents dynamic shapes from compiling.
            is_causal = False

            attn_output = torch.nn.functional.scaled_dot_product_attention(
                query_states,
                key_states,
                value_states,
                attn_mask=attention_mask,
                dropout_p=self.dropout if self.training else 0.0,
                is_causal=is_causal,
            )

            attn_output = attn_output.transpose(1, 2).contiguous()
            attn_output = attn_output.view(batch_size, q_len, self.embed_dim)

            attn_output = self.out_proj(attn_output)

            return attn_output, None

        # Adopted from https://github.com/huggingface/transformers/blob/v4.51.3/src/transformers/models/phi4_multimodal/modeling_phi4_multimodal.py#L488
        # moved position_ids calculation outside of model
        def embd_forward(
            self,
            pixel_values: torch.FloatTensor,
            patch_attention_mask: torch.BoolTensor,
            position_ids: torch.FloatTensor = None,
        ) -> torch.Tensor:
            batch_size = pixel_values.size(0)

            patch_embeds = self.patch_embedding(pixel_values)
            embeddings = patch_embeds.flatten(2).transpose(1, 2)

            if position_ids is None:
                max_im_h, max_im_w = pixel_values.size(2), pixel_values.size(3)
                max_nb_patches_h, max_nb_patches_w = max_im_h // self.patch_size, max_im_w // self.patch_size
                boundaries = torch.arange(1 / self.num_patches_per_side, 1.0, 1 / self.num_patches_per_side)
                position_ids = torch.full(
                    size=(
                        batch_size,
                        max_nb_patches_h * max_nb_patches_w,
                    ),
                    fill_value=0,
                )

                for batch_idx, p_attn_mask in enumerate(patch_attention_mask):
                    nb_patches_h = p_attn_mask[:, 0].sum()
                    nb_patches_w = p_attn_mask[0].sum()

                    fractional_coords_h = torch.arange(0, 1 - 1e-6, 1 / nb_patches_h)
                    fractional_coords_w = torch.arange(0, 1 - 1e-6, 1 / nb_patches_w)

                    bucket_coords_h = torch.bucketize(fractional_coords_h, boundaries, right=True)
                    bucket_coords_w = torch.bucketize(fractional_coords_w, boundaries, right=True)

                    pos_ids = (bucket_coords_h[:, None] * self.num_patches_per_side + bucket_coords_w).flatten()
                    position_ids[batch_idx][p_attn_mask.view(-1).cpu()] = pos_ids

            position_ids = position_ids.to(self.position_embedding.weight.device)

            embeddings = embeddings + self.position_embedding(position_ids)
            return embeddings

        if (
            getattr(self._model.img_processor.encoder.layers[0].self_attn.config, "_attn_implementation", "eager")
            != "sdpa"
        ):
            for layer in self._model.img_processor.encoder.layers:
                layer.self_attn._orig_forward = layer.self_attn.forward
                layer.self_attn.forward = types.MethodType(attn_forward, layer.self_attn)
        self._model.img_processor._orig_forward = self._model.img_processor.forward
        self._model.img_processor.forward = types.MethodType(transformer_fwd, self._model.img_processor)
        self._model.img_processor.embeddings._orig_forward = self._model.img_processor.embeddings.forward
        self._model.img_processor.embeddings.forward = types.MethodType(
            embd_forward, self._model.img_processor.embeddings
        )

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)
        self._model.forward = self._model.__orig_forward
        for layer in self._model.img_processor.encoder.layers:
            if hasattr(layer.self_attn, "_orig_frward"):
                layer.self_attn.forward = layer.self_attn._orig_forward
        self._model.img_processor.forward = self._model.img_processor._orig_forward
        self._model.img_processor.embeddings.forward = self._model.img_processor.embeddings._orig_forward


class Llama4ImageEmbeddingsModelPatcher(ModelPatcher):
    def __init__(
        self,
        config: "OpenVINOConfig",
        model: "PreTrainedModel",
        model_kwargs: Dict[str, Any],
    ):
        model.__orig_forward = model.forward

        # Adopted from https://github.com/huggingface/transformers/blob/v4.51.0/src/transformers/models/llama4/modeling_llama4.py#L1732-L1741
        def get_image_embeddings(self, pixel_values):
            if is_transformers_version("<", "4.57"):
                image_features = self.get_image_features(
                    pixel_values=pixel_values,
                    vision_feature_layer=self.config.vision_config.vision_feature_layer,
                    vision_feature_select_strategy=self.config.vision_config.vision_feature_select_strategy,
                )
            else:
                image_features = self.get_image_features(
                    pixel_values=pixel_values,
                    vision_feature_select_strategy=self.config.vision_config.vision_feature_select_strategy,
                )
            vision_flat = image_features.view(-1, image_features.size(-1))
            projected_vision_flat = self.multi_modal_projector(vision_flat)
            return projected_vision_flat

        model.forward = types.MethodType(get_image_embeddings, model)
        super().__init__(config, model, model_kwargs)

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)

        self._model.forward = self._model.__orig_forward


# modified from https://github.com/huggingface/transformers/blob/v4.51.0/src/transformers/models/llama4/modeling_llama4.py#L229
# use real cos / sin instead of complex
def llama4_rope_forward(self, x, position_ids):
    if "dynamic" in self.rope_type:
        self._dynamic_frequency_update(position_ids, device=x.device)
    # Core RoPE block
    inv_freq_expanded = self.inv_freq[None, :, None].float().expand(position_ids.shape[0], -1, 1)
    position_ids_expanded = position_ids[:, None, :].float()
    # Force float32 (see https://github.com/huggingface/transformers/pull/29285)
    device_type = x.device.type
    device_type = device_type if isinstance(device_type, str) and device_type != "mps" else "cpu"
    with torch.autocast(device_type=device_type, enabled=False):
        freqs = (inv_freq_expanded.float() @ position_ids_expanded.float()).transpose(1, 2)
        emb = torch.cat((freqs, freqs), dim=-1)
        cos = emb.cos() * self.attention_scaling
        sin = emb.sin() * self.attention_scaling

    return cos.to(dtype=x.dtype), sin.to(dtype=x.dtype)


# use real cos / sin instead of complex
# Modified from https://github.com/huggingface/transformers/blob/v4.51.3/src/transformers/models/llama4/modeling_llama4.py#L247
# Based on https://github.com/huggingface/transformers/blob/v4.51.3/src/transformers/models/deepseek_v3/modeling_deepseek_v3.py#L292
# Native DeepSeek apply rotary emb works in the same way like llama4 apply rotary emb
def llama4_apply_rotary_emb(
    xq: torch.Tensor, xk: torch.Tensor, cos: torch.Tensor, sin: torch.Tensor
) -> Tuple[torch.Tensor, torch.Tensor]:
    from transformers.models.llama.modeling_llama import rotate_half

    xq_ = xq.float()
    xk_ = xk.float()
    cos = cos.unsqueeze(2)
    sin = sin.unsqueeze(2)
    b, h, s, d = xq_.shape
    xq_ = xq_.view(b, h, s, d // 2, 2).transpose(4, 3).reshape(b, h, s, d)

    b, h, s, d = xk_.shape
    xk_ = xk_.view(b, h, s, d // 2, 2).transpose(4, 3).reshape(b, h, s, d)

    q_embed = (xq_ * cos) + (rotate_half(xq_) * sin)
    k_embed = (xk_ * cos) + (rotate_half(xk_) * sin)
    return q_embed.type_as(xq), k_embed.type_as(xk)


# https://github.com/huggingface/transformers/blob/v4.51.0/src/transformers/models/llama4/modeling_llama4.py#L329
# use real cos / sin instead of complex
def llama4_attn_forward(
    self,
    hidden_states: torch.Tensor,
    position_embeddings: Tuple[torch.Tensor, torch.Tensor],
    attention_mask: Optional[torch.Tensor],
    past_key_value: Optional[tuple[tuple[torch.Tensor]]] = None,
    past_key_values: Optional[tuple[tuple[torch.Tensor]]] = None,
    cache_position: Optional[torch.LongTensor] = None,
    **kwargs,
) -> Tuple[torch.Tensor, Optional[torch.Tensor], Optional[Tuple[torch.Tensor]]]:
    from transformers.models.llama4.modeling_llama4 import ALL_ATTENTION_FUNCTIONS, eager_attention_forward

    past_key_value = past_key_value or past_key_values

    input_shape = hidden_states.shape[:-1]
    hidden_shape = (*input_shape, -1, self.head_dim)

    query_states = self.q_proj(hidden_states).view(hidden_shape)
    key_states = self.k_proj(hidden_states).view(*input_shape, -1, self.head_dim)
    value_states = self.v_proj(hidden_states).view(hidden_shape).transpose(1, 2)

    if self.use_rope:  # the 16E model skips rope for long context on certain layers
        cos, sin = position_embeddings[0], position_embeddings[1]
        query_states, key_states = llama4_apply_rotary_emb(
            query_states, key_states, cos.to(query_states.device), sin.to(query_states.device)
        )

    if hasattr(self, "qk_norm"):  # the 128E model does not use qk_norm
        query_states = self.qk_norm(query_states)
        key_states = self.qk_norm(key_states)

    # Use temperature tuning from https://arxiv.org/abs/2501.19399) to NoROPE layers
    if self.attn_temperature_tuning and not self.use_rope:
        attn_scales = (
            torch.log1p(torch.floor((cache_position.float() + 1.0) / self.floor_scale)) * self.attn_scale + 1.0
        )
        attn_scales = attn_scales.view((1, input_shape[-1], 1, 1)).expand((*input_shape, 1, 1))  # batch size > 1
        query_states = (query_states * attn_scales).to(query_states.dtype)

    query_states = query_states.transpose(1, 2)
    key_states = key_states.transpose(1, 2)

    if past_key_value is not None:
        # sin and cos are specific to RoPE models; cache_position needed for the static cache
        cache_kwargs = {"cache_position": cache_position}
        key_states, value_states = past_key_value.update(key_states, value_states, self.layer_idx, cache_kwargs)

    attention_interface = eager_attention_forward
    if self.config._attn_implementation != "eager":
        attention_interface = ALL_ATTENTION_FUNCTIONS[self.config._attn_implementation]

    attn_output, attn_weights = attention_interface(
        self,
        query_states,
        key_states,
        value_states,
        attention_mask,
        dropout=0.0 if not self.training else self.attention_dropout,
        scaling=self.scaling,
        **kwargs,
    )

    attn_output = attn_output.reshape(*input_shape, -1).contiguous()
    attn_output = self.o_proj(attn_output)
    return attn_output, attn_weights


# Copied from https://github.com/huggingface/transformers/blob/v4.56.0/src/transformers/masking_utils.py#L105
# transformers.masking_utils._legacy_chunked_overlay deprecated since transformers v5
def _legacy_chunked_overlay(chunk_size: int) -> Callable:
    def inner_mask(batch_idx: int, head_idx: int, q_idx: int, kv_idx: int) -> bool:
        return kv_idx // chunk_size == q_idx // chunk_size

    return inner_mask


class Llama4TextModelPatcher(ModelPatcher):
    def __enter__(self):
        super().__enter__()

        self._model.model.rotary_emb._orig_forward = self._model.model.rotary_emb.forward
        self._model.model.rotary_emb.forward = types.MethodType(llama4_rope_forward, self._model.model.rotary_emb)
        for layer in self._model.model.layers[: self._model.model.config.num_hidden_layers]:
            layer.self_attn._orig_forward = layer.self_attn.forward
            layer.self_attn.forward = types.MethodType(llama4_attn_forward, layer.self_attn)

        if is_transformers_version(">=", "4.56"):
            # openvino is not able to trace through the new chunked_overlay with left_padding
            self.original_chunked_overlay = transformers.masking_utils.chunked_overlay
            transformers.masking_utils.chunked_overlay = lambda chunk_size, left_padding: _legacy_chunked_overlay(
                chunk_size
            )

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)

        self._model.model.rotary_emb.forward = self._model.model.rotary_emb._orig_forward
        for layer in self._model.model.layers[: self._model.model.config.num_hidden_layers]:
            layer.self_attn.forward = layer.self_attn._orig_forward

        if is_transformers_version(">=", "4.56"):
            transformers.masking_utils.chunked_overlay = self.original_chunked_overlay


# Vectorized implementation of ConvSequenceTransform to avoid if-else branching
class ConvSequenceTransform(torch.nn.Module):
    def __init__(self, conv_kernel_size, use_conv_bias, conv1, act, conv_bias):
        super().__init__()
        self.conv_kernel_size = conv_kernel_size
        self.use_conv_bias = use_conv_bias
        self.conv1d = conv1
        self.act = act
        self.conv_bias = conv_bias

    def forward(self, hidden_states, cache_position, conv_state):
        # Pad the input
        is_prefill = cache_position.shape[0] == self.conv_kernel_size
        pad_value = (self.conv_kernel_size - hidden_states.shape[-1]) * (is_prefill)
        new_conv_state = torch.nn.functional.pad(hidden_states, (pad_value, 0))

        # Update convolutional state
        upd_cache_position = cache_position.clamp(0, self.conv_kernel_size - 1)
        upd_conv_state = conv_state.roll(shifts=-1, dims=-1)
        upd_conv_state[:, :, upd_cache_position] = new_conv_state

        # compute both versions of hidden_states
        # 1. cache_position.shape[0] == self.conv_kernel_size, prefill step
        prefill_kernel_applied = self.conv1d(hidden_states)[:, :, : hidden_states.shape[-1]]

        # the second version
        # 2. re-compute conv_states for decoding step
        new_upd_conv_state = upd_conv_state * self.conv1d.weight[:, 0, :]
        decoder_kernel_applied = new_upd_conv_state.sum(dim=-1, keepdim=True)
        decoder_kernel_applied = decoder_kernel_applied.squeeze(2)
        if self.use_conv_bias:
            decoder_kernel_applied += self.conv_bias
        decoder_kernel_applied = decoder_kernel_applied.unsqueeze(-1)

        # Select the correct result
        is_prefill = torch.tensor(is_prefill, dtype=hidden_states.dtype)
        hidden_states = is_prefill * prefill_kernel_applied + (1 - is_prefill) * decoder_kernel_applied

        # Apply activation
        hidden_states = self.act(hidden_states)
        return hidden_states, upd_conv_state


# Vectorized implementation of the selective scan to compute SSM states and scan outputs at each time step
class SelectiveScan(torch.nn.Module):
    def forward(self, ssm, u, dt, A, B, C, D):
        # dt - [batch, seq_len, intermediate_size]
        # A - [intermediate_size, ssm_state_size]
        # B [batch, seq_len, ssm_state_size]
        # u, hidden states - [batch, seq_len, intermediate_size]
        dA = dt.unsqueeze(-1) * A
        dB_u = dt * u  # shape: (b, l, d)
        dB_u = dB_u.unsqueeze(-1) * B.unsqueeze(2)  # (b, l, d, 1) * (b, l, 1, n) => (b, l, d, n)
        dA_cumsum = torch.nn.functional.pad(dA[:, 1:], (0, 0, 0, 0, 0, 1)).flip(1).cumsum(1).exp().flip(1)
        x = dB_u * dA_cumsum + (ssm.unsqueeze(1) * dA[:, :1].exp())
        x = x.cumsum(1) / (dA_cumsum + 1e-12)
        y = (x * C.unsqueeze(2)).sum(dim=-1)
        return y + u * D, x[:, -1, :, :]


# The original implementation of this forward method can be found at:
# https://github.com/huggingface/transformers/blob/v4.53.2/src/transformers/models/mamba/modeling_mamba.py#L233
# This patch modifies the method to vectorize the selective scan procedure, enabling correct graph tracing
def mamba_mixer_forward(
    self,
    input_states,
    cache_params=None,
    cache_position: Optional[torch.LongTensor] = None,
    attention_mask: Optional[torch.LongTensor] = None,
):
    batch_size, seq_len, _ = input_states.shape
    dtype = input_states.dtype
    # 1. Gated MLP's linear projection
    projected_states = self.in_proj(input_states).transpose(1, 2)  # [batch, 2 * intermediate_size, seq_len]
    hidden_states, gate = projected_states.chunk(2, dim=1)

    if attention_mask is not None:
        hidden_states = hidden_states * attention_mask.unsqueeze(1)

    # 2. Convolution sequence transformation
    if cache_params is not None:
        ssm_state = cache_params.ssm_states[self.layer_idx].clone()
        ssm_state = ssm_state.to(hidden_states.device)
        # use `cache_position.shape[0]` to check whether we are in prefill
        # stage, it's equivalent to check `cache_position[0] == 0`, which
        # breaks dynamo fullgraph constraints
        hidden_states, conv_state = self.conv_sequence_transform(
            hidden_states, cache_position, cache_params.conv_states[self.layer_idx]
        )
        cache_params.conv_states[self.layer_idx] = conv_state
    else:
        ssm_state = torch.zeros(
            (batch_size, self.intermediate_size, self.ssm_state_size), device=hidden_states.device, dtype=dtype
        )
        hidden_states = self.act(self.conv1d(hidden_states)[..., :seq_len])  # [batch, intermediate_size, seq_len]

    if attention_mask is not None:
        hidden_states = hidden_states * attention_mask.unsqueeze(1)

    # 3. State Space Model sequence transformation
    # 3.a. Selection:  [batch, seq_len, self.time_step_rank + self.ssm_state_size * 2]
    ssm_parameters = self.x_proj(hidden_states.transpose(1, 2))
    time_step, B, C = torch.split(
        ssm_parameters, [self.time_step_rank, self.ssm_state_size, self.ssm_state_size], dim=-1
    )

    if self.ssm_rms_normalization:
        B = self.ssm_rms_normalization(B, variance_epsilon=self.rms_eps)
        C = self.ssm_rms_normalization(C, variance_epsilon=self.rms_eps)
        time_step = self.ssm_rms_normalization(time_step, variance_epsilon=self.rms_eps)

    discrete_time_step = self.dt_proj(time_step)  # [batch, seq_len, intermediate_size]
    discrete_time_step = torch.nn.functional.softplus(discrete_time_step)  # [batch, intermediate_size, seq_len]

    # 3.b. Discretization: B and C to [batch, seq_len, intermediate_size, ssm_state_size] (SRAM)
    A = -torch.exp(self.A_log.float())
    B = B.float()
    D = self.D.float()

    scan_output, ssm_state = self.selective_scan(
        ssm_state, hidden_states.float().transpose(1, 2), discrete_time_step, A, B, C, D
    )
    scan_output = scan_output.transpose(1, 2)
    scan_output = scan_output * self.act(gate)

    if cache_params is not None:
        cache_params.ssm_states[self.layer_idx].copy_(ssm_state)

    # 4. Final linear projection
    contextualized_states = self.out_proj(scan_output.transpose(1, 2))  # [batch, seq_len, hidden_size]
    return contextualized_states


# This patcher class serves the following purposes:
# 1. Inject a MambaCache structure into the original model to simplify input and output handling related to SSM states
# 2. Patch ConvSequenceTransform module to avoid if-else branching
# 3. Vectorize the selective scan operation to ensure correct behavior during JIT tracing
class MambaPatcher(ModelPatcher):
    def __init__(
        self,
        config: "OpenVINOConfig",
        model: "PreTrainedModel",
        model_kwargs: Optional[Dict[str, Any]] = None,
    ):
        try:
            from transformers.models.mamba.modeling_mamba import MambaCache
        except ImportError:
            MambaCache = object

        super().__init__(config, model, model_kwargs)

        class MambaCacheWrap(MambaCache):
            # This class serves to create MambaCache object for additional input data format
            # when lists of tensors representing convolution and SSM states are separated
            def __init__(
                self,
                config: "PretrainedConfig",
                batch_size: int = None,
                dtype: torch.dtype = torch.float32,
                device: Optional[Union[torch.device, str]] = None,
                max_batch_size: Optional[int] = None,
                conv_states: Optional[List[torch.Tensor]] = None,
                ssm_states: Optional[List[torch.Tensor]] = None,
            ):
                self.dtype = dtype
                self.max_batch_size = batch_size or max_batch_size
                self.intermediate_size = config.intermediate_size
                self.ssm_state_size = config.state_size
                self.conv_kernel_size = config.conv_kernel
                self.device = torch.device(device) if device is not None else torch.device("cpu")

                if conv_states is not None:
                    self.conv_states = conv_states
                else:
                    self.conv_states = []
                    for _ in range(config.num_hidden_layers):
                        conv_state: torch.Tensor = torch.zeros(
                            self.max_batch_size,
                            self.intermediate_size,
                            self.conv_kernel_size,
                            device=self.device,
                            dtype=dtype,
                        )
                        self.conv_states.append(conv_state)

                if ssm_states is not None:
                    self.ssm_states = ssm_states
                else:
                    self.ssm_states: List[torch.Tensor] = []
                    for _ in range(config.num_hidden_layers):
                        ssm_state: torch.Tensor = torch.zeros(
                            self.max_batch_size,
                            self.intermediate_size,
                            self.ssm_state_size,
                            device=self.device,
                            dtype=dtype,
                        )

                        self.ssm_states.append(ssm_state)

        def patched_forward(
            input_ids,
            attention_mask=None,
            cache_params=None,
            cache_position=None,
        ):
            use_cache = False
            wrapped_cache_params = None
            if cache_params is not None:
                use_cache = True
                # past_ssm_conv_states is a list of tuples of (ssm_state, conv_state) for each Mamba block
                ssm_states = [ssm_conv_state[0] for ssm_conv_state in cache_params]
                conv_states = [ssm_conv_state[1] for ssm_conv_state in cache_params]
                wrapped_cache_params = MambaCacheWrap(
                    self.real_config._config,
                    input_ids.shape[0],
                    conv_states=conv_states,
                    ssm_states=ssm_states,
                )

            result = self.orig_forward(
                input_ids=input_ids,
                attention_mask=attention_mask,
                cache_position=cache_position,
                cache_params=wrapped_cache_params,
                use_cache=use_cache,
            )

            if use_cache:
                present_ssm_conv_states = []
                for ssm_state, conv_state in zip(result.cache_params.ssm_states, result.cache_params.conv_states):
                    present_ssm_conv_states.append(
                        (
                            ssm_state,
                            conv_state,
                        )
                    )
                result = {
                    "logits": result.logits,
                    "cache_params_present": present_ssm_conv_states,
                }

            return result

        self.patched_forward = patched_forward

        model_type = getattr(self.real_config._config, "model_type", None)
        self.ssm_rms_normalization = None

        # falcon-mamba model has only difference from mamba that is RMS normalization for B, C, and time-step coefficients
        if model_type == "falcon_mamba":
            from transformers.models.falcon_mamba.modeling_falcon_mamba import rms_forward

            self.ssm_rms_normalization = rms_forward

    def __enter__(self):
        super().__enter__()
        setattr(self._model, self.orig_forward_name, self.patched_forward)
        selective_scan = SelectiveScan()

        for layer in self._model.backbone.layers:
            layer.mixer.selective_scan = selective_scan
            layer.mixer._orig_forward = layer.mixer.forward

            layer.mixer.ssm_rms_normalization = self.ssm_rms_normalization

            layer.mixer.forward = types.MethodType(mamba_mixer_forward, layer.mixer)
            conv_transform = ConvSequenceTransform(
                layer.mixer.conv_kernel_size,
                layer.mixer.use_conv_bias,
                layer.mixer.conv1d,
                layer.mixer.act,
                layer.mixer.conv1d.bias,
            )
            layer.mixer.conv_sequence_transform = conv_transform

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)
        setattr(self._model, self.orig_forward_name, self.orig_forward)
        for layer in self._model.backbone.layers:
            layer.mixer.forward = layer.mixer._orig_forward


# https://github.com/huggingface/transformers/blob/v4.53.0/src/transformers/models/qwen3_moe/modeling_qwen3_moe.py#L228
def qwen3_moe_forward_patched(self, hidden_states: torch.Tensor) -> torch.Tensor:
    batch_size, sequence_length, hidden_dim = hidden_states.shape
    hidden_states = hidden_states.view(-1, hidden_dim)
    # router_logits: (batch * sequence_length, n_experts)
    router_logits = self.gate(hidden_states)

    routing_weights = torch.nn.functional.softmax(router_logits, dim=1, dtype=torch.float)
    routing_weights, selected_experts = torch.topk(routing_weights, self.top_k, dim=-1)
    if self.norm_topk_prob:  # only diff with mixtral sparse moe block!
        routing_weights /= routing_weights.sum(dim=-1, keepdim=True)
    # we cast back to the input dtype
    routing_weights = routing_weights.to(hidden_states.dtype)

    final_hidden_states = torch.zeros(
        (batch_size * sequence_length, hidden_dim), dtype=hidden_states.dtype, device=hidden_states.device
    )

    # One hot encode the selected experts to create an expert mask
    # this will be used to easily index which expert is going to be sollicitated
    expert_mask = torch.nn.functional.one_hot(selected_experts, num_classes=self.num_experts).permute(2, 1, 0)

    # TODO: we loop over all possible experts instead of hitted ones to avoid issues in graph execution.
    # expert_hitted = torch.greater(expert_mask.sum(dim=(-1, -2)), 0).nonzero()
    # Loop over all available experts in the model and perform the computation on each expert
    for expert_idx in range(self.num_experts):
        expert_layer = self.experts[expert_idx]
        idx, top_x = torch.where(expert_mask[expert_idx].squeeze(0))

        # Index the correct hidden states and compute the expert hidden state for
        # the current expert. We need to make sure to multiply the output hidden
        # states by `routing_weights` on the corresponding tokens (top-1 and top-2)
        current_state = hidden_states[None, top_x].reshape(-1, hidden_dim)
        current_hidden_states = expert_layer(current_state) * routing_weights[top_x, idx, None]

        # However `index_add_` only support torch tensors for indexing so we'll use
        # the `top_x` tensor here.
        final_hidden_states.index_add_(0, top_x, current_hidden_states.to(hidden_states.dtype))
    final_hidden_states = final_hidden_states.reshape(batch_size, sequence_length, hidden_dim)
    return final_hidden_states, router_logits


class Qwen3MoeModelPatcher(OVDecoderModelPatcher):
    def __enter__(self):
        super().__enter__()

        if is_transformers_version("<", "5"):
            self.original_moe_forward = Qwen3MoeSparseMoeBlock.forward
            Qwen3MoeSparseMoeBlock.forward = qwen3_moe_forward_patched
        else:
            from transformers.models.qwen3_moe.modeling_qwen3_moe import Qwen3MoeExperts

            self.original_moe_forward = Qwen3MoeExperts.forward
            Qwen3MoeExperts.forward = lfm2_moe_experts_forward

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)

        if is_transformers_version("<", "5"):
            Qwen3MoeSparseMoeBlock.forward = self.original_moe_forward
        else:
            from transformers.models.qwen3_moe.modeling_qwen3_moe import Qwen3MoeExperts

            Qwen3MoeExperts.forward = self.original_moe_forward


# The original implementation of this forward method can be found at:
# https://github.com/huggingface/transformers/blob/v4.55.4/src/transformers/models/zamba2/modeling_zamba2.py#L729
# This patch modifies `forward()` so that when traced by torch.jit, it works correctly
# during both the prefill and decoding steps.
# The patched version differs from the original in that it executes both the prefill
# and decoding branches every time to compute and store the values of B, C, hidden states,
# conv_state, and ssm_state in the cache.
# The distinction between prefill and decoding modes is determined by the sequence length
# (seq_len): 1. seq_len > 1 indicates the prefill phase;
# seq_len = 1 indicates the decoding phase.
def zamba2_mamba_mixer(
    self,
    hidden_states,
    cache_params=None,
    cache_position: Optional[torch.LongTensor] = None,
    attention_mask: Optional[torch.Tensor] = None,
):
    def pad_tensor_by_size(input_tensor: torch.Tensor, pad_size: int):
        pad_shape = (0, 0, 0, 0, 0, pad_size, 0, 0) if len(input_tensor.shape) == 4 else (0, 0, 0, pad_size, 0, 0)
        return torch.nn.functional.pad(input_tensor, pad_shape, mode="constant", value=0)

    def reshape_into_chunks(input_tensor, pad_size, chunk_size):
        # [bsz, seq_len, ...] -> [bsz, seq_len multiple of chunk_size, ...]
        input_tensor = pad_tensor_by_size(input_tensor, pad_size)
        if len(input_tensor.shape) == 3:
            # [bsz, seq_len multiple of chunk_size, num_heads] -> [bsz, -1, chunk_size, num_heads]
            return input_tensor.reshape(input_tensor.shape[0], -1, chunk_size, input_tensor.shape[2])
        else:
            # [bsz, seq_len multiple of chunk_size, num_heads, head_dim or state_size] -> [bsz, -1, chunk_size, num_heads, head_dim or state_size]
            return input_tensor.reshape(
                input_tensor.shape[0], -1, chunk_size, input_tensor.shape[2], input_tensor.shape[3]
            )

    def segment_sum(input_tensor):
        chunk_size = input_tensor.size(-1)
        # 1. expand input tensor to have an additional dimension and repeat along that dimension
        # [..., chunk_size] -> [..., chunk_size, chunk_size]
        input_tensor = input_tensor[..., None].expand(*input_tensor.size(), chunk_size)
        # 2. create a lower triangular mask with the diagonal set to 0 to 0 out elements above diag
        mask = torch.tril(
            torch.ones(chunk_size, chunk_size, device=input_tensor.device, dtype=torch.bool), diagonal=-1
        )
        input_tensor = input_tensor.masked_fill(~mask, 0)
        # 3. compute actual cumsum
        tensor_segsum = torch.cumsum(input_tensor, dim=-2)
        # 4. apply mask to keep only the lower triangular part of the cumulative sum result (incl diagonal this time)
        mask = torch.tril(torch.ones(chunk_size, chunk_size, device=input_tensor.device, dtype=torch.bool), diagonal=0)
        tensor_segsum = tensor_segsum.masked_fill(~mask, -torch.inf)
        return tensor_segsum

    input_states = hidden_states
    layer_idx = self.layer_idx
    if cache_params is not None and hasattr(cache_params, "mamba_layer_idx_mapping"):
        layer_idx = cache_params.mamba_layer_idx_mapping[layer_idx]

    batch_size, seq_len, _ = input_states.shape
    dtype = input_states.dtype

    # distinguish prefill and decoding stage
    is_decoding = torch.tensor(seq_len == 1).to(dtype)

    # Gated MLP's linear projection
    input_states_prefill = (input_states * attention_mask[:, :seq_len, None]).to(dtype)
    input_states_dec = input_states
    input_states = input_states_dec * is_decoding + input_states_prefill * (1.0 - is_decoding)
    projected_states = self.in_proj(input_states)

    d_mlp = (
        projected_states.shape[-1]
        - 2 * self.intermediate_size
        - 2 * self.n_groups * self.ssm_state_size
        - self.num_heads
    ) // 2
    _, _, gate, hidden_states, dt = projected_states.split(
        [d_mlp, d_mlp, self.intermediate_size, self.conv_dim, self.num_heads], dim=-1
    )

    # 1. Convolution sequence transformation
    # 1.1 Convolution sequence transformation for decoding step
    if cache_params is not None:
        conv_state_dec = cache_params.conv_states[layer_idx]
        conv_state_dec = torch.roll(conv_state_dec, shifts=-1, dims=-1)
        conv_state_dec[:, :, -1] = hidden_states[:, 0, :] if hidden_states.ndim == 3 else hidden_states

        hidden_states_dec = torch.sum(conv_state_dec.to(projected_states.device) * self.conv1d.weight[:, 0, :], dim=-1)
        if self.use_conv_bias:
            hidden_states_dec += self.conv1d.bias
        hidden_states_dec = self.act(hidden_states_dec).to(dtype)[
            :, None, ...
        ]  # [batch, 1, intermediate_size] : decoding

        # 1.2 Convolution sequence transformation for prefill step
        hidden_states_prefill = hidden_states.transpose(1, 2)
        conv_state_prefill = torch.nn.functional.pad(
            hidden_states_prefill, (self.conv_kernel_size - hidden_states_prefill.shape[-1], 0)
        )

        hidden_states_prefill = self.act(self.conv1d(hidden_states_prefill).transpose(1, 2))[
            :, :seq_len, :
        ]  # [batch, intermediate_size, seq_len]
        if attention_mask is not None:
            # tune out hidden states for pad tokens, see https://github.com/state-spaces/mamba/issues/66
            hidden_states_prefill = (hidden_states_prefill * attention_mask[:, :seq_len, None]).to(dtype)

        # Compute final conv state and set into the cache
        conv_state = conv_state_prefill * (1.0 - is_decoding) + conv_state_dec * is_decoding
        cache_params.conv_states[layer_idx].copy_(conv_state)
    else:
        hidden_states_prefill = self.act(self.conv1d(hidden_states.transpose(1, 2))[..., :seq_len].transpose(1, 2))
        hidden_states_dec = hidden_states_prefill[:, :1]

    hidden_states_prefill, B_prefill, C_prefill = torch.split(
        hidden_states_prefill,
        [self.intermediate_size, self.n_groups * self.ssm_state_size, self.n_groups * self.ssm_state_size],
        dim=-1,
    )
    hidden_states_dec, B_dec, C_dec = torch.split(
        hidden_states_dec,
        [self.intermediate_size, self.n_groups * self.ssm_state_size, self.n_groups * self.ssm_state_size],
        dim=-1,
    )

    A = -torch.exp(self.A_log.float())  # [num_heads]

    # 2. SSM state
    # 2.1 Compute SSM state for decoding step
    if cache_params is not None:
        dt_dec = dt
        dt_dec = dt_dec.reshape(dt_dec.shape[0], -1, dt_dec.shape[-1])[:, :1, :]
        # dt - [B, 1, H], H - num_heads
        dt_dec = dt_dec.transpose(1, 2).expand(
            batch_size, dt_dec.shape[-1], self.head_dim
        )  # dt - [B, num_heads, head_dim]
        dt_bias_dec = self.dt_bias
        dt_bias_dec = dt_bias_dec.reshape(dt_bias_dec.shape[0], -1).expand(
            dt_bias_dec.shape[0], self.head_dim
        )  # dt_bias [num_heads, head_dim]
        dt_dec = torch.nn.functional.softplus(dt_dec + dt_bias_dec)
        dt_dec = torch.clamp(dt_dec, self.time_step_min)  # dt - [B, num_heads, head_dim]

        A_dec = A[..., None, None].expand(self.num_heads, self.head_dim, self.ssm_state_size).to(dtype=torch.float32)
        dA = torch.exp(dt_dec[..., None] * A_dec)

        # Discretize B
        # [bsz, n_groups * state_size] -> [bsz, n_groups, 1, state_size] ->
        # -> [bsz, n_groups, group to head repetition factor, state_size] -> [bsz, num_heads, state_size]
        B_dec = B_dec.reshape(batch_size, -1)[:, : self.n_groups * self.ssm_state_size]
        B_dec = B_dec.reshape(batch_size, self.n_groups, -1)[..., None, :]
        B_dec = B_dec.expand(batch_size, self.n_groups, self.num_heads // self.n_groups, B_dec.shape[-1]).contiguous()
        B_dec = B_dec.reshape(batch_size, -1, B_dec.shape[-1])
        dB = dt_dec[..., None] * B_dec[..., None, :]

        # Discretize x into dB
        # [bsz, intermediate_size] -> [bsz, num_heads, head_dim]
        hidden_states_dec = hidden_states_dec.reshape(batch_size, -1, self.head_dim)
        dBx = dB * hidden_states_dec[..., None]

        # State calculation
        new_ssm_state_dec = cache_params.ssm_states[layer_idx] * dA + dBx

        # Subsequent output
        # [bsz, n_groups * state_size] -> [bsz, num_heads, state_size]
        C_dec = C_dec.reshape(batch_size, -1)[:, : self.n_groups * self.ssm_state_size]
        C_dec = C_dec.reshape(batch_size, self.n_groups, -1)[..., None, :]
        C_dec = C_dec.expand(batch_size, self.n_groups, self.num_heads // self.n_groups, C_dec.shape[-1]).contiguous()
        C_dec = C_dec.reshape(batch_size, -1, C_dec.shape[-1])

        ssm_states_dec = new_ssm_state_dec.to(C_dec.dtype)  # Shape: [b, h, d, n]

        # Reshape ssm_states to merge the first two dimensions
        ssm_states_reshaped = ssm_states_dec.view(batch_size * self.num_heads, self.head_dim, self.ssm_state_size)
        C_reshaped = C_dec.view(batch_size * self.num_heads, self.ssm_state_size, 1)  # Shape: [b*h, n, 1]
        y_dec = torch.bmm(ssm_states_reshaped, C_reshaped)
        y_dec = y_dec.view(batch_size, self.num_heads, self.head_dim)

        # D skip connection
        # [num_heads] -> [num_heads, head_dim]
        D_dec = self.D
        D_dec = D_dec[..., None].expand(D_dec.shape[0], self.head_dim)
        y_dec = (y_dec + hidden_states_dec * D_dec).to(y_dec.dtype)

        # [bsz, num_heads, head_dim] -> [bsz, 1, intermediate_size]
        y_dec = y_dec.reshape(batch_size, -1)[:, None, ...]

    # 2.2 Compute SSM state for prefill step
    dt = torch.nn.functional.softplus(dt + self.dt_bias)
    dt = torch.clamp(dt, self.time_step_min)

    hidden_states_prefill = hidden_states_prefill.reshape(batch_size, seq_len, -1, self.head_dim).float()
    B_prefill = B_prefill.reshape(batch_size, seq_len, -1, self.ssm_state_size).float()
    C_prefill = C_prefill.reshape(batch_size, seq_len, -1, self.ssm_state_size).float()
    B_prefill = B_prefill.repeat_interleave(self.num_heads // self.n_groups, dim=2, output_size=self.num_heads)
    C_prefill = C_prefill.repeat_interleave(self.num_heads // self.n_groups, dim=2, output_size=self.num_heads)
    pad_size = (self.chunk_size - seq_len % self.chunk_size) % self.chunk_size

    D_residual = self.D[..., None] * pad_tensor_by_size(hidden_states_prefill, pad_size)

    # Discretize x and A
    hidden_states_prefill = hidden_states_prefill * dt[..., None]
    A = A.to(hidden_states_prefill.dtype) * dt

    # Rearrange into blocks/chunks
    hidden_states_prefill, A, B_prefill, C_prefill = [
        reshape_into_chunks(t, pad_size, self.chunk_size) for t in (hidden_states_prefill, A, B_prefill, C_prefill)
    ]

    # [bsz, -1, chunk_size, num_heads] -> [bsz, num_heads, -1, chunk_size]
    A = A.permute(0, 3, 1, 2)
    A_cumsum = torch.cumsum(A, dim=-1)

    # Compute the output for each intra-chunk (diagonal blocks)
    # This is the analog of a causal mask
    L = torch.exp(segment_sum(A))

    # First, contraction of C and B to get G (attention-weights like)
    G_intermediate = C_prefill[:, :, :, None, :, :] * B_prefill[:, :, None, :, :, :]  # shape: (b, c, l, s, h, n)
    G = G_intermediate.sum(dim=-1)  # shape: (b, c, l, s, h)

    # Compute M, equivalent to applying attention mask to weights
    M_intermediate = G[..., None] * L.permute(0, 2, 3, 4, 1)[..., None]
    M = M_intermediate.sum(dim=-1)

    # Compute Y_diag (apply to values)
    Y_diag = (M[..., None] * hidden_states_prefill[:, :, None]).sum(3)

    # (right term of low-rank factorization of off-diagonal blocks; B terms)
    decay_states = torch.exp(A_cumsum[:, :, :, -1:] - A_cumsum)
    B_decay_contraction = B_prefill * decay_states.permute(0, 2, 3, 1)[..., None]

    # permute back B * decay states
    states = (
        (
            B_decay_contraction.permute(0, 1, 3, 2, 4)[..., None]
            * hidden_states_prefill.permute(0, 1, 3, 2, 4)[..., None, :]
        )
        .sum(dim=3)
        .permute(0, 1, 2, 4, 3)
    )
    previous_states = torch.zeros_like(states[:, :1])

    states = torch.cat([previous_states, states], dim=1)
    decay_chunk = torch.exp(segment_sum(torch.nn.functional.pad(A_cumsum[:, :, :, -1], (1, 0))))

    states_permuted = states.permute(0, 2, 1, 3, 4)
    result = (decay_chunk[..., None, None] * states_permuted[:, :, None, ...]).sum(dim=2)
    new_states = result.permute(0, 2, 1, 3, 4)
    states, new_ssm_state_prefill = new_states[:, :-1], new_states[:, -1]

    # Compute state -> output conversion per chunk
    # (left term of low-rank factorization of off-diagonal blocks; C terms)
    state_decay_out = torch.exp(A_cumsum)

    # compute Yoff
    C_times_states = C_prefill[..., None, :] * states[:, :, None, ...]
    state_decay_out_permuted = state_decay_out.permute(0, 2, 3, 1)
    Y_off = C_times_states.sum(-1) * state_decay_out_permuted[..., None]

    # Add output of intra-chunk and inter-chunk terms (diagonal and off-diagonal blocks)
    y = Y_diag + Y_off

    # [bsz, -1, self.chunk_size, num_heads, head_dim] -> [bsz, (padded) seq_len, num_heads, head_dim]
    y = y.reshape(batch_size, -1, self.num_heads, self.head_dim)

    y = y + D_residual

    # Cutting off padded chunks
    pad_mask = torch.tensor(pad_size > 0).to(torch.long)
    y_new_len = y.size(1) * (1 - pad_mask) + seq_len * pad_mask
    y = y[:, :y_new_len]
    y_prefill = y.reshape(batch_size, seq_len, -1)

    if cache_params is not None:
        y = y_prefill[:, :seq_len] * (1.0 - is_decoding) + y_dec * is_decoding
        ssm_state = new_ssm_state_prefill * (1.0 - is_decoding) + new_ssm_state_dec * is_decoding

        # Set final ssm state into the cache
        cache_params.ssm_states[layer_idx].copy_(ssm_state)
    else:
        y = y_prefill

    scan_output = self.norm(y, gate)

    # Final linear projection
    contextualized_states = self.out_proj(scan_output.to(dtype))  # [batch, seq_len, hidden_size]

    return contextualized_states


# This patcher class serves the following purposes:
# 1. Packs the KV-cache, conv_state, and ssm_state tensors into a Zamba2HybridDynamicCache structure
#    for subsequent invocation of the model's `forward` method.
# 2. Patches the Zamba2MambaMixer so that the traced `forward` function works correctly
#    during both the prefill and decoding steps.
class Zamba2ModelPatcher(ModelPatcher):
    def __init__(
        self,
        config: "OpenVINOConfig",
        model: "PreTrainedModel",
        model_kwargs: Optional[Dict[str, Any]] = None,
    ):
        from transformers.models.zamba2.modeling_zamba2 import Zamba2HybridDynamicCache

        super().__init__(config, model, model_kwargs)

        class Zamba2HybridDynamicCacheWrap(Zamba2HybridDynamicCache):
            def __init__(self, config, batch_size: int, conv_states, ssm_states, key_cache, value_cache):
                # Call parent constructor with all required arguments
                super().__init__(config=config, batch_size=batch_size)
                self.conv_states = conv_states
                self.ssm_states = ssm_states
                self.key_cache = key_cache
                self.value_cache = value_cache
                self.layer_idx_mapping = {v: i for i, v in enumerate(config.hybrid_layer_ids)}

            def update(
                self,
                key_states: torch.Tensor,
                value_states: torch.Tensor,
                layer_idx: int,
                cache_kwargs: Optional[dict[str, Any]] = None,
            ) -> tuple[torch.Tensor, torch.Tensor]:
                # map layer_idx to key_cache (value_cache) idx
                layer_idx = self.layer_idx_mapping[layer_idx]
                # Update the cache
                if self.key_cache[layer_idx].shape[-1] == 0:
                    self.key_cache[layer_idx] = key_states
                    self.value_cache[layer_idx] = value_states
                else:
                    self.key_cache[layer_idx] = torch.cat([self.key_cache[layer_idx], key_states], dim=2)
                    self.value_cache[layer_idx] = torch.cat([self.value_cache[layer_idx], value_states], dim=2)

                return self.key_cache[layer_idx], self.value_cache[layer_idx]

            def __getitem__(self, layer_idx: int) -> tuple[torch.Tensor, torch.Tensor]:
                layer_idx = self.layer_idx_mapping[layer_idx]
                return self.key_cache[layer_idx], self.value_cache[layer_idx]

            def get_seq_length(self, layer_idx: Optional[int] = 0) -> int:
                # take any layer that contains cache and not empty tensor
                layer_idx = self.transformer_layers[0] if layer_idx not in self.transformer_layers else layer_idx
                layer_idx = self.layer_idx_mapping[layer_idx]
                if len(self.key_cache) <= layer_idx or self.key_cache[layer_idx].numel() == 0:
                    return 0
                return self.key_cache[layer_idx].shape[-2]

        # the patch is needed to include KV-cache, Conv, and SSM states in the inputs and outputs.
        def patched_forward(
            input_ids,
            attention_mask=None,
            cache_params=None,
        ):
            num_hidden_layers = self.real_config._config.num_hidden_layers
            num_hybrid_layers = len(self.real_config._config.hybrid_layer_ids)
            use_cache = False
            wrapped_cache_params = None
            if cache_params is not None:
                use_cache = True
                conv_states = []
                ssm_states = []
                key_cache = []
                value_cache = []

                # decouple ssm_states, conv_states, keys and values from cache_params
                batch_size = cache_params[0].size(0)
                for idx in range(num_hidden_layers):
                    conv_states.append(cache_params[2 * idx])
                    ssm_states.append(cache_params[2 * idx + 1])

                for idx in range(num_hybrid_layers):
                    key_cache.append(cache_params[2 * num_hidden_layers + 2 * idx])
                    value_cache.append(cache_params[2 * num_hidden_layers + 2 * idx + 1])

                wrapped_cache_params = Zamba2HybridDynamicCacheWrap(
                    self.real_config._config, batch_size, conv_states, ssm_states, key_cache, value_cache
                )

            causal_lm_output = self.model_orig_forward(
                input_ids=input_ids,
                attention_mask=attention_mask,
                past_key_values=wrapped_cache_params,
                use_cache=use_cache,
            )
            outputs = {
                "logits": causal_lm_output.logits,
            }

            if use_cache:
                past_key_values = causal_lm_output.past_key_values
                # unwrap Zamba2HybridDynamicCache object
                present_key_values = []
                for idx in range(num_hidden_layers):
                    present_key_values.append(past_key_values.conv_states[idx])
                    present_key_values.append(past_key_values.ssm_states[idx])

                for idx in range(num_hybrid_layers):
                    present_key_values.append(past_key_values.key_cache[idx])
                    present_key_values.append(past_key_values.value_cache[idx])

                outputs["present_key_values"] = present_key_values

            return outputs

        self.patched_forward = patched_forward
        self.model_orig_forward = self.orig_forward
        self.orig_forward = patched_forward

    def __enter__(self):
        from transformers.models.zamba2.modeling_zamba2 import Zamba2HybridLayer, Zamba2MambaDecoderLayer

        super().__enter__()
        setattr(self._model, self.orig_forward_name, self.patched_forward)

        for layer in self._model.model.layers:
            if isinstance(layer, Zamba2MambaDecoderLayer):
                mamba_layer = layer.mamba
            elif isinstance(layer, Zamba2HybridLayer):
                mamba_layer = layer.mamba_decoder.mamba
            else:
                continue
            mamba_layer._orig_forward = mamba_layer.forward
            mamba_layer.forward = types.MethodType(zamba2_mamba_mixer, mamba_layer)

    def __exit__(self, exc_type, exc_value, traceback):
        from transformers.models.zamba2.modeling_zamba2 import Zamba2HybridLayer, Zamba2MambaDecoderLayer

        super().__exit__(exc_type, exc_value, traceback)
        setattr(self._model, self.orig_forward_name, self.model_orig_forward)
        for layer in self._model.model.layers:
            if isinstance(layer, Zamba2MambaDecoderLayer):
                mamba_layer = layer.mamba
            elif isinstance(layer, Zamba2HybridLayer):
                mamba_layer = layer.mamba_decoder.mamba
            else:
                continue
            mamba_layer.forward = mamba_layer._orig_forward


# Unified torch representation of the CausalConv1d operation
# This representation is used across all models with CausalConv1d.
# The resulting OV graph for this function can be fused into the internal CausalConv1d operation.
def ov_causal_conv1d(conv_state, input_embeds, weight, bias):
    _, hidden_size, seq_len = input_embeds.shape
    _, w_in_channels, _ = weight.shape
    state_len = conv_state.shape[-1]
    groups = hidden_size // w_in_channels

    input_embeds_new = torch.cat([conv_state, input_embeds.to(conv_state.dtype)], dim=-1)
    conv_out = F.conv1d(input_embeds_new.to(weight.dtype), weight, bias, padding=0, groups=groups)
    conv_out = conv_out[:, :, -seq_len:]

    new_conv_state = input_embeds_new[:, :, -state_len:]

    return conv_out, new_conv_state


# The original implementation of this method can be found at:
# https://github.com/huggingface/transformers/blob/v4.57.1/src/transformers/models/lfm2/modeling_lfm2.py#L476
# This patch modifies `slow_forward()` so that when traced by torch.jit, it works correctly
# during both the prefill and decoding steps.
# The patched version differs from the original in that it executes both the prefill
# and decoding branches every time to compute and store the correct value of conv_state in the cache.
# The distinction between prefill and decoding modes is determined by the sequence length
# (seq_len): 1. seq_len > 1 indicates the prefill phase;
# seq_len = 1 indicates the decoding phase.
def lfm2_short_conv_forward_patched(
    self,
    x: torch.Tensor,
    past_key_values=None,
    cache_position=None,
    attention_mask=None,
):
    seqlen = x.shape[1]

    # only apply apply_mask_to_padding_states during the prefill phase
    # https://github.com/huggingface/transformers/blob/v5.0.0/src/transformers/models/lfm2/modeling_lfm2.py#L427
    # in transformers < v5 attention_mask was never applied in Lfm2ShortConv https://github.com/huggingface/transformers/blob/v4.57.6/src/transformers/models/lfm2/modeling_lfm2.py#L485
    # until a fix was added in https://github.com/huggingface/transformers/pull/41790/
    if is_transformers_version(">=", "5"):
        # since transformers v5.4, Lfm2ShortConv.slow_forward passes attention_mask as 3 positional arg
        if attention_mask is None and is_transformers_version(">=", "5.4"):
            attention_mask = cache_position
        dtype = x.dtype
        is_decoding = torch.tensor(seqlen == 1, dtype=dtype)
        x = (x * (attention_mask[:, :seqlen, None] * (1 - is_decoding) + is_decoding)).to(dtype)

    BCx = self.in_proj(x).transpose(-1, -2)
    B, C, x = BCx.chunk(3, dim=-2)

    Bx = B * x

    if past_key_values is not None:
        layer_idx = past_key_values.conv_layer_idx_mapping[self.layer_idx]
        conv_state = past_key_values.conv_cache[layer_idx]
        conv_out, new_conv_state = ov_causal_conv1d(conv_state, Bx, self.conv.weight, self.conv.bias)
        past_key_values.conv_cache[layer_idx].copy_(new_conv_state)
    else:
        conv_out = self.conv(Bx)[..., :seqlen]

    y = C * conv_out
    y = y.transpose(-1, -2).contiguous()
    y = self.out_proj(y)
    return y


# This patcher class serves the following purposes:
# 1. Packs the KV-cache and conv_state tensors into a Lfm2HybridConvCacheWrap structure
#    for subsequent invocation of the model's `forward` method.
# 2. Patches the Lfm2ShortConv so that the traced `slow_forward` function works correctly
#    during both the prefill and decoding steps.
class Lfm2ModelPatcher(OVDecoderModelPatcher):
    def __init__(
        self,
        config: "OpenVINOConfig",
        model: "PreTrainedModel",
        model_kwargs: Optional[Dict[str, Any]] = None,
    ):
        from transformers.models.lfm2.modeling_lfm2 import Lfm2HybridConvCache

        super().__init__(config, model, model_kwargs)

        # This cache wrapper class serves for following purposes:
        # 1. Wraps KV-cache and conv_state to allow model instantiation from tensor lists.
        # 2. Removes the unused cache items that the source model contains.
        # For this reason cache items re-indexing is required.
        class Lfm2HybridConvCacheWrap(Lfm2HybridConvCache):
            def __init__(self, config, max_batch_size: int, conv_cache, key_cache, value_cache):
                # Call parent constructor with all required arguments
                super().__init__(config=config, max_batch_size=max_batch_size)
                self.key_cache = key_cache
                self.value_cache = value_cache
                self.conv_cache = conv_cache
                self.conv_layer_idx_mapping = {}
                self.attention_layer_idx_mapping = {}
                conv_layer_idx = 0
                attention_layer_idx = 0
                for i in range(config.num_hidden_layers):
                    if config.layer_types[i] == "full_attention":
                        self.attention_layer_idx_mapping[i] = attention_layer_idx
                        attention_layer_idx += 1
                    elif config.layer_types[i] == "conv":
                        self.conv_layer_idx_mapping[i] = conv_layer_idx
                        conv_layer_idx += 1

            def update(
                self,
                key_states: torch.Tensor,
                value_states: torch.Tensor,
                layer_idx: int,
                cache_kwargs: Optional[dict[str, Any]] = None,
            ) -> tuple[torch.Tensor, torch.Tensor]:
                """
                Updates the cache with the new `key_states` and `value_states` for the layer `layer_idx`.
                Patching is required for calculating of the correct cache index.
                """
                # Update the cache
                layer_idx = self.attention_layer_idx_mapping[layer_idx]
                compute_dtype = key_states.dtype

                if self.key_cache[layer_idx].numel() == 0:
                    self.key_cache[layer_idx] = key_states
                    self.value_cache[layer_idx] = value_states
                else:
                    cache_dtype = self.key_cache[layer_idx].dtype
                    self.key_cache[layer_idx] = torch.cat(
                        [self.key_cache[layer_idx], key_states.to(cache_dtype)], dim=-2
                    )
                    self.value_cache[layer_idx] = torch.cat(
                        [self.value_cache[layer_idx], value_states.to(cache_dtype)], dim=-2
                    )

                return self.key_cache[layer_idx].to(compute_dtype), self.value_cache[layer_idx].to(compute_dtype)

            def get_seq_length(self, layer_idx: Optional[int] = 0) -> int:
                """
                Returns the sequence length of the cached states. A layer index can be optionally passed.
                Patching is required for calculating of the correct cache index.
                """
                # take any layer that contains cache and not empty tensor
                layer_idx = (
                    self.first_attention_layer if self.layer_types[layer_idx] != "full_attention" else layer_idx
                )
                layer_idx = self.attention_layer_idx_mapping[layer_idx]
                if len(self.key_cache) <= layer_idx or self.key_cache[layer_idx].numel() == 0:
                    return 0
                return self.key_cache[layer_idx].shape[-2]

        def patched_forward(
            input_ids: Optional[torch.LongTensor] = None,
            attention_mask: Optional[torch.Tensor] = None,
            position_ids: Optional[torch.LongTensor] = None,
            cache_params=None,
            inputs_embeds: Optional[torch.FloatTensor] = None,
            labels: Optional[torch.LongTensor] = None,
            use_cache: Optional[bool] = None,
            cache_position=None,
            logits_to_keep: Union[int, torch.Tensor] = 0,
        ):
            use_cache = False
            wrapped_cache_params = None
            num_conv_layers = self.real_config._config.layer_types.count("conv")
            num_atten_layers = self.real_config._config.layer_types.count("full_attention")
            if cache_params is not None:
                use_cache = True
                conv_cache = []
                key_cache = []
                value_cache = []

                # decouple ssm_states, conv_states, keys and values from cache_params
                batch_size = cache_params[0].size(0)

                for idx in range(num_conv_layers):
                    conv_cache.append(cache_params[idx])

                for idx in range(num_atten_layers):
                    key_cache.append(cache_params[num_conv_layers + idx * 2])
                    value_cache.append(cache_params[num_conv_layers + idx * 2 + 1])

                wrapped_cache_params = Lfm2HybridConvCacheWrap(
                    self.real_config._config, batch_size, conv_cache, key_cache, value_cache
                )

            causal_lm_output = self.model_orig_forward(
                input_ids=input_ids,
                attention_mask=attention_mask,
                past_key_values=wrapped_cache_params,
                use_cache=use_cache,
            )
            outputs = {
                "logits": causal_lm_output.logits,
            }

            if use_cache:
                key_values = causal_lm_output.past_key_values
                # unwrap Lfm2HybridDynamicCache object
                present_key_values = []
                for idx in range(num_conv_layers):
                    present_key_values.append(key_values.conv_cache[idx])

                for idx in range(num_atten_layers):
                    present_key_values.append(key_values.key_cache[idx])
                    present_key_values.append(key_values.value_cache[idx])

                outputs["present_key_values"] = present_key_values

            return outputs

        self.patched_forward = patched_forward
        self.model_orig_forward = self.orig_forward
        self.orig_forward = patched_forward

    def __enter__(self):
        from transformers.models.lfm2.modeling_lfm2 import Lfm2ShortConv

        super().__enter__()
        setattr(self._model, self.orig_forward_name, self.patched_forward)

        for layer in self._model.model.layers:
            if hasattr(layer, "conv") and isinstance(layer.conv, Lfm2ShortConv):
                conv_layer = layer.conv
            else:
                continue
            conv_layer._orig_forward = conv_layer.slow_forward
            conv_layer.slow_forward = types.MethodType(lfm2_short_conv_forward_patched, conv_layer)

    def __exit__(self, exc_type, exc_value, traceback):
        from transformers.models.lfm2.modeling_lfm2 import Lfm2ShortConv

        super().__exit__(exc_type, exc_value, traceback)
        setattr(self._model, self.orig_forward_name, self.model_orig_forward)

        for layer in self._model.model.layers:
            if hasattr(layer, "conv") and isinstance(layer.conv, Lfm2ShortConv):
                conv_layer = layer.conv
            else:
                continue
            conv_layer.slow_forward = conv_layer._orig_forward


# Copied from https://github.com/huggingface/transformers/blob/v4.56.0/src/transformers/models/gpt_oss/modeling_gpt_oss.py#L81
def gpt_oss_forward(self, hidden_states: torch.Tensor, router_indices=None, routing_weights=None) -> torch.Tensor:
    batch_size = hidden_states.shape[0]
    hidden_states = hidden_states.reshape(-1, self.hidden_size)
    num_experts = routing_weights.shape[1]
    hidden_states = hidden_states.repeat(num_experts, 1)
    hidden_states = hidden_states.view(num_experts, -1, self.hidden_size)
    gate_up = torch.bmm(hidden_states, self.gate_up_proj) + self.gate_up_proj_bias[..., None, :]
    gate, up = gate_up[..., ::2], gate_up[..., 1::2]
    gate = gate.clamp(min=None, max=self.limit)
    up = up.clamp(min=-self.limit, max=self.limit)
    glu = gate * torch.sigmoid(gate * self.alpha)
    next_states = torch.bmm(((up + 1) * glu), self.down_proj)
    next_states = next_states + self.down_proj_bias[..., None, :]
    next_states = next_states.view(num_experts, batch_size, -1, self.hidden_size)
    next_states = next_states * routing_weights.transpose(0, 1).view(num_experts, batch_size, -1)[..., None]
    next_states = next_states.sum(dim=0)
    return next_states


class GptOssModelPatcher(OVDecoderModelPatcher):
    def __enter__(self):
        super().__enter__()

        if is_transformers_version("<", "5"):
            from transformers.models.gpt_oss.modeling_gpt_oss import GptOssExperts

            self.original_gpt_oss_forward = GptOssExperts.forward
            GptOssExperts.forward = gpt_oss_forward
        else:
            register_ov_batched_mm(self)

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)

        if is_transformers_version("<", "5"):
            from transformers.models.gpt_oss.modeling_gpt_oss import GptOssExperts

            GptOssExperts.forward = self.original_gpt_oss_forward


# Recurrent form of the GraniteMoeHybrid Mamba2 mixer (`GraniteMoeHybridMambaLayer`).
# Adapted from `torch_forward` of:
# https://github.com/huggingface/transformers/blob/v4.55-release/src/transformers/models/granitemoehybrid/modeling_granitemoehybrid.py
#
# This patch replaces the chunked SSD implementation with a recurrent form that uses
# `SelectiveSSMRecurrentCell`, which is replaced by an `ov::Loop` during
# conversion. It runs a single unified code path for both prefill and decoding stages.
def granite_moe_hybrid_mamba_mixer_forward(
    self,
    hidden_states: torch.Tensor,
    cache_params=None,
    conv_state: Optional[torch.Tensor] = None,
    recurrent_state: Optional[torch.Tensor] = None,
    attention_mask: Optional[torch.Tensor] = None,
):
    batch_size, seq_len, _ = hidden_states.shape

    def apply_mask_to_padding_states(hidden_states, attention_mask):
        if attention_mask is not None and attention_mask.shape[0] > 1:
            dtype = hidden_states.dtype
            attention_mask = attention_mask[:, -seq_len:]
            hidden_states = (hidden_states * attention_mask[:, :, None]).to(dtype)
        return hidden_states

    # 1. Gated MLP's linear projection
    hidden_states = apply_mask_to_padding_states(hidden_states, attention_mask)
    projected_states = self.in_proj(hidden_states)
    gate, hidden_states_B_C, dt = projected_states.split(
        [self.intermediate_size, self.conv_dim, self.num_heads], dim=-1
    )

    # 2. Convolution sequence transformation with cached state
    hidden_states_B_C = hidden_states_B_C.transpose(1, 2)
    if conv_state is None:
        conv_state = torch.zeros(batch_size, self.conv_dim, self.conv_kernel_size, dtype=hidden_states_B_C.dtype)
    new_hidden_states_B_C, new_conv_state = ov_causal_conv1d(
        conv_state, hidden_states_B_C, self.conv1d.weight, self.conv1d.bias
    )
    hidden_states_B_C = self.act(new_hidden_states_B_C).transpose(1, 2)
    hidden_states_B_C = apply_mask_to_padding_states(hidden_states_B_C, attention_mask)

    hidden_states_ssm, B, C = torch.split(
        hidden_states_B_C,
        [self.intermediate_size, self.n_groups * self.ssm_state_size, self.n_groups * self.ssm_state_size],
        dim=-1,
    )

    # 3. State Space Model transformation in recurrent form
    A = -torch.exp(self.A_log.float())  # (num_heads,)
    dt = torch.nn.functional.softplus(dt + self.dt_bias)  # (B, T, num_heads)
    dt = torch.clamp(dt, self.time_step_limit[0], self.time_step_limit[1]).float()

    x = hidden_states_ssm.reshape(batch_size, seq_len, self.num_heads, self.head_dim).float()
    B = B.reshape(batch_size, seq_len, self.n_groups, self.ssm_state_size).float()
    C = C.reshape(batch_size, seq_len, self.n_groups, self.ssm_state_size).float()

    if recurrent_state is None:
        recurrent_state = torch.zeros(
            batch_size, self.num_heads, self.head_dim, self.ssm_state_size, dtype=torch.float32
        )
    recurrent_state = recurrent_state.float()

    # A (H,), dt (B,T,H), B (B,T,G,N), x (B,T,H,P), C (B,T,G,N), state (B,H,P,N)
    output_cell = self.selective_ssm_recurrent_cell(A, dt, B, x, C, recurrent_state)

    num_elems = batch_size * seq_len * self.num_heads * self.head_dim
    y = output_cell[:num_elems].reshape(batch_size, seq_len, self.num_heads, self.head_dim)
    new_recurrent_state = output_cell[num_elems:].reshape(recurrent_state.shape)

    # D skip connection (independent of the recurrent state)
    y = y + x * self.D.view(1, 1, -1, 1)

    # (B, T, H, P) -> (B, T, intermediate_size)
    y = y.reshape(batch_size, seq_len, -1)

    scan_output = self.norm(y, gate)

    # 4. Final linear projection
    contextualized_states = self.out_proj(scan_output.to(hidden_states.dtype))

    return contextualized_states, new_conv_state, new_recurrent_state


class GraniteMoeHybridModelPatcher(OVDecoderModelPatcher):
    def __init__(
        self,
        config: "OpenVINOConfig",
        model: "PreTrainedModel",
        model_kwargs: Optional[Dict[str, Any]] = None,
    ):
        from openvino.frontend.pytorch import ConversionExtension, ModuleExtension

        super().__init__(config, model, model_kwargs)

        layer_types = self.real_config._config.layer_types

        class GraniteMoeHybridCacheWrap:
            def __init__(self, config, conv_states, recurrent_states, key_cache, value_cache, attention_mask=None):
                self.config = config
                self.conv_states = conv_states
                self.recurrent_states = recurrent_states
                self.key_cache = key_cache
                self.value_cache = value_cache
                self.raw_attention_mask = attention_mask
                self.mamba_mapping = {}
                self.attn_mapping = {}
                mamba_idx = 0
                attn_idx = 0
                for i, block_type in enumerate(config.layers_block_type):
                    if block_type == "mamba":
                        self.mamba_mapping[i] = mamba_idx
                        mamba_idx += 1
                    elif block_type == "attention":
                        self.attn_mapping[i] = attn_idx
                        attn_idx += 1
                self.num_attn_layers = attn_idx

            def update(self, key_states, value_states, layer_idx, cache_kwargs=None):
                idx = self.attn_mapping[layer_idx]
                self.key_cache[idx] = torch.cat([self.key_cache[idx], key_states], dim=2)
                self.value_cache[idx] = torch.cat([self.value_cache[idx], value_states], dim=2)
                return self.key_cache[idx], self.value_cache[idx]

            def get_seq_length(self, layer_idx: Optional[int] = 0) -> int:
                if self.num_attn_layers == 0 or self.key_cache[0] is None:
                    return 0
                return self.key_cache[0].shape[-2]

            def get_mask_sizes(self, query_length, layer_idx: int = 0):
                # transformers >= 5.x passes the scalar `query_length` (int or 0-dim tensor);
                # older versions passed a 1-d `cache_position` tensor. Use `.shape[0]` only for the
                # legacy 1-d tensor; a scalar (empty shape) is added directly.
                if hasattr(query_length, "shape") and len(query_length.shape) > 0:
                    query_length = query_length.shape[0]
                kv_length = self.get_seq_length() + query_length
                return kv_length, 0

            @property
            def is_sliding(self):
                return [False]

            is_compileable = False

            def has_previous_state(self, layer_idx: Optional[int] = None) -> bool:
                return True

        def patched_forward(
            input_ids,
            attention_mask=None,
            cache_params=None,
        ):
            num_mamba_layers = layer_types.count("mamba")
            num_attn_layers = layer_types.count("attention")

            use_cache = False
            wrapped_cache_params = None
            if cache_params is not None:
                use_cache = True
                conv_states = []
                recurrent_states = []
                key_cache = []
                value_cache = []

                for idx in range(num_mamba_layers):
                    conv_states.append(cache_params[2 * idx])
                    recurrent_states.append(cache_params[2 * idx + 1])

                for idx in range(num_attn_layers):
                    key_cache.append(cache_params[2 * num_mamba_layers + 2 * idx])
                    value_cache.append(cache_params[2 * num_mamba_layers + 2 * idx + 1])

                wrapped_cache_params = GraniteMoeHybridCacheWrap(
                    self.real_config._config, conv_states, recurrent_states, key_cache, value_cache, attention_mask
                )

            causal_lm_output = self.model_orig_forward(
                input_ids=input_ids,
                attention_mask=attention_mask,
                past_key_values=wrapped_cache_params,
                use_cache=use_cache,
            )
            outputs = {
                "logits": causal_lm_output.logits,
            }

            if use_cache:
                present = wrapped_cache_params
                present_key_values = []
                for idx in range(num_mamba_layers):
                    present_key_values.append(present.conv_states[idx])
                    present_key_values.append(present.recurrent_states[idx])

                for idx in range(num_attn_layers):
                    present_key_values.append(present.key_cache[idx])
                    present_key_values.append(present.value_cache[idx])

                outputs["present_key_values"] = present_key_values

            return outputs

        self.patched_forward = patched_forward
        self.model_orig_forward = self.orig_forward
        self.orig_forward = patched_forward

        self.module_extensions = {
            SelectiveSSMRecurrentCell: ModuleExtension(SelectiveSSMRecurrentCell, "SelectiveSSMRecurrentCellOp"),
        }
        self.conversion_extensions = [
            ConversionExtension("SelectiveSSMRecurrentCellOp", convert_recurrent_selective_ssm_cell),
        ]

    def __enter__(self):
        def patch_sparse_moe(sparse_moe_layer):
            sparse_moe_layer.router._orig_forward = sparse_moe_layer.router.forward
            sparse_moe_layer.router.forward = types.MethodType(
                _granite_moe_topk_gating_forward, sparse_moe_layer.router
            )
            sparse_moe_layer.input_linear._orig_forward = sparse_moe_layer.input_linear.forward
            sparse_moe_layer.input_linear.forward = types.MethodType(
                _granite_moe_parallel_experts_forward, sparse_moe_layer.input_linear
            )
            sparse_moe_layer.output_linear._orig_forward = sparse_moe_layer.output_linear.forward
            sparse_moe_layer.output_linear.forward = types.MethodType(
                _granite_moe_parallel_experts_forward, sparse_moe_layer.output_linear
            )

        super().__enter__()
        setattr(self._model, self.orig_forward_name, self.patched_forward)

        def make_mamba_forward(mamba_layer):
            def _forward(hidden_states, cache_params=None, attention_mask=None, **kwargs):
                conv_state = None
                recurrent_state = None
                raw_attention_mask = None
                if cache_params is not None:
                    mamba_idx = cache_params.mamba_mapping[mamba_layer.layer_idx]
                    conv_state = cache_params.conv_states[mamba_idx]
                    recurrent_state = cache_params.recurrent_states[mamba_idx]
                    raw_attention_mask = cache_params.raw_attention_mask
                out, new_conv_state, new_recurrent_state = granite_moe_hybrid_mamba_mixer_forward(
                    mamba_layer, hidden_states, cache_params, conv_state, recurrent_state, raw_attention_mask
                )
                if cache_params is not None:
                    mamba_idx = cache_params.mamba_mapping[mamba_layer.layer_idx]
                    cache_params.conv_states[mamba_idx] = new_conv_state
                    cache_params.recurrent_states[mamba_idx] = new_recurrent_state
                return out

            return _forward

        for layer in self._model.model.layers:
            if getattr(layer, "block_sparse_moe", None) is not None:
                patch_sparse_moe(layer.block_sparse_moe)
            if layer.mamba is not None:
                mamba_layer = layer.mamba
                mamba_layer._orig_forward = mamba_layer.forward
                mamba_layer.selective_ssm_recurrent_cell = SelectiveSSMRecurrentCell()
                mamba_layer.forward = make_mamba_forward(mamba_layer)

    def __exit__(self, exc_type, exc_value, traceback):
        def unpatch_sparse_moe(sparse_moe_layer):
            sparse_moe_layer.router.forward = sparse_moe_layer.router._orig_forward
            sparse_moe_layer.input_linear.forward = sparse_moe_layer.input_linear._orig_forward
            sparse_moe_layer.output_linear.forward = sparse_moe_layer.output_linear._orig_forward

        super().__exit__(exc_type, exc_value, traceback)
        setattr(self._model, self.orig_forward_name, self.model_orig_forward)

        for layer in self._model.model.layers:
            if getattr(layer, "block_sparse_moe", None) is not None:
                unpatch_sparse_moe(layer.block_sparse_moe)
            if layer.mamba is not None:
                mamba_layer = layer.mamba
                mamba_layer.forward = mamba_layer._orig_forward
                if hasattr(mamba_layer, "selective_ssm_recurrent_cell"):
                    del mamba_layer.selective_ssm_recurrent_cell


class BigBirdPegasusModelPatcher(OVSeq2SeqModelPatcher):
    def __enter__(self):
        super().__enter__()

        if self.real_config._behavior == "encoder" and self._model.config.attention_type == "block_sparse":
            logger.warning(
                "BigBirdPegasus model is using block sparse attention, which is not supported in OpenVINO export. "
                "The model will be exported with original full attention."
            )
            self._model.set_attention_type("original_full")

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)

        if self.real_config._behavior == "encoder" and self._model.config.attention_type == "block_sparse":
            self._model.set_attention_type("block_sparse")


# Patch MoE implementation to enable correct Torch tracing:
# https://huggingface.co/arcee-ai/Trinity-Nano-Preview/blob/main/modeling_afmoe.py#L265
#
# The original code contains a conditional branch inside a Python for-loop.
# For certain example inputs, this branch may be skipped during tracing,
# resulting in an incorrect or incomplete final graph.
#
# Additionally, the non-vectorized implementation produces a very large
# OpenVINO graph with excessive nodes, which is expensive for graph
# transformations and significantly increases model conversion time.
# So the patch provides a vectorized form of MoE.
def afmoe_moe_forward_patched(self, hidden_states):
    num_experts = self.config.num_experts
    batch_size, seq_len, hidden_dim = hidden_states.shape
    # transformers >= v5.4 (PR #44063): router returns (router_logits, top_scores, selected_experts)
    # transformers <  v5.4: router returns (routing_weights, selected_experts)
    router_output = self.router(hidden_states, self.expert_bias)
    if len(router_output) == 3:
        _, routing_weights, selected_experts = router_output
    else:
        routing_weights, selected_experts = router_output
    new_routing_weights = torch.zeros(batch_size * seq_len, self.config.num_experts, dtype=routing_weights.dtype)
    new_routing_weights.scatter_(dim=1, index=selected_experts, src=routing_weights)
    hidden_states = hidden_states.view(-1, hidden_dim)

    # Process through shared experts
    if self.shared_experts is not None:
        shared_output = self.shared_experts(hidden_states)
    else:
        shared_output = torch.zeros_like(hidden_states)

    hidden_states = hidden_states.repeat(num_experts, 1)
    hidden_states = hidden_states.view(num_experts, -1, hidden_dim)
    act_fn = self.experts.act_fn if is_transformers_version(">=", "5.4") else self.experts[0].act_fn

    # compute experts outputs in a vectorized form
    gate = torch.bmm(hidden_states, self.gate_projs.transpose(1, 2))
    up = torch.bmm(hidden_states, self.up_projs.transpose(1, 2))
    gate_up = act_fn(gate) * up
    next_states = torch.bmm(gate_up, self.down_projs.transpose(1, 2))
    next_states = next_states.view(num_experts, batch_size, -1, hidden_dim)
    next_states = next_states * new_routing_weights.transpose(0, 1).view(num_experts, batch_size, -1)[..., None]
    next_states = next_states.sum(dim=0)

    shared_output = shared_output.view(batch_size, -1, hidden_dim)
    output = shared_output + next_states
    return output.view(batch_size, seq_len, hidden_dim)


class AfmoeModelPatcher(OVDecoderModelPatcher):
    def __enter__(self):
        super().__enter__()
        for idx, layer in enumerate(self._model.model.layers):
            if layer.moe_enabled:
                afmoe_moe = layer.mlp
                num_experts = afmoe_moe.config.num_experts
                afmoe_moe._orig_forward = afmoe_moe.forward
                afmoe_moe.forward = types.MethodType(afmoe_moe_forward_patched, afmoe_moe)

                # prepare weights to combine them from all experts to get the common gate, up and down weights
                # this is required for vectorized batched matmul representation of MoE
                # Fix CVS-180119: currently OpenVINO PyTorch Frontend incorrectly patching torch.bmm operation
                # with bf16 weights that leads to operands types mismatch in torch.bmm during TorchScript tracing
                # Now we align with hidden_states (that will be always fp32 due to patching
                # above for embedding layer during tracing)

                # transformers >= v5.4 (PR #44063): AfmoeExperts stores stacked gate_up_proj/down_proj
                # transformers <  v5.4: AfmoeExperts is a ModuleList of AfmoeMLP with separate gate/up/down projs
                if hasattr(afmoe_moe.experts, "gate_up_proj"):
                    intermediate_dim = afmoe_moe.experts.gate_up_proj.shape[1] // 2
                    afmoe_moe.gate_projs = afmoe_moe.experts.gate_up_proj[:, :intermediate_dim, :].detach()
                    afmoe_moe.up_projs = afmoe_moe.experts.gate_up_proj[:, intermediate_dim:, :].detach()
                    afmoe_moe.down_projs = afmoe_moe.experts.down_proj.detach()
                else:
                    afmoe_moe.down_projs = torch.concat(
                        tuple(afmoe_moe.experts[i].down_proj.weight.unsqueeze(0) for i in range(num_experts)),
                        dim=0,
                    ).detach()
                    afmoe_moe.gate_projs = torch.concat(
                        tuple(afmoe_moe.experts[i].gate_proj.weight.unsqueeze(0) for i in range(num_experts)),
                        dim=0,
                    ).detach()
                    afmoe_moe.up_projs = torch.concat(
                        tuple(afmoe_moe.experts[i].up_proj.weight.unsqueeze(0) for i in range(num_experts)), dim=0
                    ).detach()

                if is_openvino_version("<", "2026.1.0"):
                    afmoe_moe.down_projs = afmoe_moe.down_projs.float()
                    afmoe_moe.gate_projs = afmoe_moe.gate_projs.float()
                    afmoe_moe.up_projs = afmoe_moe.up_projs.float()

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)
        for idx, layer in enumerate(self._model.model.layers):
            if layer.moe_enabled:
                afmoe_moe = layer.mlp
                afmoe_moe.forward = afmoe_moe._orig_forward
                del afmoe_moe.down_projs, afmoe_moe.gate_projs, afmoe_moe.up_projs


class VideoChatFlashQwenVisionEmbeddingModelPatcher(ModelPatcher):
    def __init__(
        self,
        config: "OpenVINOConfig",
        model: "PreTrainedModel",
        model_kwargs: Dict[str, Any] = None,
    ):
        model.__orig_forward = model.forward

        # Modified from https://huggingface.co/OpenGVLab/VideoChat-Flash-Qwen2_5-7B_InternVideo2-1B/blob/main/vision_tower_builder.py#L618-L675
        # Export keeps only one traced branch, while this model needs both image and video paths.
        # We expose rotary_pos_emb as an input (instead of internal pos_embed/image_pos_embed) so the caller
        # decides which positional embedding to pass for image vs video.
        # This also simplifies internal logic that is not needed for the export path (like residual is always None and x_vis_only is always True in original model).
        def forward_wrap(self, hidden_states, rotary_pos_emb):
            hidden_states = self.patch_embed(hidden_states.type(self.dtype))
            B, T, L, C = hidden_states.shape  # T: temporal; L: spatial
            hidden_states = hidden_states.view([B, T * L, C])

            # append cls token
            cls_tokens = self.cls_token.expand(B, -1, -1)
            hidden_states = torch.cat((cls_tokens, hidden_states), dim=1)
            hidden_states = hidden_states + rotary_pos_emb
            hidden_states = hidden_states.reshape(B, -1, C)

            for idx, blk in enumerate(self.blocks):
                hidden_states = blk(hidden_states, residual=None)

            return hidden_states

        model.forward = types.MethodType(forward_wrap, model)
        super().__init__(config, model, model_kwargs)

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)
        self._model.forward = self._model.__orig_forward


# adopted from https://github.com/huggingface/transformers/blob/v4.57.6/src/transformers/models/llama/modeling_llama.py#L197
class LlamaEagle3Attention(LlamaAttention):
    """
    LLaMA-style multi-headed self-attention adapted for Eagle-3 speculative decoding.

    This attention module extends the standard LLaMA attention mechanism to
    support Eagle-3 draft models, where the attention input is formed by
    concatenating the main model hidden states with the corresponding input
    embeddings.
    """

    def __init__(self, config):
        super().__init__(config, 0)
        self.q_proj = nn.Linear(config.hidden_size * 2, config.num_attention_heads * self.head_dim, bias=False)
        self.k_proj = nn.Linear(config.hidden_size * 2, config.num_key_value_heads * self.head_dim, bias=False)
        self.v_proj = nn.Linear(config.hidden_size * 2, config.num_key_value_heads * self.head_dim, bias=False)


# adopted from https://github.com/huggingface/transformers/blob/v4.57.6/src/transformers/models/llama/modeling_llama.py#L268
class LlamaEagle3DecoderLayer(nn.Module):
    """
    Eagle-3 decoder layer that consumes main-model hidden states and input embeddings.

    This decoder layer is designed for the Eagle-3 draft model used in
    speculative decoding. Unlike a standard LLaMA decoder layer, it accepts
    two separate inputs:
        - `hidden_states`: hidden states produced by the main (target) model
        - `input_emb`: input token embeddings corresponding to the same positions

    This layer is used exclusively within the Eagle-3 draft model and is not
    compatible with token-only decoding pipelines.
    """

    def __init__(self, config, last=True):
        super().__init__()
        self.hidden_size = config.hidden_size
        self.self_attn = LlamaEagle3Attention(config=config)
        self.mlp = LlamaMLP(config)
        self.last = last
        self.hidden_norm = LlamaRMSNorm(config.hidden_size, eps=config.rms_norm_eps)
        self.input_layernorm = LlamaRMSNorm(config.hidden_size, eps=config.rms_norm_eps)
        self.post_attention_layernorm = LlamaRMSNorm(config.hidden_size, eps=config.rms_norm_eps)

    def forward(
        self,
        input_emb: torch.Tensor,
        hidden_states: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        past_key_values: Optional[Cache] = None,
        position_embeddings: tuple[torch.Tensor, torch.Tensor] = None,
        output_attentions: Optional[bool] = False,
        use_cache: Optional[bool] = False,
    ) -> Tuple[torch.FloatTensor, Optional[Tuple[torch.FloatTensor, torch.FloatTensor]]]:
        residual = hidden_states

        hidden_states = self.hidden_norm(hidden_states)
        input_emb = self.input_layernorm(input_emb)

        hidden_states = torch.cat((input_emb, hidden_states), dim=-1)

        # Self Attention
        hidden_states, _ = self.self_attn(
            hidden_states=hidden_states,
            attention_mask=attention_mask,
            position_ids=position_ids,
            **{"past_key_values" if is_transformers_version(">=", "5.0") else "past_key_value": past_key_values},
            output_attentions=output_attentions,
            position_embeddings=position_embeddings,
            use_cache=use_cache,
        )
        hidden_states = residual + hidden_states

        # Fully Connected
        residual = hidden_states
        hidden_states = self.post_attention_layernorm(hidden_states)
        hidden_states = self.mlp(hidden_states)
        hidden_states = residual + hidden_states

        return hidden_states


# adopted from https://github.com/huggingface/transformers/blob/v4.57.6/src/transformers/models/llama/modeling_llama.py#L334
class LlamaEagle3Model(LlamaPreTrainedModel):
    """
    Eagle-3 draft model built on a LLaMA backbone for speculative decoding.

    This model extends the standard LLaMA architecture to support Eagle-3’s
    draft model workflow, where the model operates on hidden states produced
    by a main (target) model rather than directly on token IDs.

    **Triple Hidden-State Concatenation**: The model accepts three
    hidden-state tensors from the main model. These are concatenated along
    the hidden dimension and then projected via a linear layer (`fc`) to
    match `hidden_size`. This forms the effective input to the decoder.
    """

    def __init__(self, config: LlamaConfig):
        config.tie_word_embeddings = False
        super().__init__(config)
        self.hidden_size = config.hidden_size

        self.embed_tokens = nn.Embedding(config.vocab_size, config.hidden_size, config.pad_token_id)
        # Select rotary embedding based on the target model's RoPE configuration:
        #   - LlamaRotaryEmbedding for standard Eagle-3 draft models
        #     (e.g. AngelSlim/Qwen3-1.7B_eagle3).
        #   - Qwen3VLTextRotaryEmbedding for VLM Eagle-3 draft models that
        #     require interleaved multimodal RoPE / MRoPE
        #     (e.g. AngelSlim/Qwen3-VL-4B-Instruct_eagle3).
        # adopted from https://github.com/Tencent/AngelSlim/blob/main/angelslim/compressor/speculative/train/models/draft/llama_eagle3.py#L258
        rope_scaling = getattr(config, "rope_scaling", None) or {}
        rope_type = rope_scaling.get("rope_type") or rope_scaling.get("type")
        if rope_type == "mrope" or rope_scaling.get("mrope_section") is not None:
            self.rotary_emb = Qwen3VLTextRotaryEmbedding(config=config)
        else:
            self.rotary_emb = LlamaRotaryEmbedding(config=config)

        self.midlayer = LlamaEagle3DecoderLayer(config)
        self.target_hidden_size = getattr(config, "target_hidden_size", config.hidden_size)
        self.fc = nn.Linear(self.target_hidden_size * 3, self.hidden_size, bias=False)
        self.norm = LlamaRMSNorm(config.hidden_size, eps=config.rms_norm_eps)

        self.lm_head = nn.Linear(config.hidden_size, config.draft_vocab_size, bias=False)

        d2t = torch.zeros((config.draft_vocab_size), dtype=torch.long)
        t2d = torch.zeros((config.vocab_size), dtype=torch.bool)
        self.register_buffer("d2t", d2t)
        self.register_buffer("t2d", t2d)

        # Initialize weights and apply final processing
        self.post_init()

    def forward(
        self,
        input_ids: Optional[torch.LongTensor] = None,
        hidden_states: Optional[torch.FloatTensor] = None,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        past_key_values: Optional[Cache] = None,
        inputs_embeds: Optional[torch.FloatTensor] = None,
        use_cache: Optional[bool] = None,
        cache_position: Optional[torch.LongTensor] = None,
        **kwargs: Unpack[TransformersKwargs],
    ) -> BaseModelOutputWithPast:
        batch_size, seq_length, _ = hidden_states.shape
        use_cache = use_cache if use_cache is not None else self.config.use_cache

        if (input_ids is None) ^ (inputs_embeds is not None):
            raise ValueError("You must specify exactly one of input_ids or inputs_embeds")

        if inputs_embeds is None:
            inputs_embeds: torch.Tensor = self.embed_tokens(input_ids)

        if use_cache and past_key_values is None:
            past_key_values = DynamicCache(config=self.config)

        if cache_position is None:
            past_seen_tokens = past_key_values.get_seq_length() if past_key_values is not None else 0
            cache_position: torch.Tensor = torch.arange(
                past_seen_tokens, past_seen_tokens + inputs_embeds.shape[1], device=inputs_embeds.device
            )

        if position_ids is None:
            position_ids = cache_position.unsqueeze(0)

        if is_transformers_version(">=", "5.5"):
            causal_mask = create_causal_mask(
                config=self.config,
                inputs_embeds=inputs_embeds,
                attention_mask=attention_mask,
                past_key_values=past_key_values,
                position_ids=position_ids,
            )
        else:
            causal_mask = create_causal_mask(
                config=self.config,
                input_embeds=inputs_embeds,
                attention_mask=attention_mask,
                cache_position=cache_position,
                past_key_values=past_key_values,
                position_ids=position_ids,
            )

        if hidden_states is None:
            hidden_states = torch.zeros(
                [batch_size, seq_length, self.embed_dim],
                self.embed_dim,
                dtype=inputs_embeds.dtype,
                device=inputs_embeds.device,
            )

        # hidden_states = inputs_embeds
        inputs_embeds = inputs_embeds.to(hidden_states.dtype)
        if hidden_states.shape[-1] != inputs_embeds.shape[-1]:
            hidden_states = self.fc(hidden_states)

        position_embeddings = self.rotary_emb(hidden_states, position_ids=position_ids)

        hidden_states = self.midlayer(
            input_emb=inputs_embeds,
            hidden_states=hidden_states,
            attention_mask=causal_mask,
            position_embeddings=position_embeddings,
            position_ids=position_ids,
            past_key_values=past_key_values,
            use_cache=True,
        )

        hidden_states = self.norm(hidden_states)
        return BaseModelOutputWithPast(
            last_hidden_state=hidden_states,
            past_key_values=past_key_values,
        )


@dataclass
class Eagle3Output(ModelOutput):
    """
    Output container for the Eagle-3 draft model.

    This class extends `ModelOutput` to hold the outputs of the Eagle-3
    speculative decoding model. It contains `d2t`,
    a mapping from generated draft tokens to the corresponding main
    model tokens. This is used to reconcile the draft model outputs
    with the main model vocabulary during speculative decoding.
    """

    logits: Optional[torch.FloatTensor] = None
    past_key_values: Optional[Cache] = None
    hidden_states: Optional[tuple[torch.FloatTensor, ...]] = None
    d2t: Optional[torch.LongTensor] = None


# adopted from https://github.com/huggingface/transformers/blob/v4.57.6/src/transformers/models/llama/modeling_llama.py#L413
class LlamaEagle3ForCausalLM(LlamaPreTrainedModel, GenerationMixin):
    _tied_weights_keys = ["lm_head.weight"]

    def __init__(self, config):
        super().__init__(config)
        self.model = LlamaEagle3Model(config)
        self.vocab_size = config.vocab_size
        self.identity = torch.nn.Identity()
        self.post_init()

    def forward(
        self,
        input_ids: Optional[torch.LongTensor] = None,
        hidden_states: Optional[torch.FloatTensor] = None,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        past_key_values: Optional[Cache] = None,
        inputs_embeds: Optional[torch.FloatTensor] = None,
        use_cache: Optional[bool] = None,
        cache_position: Optional[torch.LongTensor] = None,
        logits_to_keep: Union[int, torch.Tensor] = 0,
        **kwargs: Unpack[TransformersKwargs],
    ) -> Eagle3Output:
        # decoder outputs consists of (dec_features, layer_state, dec_hidden, dec_attn)
        outputs: BaseModelOutputWithPast = self.model(
            input_ids=input_ids,
            hidden_states=hidden_states,
            attention_mask=attention_mask,
            position_ids=position_ids,
            past_key_values=past_key_values,
            inputs_embeds=inputs_embeds,
            use_cache=use_cache,
            cache_position=cache_position,
            **kwargs,
        )

        hidden_states = outputs.last_hidden_state
        # Only compute necessary logits, and do not upcast them to float if we are not computing the loss
        slice_indices = slice(-logits_to_keep, None) if isinstance(logits_to_keep, int) else logits_to_keep
        logits = self.model.lm_head(hidden_states[:, slice_indices, :])

        d2t_out = self.identity(self.model.d2t)
        return Eagle3Output(
            logits=logits,
            past_key_values=outputs.past_key_values,
            hidden_states=outputs.hidden_states,
            d2t=d2t_out,
        )


def _dflash_apply_rotary_pos_emb(q, k, cos, sin, unsqueeze_dim=1):
    cos = cos.unsqueeze(unsqueeze_dim)
    sin = sin.unsqueeze(unsqueeze_dim)
    q_len = q.size(-2)
    q_embed = (q * cos[..., -q_len:, :]) + (qwen3_rotate_half(q) * sin[..., -q_len:, :])
    k_embed = (k * cos) + (qwen3_rotate_half(k) * sin)
    return q_embed, k_embed


def _dflash_repeat_kv(hidden_states: torch.Tensor, n_rep: int) -> torch.Tensor:
    """repeat_kv using reshape instead of unsqueeze to insert the group dim.

    The GPU plugin's UnsqueezeBroadcastReshapeSDPAFusion matches a Reshape but not the
    Unsqueeze from stock ``[:, :, None]`` (valid only atop a KVCache op the draft lacks).
    Matching keeps the draft on native-GQA SDPA (micro kernel), not a materialized broadcast.
    """
    batch, num_key_value_heads, slen, head_dim = hidden_states.shape
    if n_rep == 1:
        return hidden_states
    hidden_states = hidden_states.reshape(batch, num_key_value_heads, 1, slen, head_dim).expand(
        batch, num_key_value_heads, n_rep, slen, head_dim
    )
    return hidden_states.reshape(batch, num_key_value_heads * n_rep, slen, head_dim)


def _dflash_attention_mask(
    query_states: torch.Tensor,
    key_states: torch.Tensor,
    cache_position: Optional[torch.LongTensor],
    sliding_window: Optional[int],
    attention_mask: Optional[torch.Tensor] = None,
) -> Optional[torch.Tensor]:
    q_len = query_states.shape[-2]
    kv_len = key_states.shape[-2]
    if sliding_window is None:
        if attention_mask is None:
            return None
        # Full-attention layers only need the caller's padding mask. Avoid building
        # and adding an all-zero [batch, 1, q_len, kv_len] mask.
        return attention_mask[:, :, :, -kv_len:]
    device = query_states.device
    dtype = query_states.dtype
    full_mask = torch.zeros((q_len, kv_len), dtype=dtype, device=device)

    if sliding_window is not None:
        # Window test is relative: (query_pos - key_pos) >= window. kv_len already
        # reflects any cached slice, so a 0-based frame (queries = last q_len) gives
        # the right distances with no absolute offset.
        query_positions = torch.arange(kv_len - q_len, kv_len, device=device)
        key_positions = torch.arange(kv_len, device=device)
        outside_window = (query_positions.reshape(-1, 1) - key_positions.reshape(1, -1)) >= sliding_window
        full_mask = full_mask.masked_fill(outside_window, torch.finfo(dtype).min)

    full_mask = full_mask[None, None, :, :].expand(query_states.shape[0], 1, -1, -1)

    if attention_mask is None:
        return full_mask
    # Keep the last kv_len columns: the kept keys are the caller mask's final entries.
    return attention_mask[:, :, :, -kv_len:] + full_mask


# adopted from https://github.com/z-lab/dflash/blob/main/dflash/model.py#L185
# and https://github.com/huggingface/transformers/blob/v5.14.0/src/transformers/models/qwen3/modeling_qwen3.py#L222
class Qwen3DFlashAttention(Qwen3Attention):
    """Qwen3 attention variant used by DFlash, where draft tokens attend over target context and noise tokens."""

    def __init__(self, config: "Qwen3Config", layer_idx: int):
        super().__init__(config, layer_idx)
        self.is_causal = False

    def forward(
        self,
        hidden_states: torch.Tensor,
        target_hidden: torch.Tensor,
        position_embeddings: Tuple[torch.Tensor, torch.Tensor],
        attention_mask: Optional[torch.Tensor] = None,
        past_key_values: Optional[Cache] = None,
        cache_position: Optional[torch.LongTensor] = None,
        **kwargs: Unpack[TransformersKwargs],
    ) -> Tuple[torch.Tensor, Optional[torch.Tensor]]:
        from transformers.modeling_utils import ALL_ATTENTION_FUNCTIONS

        bsz, q_len = hidden_states.shape[:-1]
        ctx_len = target_hidden.shape[1]

        query_states = self.q_proj(hidden_states).view(bsz, q_len, self.config.num_attention_heads, self.head_dim)
        query_states = self.q_norm(query_states).transpose(1, 2)

        kv_hidden_states = torch.cat([target_hidden, hidden_states], dim=1)
        key_states = self.k_proj(kv_hidden_states).view(
            bsz, ctx_len + q_len, self.config.num_key_value_heads, self.head_dim
        )
        value_states = self.v_proj(kv_hidden_states).view(
            bsz, ctx_len + q_len, self.config.num_key_value_heads, self.head_dim
        )
        key_states = self.k_norm(key_states).transpose(1, 2)
        value_states = value_states.transpose(1, 2)

        cos, sin = position_embeddings
        query_states, key_states = _dflash_apply_rotary_pos_emb(query_states, key_states, cos, sin)
        target_key_states, block_key_states = key_states.split([ctx_len, q_len], dim=2)
        target_value_states, block_value_states = value_states.split([ctx_len, q_len], dim=2)

        if past_key_values is not None:
            # Persist only committed target-prefix K/V; the speculative block is local,
            # so rejection never needs a cache trim.
            target_cache_position = cache_position[:ctx_len] if cache_position is not None else None
            cache_kwargs = {"sin": sin[:, :ctx_len], "cos": cos[:, :ctx_len], "cache_position": target_cache_position}
            target_key_states, target_value_states = past_key_values.update(
                target_key_states,
                target_value_states,
                self.layer_idx,
                cache_kwargs,
            )

        if self.sliding_window is not None:
            # Sliding layers need only the last `sliding_window` target tokens (a query
            # at p attends to (p - window, p]). Slicing makes the concat and SDPA
            # O(window) not O(context); the window mask below still trims within the kept
            # set, so output is unchanged. Negative slice is a no-op while context <= window.
            target_key_states = target_key_states[:, :, -self.sliding_window :, :]
            target_value_states = target_value_states[:, :, -self.sliding_window :, :]

        key_states = torch.cat([target_key_states, block_key_states], dim=2)
        value_states = torch.cat([target_value_states, block_value_states], dim=2)
        attention_mask = _dflash_attention_mask(
            query_states,
            key_states,
            cache_position,
            self.sliding_window,
            attention_mask,
        )

        attention_interface = qwen3_eager_attention_forward
        attention_module = self
        if self.config._attn_implementation != "eager":
            attention_interface = ALL_ATTENTION_FUNCTIONS[self.config._attn_implementation]
            if self.config._attn_implementation == "sdpa" and self.num_key_value_groups > 1:
                # Re-pin static head / head_dim before repeat_kv: cldnn makes the
                # cat([cache, block]) fully dynamic, hiding the KV head count from the GPU
                # SDPA's GQA dispatch (slow ref kernel). A literal-dim Reshape restores it,
                # so the repeat_kv fusion yields native-GQA SDPA (micro kernel).
                key_states = key_states.reshape(bsz, self.config.num_key_value_heads, -1, self.head_dim)
                value_states = value_states.reshape(bsz, self.config.num_key_value_heads, -1, self.head_dim)
                key_states = _dflash_repeat_kv(key_states, self.num_key_value_groups)
                value_states = _dflash_repeat_kv(value_states, self.num_key_value_groups)
                attention_module = SimpleNamespace(is_causal=self.is_causal)

        attn_output, attn_weights = attention_interface(
            attention_module,
            query_states,
            key_states,
            value_states,
            attention_mask,
            dropout=0.0 if not self.training else self.attention_dropout,
            scaling=self.scaling,
            sliding_window=self.sliding_window,
            **kwargs,
        )
        attn_output = attn_output.reshape(bsz, q_len, -1)
        attn_output = self.o_proj(attn_output)
        return attn_output, attn_weights


# adopted from https://github.com/z-lab/dflash/blob/main/dflash/model.py#L258
class Qwen3DFlashDecoderLayer(nn.Module):
    def __init__(self, config: "Qwen3Config", layer_idx: int):
        super().__init__()
        self.hidden_size = config.hidden_size
        self.self_attn = Qwen3DFlashAttention(config=config, layer_idx=layer_idx)
        self.mlp = Qwen3MLP(config)
        self.input_layernorm = Qwen3RMSNorm(config.hidden_size, eps=config.rms_norm_eps)
        self.post_attention_layernorm = Qwen3RMSNorm(config.hidden_size, eps=config.rms_norm_eps)

    def forward(
        self,
        target_hidden: torch.Tensor,
        hidden_states: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        past_key_value: Optional[Cache] = None,
        output_attentions: Optional[bool] = False,
        use_cache: Optional[bool] = False,
        cache_position: Optional[torch.LongTensor] = None,
        position_embeddings: Optional[Tuple[torch.Tensor, torch.Tensor]] = None,
        **kwargs: Unpack[TransformersKwargs],
    ) -> torch.FloatTensor:
        residual = hidden_states
        hidden_states = self.input_layernorm(hidden_states)
        hidden_states = self.self_attn(
            hidden_states=hidden_states,
            target_hidden=target_hidden,
            attention_mask=attention_mask,
            position_ids=position_ids,
            past_key_values=past_key_value,
            output_attentions=output_attentions,
            use_cache=use_cache,
            cache_position=cache_position,
            position_embeddings=position_embeddings,
            **kwargs,
        )[0]
        hidden_states = residual + hidden_states

        residual = hidden_states
        hidden_states = self.post_attention_layernorm(hidden_states)
        hidden_states = self.mlp(hidden_states)
        hidden_states = residual + hidden_states
        return hidden_states


# adopted from https://github.com/z-lab/dflash/blob/main/dflash/model.py#L302
class Qwen3DFlashDraftModel(Qwen3PreTrainedModel):
    config_class = Qwen3Config
    _no_split_modules = ["Qwen3DFlashDecoderLayer"]

    def __init__(self, config) -> None:
        super().__init__(config)
        if not hasattr(config, "_orig_attn_implementation"):
            config._orig_attn_implementation = config._attn_implementation
        config._attn_implementation = "sdpa"
        self.layers = nn.ModuleList(
            [Qwen3DFlashDecoderLayer(config, layer_idx) for layer_idx in range(config.num_hidden_layers)]
        )
        dflash_config = getattr(config, "dflash_config", {})
        self.target_layer_ids = dflash_config.get("target_layer_ids", [])
        self.norm = Qwen3RMSNorm(config.hidden_size, eps=config.rms_norm_eps)
        self.rotary_emb = Qwen3RotaryEmbedding(config)
        self.fc = nn.Linear(len(self.target_layer_ids) * config.hidden_size, config.hidden_size, bias=False)
        self.hidden_norm = Qwen3RMSNorm(config.hidden_size, eps=config.rms_norm_eps)
        self.mask_token_id = dflash_config.get("mask_token_id", None)
        self.post_init()

    def forward(
        self,
        position_ids: torch.LongTensor,
        attention_mask: Optional[torch.Tensor] = None,
        noise_embedding: Optional[torch.Tensor] = None,
        hidden_states: Optional[torch.Tensor] = None,
        past_key_values: Optional[Cache] = None,
        use_cache: Optional[bool] = None,
        cache_position: Optional[torch.LongTensor] = None,
        **kwargs,
    ) -> BaseModelOutputWithPast:
        noise_states = noise_embedding
        target_hidden = hidden_states.to(noise_states.dtype)
        target_hidden = self.hidden_norm(self.fc(target_hidden))
        use_cache = use_cache if use_cache is not None else self.config.use_cache
        if use_cache:
            if past_key_values is None:
                past_key_values = DynamicCache(config=self.config)
            elif not isinstance(past_key_values, Cache):
                if is_transformers_version("<", "5"):
                    past_key_values = DynamicCache.from_legacy_cache(past_key_values)
                else:
                    past_key_values = DynamicCache(past_key_values)
        if use_cache and cache_position is None:
            past_seen_tokens = past_key_values.get_seq_length() if past_key_values is not None else 0
            cache_position = torch.arange(
                past_seen_tokens,
                past_seen_tokens + target_hidden.shape[1] + noise_states.shape[1],
                device=noise_states.device,
            )
        if attention_mask is not None and attention_mask.dim() == 2:
            attention_mask = (1.0 - attention_mask[:, None, None, :].to(dtype=noise_states.dtype)) * torch.finfo(
                noise_states.dtype
            ).min
        position_embeddings = self.rotary_emb(noise_states, position_ids)
        for layer in self.layers:
            noise_states = layer(
                hidden_states=noise_states,
                target_hidden=target_hidden,
                attention_mask=attention_mask,
                position_ids=position_ids,
                past_key_value=past_key_values,
                use_cache=use_cache,
                cache_position=cache_position,
                position_embeddings=position_embeddings,
                **kwargs,
            )
        return BaseModelOutputWithPast(
            last_hidden_state=self.norm(noise_states),
            past_key_values=past_key_values if use_cache else None,
        )


# adopted from https://github.com/z-lab/dflash/blob/main/dflash/model.py#L302
class Qwen3DFlashForCausalLM(Qwen3DFlashDraftModel, GenerationMixin):
    """DFlash draft head exported as embeddings-in / hidden-states-out.

    The token embedding and lm_head are intentionally absent: the draft consumes
    ``inputs_embeds`` (produced from the target embedding) and emits the post-norm
    ``last_hidden_state``. OpenVINO GenAI grafts the target lm_head onto this output
    at load time, so the export bundles neither the embedding nor the projection.
    """

    def forward(
        self,
        inputs_embeds: torch.FloatTensor,
        hidden_states: torch.Tensor,
        position_ids: torch.LongTensor,
        attention_mask: Optional[torch.Tensor] = None,
        past_key_values: Optional[Cache] = None,
        use_cache: Optional[bool] = None,
        logits_to_keep: Optional[int] = None,
        **kwargs,
    ) -> BaseModelOutputWithPast:
        outputs = super().forward(
            hidden_states=hidden_states,
            noise_embedding=inputs_embeds,
            position_ids=position_ids,
            attention_mask=attention_mask,
            past_key_values=past_key_values,
            use_cache=use_cache,
            **kwargs,
        )
        # Drop the seed position so emitted hidden states align 1:1 with the draft
        # candidate tokens that the grafted lm_head will score.
        if logits_to_keep is None:
            last_hidden_state = outputs.last_hidden_state[:, 1:, :]
        else:
            last_hidden_state = outputs.last_hidden_state[:, -logits_to_keep:, :]
        return BaseModelOutputWithPast(
            last_hidden_state=last_hidden_state,
            past_key_values=outputs.past_key_values,
        )


# Patched implementation of the gated delta rule in recurrent form.
# Adapted from:
# https://github.com/huggingface/transformers/blob/v4.57-release/src/transformers/models/qwen3_next/modeling_qwen3_next.py#L522
#
# To represent the for-loop that generates output embeddings, we use a module
# and the conversion extension mechanism. This is necessary because there is
# no known vectorized form of this loop that would allow it to be correctly
# traced with torch.jit.trace
def patched_recurrent_gated_delta_rule(
    self, query, key, value, g, beta, initial_state, output_final_state, use_qk_l2norm_in_kernel=False
):
    def l2norm(x: torch.FloatTensor, dim: int = -1, eps: float = 1e-6):
        """This function is intended to align with the l2norm implementation in the FLA library."""
        inv_norm = torch.rsqrt((x * x).sum(dim=dim, keepdim=True) + eps)
        return x * inv_norm

    initial_dtype = query.dtype
    if use_qk_l2norm_in_kernel:
        query = l2norm(query, dim=-1, eps=1e-6)
        key = l2norm(key, dim=-1, eps=1e-6)
    query, key, value, beta, g = [
        x.transpose(1, 2).contiguous().to(torch.float32) for x in (query, key, value, beta, g)
    ]

    batch_size, num_heads, sequence_length, k_head_dim = key.shape
    v_head_dim = value.shape[-1]
    scale = 1 / (query.shape[-1] ** 0.5)
    query = query * scale

    last_recurrent_state = (
        torch.zeros(batch_size, num_heads, k_head_dim, v_head_dim).to(value)
        if initial_state is None
        else initial_state.to(value)
    )

    output_cell = self.recurrent_attention_cell(
        query,  # (B, H, T, D1)
        key,  # (B, H, T, D1)
        value,  # (B, H, T, D2)
        g,  # (B, H, T)
        beta,  # (B, H, T)
        last_recurrent_state,  # (B, H, D1, D2)
    )

    num_elems = value.numel()
    core_attn_out = output_cell[:num_elems].reshape(value.shape)
    last_recurrent_state = output_cell[num_elems:].reshape(last_recurrent_state.shape)

    if not output_final_state:
        last_recurrent_state = None
    core_attn_out = core_attn_out.transpose(1, 2).contiguous().to(initial_dtype)
    return core_attn_out, last_recurrent_state


# Adopted from:
# https://github.com/huggingface/transformers/blob/v4.57-release/src/transformers/models/qwen3_next/modeling_qwen3_next.py#L660
#
# The CausalConv1D block is overridden with a generic patch provided by `ov_causal_conv1d()`.
# The GatedDeltaNet block is overridden with a recurrent version of its implementation.
#
# To replace GatedDeltaNet with its recurrent form, patching uses the ModuleExtension
# approach, which replaces the GatedDeltaNet block with a single operation,
# `GatedDeltaNetOp`. OpenVINO then applies the `convert_recurrent_attention_cell()`
# conversion rule to this operation.
def qwen3_next_gated_delta_net_forward(
    self,
    hidden_states: torch.Tensor,
    cache_params=None,
    cache_position: Optional[torch.LongTensor] = None,
    attention_mask: Optional[torch.Tensor] = None,
):
    def apply_mask_to_padding_states(hidden_states, attention_mask):
        """
        Tunes out the hidden states for padding tokens, see https://github.com/state-spaces/mamba/issues/66
        """
        # NOTE: attention mask is a 2D boolean tensor
        if attention_mask is not None and attention_mask.shape[1] > 1 and attention_mask.shape[0] > 1:
            dtype = hidden_states.dtype
            hidden_states = (hidden_states * attention_mask[:, :, None]).to(dtype)

        return hidden_states

    hidden_states = apply_mask_to_padding_states(hidden_states, attention_mask)

    # Set up dimensions for reshapes later
    batch_size, seq_len, _ = hidden_states.shape

    # getting projected states from cache if it exists
    layer_idx = None
    recurrent_state = None
    if cache_params is not None:
        layer_idx = cache_params.linear_attn_mapping[self.layer_idx]
        conv_state = cache_params.conv_states[layer_idx]
        recurrent_state = cache_params.recurrent_states[layer_idx]

    projected_states_qkvz = self.in_proj_qkvz(hidden_states)
    projected_states_ba = self.in_proj_ba(hidden_states)
    query, key, value, z, b, a = self.fix_query_key_value_ordering(projected_states_qkvz, projected_states_ba)
    query, key, value = (x.reshape(x.shape[0], x.shape[1], -1) for x in (query, key, value))

    mixed_qkv = torch.cat((query, key, value), dim=-1)
    mixed_qkv = mixed_qkv.transpose(1, 2)

    if cache_params is not None:
        new_mixed_qkv, new_conv_state = ov_causal_conv1d(conv_state, mixed_qkv, self.conv1d.weight, self.conv1d.bias)
        mixed_qkv = F.silu(new_mixed_qkv)
        cache_params.conv_states[layer_idx] = new_conv_state
    else:
        mixed_qkv = F.silu(self.conv1d(mixed_qkv)[:, :, :seq_len])

    mixed_qkv = mixed_qkv.transpose(1, 2)
    query, key, value = torch.split(
        mixed_qkv,
        [
            self.key_dim,
            self.key_dim,
            self.value_dim,
        ],
        dim=-1,
    )
    query = query.reshape(query.shape[0], query.shape[1], -1, self.head_k_dim)
    key = key.reshape(key.shape[0], key.shape[1], -1, self.head_k_dim)
    value = value.reshape(value.shape[0], value.shape[1], -1, self.head_v_dim)

    beta = b.sigmoid()
    # If the model is loaded in fp16, without the .float() here, A might be -inf
    g = -self.A_log.float().exp() * F.softplus(a.float() + self.dt_bias)
    if self.num_v_heads // self.num_k_heads > 1:
        query = query.repeat_interleave(self.num_v_heads // self.num_k_heads, dim=2)
        key = key.repeat_interleave(self.num_v_heads // self.num_k_heads, dim=2)

    core_attn_out, last_recurrent_state = self.recurrent_gated_delta_rule(
        self,
        query,
        key,
        value,
        g=g,
        beta=beta,
        initial_state=recurrent_state,
        output_final_state=cache_params is not None,
        use_qk_l2norm_in_kernel=True,
    )

    # Update cache
    if cache_params is not None:
        cache_params.recurrent_states[layer_idx] = last_recurrent_state

    z_shape_og = z.shape
    # reshape input data into 2D tensor
    core_attn_out = core_attn_out.reshape(-1, core_attn_out.shape[-1])
    z = z.reshape(-1, z.shape[-1])
    core_attn_out = self.norm(core_attn_out, z)
    core_attn_out = core_attn_out.reshape(z_shape_og)
    core_attn_out = core_attn_out.reshape(core_attn_out.shape[0], core_attn_out.shape[1], -1)

    output = self.out_proj(core_attn_out)
    return output


# Patches the MoE block with a vectorized implementation.
# The vectorized form is required to ensure correct torch.jit tracing for this component.
def patched_qwen3_next_sparse_moe_block(self, hidden_states: torch.Tensor) -> torch.Tensor:
    num_experts = self.num_experts
    batch_size, sequence_length, hidden_dim = hidden_states.shape
    hidden_states = hidden_states.view(-1, hidden_dim)
    # router_logits: (batch * sequence_length, n_experts)
    router_logits = self.gate(hidden_states)

    routing_weights = F.softmax(router_logits, dim=1, dtype=torch.float)
    routing_weights, selected_experts = torch.topk(routing_weights, self.top_k, dim=-1)
    if self.norm_topk_prob:
        routing_weights /= routing_weights.sum(dim=-1, keepdim=True)
    # we cast back to the input dtype
    routing_weights = routing_weights.to(hidden_states.dtype)

    new_routing_weights = torch.zeros(batch_size * sequence_length, num_experts, dtype=routing_weights.dtype)
    new_routing_weights.scatter_(dim=1, index=selected_experts, src=routing_weights)

    shared_expert_output = self.shared_expert(hidden_states)
    shared_expert_output = torch.sigmoid(self.shared_expert_gate(hidden_states)) * shared_expert_output

    hidden_states = hidden_states.repeat(num_experts, 1)
    hidden_states = hidden_states.view(num_experts, -1, hidden_dim)
    act_fn = self.experts[0].act_fn

    # compute experts outputs in a vectorized form
    gate = torch.bmm(hidden_states, self.gate_projs.transpose(1, 2))
    up = torch.bmm(hidden_states, self.up_projs.transpose(1, 2))
    gate_up = act_fn(gate) * up
    next_states = torch.bmm(gate_up, self.down_projs.transpose(1, 2))
    next_states = next_states.view(num_experts, batch_size, -1, hidden_dim)
    next_states = next_states * new_routing_weights.transpose(0, 1).view(num_experts, batch_size, -1)[..., None]
    next_states = next_states.sum(dim=0)

    shared_expert_output = shared_expert_output.view(batch_size, -1, hidden_dim)
    output = shared_expert_output + next_states
    return output.view(batch_size, sequence_length, hidden_dim)


# This torch.nn.Module represents the GatedDeltaNet layer in its recurrent form.
# It is required for converting the GatedDeltaNet layer with OpenVINO using the ModuleExtension mechanism.
class RecurrentAttentionCell(torch.nn.Module):
    def __init__(self):
        super().__init__()

    def forward(
        self,
        query,  # (B, H, T, D1)
        key,  # (B, H, T, D1)
        value,  # (B, H, T, D2)
        g,  # (B, H, T)
        beta,  # (B, H, T)
        last_recurrent_state,  # (B, H, D1, D2)
    ):
        _, _, sequence_length, _ = key.shape
        core_attn_out = torch.zeros_like(value)

        for i in range(sequence_length):
            q_t = query[:, :, i]
            k_t = key[:, :, i]
            v_t = value[:, :, i]
            g_t = g[:, :, i].exp().unsqueeze(-1).unsqueeze(-1)
            beta_t = beta[:, :, i].unsqueeze(-1)

            last_recurrent_state = last_recurrent_state * g_t
            kv_mem = (last_recurrent_state * k_t.unsqueeze(-1)).sum(dim=-2)
            delta = (v_t - kv_mem) * beta_t
            last_recurrent_state = last_recurrent_state + k_t.unsqueeze(-1) * delta.unsqueeze(-2)
            core_attn_out[:, :, i] = (last_recurrent_state * q_t.unsqueeze(-1)).sum(dim=-2)

        # This is a workaround to ensure a single output from the torch.nn.Module.
        # The OpenVINO ModuleExtension mechanism has a limitation and expects
        # the module to produce only one output.
        output_cell = torch.cat([core_attn_out.flatten(), last_recurrent_state.flatten()], dim=0)
        return output_cell


class Qwen3NextModelPatcher(OVDecoderModelPatcher):
    def __init__(
        self,
        config: "OpenVINOConfig",
        model: "PreTrainedModel",
        model_kwargs: Optional[Dict[str, Any]] = None,
    ):
        from transformers.models.qwen3_next.modeling_qwen3_next import Qwen3NextDynamicCache

        from openvino.frontend.pytorch import ConversionExtension, ModuleExtension

        super().__init__(config, model, model_kwargs)

        class Qwen3NextDynamicCacheWrap(Qwen3NextDynamicCache):
            def __init__(self, config, conv_states, recurrent_states, key_cache, value_cache):
                # Call parent constructor with all required arguments
                super().__init__(config=config)

                self.conv_states = conv_states
                self.recurrent_states = recurrent_states
                self.key_cache = key_cache
                self.value_cache = value_cache
                self.full_attn_mapping = {}
                self.linear_attn_mapping = {}
                full_attn_layer_idx = 0
                linear_attn_layer_idx = 0
                for i in range(len(config.layer_types)):
                    if self.layer_types[i] == "full_attention":
                        self.full_attn_mapping[i] = full_attn_layer_idx
                        full_attn_layer_idx += 1
                    elif self.layer_types[i] == "linear_attention":
                        self.linear_attn_mapping[i] = linear_attn_layer_idx
                        linear_attn_layer_idx += 1

            def update(
                self,
                key_states: torch.Tensor,
                value_states: torch.Tensor,
                layer_idx: int,
                cache_kwargs: Optional[dict[str, Any]] = None,
            ) -> tuple[torch.Tensor, torch.Tensor]:
                # map layer_idx to key_cache (value_cache) idx
                layer_idx = self.full_attn_mapping[layer_idx]
                if self.key_cache[layer_idx] is None:
                    self.key_cache[layer_idx] = key_states
                    self.value_cache[layer_idx] = value_states
                else:
                    self.key_cache[layer_idx] = torch.cat([self.key_cache[layer_idx], key_states], dim=2)
                    self.value_cache[layer_idx] = torch.cat([self.value_cache[layer_idx], value_states], dim=2)

                return self.key_cache[layer_idx], self.value_cache[layer_idx]

            def get_seq_length(self, layer_idx: Optional[int] = 0) -> int:
                """Returns the sequence length of the cached states. A layer index can be optionally passed."""
                # take any layer that contains cache and not empty tensor
                layer_idx = self.transformer_layers[0] if layer_idx not in self.transformer_layers else layer_idx
                layer_idx = self.full_attn_mapping[layer_idx]
                if len(self.key_cache) <= layer_idx or self.key_cache[layer_idx] is None:
                    return 0
                return self.key_cache[layer_idx].shape[-2]

            @property
            def has_previous_state(self):
                """We have a previous state if the last linear (conv) layer was already updated."""
                layer_idx = self.linear_attn_mapping[self.last_linear_layer]
                return self.conv_states[layer_idx] is not None

        # the patch is needed to include KV-cache, Conv, and SSM states in the inputs and outputs.
        def patched_forward(
            input_ids,
            attention_mask=None,
            cache_params=None,
        ):
            num_full_attn_layers = self.real_config._config.layer_types.count("full_attention")
            num_linear_attn_layers = self.real_config._config.layer_types.count("linear_attention")

            use_cache = False
            wrapped_cache_params = None
            if cache_params is not None:
                use_cache = True
                conv_states = []
                recurrent_states = []
                key_cache = []
                value_cache = []

                # decouple ssm_states, conv_states, keys and values from cache_params
                for idx in range(num_linear_attn_layers):
                    conv_states.append(cache_params[2 * idx])
                    recurrent_states.append(cache_params[2 * idx + 1])

                for idx in range(num_full_attn_layers):
                    key_cache.append(cache_params[2 * num_linear_attn_layers + 2 * idx])
                    value_cache.append(cache_params[2 * num_linear_attn_layers + 2 * idx + 1])

                wrapped_cache_params = Qwen3NextDynamicCacheWrap(
                    self.real_config._config, conv_states, recurrent_states, key_cache, value_cache
                )

            causal_lm_output = self.model_orig_forward(
                input_ids=input_ids,
                attention_mask=attention_mask,
                past_key_values=wrapped_cache_params,
                use_cache=use_cache,
            )
            outputs = {
                "logits": causal_lm_output.logits,
            }

            if use_cache:
                past_key_values = causal_lm_output.past_key_values
                present_key_values = []
                for idx in range(num_linear_attn_layers):
                    present_key_values.append(past_key_values.conv_states[idx])
                    present_key_values.append(past_key_values.recurrent_states[idx])

                for idx in range(num_full_attn_layers):
                    present_key_values.append(past_key_values.key_cache[idx])
                    present_key_values.append(past_key_values.value_cache[idx])

                outputs["present_key_values"] = present_key_values

            return outputs

        self.patched_forward = patched_forward
        self.model_orig_forward = self.orig_forward
        self.orig_forward = patched_forward

        self.module_extensions = {
            RecurrentAttentionCell: ModuleExtension(RecurrentAttentionCell, "RecurrentAttentionCellOp"),
        }
        self.conversion_extensions = [
            ConversionExtension("RecurrentAttentionCellOp", convert_recurrent_attention_cell),
        ]

    def __enter__(self):
        from transformers.models.qwen3_next.modeling_qwen3_next import Qwen3NextSparseMoeBlock

        super().__enter__()
        setattr(self._model, self.orig_forward_name, self.patched_forward)

        for idx, decoder_layer in enumerate(self._model.model.layers):
            layer_type = self._model.model.config.layer_types[idx]
            if layer_type == "linear_attention":
                linear_attn_layer = decoder_layer.linear_attn
                linear_attn_layer._orig_forward = linear_attn_layer.forward
                linear_attn_layer.forward = types.MethodType(qwen3_next_gated_delta_net_forward, linear_attn_layer)
                linear_attn_layer.recurrent_gated_delta_rule = patched_recurrent_gated_delta_rule
                linear_attn_layer.recurrent_attention_cell = RecurrentAttentionCell()
            if isinstance(decoder_layer.mlp, Qwen3NextSparseMoeBlock):
                sparse_moe_block = decoder_layer.mlp
                num_experts = sparse_moe_block.num_experts
                sparse_moe_block._orig_forward = decoder_layer.mlp.forward
                sparse_moe_block.forward = types.MethodType(patched_qwen3_next_sparse_moe_block, sparse_moe_block)
                # TODO: remove `float()` casting when CVS-181449 is fixed
                # now it is needed to have MoE optimizations to be applied
                sparse_moe_block.down_projs = torch.concat(
                    tuple(sparse_moe_block.experts[i].down_proj.weight.unsqueeze(0) for i in range(num_experts)), dim=0
                ).float()
                sparse_moe_block.gate_projs = torch.concat(
                    tuple(sparse_moe_block.experts[i].gate_proj.weight.unsqueeze(0) for i in range(num_experts)), dim=0
                ).float()
                sparse_moe_block.up_projs = torch.concat(
                    tuple(sparse_moe_block.experts[i].up_proj.weight.unsqueeze(0) for i in range(num_experts)), dim=0
                ).float()

    def __exit__(self, exc_type, exc_value, traceback):
        from transformers.models.qwen3_next.modeling_qwen3_next import Qwen3NextSparseMoeBlock

        super().__exit__(exc_type, exc_value, traceback)
        setattr(self._model, self.orig_forward_name, self.model_orig_forward)
        for idx, decoder_layer in enumerate(self._model.model.layers):
            layer_type = self._model.model.config.layer_types[idx]
            if layer_type == "linear_attention":
                linear_attn_layer = decoder_layer.linear_attn
                linear_attn_layer.forward = linear_attn_layer._orig_forward
            if isinstance(decoder_layer.mlp, Qwen3NextSparseMoeBlock):
                sparse_moe_block = decoder_layer.mlp
                decoder_layer.mlp.forward = decoder_layer.mlp._orig_forward
                del sparse_moe_block.down_projs, sparse_moe_block.gate_projs, sparse_moe_block.up_projs


# This torch.nn.Module represents the Mamba2 selective-scan recurrence in its recurrent form.
# It is required for converting the Mamba2 mixer with OpenVINO using the ModuleExtension mechanism.
#
# The discretized quantities `dA` (decay), `dBx` (input contribution) and `C` (output projection)
# are precomputed and vectorized over the sequence dimension in the patched mixer forward
# (`granite_moe_hybrid_mamba_mixer_forward`). The recurrence over the SSM state is:
#       state_t = state_{t-1} * dA_t + dBx_t
#       y_t     = reduce_sum(state_t * C_t, axis=N)
# This loop has no known vectorized form that can be correctly traced by torch.jit.trace,
# so it is replaced with an `ov::Loop` operation via `convert_recurrent_selective_ssm_cell`.
class SelectiveSSMRecurrentCell(torch.nn.Module):
    def __init__(self):
        super().__init__()

    def forward(
        self,
        A,  # (H,)          — negative log-decay rates per head
        dt,  # (B, T, H)    — time steps (after softplus + clamp)
        B,  # (B, T, G, N)  — input-projection matrix (G groups, broadcast to H heads)
        x,  # (B, T, H, P)  — input hidden states (P = head_dim)
        C,  # (B, T, G, N)  — output-projection matrix (G groups, broadcast to H heads)
        last_state,  # (B, H, P, N) — initial recurrent state
    ):
        # Mamba-2 selective scan in recurrent form (one step per token):
        #   dA_t    = exp(A * dt_t)           — per-head state decay
        #   dBx_t   = dtB_t ⊗ x_t            — discretized input (outer product over P×N)
        #   state_t = state_{t-1} * dA_t + dBx_t
        #   y_t     = Σ_n (state_t * C_t)     — readout (reduce over state dim N)
        sequence_length = dt.shape[1]
        num_heads = dt.shape[2]
        num_groups = B.shape[2]
        heads_per_group = num_heads // num_groups
        core_out = torch.zeros(x.shape, dtype=x.dtype)  # (B, T, H, P)

        # Expand B/C from (B, T, G, N) → (B, T, H, N) via repeat_interleave
        B = B.repeat_interleave(heads_per_group, dim=2)
        C = C.repeat_interleave(heads_per_group, dim=2)

        # Time discretization of A and B is vectorized over the whole sequence (T) before the
        # loop — cheaper than recomputing exp / (dt * B) per timestep inside the loop:
        #   dA  = exp(A * dt)   -> (B, T, H)      per-head state decay
        #   dtB = dt * B        -> (B, T, H, N)   discretized input matrix
        # The outer product dtB ⊗ x stays inside the loop (its (B, T, H, P, N) form is too large
        # to materialize up front).
        dA = torch.exp(dt * A.view(1, 1, -1))  # (B, T, H)
        dtB = dt[..., None] * B  # (B, T, H, N)

        for i in range(sequence_length):
            dBx_t = dtB[:, i, :, None, :] * x[:, i, :, :, None]  # (B, H, P, N)
            last_state = last_state * dA[:, i, :, None, None] + dBx_t
            core_out[:, i] = (last_state * C[:, i].unsqueeze(-2)).sum(dim=-1)

        # Single flattened output (OpenVINO ModuleExtension expects one tensor).
        output_cell = torch.cat([core_out.flatten(), last_state.flatten()], dim=0)
        return output_cell


# OpenVINO has a bug due to which Clamp(-inf, inf) doesn't work correctly: CVS-185473.
# When min == -inf and max == inf, Clamp is equivalent to an identity operation and
# can be removed from the model, which serves as a workaround for the issue.
def patched_gemma4_clippable_linear_forward(self, hidden_states: torch.Tensor) -> torch.Tensor:
    hidden_states = self.linear(hidden_states)
    return hidden_states


class Gemma4ImageEmbeddingsModelPatcher(CommonImageEmbeddingsModelPatcher):
    def __init__(self, config, model, model_kwargs):
        super().__init__(config, model, model_kwargs)
        from transformers.models.gemma4.modeling_gemma4 import Gemma4ClippableLinear

        # Get the vision encoder - it's at model.model.vision_tower.encoder
        vision_model = model.model.vision_tower if is_transformers_version(">=", "5") else model.vision_tower
        self._vision_encoder = vision_model.encoder

        # Patch the vision encoder forward to bypass create_bidirectional_mask,
        # which is not compatible with torch.jit.trace due to dynamic masking logic.
        # Instead, we construct a simple 4D bidirectional attention mask from the
        # 2D padding mask to properly mask out padding patches.
        orig_encoder_forward = self._vision_encoder.forward

        def patched_encoder_forward(inputs_embeds, attention_mask=None, pixel_position_ids=None, **kwargs):
            hidden_states = inputs_embeds
            position_embeddings = self._vision_encoder.rotary_emb(hidden_states, pixel_position_ids)

            # Build a 4D bidirectional attention mask from the 2D boolean mask.
            # attention_mask is [batch, seq_len] with True=valid, False=padding.
            # Decoder layers expect a 4D mask [batch, 1, seq_len, seq_len] where
            # 0 = attend and large negative = masked.
            attn_mask_4d = None
            if attention_mask is not None:
                min_dtype = torch.finfo(hidden_states.dtype).min
                # [batch, 1, 1, seq_len] key mask
                key_mask = attention_mask[:, None, None, :].to(hidden_states.dtype)
                # Convert: 1.0 for valid tokens, min_dtype for padding
                attn_mask_4d = (1.0 - key_mask) * min_dtype

            for decoder_layer in self._vision_encoder.layers[: self._vision_encoder.config.num_hidden_layers]:
                hidden_states = decoder_layer(
                    hidden_states,
                    attention_mask=attn_mask_4d,
                    position_embeddings=position_embeddings,
                    position_ids=pixel_position_ids,
                    **kwargs,
                )

            return BaseModelOutputWithPast(last_hidden_state=hidden_states)

        self._orig_encoder_forward = orig_encoder_forward
        self._vision_encoder.forward = patched_encoder_forward

        for layer in self._vision_encoder.layers:
            for module in layer.modules():
                if isinstance(module, Gemma4ClippableLinear) and module.use_clipped_linears:
                    if (
                        module.input_min == -float("inf")
                        and module.input_max == float("inf")
                        and module.output_min == -float("inf")
                        and module.output_max == float("inf")
                    ):
                        module.orig_forward = module.forward
                        module.forward = types.MethodType(patched_gemma4_clippable_linear_forward, module)

    def __exit__(self, exc_type, exc_value, traceback):
        from transformers.models.gemma4.modeling_gemma4 import Gemma4ClippableLinear

        self._vision_encoder.forward = self._orig_encoder_forward
        super().__exit__(exc_type, exc_value, traceback)

        for layer in self._vision_encoder.layers:
            for module in layer.modules():
                if isinstance(module, Gemma4ClippableLinear) and module.use_clipped_linears:
                    if (
                        module.input_min == -float("inf")
                        and module.input_max == float("inf")
                        and module.output_min == -float("inf")
                        and module.output_max == float("inf")
                    ):
                        module.forward = module.orig_forward


# Builds the gemma4_unified causal mask dict. Unlike gemma4, the bidirectional vision
# attention applies to BOTH the full-attention and sliding-attention masks (gemma4 only
# un-masks the sliding mask), so vision tokens in the same image block attend to each other
# regardless of layer type. Mirrors transformers create_masks_for_generate with
# block_sequence_ids when use_bidirectional_attention == "vision".
# Original code: https://github.com/huggingface/transformers/blob/v5.10.0/src/transformers/models/gemma4_unified/modeling_gemma4_unified.py#L992
def _create_gemma4_unified_bidirectional_mask_dict(
    attention_mask_2d, mm_token_type_ids, inputs_embeds, sliding_window
):
    dtype = inputs_embeds.dtype
    device = inputs_embeds.device
    min_dtype = torch.finfo(dtype).min

    batch_size = inputs_embeds.shape[0]
    seq_len = inputs_embeds.shape[1]
    target_len = attention_mask_2d.shape[-1]
    past_len = target_len - seq_len

    # Standard causal mask [seq_len, target_len]
    causal_mask = torch.full((seq_len, target_len), min_dtype, dtype=dtype, device=device)
    causal_mask = torch.triu(causal_mask, diagonal=past_len + 1)

    # Apply padding from attention_mask_2d
    padding_mask = (1.0 - attention_mask_2d[:, None, None, :].to(dtype=dtype, device=device)) * min_dtype
    full_mask = causal_mask[None, None, :, :].expand(batch_size, 1, -1, -1) + padding_mask
    mm_token_type_ids = torch.nn.functional.pad(
        mm_token_type_ids, (0, target_len - mm_token_type_ids.shape[-1]), value=0
    )

    # Sliding window causal mask
    sliding_mask = full_mask.clone()
    row_pos = torch.arange(seq_len, device=device).unsqueeze(1) + past_len
    col_pos = torch.arange(target_len, device=device).unsqueeze(0)
    beyond_window = (row_pos - col_pos) >= sliding_window
    sliding_mask = sliding_mask.masked_fill(beyond_window[None, None, :, :], min_dtype)

    # Identify contiguous vision groups (trace-friendly, no in-place ops)
    # mm_token_type_ids: [batch, total_len] - 0=text, 1=image, 2=video/audio
    is_vision = (mm_token_type_ids == 1) | (mm_token_type_ids == 2)
    is_prev_vision = torch.nn.functional.pad(is_vision[:, :-1].to(dtype=torch.int32), (1, 0), value=0).bool()
    new_vision_starts = is_vision & ~is_prev_vision
    vision_group_ids = torch.cumsum(new_vision_starts.to(dtype=torch.int32), dim=1) - 1
    vision_group_ids = torch.where(is_vision, vision_group_ids, torch.tensor(-1, dtype=torch.int32, device=device))

    query_groups = vision_group_ids[:, past_len : past_len + seq_len]  # [batch, seq_len]
    key_groups = vision_group_ids  # [batch, total_len]
    same_group = (query_groups.unsqueeze(2) == key_groups.unsqueeze(1)) & (key_groups.unsqueeze(1) >= 0)
    same_group = same_group.unsqueeze(1)  # [batch, 1, seq_len, total_len]

    # Un-mask same-group vision tokens in both masks (bidirectional attention within an image).
    full_mask = full_mask.masked_fill(same_group, 0.0)
    sliding_mask = sliding_mask.masked_fill(same_group, 0.0)

    return {
        "full_attention": full_mask,
        "sliding_attention": sliding_mask,
    }


# The gemma4_unified text attention mirrors gemma4 but always exposes its own KV
# (the released 12B checkpoint sets num_kv_shared_layers=0, so no layer reuses
# another layer's KV) and fuses v_proj into k_proj when attention_k_eq_v is set
# (then self.v_proj is None and value_states reuse key_states before normalization).
# Needs to be patched so the attention runs the trace-friendly eager implementation
# and reshapes the attention mask to match the attention weights.
# Original code: https://github.com/huggingface/transformers/blob/main/src/transformers/models/gemma4_unified/modeling_gemma4_unified.py#L405
def gemma4_unified_text_attention_forward(
    self,
    hidden_states: torch.Tensor,
    position_embeddings: torch.Tensor,
    attention_mask: Optional[torch.Tensor],
    past_key_values: Optional[Cache] = None,
    cache_position: Optional[torch.LongTensor] = None,
    **kwargs,
) -> tuple:
    from transformers.models.gemma4_unified.modeling_gemma4_unified import apply_rotary_pos_emb

    input_shape = hidden_states.shape[:-1]
    hidden_shape = (*input_shape, -1, self.head_dim)

    cos, sin = position_embeddings

    query_states = self.q_proj(hidden_states).view(hidden_shape)
    query_states = self.q_norm(query_states)
    query_states = apply_rotary_pos_emb(query_states, cos, sin, unsqueeze_dim=2)
    query_states = query_states.transpose(1, 2)

    key_states = self.k_proj(hidden_states).view(hidden_shape)
    # When attention_k_eq_v is set the layer has no v_proj and reuses keys as values.
    value_states = self.v_proj(hidden_states).view(hidden_shape) if self.v_proj is not None else key_states

    key_states = self.k_norm(key_states)
    key_states = apply_rotary_pos_emb(key_states, cos, sin, unsqueeze_dim=2)
    key_states = key_states.transpose(1, 2)

    value_states = self.v_norm(value_states)
    value_states = value_states.transpose(1, 2)

    if past_key_values is not None:
        # Match HF Gemma4UnifiedTextAttention: store the full-length KV (no sliding-window
        # eviction in the cache). Sliding attention is enforced solely via the attention mask,
        # so passing a sliding_window here would wrongly evict cached KV during decode.
        key_states, value_states = past_key_values.update(key_states, value_states, self.layer_idx)

    # Reuse the gemma4 eager attention which already handles GQA repeat, softcapping and mask reshaping.
    attn_output, attn_weights = gemma4_eager_attention_forward_patched(
        self,
        query_states,
        key_states,
        value_states,
        attention_mask,
        dropout=self.attention_dropout if self.training else 0.0,
        scaling=self.scaling,
        sliding_window=self.sliding_window,
        **kwargs,
    )

    attn_output = attn_output.reshape(*input_shape, -1).contiguous()
    attn_output = self.o_proj(attn_output)
    return attn_output, attn_weights


# Forward method of the gemma4_unified language model (the inner Gemma4UnifiedModel).
# The OV language model receives already-merged inputs_embeds (vision soft tokens are scattered
# in Python) plus a precomputed token_type_ids, and must build the gemma3-style bidirectional
# vision attention mask itself (the original relies on input_ids and the multimodal towers).
# Original code: https://github.com/huggingface/transformers/blob/main/src/transformers/models/gemma4_unified/modeling_gemma4_unified.py#L992
def gemma4_unified_language_model_forward(
    self,
    input_ids: Optional[torch.LongTensor] = None,
    attention_mask: Optional[torch.Tensor] = None,
    position_ids: Optional[torch.LongTensor] = None,
    past_key_values: Optional[Cache] = None,
    mm_token_type_ids: Optional[torch.LongTensor] = None,
    cache_position: Optional[torch.LongTensor] = None,
    inputs_embeds: Optional[torch.FloatTensor] = None,
    use_cache: Optional[bool] = None,
    output_attentions: Optional[bool] = None,
    output_hidden_states: Optional[bool] = None,
    **lm_kwargs,
):
    from transformers.models.gemma4_unified.modeling_gemma4_unified import Gemma4UnifiedModelOutputWithPast

    if (input_ids is None) ^ (inputs_embeds is not None):
        raise ValueError("You must specify exactly one of input_ids or inputs_embeds")

    # Larger gemma4 models use gemma3-style bidirectional attention for vision tokens.
    use_bidirectional = getattr(self.config.get_text_config(), "use_bidirectional_attention", None) == "vision"
    if use_bidirectional and mm_token_type_ids is not None:
        attention_mask = _create_gemma4_unified_bidirectional_mask_dict(
            attention_mask,
            mm_token_type_ids,
            inputs_embeds,
            self.config.get_text_config().sliding_window,
        )

    outputs = self.model.language_model(
        input_ids=None,
        attention_mask=attention_mask,
        position_ids=position_ids,
        past_key_values=past_key_values,
        inputs_embeds=inputs_embeds,
        use_cache=use_cache,
        output_attentions=output_attentions,
        output_hidden_states=output_hidden_states,
        cache_position=cache_position,
        **lm_kwargs,
    )

    return Gemma4UnifiedModelOutputWithPast(
        last_hidden_state=outputs.last_hidden_state,
        past_key_values=outputs.past_key_values if use_cache else None,
        hidden_states=outputs.hidden_states,
        attentions=outputs.attentions,
    )


# Top-level gemma4_unified forward producing logits (with final logit softcapping) and KV cache.
# Mirrors gemma4_lm_forward but without per_layer_inputs (the unified text model has no PLE).
# Original code: https://github.com/huggingface/transformers/blob/main/src/transformers/models/gemma4_unified/modeling_gemma4_unified.py#L1224
def gemma4_unified_lm_forward(
    self,
    attention_mask: Optional[torch.Tensor] = None,
    position_ids: Optional[torch.LongTensor] = None,
    past_key_values: Optional[Cache] = None,
    inputs_embeds: Optional[torch.FloatTensor] = None,
    token_type_ids: Optional[torch.LongTensor] = None,
    input_ids: Optional[torch.LongTensor] = None,
    cache_position: Optional[torch.LongTensor] = None,
    labels: Optional[torch.LongTensor] = None,
    use_cache: Optional[bool] = None,
    output_attentions: Optional[bool] = None,
    output_hidden_states: Optional[bool] = None,
    logits_to_keep: Union[int, torch.Tensor] = 0,
    **lm_kwargs,
):
    output_attentions = output_attentions if output_attentions is not None else self.config.output_attentions
    output_hidden_states = (
        output_hidden_states if output_hidden_states is not None else self.config.output_hidden_states
    )
    use_cache = False

    if past_key_values is not None:
        use_cache = True
        past_key_values = preprocess_past_key_values(past_key_values)

    outputs = self.model(
        input_ids=input_ids,
        attention_mask=attention_mask,
        position_ids=position_ids,
        past_key_values=past_key_values,
        mm_token_type_ids=token_type_ids,
        cache_position=cache_position,
        inputs_embeds=inputs_embeds,
        labels=labels,
        use_cache=use_cache,
        output_attentions=output_attentions,
        output_hidden_states=output_hidden_states,
        return_dict=True,
        **lm_kwargs,
    )

    hidden_states = outputs.last_hidden_state
    slice_indices = slice(-logits_to_keep, None) if isinstance(logits_to_keep, int) else logits_to_keep
    tmp_logits = self.lm_head(hidden_states[:, slice_indices, :])
    if (final_logit_softcapping := self.config.get_text_config().final_logit_softcapping) is not None:
        tmp_logits = tmp_logits / final_logit_softcapping
        tmp_logits = torch.tanh(tmp_logits)
        tmp_logits = tmp_logits * final_logit_softcapping

    outputs_dict = {
        "logits": tmp_logits,
    }

    if use_cache:
        key_values = outputs.past_key_values
        present_key_values = postprocess_past_key_values(key_values)
        outputs_dict["past_key_values"] = present_key_values
    return tuple([value if not isinstance(value, list) else tuple(value) for value in outputs_dict.values()])


class Gemma4UnifiedLMModelPatcher(Gemma3LMModelPatcher):
    def __init__(self, config, model, model_kwargs):
        super().__init__(config, model, model_kwargs)

        self.patched_forward = gemma4_unified_lm_forward
        self.model_orig_forward = self.orig_forward
        self.orig_forward = gemma4_unified_lm_forward

        self.model_orig_language_model_forward = self._model.model.forward

    def __enter__(self):
        super().__enter__()

        setattr(self._model, self.orig_forward_name, types.MethodType(gemma4_unified_lm_forward, self._model))
        setattr(self._model.model, "forward", types.MethodType(gemma4_unified_language_model_forward, self._model))
        for decoder_layer in self._model.model.language_model.layers:
            decoder_layer.self_attn.orig_forward = decoder_layer.self_attn.forward
            decoder_layer.self_attn.forward = types.MethodType(
                gemma4_unified_text_attention_forward, decoder_layer.self_attn
            )

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)

        for decoder_layer in self._model.model.language_model.layers:
            decoder_layer.self_attn.forward = decoder_layer.self_attn.orig_forward

        setattr(self._model, self.orig_forward_name, self.model_orig_forward)
        setattr(self._model.model, "forward", self.model_orig_language_model_forward)


# The gemma4_unified vision tower is encoder-free: get_image_features projects raw merged
# pixel patches through Gemma4UnifiedVisionEmbedder. The default get_image_features strips
# padding patches via boolean indexing on a data-dependent mask, which is not trace-friendly,
# so we export the embedder directly and keep all patches (padding positions are dropped later
# when soft tokens are scattered into the text sequence by mm_token_type_ids).
class Gemma4UnifiedImageEmbeddingsModelPatcher(ModelPatcher):
    def __init__(self, config, model, model_kwargs):
        super().__init__(config, model, model_kwargs)

        embed_vision = model.model.embed_vision

        def patched_forward(pixel_values, image_position_ids):
            outputs = embed_vision(pixel_values, image_position_ids)
            return {"last_hidden_state": outputs}

        self.patched_forward = patched_forward


# Patches the MoE block with a vectorized implementation.
# The vectorized form is required to ensure correct torch.jit tracing for this component.
# Original implementation: https://github.com/huggingface/transformers/blob/v5.0.0/src/transformers/models/lfm2_moe/modeling_lfm2_moe.py#L167
def lfm2_moe_experts_forward(
    self,
    hidden_states: torch.Tensor,
    top_k_index: torch.Tensor,
    top_k_weights: torch.Tensor,
) -> torch.Tensor:
    routing_weights = top_k_weights.to(hidden_states.dtype)
    num_tokens, hidden_dim = hidden_states.shape
    num_experts = self.num_experts

    dense_routing_weights = torch.zeros(
        num_tokens,
        num_experts,
        device=hidden_states.device,
        dtype=hidden_states.dtype,
    )
    dense_routing_weights.scatter_(dim=1, index=top_k_index, src=routing_weights)
    hidden_states_expanded = hidden_states.repeat(num_experts, 1)  # (num_experts * num_tokens, hidden_dim)
    hidden_states_expanded = hidden_states_expanded.view(
        num_experts, -1, hidden_dim
    )  # (num_experts, num_tokens, hidden_dim)

    gate_proj, up_proj = self.gate_up_proj.chunk(2, dim=-2)

    gate = torch.bmm(hidden_states_expanded, gate_proj.transpose(1, 2))
    up = torch.bmm(hidden_states_expanded, up_proj.transpose(1, 2))
    next_states = self.act_fn(gate) * up
    next_states = torch.bmm(next_states, self.down_proj.transpose(1, 2))

    next_states = next_states.view(num_experts, num_tokens, hidden_dim)
    next_states = next_states * dense_routing_weights.transpose(0, 1).view(num_experts, num_tokens)[..., None]
    next_states = next_states.sum(dim=0)

    return next_states


class Lfm2MoeModelPatcher(Lfm2ModelPatcher):
    def __enter__(self):
        super().__enter__()
        from transformers.models.lfm2_moe.modeling_lfm2_moe import (
            Lfm2MoeDecoderLayer,
            Lfm2MoeExperts,
            Lfm2MoeShortConv,
            Lfm2MoeSparseMoeBlock,
        )

        super().__enter__()
        setattr(self._model, self.orig_forward_name, self.patched_forward)

        for layer in self._model.model.layers:
            if hasattr(layer, "conv") and isinstance(layer.conv, Lfm2MoeShortConv):
                conv_layer = layer.conv
                conv_layer._orig_forward = conv_layer.slow_forward
                conv_layer.slow_forward = types.MethodType(lfm2_short_conv_forward_patched, conv_layer)

            if isinstance(layer, Lfm2MoeDecoderLayer) and isinstance(layer.feed_forward, Lfm2MoeSparseMoeBlock):
                sparse_moe_block = layer.feed_forward
                if isinstance(sparse_moe_block.experts, Lfm2MoeExperts):
                    lfm2_moe_experts = sparse_moe_block.experts
                    lfm2_moe_experts._orig_forward = lfm2_moe_experts.forward
                    lfm2_moe_experts.forward = types.MethodType(lfm2_moe_experts_forward, lfm2_moe_experts)

    def __exit__(self, exc_type, exc_value, traceback):
        from transformers.models.lfm2_moe.modeling_lfm2_moe import (
            Lfm2MoeDecoderLayer,
            Lfm2MoeExperts,
            Lfm2MoeShortConv,
            Lfm2MoeSparseMoeBlock,
        )

        super().__exit__(exc_type, exc_value, traceback)
        setattr(self._model, self.orig_forward_name, self.model_orig_forward)

        for layer in self._model.model.layers:
            if hasattr(layer, "conv") and isinstance(layer.conv, Lfm2MoeShortConv):
                conv_layer = layer.conv
                conv_layer.slow_forward = conv_layer._orig_forward

            if isinstance(layer, Lfm2MoeDecoderLayer) and isinstance(layer.feed_forward, Lfm2MoeSparseMoeBlock):
                sparse_moe_block = layer.feed_forward
                if isinstance(sparse_moe_block.experts, Lfm2MoeExperts):
                    lfm2_moe_experts = sparse_moe_block.experts
                    lfm2_moe_experts.forward = lfm2_moe_experts._orig_forward


# The CausalConv1D block is overridden with a generic patch provided by `ov_causal_conv1d()`.
# The GatedDeltaNet block is overridden with a recurrent version of its implementation.
#
# To replace GatedDeltaNet with its recurrent form, patching uses the ModuleExtension
# approach, which replaces the GatedDeltaNet block with a single operation,
# `GatedDeltaNetOp`. OpenVINO then applies the `convert_recurrent_attention_cell()`
# conversion rule to this operation.
# Adapted from: https://github.com/huggingface/transformers/blob/v5.2-release/src/transformers/models/qwen3_5/modeling_qwen3_5.py#L511
def qwen3_5_gated_delta_net_forward(
    self,
    hidden_states: torch.Tensor,
    cache_params=None,
    cache_position: Optional[torch.LongTensor] = None,
    attention_mask: Optional[torch.Tensor] = None,
):
    def apply_mask_to_padding_states(hidden_states, attention_mask):
        """
        Tunes out the hidden states for padding tokens, see https://github.com/state-spaces/mamba/issues/66
        """
        # NOTE: attention mask is a 2D boolean tensor
        if attention_mask is not None and attention_mask.shape[1] > 1 and attention_mask.shape[0] > 1:
            dtype = hidden_states.dtype
            hidden_states = (hidden_states * attention_mask[:, :, None]).to(dtype)

        return hidden_states

    hidden_states = apply_mask_to_padding_states(hidden_states, attention_mask)

    # Set up dimensions for reshapes later
    batch_size, seq_len, _ = hidden_states.shape

    # getting projected states from cache if it exists
    layer_idx = None
    recurrent_state = None
    if cache_params is not None:
        layer_idx = cache_params.linear_attn_mapping[self.layer_idx]
        conv_state = cache_params.conv_states[layer_idx]
        recurrent_state = cache_params.recurrent_states[layer_idx]

    mixed_qkv = self.in_proj_qkv(hidden_states)
    mixed_qkv = mixed_qkv.transpose(1, 2)

    z = self.in_proj_z(hidden_states)
    z = z.reshape(batch_size, seq_len, -1, self.head_v_dim)

    b = self.in_proj_b(hidden_states)
    a = self.in_proj_a(hidden_states)

    if cache_params is not None:
        new_mixed_qkv, new_conv_state = ov_causal_conv1d(conv_state, mixed_qkv, self.conv1d.weight, self.conv1d.bias)
        mixed_qkv = F.silu(new_mixed_qkv)
        cache_params.conv_states[layer_idx] = new_conv_state
    else:
        mixed_qkv = F.silu(self.conv1d(mixed_qkv)[:, :, :seq_len])

    mixed_qkv = mixed_qkv.transpose(1, 2)
    query, key, value = torch.split(
        mixed_qkv,
        [
            self.key_dim,
            self.key_dim,
            self.value_dim,
        ],
        dim=-1,
    )
    query = query.reshape(query.shape[0], query.shape[1], -1, self.head_k_dim)
    key = key.reshape(key.shape[0], key.shape[1], -1, self.head_k_dim)
    value = value.reshape(value.shape[0], value.shape[1], -1, self.head_v_dim)

    beta = b.sigmoid()
    # If the model is loaded in fp16, without the .float() here, A might be -inf
    g = -self.A_log.float().exp() * F.softplus(a.float() + self.dt_bias)
    if self.num_v_heads // self.num_k_heads > 1:
        query = query.repeat_interleave(self.num_v_heads // self.num_k_heads, dim=2)
        key = key.repeat_interleave(self.num_v_heads // self.num_k_heads, dim=2)

    core_attn_out, last_recurrent_state = self.recurrent_gated_delta_rule(
        self,
        query,
        key,
        value,
        g=g,
        beta=beta,
        initial_state=recurrent_state,
        output_final_state=cache_params is not None,
        use_qk_l2norm_in_kernel=True,
    )

    # Update cache
    if cache_params is not None:
        cache_params.recurrent_states[layer_idx] = last_recurrent_state

    # reshape input data into 2D tensor
    core_attn_out = core_attn_out.reshape(-1, self.head_v_dim)
    z = z.reshape(-1, self.head_v_dim)
    core_attn_out = self.norm(core_attn_out, z)
    core_attn_out = core_attn_out.reshape(batch_size, seq_len, -1)

    output = self.out_proj(core_attn_out)
    return output


class Qwen3_5ModelPatcher(OVDecoderModelPatcher):
    def __init__(
        self,
        config: "OpenVINOConfig",
        model: "PreTrainedModel",
        model_kwargs: Optional[Dict[str, Any]] = None,
    ):
        from transformers.models.qwen3_5.modeling_qwen3_5 import Qwen3_5DynamicCache

        from openvino.frontend.pytorch import ConversionExtension, ModuleExtension

        from ._ov_ops import convert_recurrent_attention_cell

        super().__init__(config, model, model_kwargs)

        # Detect VLM vs text-only model
        self._is_vlm = hasattr(self._model.model, "language_model")
        if self._is_vlm:
            self._text_model = self._model.model.language_model
            self._text_config = self._model.config.text_config
        else:
            self._text_model = self._model.model
            self._text_config = self._model.model.config

        class Qwen3_5DynamicCacheWrap(Qwen3_5DynamicCache):
            def __init__(self, config, conv_states, recurrent_states, key_cache, value_cache):
                # Call parent constructor with all required arguments
                super().__init__(config=config)

                self.conv_states = conv_states
                self.recurrent_states = recurrent_states
                self.key_cache = key_cache
                self.value_cache = value_cache
                self.full_attn_mapping = {}
                self.linear_attn_mapping = {}
                full_attn_layer_idx = 0
                linear_attn_layer_idx = 0
                for i in range(len(config.layer_types)):
                    if self.layer_types[i] == "full_attention":
                        self.full_attn_mapping[i] = full_attn_layer_idx
                        full_attn_layer_idx += 1
                    elif self.layer_types[i] == "linear_attention":
                        self.linear_attn_mapping[i] = linear_attn_layer_idx
                        linear_attn_layer_idx += 1

            def update(
                self,
                key_states: torch.Tensor,
                value_states: torch.Tensor,
                layer_idx: int,
                cache_kwargs: Optional[dict[str, Any]] = None,
            ) -> tuple[torch.Tensor, torch.Tensor]:
                # map layer_idx to key_cache (value_cache) idx
                layer_idx = self.full_attn_mapping[layer_idx]
                if self.key_cache[layer_idx] is None:
                    self.key_cache[layer_idx] = key_states
                    self.value_cache[layer_idx] = value_states
                else:
                    self.key_cache[layer_idx] = torch.cat([self.key_cache[layer_idx], key_states], dim=2)
                    self.value_cache[layer_idx] = torch.cat([self.value_cache[layer_idx], value_states], dim=2)

                return self.key_cache[layer_idx], self.value_cache[layer_idx]

            def get_seq_length(self, layer_idx: Optional[int] = 0) -> int:
                """Returns the sequence length of the cached states. A layer index can be optionally passed."""
                # take any layer that contains cache and not empty tensor
                layer_idx = self.transformer_layers[0] if layer_idx not in self.transformer_layers else layer_idx
                layer_idx = self.full_attn_mapping[layer_idx]
                if len(self.key_cache) <= layer_idx or self.key_cache[layer_idx] is None:
                    return 0
                return self.key_cache[layer_idx].shape[-2]

            @property
            def has_previous_state(self):
                """We have a previous state if the last linear (conv) layer was already updated."""
                layer_idx = self.linear_attn_mapping[self.last_linear_layer]
                return self.conv_states[layer_idx] is not None

        # the patch is needed to include KV-cache, Conv, and SSM states in the inputs and outputs.
        def patched_forward(
            input_ids=None,
            attention_mask=None,
            cache_params=None,
            inputs_embeds=None,
            position_ids=None,
        ):
            text_config = self._text_config
            num_full_attn_layers = text_config.layer_types.count("full_attention")
            num_linear_attn_layers = text_config.layer_types.count("linear_attention")

            use_cache = False
            wrapped_cache_params = None
            if cache_params is not None:
                use_cache = True
                conv_states = []
                recurrent_states = []
                key_cache = []
                value_cache = []

                # decouple ssm_states, conv_states, keys and values from cache_params
                for idx in range(num_linear_attn_layers):
                    conv_states.append(cache_params[2 * idx])
                    recurrent_states.append(cache_params[2 * idx + 1])

                for idx in range(num_full_attn_layers):
                    key_cache.append(cache_params[2 * num_linear_attn_layers + 2 * idx])
                    value_cache.append(cache_params[2 * num_linear_attn_layers + 2 * idx + 1])

                wrapped_cache_params = Qwen3_5DynamicCacheWrap(
                    text_config, conv_states, recurrent_states, key_cache, value_cache
                )

            if self._is_vlm:
                # VLM case: call language model through the composite model
                outputs_lm = self._text_model(
                    inputs_embeds=inputs_embeds,
                    attention_mask=attention_mask,
                    position_ids=position_ids,
                    past_key_values=wrapped_cache_params,
                    use_cache=use_cache,
                )
                hidden_states = outputs_lm[0]
                logits = self._model.lm_head(hidden_states)
                past_kv = outputs_lm.past_key_values
            else:
                causal_lm_output = self.model_orig_forward(
                    input_ids=input_ids,
                    attention_mask=attention_mask,
                    past_key_values=wrapped_cache_params,
                    use_cache=use_cache,
                )
                logits = causal_lm_output.logits
                past_kv = causal_lm_output.past_key_values
            outputs = {
                "logits": logits,
            }

            if use_cache:
                present_key_values = []
                for idx in range(num_linear_attn_layers):
                    present_key_values.append(past_kv.conv_states[idx])
                    present_key_values.append(past_kv.recurrent_states[idx])

                for idx in range(num_full_attn_layers):
                    present_key_values.append(past_kv.key_cache[idx])
                    present_key_values.append(past_kv.value_cache[idx])

                outputs["present_key_values"] = present_key_values

            return outputs

        self.patched_forward = patched_forward
        self.model_orig_forward = self.orig_forward
        self.orig_forward = patched_forward

        self.module_extensions = {
            RecurrentAttentionCell: ModuleExtension(RecurrentAttentionCell, "RecurrentAttentionCellOp"),
        }
        self.conversion_extensions = [
            ConversionExtension("RecurrentAttentionCellOp", convert_recurrent_attention_cell),
        ]

    def __enter__(self):
        super().__enter__()
        setattr(self._model, self.orig_forward_name, self.patched_forward)

        for idx, decoder_layer in enumerate(self._text_model.layers):
            layer_type = self._text_config.layer_types[idx]
            if layer_type == "linear_attention":
                linear_attn_layer = decoder_layer.linear_attn
                linear_attn_layer._orig_forward = linear_attn_layer.forward
                linear_attn_layer.forward = types.MethodType(qwen3_5_gated_delta_net_forward, linear_attn_layer)
                linear_attn_layer.recurrent_gated_delta_rule = patched_recurrent_gated_delta_rule
                linear_attn_layer.recurrent_attention_cell = RecurrentAttentionCell()

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)
        setattr(self._model, self.orig_forward_name, self.model_orig_forward)
        for idx, decoder_layer in enumerate(self._text_model.layers):
            layer_type = self._text_config.layer_types[idx]
            if layer_type == "linear_attention":
                linear_attn_layer = decoder_layer.linear_attn
                linear_attn_layer.forward = linear_attn_layer._orig_forward


class Qwen3_5VisionEmbMergerPatcher(ModelPatcher):
    def __init__(
        self,
        config: "OpenVINOConfig",
        model: "PreTrainedModel",
        model_kwargs: Dict[str, Any] = None,
    ):
        model.__orig_forward = model.forward

        # Adapted from Qwen3.5 VisionModel forward
        # added attention_mask input instead of cu_seqlens for its internal calculation
        # separated patch_embed and rot_pos_emb calls for performing as part of another model
        def image_embed_forward(
            self, hidden_states: torch.Tensor, attention_mask: torch.Tensor, rotary_pos_emb: torch.Tensor
        ) -> torch.Tensor:
            emb = torch.cat((rotary_pos_emb, rotary_pos_emb), dim=-1)
            position_embeddings = (emb.cos(), emb.sin())
            for blk in self.blocks:
                hidden_states = blk(
                    hidden_states, attention_mask=attention_mask, position_embeddings=position_embeddings
                )
            return self.merger(hidden_states)

        model.forward = types.MethodType(image_embed_forward, model)
        super().__init__(config, model, model_kwargs)

    def __enter__(self):
        patch_qwen2vl_vision_blocks(self._model)
        super().__enter__()

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)
        self._model.forward = self._model.__orig_forward
        for block in self._model.blocks:
            block.forward = block._orig_forward
            block.attn.forward = block.attn._orig_forward


def _qwen3_5_mtp_module_forward(
    self, hidden_states, inputs_embeds, attention_mask=None, position_ids=None, past_key_values=None
):
    """
    Trace-friendly forward shared by the dense and MoE Qwen3.5 MTP heads.

    Everything the single MTP decoder layer needs is produced here: the input dtype is normalized,
    the rotary position embeddings (MRoPE) and the 4D causal mask are built, and the KV cache is
    wrapped in a minimal ``_MTPDynamicCache`` (kept instead of a transformers ``DynamicCache`` so the
    traced graph stays free of the cache's lazy-init / ``numel`` branches). The head has one decoder
    layer, so ``past_key_values`` is the standard optimum ``[(key, value)]`` list with a single pair.
    """
    dtype = self.fc.weight.dtype
    hidden_states = hidden_states.to(dtype)
    inputs_embeds = inputs_embeds.to(dtype)

    use_cache = past_key_values is not None
    wrapped_cache = None
    past_key_values_length = 0
    if use_cache:
        past_key, past_value = past_key_values[0]
        wrapped_cache = _MTPDynamicCache(past_key.to(dtype), past_value.to(dtype))
        past_key_values_length = past_key.shape[2]

    h_norm = self.pre_fc_norm_hidden(hidden_states)
    e_norm = self.pre_fc_norm_embedding(inputs_embeds)
    combined = torch.cat([e_norm, h_norm], dim=-1)
    x = self.fc(combined)

    # Compute rotary position embeddings (MRoPE: expand to 3D)
    if position_ids.ndim == 2:
        rope_position_ids = position_ids[None, ...].expand(3, position_ids.shape[0], -1)
    else:
        rope_position_ids = position_ids
    position_embeddings = self.rotary_emb(x, rope_position_ids)

    # Build causal 4D attention mask from 2D attention_mask
    batch_size, seq_length = x.shape[:2]
    total_length = seq_length + past_key_values_length

    # Create causal mask using comparison (trace-friendly, no static shapes)
    # row indices [0..seq_length-1], col indices [0..total_length-1]
    row_idx = torch.arange(seq_length, device=x.device).unsqueeze(1) + past_key_values_length
    col_idx = torch.arange(total_length, device=x.device).unsqueeze(0)
    # causal: mask where col > row (future positions)
    causal_bool = col_idx > row_idx  # [seq_length, total_length]
    causal_mask = causal_bool.unsqueeze(0).unsqueeze(0).to(x.dtype) * torch.finfo(x.dtype).min

    # Apply padding mask from attention_mask
    if attention_mask is not None:
        padding_mask = (1.0 - attention_mask[:, None, None, :total_length].to(x.dtype)) * torch.finfo(x.dtype).min
        causal_mask = causal_mask + padding_mask

    layer = self.layers[0]
    x = layer(
        x,
        position_embeddings=position_embeddings,
        attention_mask=causal_mask,
        position_ids=rope_position_ids,
        past_key_values=wrapped_cache,
    )

    x = self.norm(x)

    outputs = {"last_hidden_state": x}
    if use_cache:
        outputs["present_key_values"] = [wrapped_cache.key_cache[0], wrapped_cache.value_cache[0]]
    return outputs


class Qwen3_5MTPModule(nn.Module):
    """
    Standalone PyTorch module wrapping the MTP (Multi-Token Prediction) head weights
    from Qwen3.5 for independent OpenVINO export.
    """

    __module__ = "transformers.models.qwen3_5"

    def __init__(self, text_config):
        super().__init__()
        from transformers.models.qwen3_5.modeling_qwen3_5 import (
            Qwen3_5DecoderLayer,
            Qwen3_5RMSNorm,
            Qwen3_5TextConfig,
            Qwen3_5TextRotaryEmbedding,
        )

        self.config = text_config
        hidden_size = text_config.hidden_size

        # MTP-specific layers
        self.pre_fc_norm_embedding = Qwen3_5RMSNorm(hidden_size, eps=text_config.rms_norm_eps)
        self.pre_fc_norm_hidden = Qwen3_5RMSNorm(hidden_size, eps=text_config.rms_norm_eps)
        self.fc = nn.Linear(hidden_size * 2, hidden_size, bias=False)

        # Single decoder layer (full attention type)
        mtp_config = Qwen3_5TextConfig(
            vocab_size=text_config.vocab_size,
            hidden_size=text_config.hidden_size,
            intermediate_size=text_config.intermediate_size,
            num_hidden_layers=1,
            num_attention_heads=text_config.num_attention_heads,
            num_key_value_heads=text_config.num_key_value_heads,
            hidden_act=text_config.hidden_act,
            max_position_embeddings=text_config.max_position_embeddings,
            rms_norm_eps=text_config.rms_norm_eps,
            attention_bias=text_config.attention_bias,
            head_dim=text_config.head_dim,
            rope_parameters=text_config.rope_parameters,
            layer_types=["full_attention"],
        )
        self.layers = nn.ModuleList([Qwen3_5DecoderLayer(mtp_config, layer_idx=0)])
        self.rotary_emb = Qwen3_5TextRotaryEmbedding(mtp_config)

        # Final norm
        self.norm = Qwen3_5RMSNorm(hidden_size, eps=text_config.rms_norm_eps)

    @classmethod
    def from_pretrained_model(cls, model):
        """Create MTP module and load weights from the full Qwen3.5 model checkpoint."""
        config = model.config
        text_config = getattr(config, "text_config", config)
        mtp_module = cls(text_config)

        # Load MTP-specific weights (transformers ignores 'mtp.*' keys on load).
        _load_mtp_weights(mtp_module, model)

        # Override model_type so patch_stateful uses standard decoder path
        # (qwen3_5_text is in SSM_MODELS which routes to hybrid_ssm stateful logic)
        mtp_module.config = copy.deepcopy(text_config)
        mtp_module.config.model_type = "qwen3_5_mtp"
        return mtp_module

    forward = _qwen3_5_mtp_module_forward


def _set_nested_attr(module, name, tensor):
    """Set a nested attribute on a module from a dot-separated name."""
    parts = name.split(".")
    for part in parts[:-1]:
        if part.isdigit():
            module = module[int(part)]
        else:
            module = getattr(module, part)
    param_name = parts[-1]
    if hasattr(module, param_name):
        param = getattr(module, param_name)
        if isinstance(param, nn.Parameter):
            param.data = tensor
        else:
            setattr(module, param_name, nn.Parameter(tensor))
    else:
        setattr(module, param_name, nn.Parameter(tensor))


def _load_mtp_weights(mtp_module, model):
    """Populate an MTP head module with the ``mtp.*`` weights from the checkpoint.

    The transformers modeling code lists ``mtp.*`` in ``_keys_to_ignore_on_load_unexpected``,
    so these weights are never held on the loaded model and must be read directly from the
    checkpoint files. Supports both a local export directory and a Hugging Face hub repo id.
    """
    model_name = getattr(model.config, "_name_or_path", None)
    if not model_name:
        raise ValueError("Cannot load MTP weights: model config has no '_name_or_path'.")

    is_local = os.path.isdir(model_name)

    def _resolve(filename):
        if is_local:
            path = os.path.join(model_name, filename)
            return path if os.path.isfile(path) else None
        try:
            return hf_hub_download(model_name, filename)
        except EntryNotFoundError:
            return None

    # Determine which safetensors file(s) hold the mtp weights.
    shard_files = []
    index_path = _resolve("model.safetensors.index.json")
    if index_path is not None:
        with open(index_path) as f:
            index = json.load(f)
        mtp_keys = [k for k in index["weight_map"] if k.startswith("mtp.")]
        shard_files = sorted({index["weight_map"][k] for k in mtp_keys})
    elif _resolve("model.safetensors") is not None:
        shard_files = ["model.safetensors"]

    loaded = 0
    for shard in shard_files:
        shard_path = _resolve(shard)
        if shard_path is None:
            continue
        with safe_open(shard_path, framework="pt") as f:
            for key in f.keys():
                if key.startswith("mtp."):
                    _set_nested_attr(mtp_module, key[4:], f.get_tensor(key))
                    loaded += 1

    if loaded == 0:
        raise RuntimeError(
            f"No MTP ('mtp.*') weights were loaded from '{model_name}'. The exported MTP head "
            "would contain random weights, yielding a 0% speculative acceptance rate. Ensure the "
            "checkpoint contains the MTP weights and is reachable as a local directory or hub repo."
        )
    return mtp_module


class _MTPDynamicCache:
    """Minimal cache wrapper for MTP export that avoids DynamicCache's layer-based API."""

    def __init__(self, key_states, value_states):
        self.key_cache = [key_states]
        self.value_cache = [value_states]

    def get_seq_length(self, layer_idx=0):
        if len(self.key_cache) > layer_idx and self.key_cache[layer_idx] is not None:
            return self.key_cache[layer_idx].shape[-2]
        return 0

    def update(self, key_states, value_states, layer_idx, cache_kwargs=None):
        if self.key_cache[layer_idx] is not None:
            key_states = torch.cat([self.key_cache[layer_idx], key_states], dim=2)
            value_states = torch.cat([self.value_cache[layer_idx], value_states], dim=2)
        self.key_cache[layer_idx] = key_states
        self.value_cache[layer_idx] = value_states
        return key_states, value_states


class Qwen3_5MTPModelPatcher(ModelPatcher):
    def __init__(
        self,
        config: "OpenVINOConfig",
        model: "PreTrainedModel",
        model_kwargs: Optional[Dict[str, Any]] = None,
    ):
        super().__init__(config, model, model_kwargs)
        # The MTP forward lives on the module itself (see `_qwen3_5_mtp_module_forward`). Drive it
        # directly and bypass the base `ModelPatcher` wrapper, whose cache pre/post-processing
        # (legacy list -> DynamicCache) would change the traced graph.
        self.patched_forward = self._model.forward
        self.orig_forward = self._model.forward


# Patched forward for MobileNetV5MultiScaleFusionAdapter (MSFA) used by the Gemma3n vision tower.
# The original MSFA forward has data-dependent control flow that branches on tensor spatial
# dimensions to choose between F.interpolate and F.avg_pool2d for resizing to output_resolution.
# torch.jit.trace bakes only the path taken with dummy inputs, causing incorrect results when
# actual inference images have different spatial dimensions.
# This patch replaces the conditional resize with F.adaptive_avg_pool2d which:
#   - accepts a constant output_size making it trace-friendly
#   - is equivalent to avg_pool2d when input dims are evenly divisible by output dims
#   - handles identity (no-op) when input dims == output dims
# Adopted from timm.models.mobilenetv5.MobileNetV5MultiScaleFusionAdapter.forward
# Original code: https://github.com/huggingface/pytorch-image-models/blob/v1.0.27/timm/models/mobilenetv5.py#L92
def _gemma3n_msfa_forward(self, inputs: List[torch.Tensor]) -> torch.Tensor:
    high_resolution = inputs[0].shape[-2:]
    resized_inputs = []
    for img in inputs:
        feat_size = img.shape[-2:]
        if feat_size[0] < high_resolution[0] or feat_size[1] < high_resolution[1]:
            img = F.interpolate(img, size=high_resolution, mode=self.interpolation_mode)
        resized_inputs.append(img)

    channel_cat_imgs = torch.cat(resized_inputs, dim=1)
    img = self.ffn(channel_cat_imgs)

    # Use adaptive_avg_pool2d instead of conditional avg_pool2d / interpolate.
    # output_resolution is a constant tuple, so this is trace-friendly.
    img = F.adaptive_avg_pool2d(img, self.output_resolution)

    img = self.norm(img)
    return img


class Gemma3nImageEmbeddingsModelPatcher(CommonImageEmbeddingsModelPatcher):
    def __enter__(self):
        super().__enter__()
        # Patch MSFA forward to be trace-friendly
        vision_tower = self._model.model.vision_tower
        timm_model = vision_tower.timm_model
        if hasattr(timm_model, "msfa") and timm_model.msfa is not None:
            timm_model.msfa._orig_forward = timm_model.msfa.forward
            timm_model.msfa.forward = types.MethodType(_gemma3n_msfa_forward, timm_model.msfa)

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)
        vision_tower = self._model.model.vision_tower
        timm_model = vision_tower.timm_model
        if hasattr(timm_model, "msfa") and timm_model.msfa is not None and hasattr(timm_model.msfa, "_orig_forward"):
            timm_model.msfa.forward = timm_model.msfa._orig_forward


# Patches the MoE block with a vectorized implementation.
# The vectorized form is required to ensure correct torch.jit tracing for this component.
# Original implementation: https://github.com/huggingface/transformers/blob/v5.2.0/src/transformers/models/qwen3_5_moe/modeling_qwen3_5_moe.py#L823
def patched_qwen3_5_moe_sparse_moe_block(self, hidden_states: torch.Tensor) -> torch.Tensor:
    num_experts = self.experts.num_experts
    batch_size, sequence_length, hidden_dim = hidden_states.shape
    hidden_states = hidden_states.view(-1, hidden_dim)

    # router returns (logits, scores, indices)
    _, routing_weights, selected_experts = self.gate(hidden_states)

    new_routing_weights = torch.zeros(batch_size * sequence_length, num_experts, dtype=routing_weights.dtype)
    new_routing_weights.scatter_(dim=1, index=selected_experts, src=routing_weights)

    shared_expert_output = self.shared_expert(hidden_states)
    shared_expert_output = torch.sigmoid(self.shared_expert_gate(hidden_states)) * shared_expert_output

    hidden_states = hidden_states.repeat(num_experts, 1)
    hidden_states = hidden_states.view(num_experts, -1, hidden_dim)
    act_fn = self.experts.act_fn

    # compute experts outputs in a vectorized form using torch.bmm
    gate_proj, up_proj = self.experts.gate_up_proj.chunk(2, dim=-2)
    gate = torch.bmm(hidden_states, gate_proj.transpose(1, 2))
    up = torch.bmm(hidden_states, up_proj.transpose(1, 2))
    gate_up = act_fn(gate) * up
    next_states = torch.bmm(gate_up, self.experts.down_proj.transpose(1, 2))
    next_states = next_states.view(num_experts, batch_size, -1, hidden_dim)
    next_states = next_states * new_routing_weights.transpose(0, 1).view(num_experts, batch_size, -1)[..., None]
    next_states = next_states.sum(dim=0)

    shared_expert_output = shared_expert_output.view(batch_size, -1, hidden_dim)
    output = shared_expert_output + next_states
    return output.view(batch_size, sequence_length, hidden_dim)


class Qwen3_5MoeModelPatcher(Qwen3_5ModelPatcher):
    def __init__(
        self,
        config: "OpenVINOConfig",
        model: "PreTrainedModel",
        model_kwargs: Optional[Dict[str, Any]] = None,
    ):
        super().__init__(config, model, model_kwargs)

    def __enter__(self):
        from transformers.models.qwen3_5_moe.modeling_qwen3_5_moe import Qwen3_5MoeSparseMoeBlock

        super().__enter__()
        for decoder_layer in self._text_model.layers:
            if isinstance(decoder_layer.mlp, Qwen3_5MoeSparseMoeBlock):
                sparse_moe_block = decoder_layer.mlp
                sparse_moe_block._orig_forward = sparse_moe_block.forward
                sparse_moe_block.forward = types.MethodType(patched_qwen3_5_moe_sparse_moe_block, sparse_moe_block)

    def __exit__(self, exc_type, exc_value, traceback):
        from transformers.models.qwen3_5_moe.modeling_qwen3_5_moe import Qwen3_5MoeSparseMoeBlock

        super().__exit__(exc_type, exc_value, traceback)
        for decoder_layer in self._text_model.layers:
            if isinstance(decoder_layer.mlp, Qwen3_5MoeSparseMoeBlock):
                sparse_moe_block = decoder_layer.mlp
                sparse_moe_block.forward = sparse_moe_block._orig_forward


class Qwen3_5MoeMTPModule(nn.Module):
    """
    Standalone PyTorch module wrapping the MTP head weights from Qwen3.5-MoE
    (e.g. Qwen3.6-35B-A3B) for independent OpenVINO export.

    Unlike the dense Qwen3.5 MTP, this variant uses a MoE decoder layer with
    sparse experts in the MLP.
    """

    __module__ = "transformers.models.qwen3_5_moe"

    def __init__(self, text_config):
        super().__init__()
        from transformers.models.qwen3_5_moe.modeling_qwen3_5_moe import (
            Qwen3_5MoeDecoderLayer,
            Qwen3_5MoeRMSNorm,
            Qwen3_5MoeTextConfig,
            Qwen3_5MoeTextRotaryEmbedding,
        )

        self.config = text_config
        hidden_size = text_config.hidden_size

        # MTP-specific layers
        self.pre_fc_norm_embedding = Qwen3_5MoeRMSNorm(hidden_size, eps=text_config.rms_norm_eps)
        self.pre_fc_norm_hidden = Qwen3_5MoeRMSNorm(hidden_size, eps=text_config.rms_norm_eps)
        self.fc = nn.Linear(hidden_size * 2, hidden_size, bias=False)

        # Single decoder layer (full attention + MoE MLP)
        mtp_config = Qwen3_5MoeTextConfig(
            vocab_size=text_config.vocab_size,
            hidden_size=text_config.hidden_size,
            moe_intermediate_size=text_config.moe_intermediate_size,
            shared_expert_intermediate_size=text_config.shared_expert_intermediate_size,
            num_hidden_layers=1,
            num_attention_heads=text_config.num_attention_heads,
            num_key_value_heads=text_config.num_key_value_heads,
            hidden_act=text_config.hidden_act,
            max_position_embeddings=text_config.max_position_embeddings,
            rms_norm_eps=text_config.rms_norm_eps,
            attention_bias=getattr(text_config, "attention_bias", False),
            head_dim=text_config.head_dim,
            rope_parameters=text_config.rope_parameters,
            layer_types=["full_attention"],
            num_experts=text_config.num_experts,
            num_experts_per_tok=text_config.num_experts_per_tok,
        )
        self.layers = nn.ModuleList([Qwen3_5MoeDecoderLayer(mtp_config, layer_idx=0)])
        self.rotary_emb = Qwen3_5MoeTextRotaryEmbedding(mtp_config)

        # Final norm
        self.norm = Qwen3_5MoeRMSNorm(hidden_size, eps=text_config.rms_norm_eps)

    @classmethod
    def from_pretrained_model(cls, model):
        """Create MoE MTP module and load weights from the full model checkpoint."""
        config = model.config
        text_config = getattr(config, "text_config", config)
        mtp_module = cls(text_config)

        # Load MTP-specific weights (transformers ignores 'mtp.*' keys on load).
        _load_mtp_weights(mtp_module, model)

        # Override model_type so patch_stateful uses standard decoder path
        mtp_module.config = copy.deepcopy(text_config)
        mtp_module.config.model_type = "qwen3_5_mtp"
        return mtp_module

    forward = _qwen3_5_mtp_module_forward


class Qwen3_5MoeMTPModelPatcher(Qwen3_5MTPModelPatcher):
    """MTP model patcher for MoE variant — patches the MoE sparse block in the MTP decoder layer."""

    def __init__(
        self,
        config: "OpenVINOConfig",
        model: "PreTrainedModel",
        model_kwargs: Optional[Dict[str, Any]] = None,
    ):
        super().__init__(config, model, model_kwargs)

    def __enter__(self):
        from transformers.models.qwen3_5_moe.modeling_qwen3_5_moe import Qwen3_5MoeSparseMoeBlock

        super().__enter__()
        for decoder_layer in self._model.layers:
            if isinstance(decoder_layer.mlp, Qwen3_5MoeSparseMoeBlock):
                sparse_moe_block = decoder_layer.mlp
                sparse_moe_block._orig_forward = sparse_moe_block.forward
                sparse_moe_block.forward = types.MethodType(patched_qwen3_5_moe_sparse_moe_block, sparse_moe_block)

    def __exit__(self, exc_type, exc_value, traceback):
        from transformers.models.qwen3_5_moe.modeling_qwen3_5_moe import Qwen3_5MoeSparseMoeBlock

        super().__exit__(exc_type, exc_value, traceback)
        for decoder_layer in self._model.layers:
            if isinstance(decoder_layer.mlp, Qwen3_5MoeSparseMoeBlock):
                sparse_moe_block = decoder_layer.mlp
                sparse_moe_block.forward = sparse_moe_block._orig_forward


class Qwen3ASRModelPatcher(OVSeq2SeqModelPatcher):
    """
    Model patcher for Qwen3-ASR encoder-decoder export.

    For encoder: patches the audio tower forward to use standard attention (no cu_seqlens/chunking).
    For decoder: patches forward to accept encoder_outputs/decoder_input_ids and map them to the thinker's interface.
    """

    def __init__(
        self,
        config: "OpenVINOConfig",
        model: "PreTrainedModel",
        model_kwargs: Optional[Dict[str, Any]] = None,
    ):
        super().__init__(config, model, model_kwargs)

    def __enter__(self):
        super().__enter__()

        if self.real_config._behavior == "encoder":
            self._patch_audio_encoder()
        elif self.real_config._behavior == "decoder":
            self._patch_decoder()

    def _patch_audio_encoder(self):
        """
        Patch audio encoder forward for OV-compatible tracing.
        Removes dynamic chunking and cu_seqlens-based attention.
        Patches attention layers to work with batched 3D inputs.
        """
        encoder = self._model
        # Force eager attention to avoid cu_seqlens dependency
        encoder.config._attn_implementation = "eager"
        for layer in encoder.layers:
            layer.self_attn.config._attn_implementation = "eager"

            # Patch each attention layer to accept 3D batched input (batch, seq, dim)
            attn = layer.self_attn
            attn._orig_forward = attn.forward

            def make_patched_attn_forward(attn_module):
                # Original code: https://github.com/QwenLM/Qwen3-ASR/blob/c17a131fe028b2e428b6e80a33d30bb4fa57b8df/qwen_asr/core/transformers_backend/modeling_qwen3_asr.py#L477
                def patched_attn_forward(hidden_states, cu_seqlens=None, attention_mask=None, **kwargs):
                    # hidden_states: (batch, seq_len, dim) - standard 3D batched
                    bsz, seq_length, _ = hidden_states.size()

                    query_states = (
                        attn_module.q_proj(hidden_states)
                        .reshape(bsz, seq_length, attn_module.num_heads, -1)
                        .transpose(1, 2)
                    )
                    key_states = (
                        attn_module.k_proj(hidden_states)
                        .reshape(bsz, seq_length, attn_module.num_heads, -1)
                        .transpose(1, 2)
                    )
                    value_states = (
                        attn_module.v_proj(hidden_states)
                        .reshape(bsz, seq_length, attn_module.num_heads, -1)
                        .transpose(1, 2)
                    )

                    attn_weights = torch.matmul(query_states, key_states.transpose(2, 3)) * attn_module.scaling
                    attn_weights = torch.nn.functional.softmax(attn_weights, dim=-1, dtype=torch.float32).to(
                        query_states.dtype
                    )

                    attn_output = torch.matmul(attn_weights, value_states)
                    attn_output = attn_output.transpose(1, 2).contiguous().reshape(bsz, seq_length, -1)
                    attn_output = attn_module.out_proj(attn_output)
                    return attn_output

                return patched_attn_forward

            attn.forward = make_patched_attn_forward(attn)

            # Patch each encoder layer to accept 3D input and skip cu_seqlens
            layer._orig_forward = layer.forward

            def make_patched_layer_forward(enc_layer):
                # Original code:https://github.com/QwenLM/Qwen3-ASR/blob/c17a131fe028b2e428b6e80a33d30bb4fa57b8df/qwen_asr/core/transformers_backend/modeling_qwen3_asr.py#L536
                def patched_layer_forward(hidden_states, cu_seqlens=None, attention_mask=None, **kwargs):
                    residual = hidden_states
                    hidden_states = enc_layer.self_attn_layer_norm(hidden_states)
                    hidden_states = enc_layer.self_attn(hidden_states=hidden_states, attention_mask=attention_mask)
                    hidden_states = residual + hidden_states
                    residual = hidden_states
                    hidden_states = enc_layer.final_layer_norm(hidden_states)
                    hidden_states = enc_layer.fc1(hidden_states)
                    hidden_states = enc_layer.activation_fn(hidden_states)
                    hidden_states = enc_layer.fc2(hidden_states)
                    hidden_states = residual + hidden_states
                    return (hidden_states,)

                return patched_layer_forward

            layer.forward = make_patched_layer_forward(layer)

        # Save original forward
        encoder._orig_forward = encoder.forward

        # Original code: https://github.com/QwenLM/Qwen3-ASR/blob/c17a131fe028b2e428b6e80a33d30bb4fa57b8df/qwen_asr/core/transformers_backend/modeling_qwen3_asr.py#L669
        def patched_audio_forward(input_features, feature_lens=None, aftercnn_lens=None, **kwargs):
            """
            Simplified audio encoder forward for OV export.
            Processes audio input without dynamic chunking.

            input_features: (batch_size, num_mel_bins, seq_len) or (num_mel_bins, seq_len)
            """
            # Ensure input is batched: (batch, num_mel, seq_len)
            if input_features.dim() == 2:
                input_features = input_features.unsqueeze(0)

            # Apply convolutions: conv2d expects (batch, 1, num_mel, seq_len)
            x = input_features.unsqueeze(1)  # (batch, 1, num_mel, seq_len)
            x = F.gelu(encoder.conv2d1(x))
            x = F.gelu(encoder.conv2d2(x))
            x = F.gelu(encoder.conv2d3(x))

            b, c, f, t = x.size()
            x = encoder.conv_out(x.permute(0, 3, 1, 2).contiguous().view(b, t, c * f))

            # Add positional embeddings
            pos_emb = encoder.positional_embedding.positional_embedding[:t, :].unsqueeze(0).to(x.dtype)
            hidden_states = x + pos_emb  # (batch, t, hidden_dim)

            # Process through patched encoder layers with standard 3D batched attention
            for encoder_layer in encoder.layers:
                layer_outputs = encoder_layer(hidden_states)
                hidden_states = layer_outputs[0]

            hidden_states = encoder.ln_post(hidden_states)
            hidden_states = encoder.proj1(hidden_states)
            hidden_states = encoder.act(hidden_states)
            hidden_states = encoder.proj2(hidden_states)

            return BaseModelOutput(last_hidden_state=hidden_states)

        encoder.forward = patched_audio_forward

    def _patch_decoder(self):
        """
        Patch full model forward for decoder export.
        Maps seq2seq inputs (encoder_outputs, decoder_input_ids) to the thinker's interface.
        Returns a flat tuple of tensors (logits + KV cache) for TorchScript tracing compatibility.
        """
        model = self._model
        thinker = model.thinker

        # Force eager attention for text model
        thinker.config.text_config._attn_implementation = "eager"

        # Save original forward
        model._orig_forward = model.forward

        # Original code: https://github.com/QwenLM/Qwen3-ASR/blob/c17a131fe028b2e428b6e80a33d30bb4fa57b8df/qwen_asr/core/transformers_backend/modeling_qwen3_asr.py#L1159
        def patched_decoder_forward(
            encoder_outputs=None,
            decoder_input_ids=None,
            attention_mask=None,
            past_key_values=None,
            cache_position=None,
            **kwargs,
        ):
            """
            Decoder forward that accepts seq2seq-style inputs.
            encoder_outputs: pre-computed audio features from encoder (batch, enc_seq_len, hidden_dim)
            decoder_input_ids: text token ids (batch, dec_seq_len)
            Returns a flat tuple: (logits, k0, v0, k1, v1, ...) for TorchScript compatibility.
            """
            # Convert past_key_values from legacy list format to DynamicCache
            if past_key_values is not None and isinstance(past_key_values, (list, tuple)):
                cache = DynamicCache()
                for layer_past in past_key_values:
                    if len(layer_past) >= 2:
                        cache.update(layer_past[0], layer_past[1], len(cache))
                past_key_values = cache
            elif past_key_values is None:
                # Pre-create DynamicCache so that thinker.model uses it even during
                # torch.jit.trace (the model skips cache creation when tracing).
                past_key_values = DynamicCache()

            input_ids = decoder_input_ids
            inputs_embeds = thinker.get_input_embeddings()(input_ids)

            # Merge audio features from encoder into embeddings at audio placeholder positions
            if encoder_outputs is not None:
                if isinstance(encoder_outputs, (tuple, list)):
                    encoder_hidden_states = encoder_outputs[0]
                else:
                    encoder_hidden_states = encoder_outputs
                # Flatten encoder outputs: (total_audio_tokens, hidden_dim)
                audio_features = encoder_hidden_states.reshape(-1, encoder_hidden_states.shape[-1])
                audio_features = audio_features.to(inputs_embeds.device, inputs_embeds.dtype)

                # Use cumsum-based indexing + torch.where for OV-friendly dynamic shapes
                special_audio_mask = input_ids == thinker.config.audio_token_id  # [batch, seq]
                # cumsum gives 1-based index of audio tokens; subtract 1 for 0-based
                audio_cumsum = special_audio_mask.long().cumsum(dim=-1) - 1  # [batch, seq]
                # Clamp to valid range for gather (non-audio positions will be masked out anyway)
                audio_cumsum = audio_cumsum.clamp(min=0)
                # Expand to [batch, seq, hidden] by gathering from audio_features
                gather_indices = audio_cumsum.unsqueeze(-1).expand(
                    -1, -1, inputs_embeds.shape[-1]
                )  # [batch, seq, hidden]
                # audio_features is [total_audio_tokens, hidden], expand for batch gather
                audio_features_expanded = audio_features.unsqueeze(0).expand(
                    inputs_embeds.shape[0], -1, -1
                )  # [batch, total, hidden]
                gathered_audio = torch.gather(audio_features_expanded, 1, gather_indices)  # [batch, seq, hidden]
                # Use where to select: audio feature at audio positions, original embed elsewhere
                mask_3d = special_audio_mask.unsqueeze(-1)  # [batch, seq, 1]
                inputs_embeds = torch.where(mask_3d, gathered_audio, inputs_embeds)

            # Compute position_ids
            position_ids = None
            if attention_mask is not None:
                if (
                    cache_position is None
                    or (cache_position is not None and cache_position[0] == 0)
                    or thinker.rope_deltas is None
                ):
                    delta0 = (1 - attention_mask).sum(dim=-1).unsqueeze(1)
                    position_ids, rope_deltas = thinker.get_rope_index(attention_mask)
                    rope_deltas = rope_deltas - delta0
                    thinker.rope_deltas = rope_deltas
                else:
                    batch_size, seq_length = input_ids.shape
                    delta = cache_position[0] + thinker.rope_deltas
                    position_ids = torch.arange(seq_length, device=input_ids.device)
                    position_ids = position_ids.view(1, -1).expand(batch_size, -1)
                    position_ids = position_ids.add(delta)
                    position_ids = position_ids.unsqueeze(0).expand(3, -1, -1)

            outputs = thinker.model(
                attention_mask=attention_mask,
                position_ids=position_ids,
                past_key_values=past_key_values,
                inputs_embeds=inputs_embeds,
                use_cache=True,
                cache_position=cache_position,
            )

            logits = thinker.lm_head(outputs[0])

            past_kv = outputs.past_key_values
            # Convert DynamicCache to flat tuple of tensors for TorchScript tracing
            # Output format: (logits, k0, v0, k1, v1, ...)
            flat_output = [logits]
            if isinstance(past_kv, DynamicCache):
                for layer in past_kv.layers:
                    flat_output.append(layer.keys)
                    flat_output.append(layer.values)
            elif past_kv is not None:
                legacy = past_kv if isinstance(past_kv, (list, tuple)) else past_kv.to_legacy_cache()
                for layer_kv in legacy:
                    flat_output.append(layer_kv[0])
                    flat_output.append(layer_kv[1])

            return tuple(flat_output)

        model.forward = patched_decoder_forward

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)

        if hasattr(self._model, "_orig_forward"):
            self._model.forward = self._model._orig_forward
            del self._model._orig_forward


class FunASRModelPatcher(OVSeq2SeqModelPatcher):
    """
    Model patcher for FunASR (e.g. Fun-ASR-Nano) encoder-decoder export.

    Encoder: SenseVoice audio encoder + adaptor. All frames are assumed valid (no masking)
    because funasr's native mask ops use .tolist() which bakes trace-time constants.

    Decoder: a standard Qwen3 LLM. The audio embeddings produced by the encoder are spliced into the
    decoder input embeddings at audio placeholder positions (token id == audio_token_id, which is 0
    for FunASR), then the Qwen3 LM runs with self-attention KV cache only (no cross-attention).
    """

    def __enter__(self):
        super().__enter__()

        if self.real_config._behavior == "encoder":
            self._patch_audio_encoder()
        elif self.real_config._behavior == "decoder":
            self._patch_decoder()

    def _patch_audio_encoder(self):
        # self._model is the _FunASRAudioEncoder wrapper (audio_encoder + audio_adaptor)
        encoder_wrap = self._model
        sense_voice = encoder_wrap.audio_encoder
        adaptor = encoder_wrap.audio_adaptor

        # Patch SANM encoder self-attention layers to skip masking during trace.
        # The native mask computation uses `lengths.tolist()` which bakes trace-time values as constants,
        # making the graph incompatible with different sequence lengths at inference time.
        self._sanm_layers = list(sense_voice.encoders0) + list(sense_voice.encoders) + list(sense_voice.tp_encoders)
        self._adaptor_blocks = getattr(adaptor, "blocks", None)

        def _sanm_forward_no_mask(self, x, mask=None, mask_shfit_chunk=None, mask_att_chunk_encoder=None):
            return self._orig_forward(x, mask=None, mask_shfit_chunk=None, mask_att_chunk_encoder=None)

        for layer in self._sanm_layers:
            attn = layer.self_attn
            attn._orig_forward = attn.forward
            attn.forward = types.MethodType(_sanm_forward_no_mask, attn)

        # Patch adaptor transformer attention layers similarly.
        def _adaptor_forward_no_mask(self, query, key, value, mask=None):
            return self._orig_forward(query, key, value, mask=None)

        if self._adaptor_blocks is not None:
            for block in self._adaptor_blocks:
                attn = block.self_attn
                attn._orig_forward = attn.forward
                attn.forward = types.MethodType(_adaptor_forward_no_mask, attn)

        encoder_wrap._orig_forward = encoder_wrap.forward

        def patched_encoder_forward(input_features):
            speech_lengths = torch.tensor([input_features.shape[1]] * input_features.shape[0], dtype=torch.int32)
            encoder_out, encoder_out_lens = sense_voice(input_features, speech_lengths)
            adaptor_out, _ = adaptor(encoder_out, encoder_out_lens)
            return BaseModelOutput(last_hidden_state=adaptor_out)

        encoder_wrap.forward = patched_encoder_forward

    def _patch_decoder(self):
        # self._model is the _FunASRForSpeechSeq2Seq wrapper
        model = self._model
        self._llm = model.llm
        llm = self._llm
        audio_token_id = getattr(model.config, "audio_token_id", 0)

        # Force eager attention for stable OpenVINO tracing.
        self._orig_attn_implementation = llm.config._attn_implementation
        llm.set_attn_implementation("eager")

        model._orig_forward = model.forward

        def patched_decoder_forward(
            encoder_outputs=None,
            decoder_input_ids=None,
            attention_mask=None,
            past_key_values=None,
            cache_position=None,
            **kwargs,
        ):
            if past_key_values is not None and isinstance(past_key_values, (list, tuple)):
                cache = DynamicCache()
                for layer_past in past_key_values:
                    if len(layer_past) >= 2:
                        cache.update(layer_past[0], layer_past[1], len(cache))
                past_key_values = cache
            elif past_key_values is None:
                past_key_values = DynamicCache()

            input_ids = decoder_input_ids
            inputs_embeds = llm.get_input_embeddings()(input_ids)

            # Splice audio embeddings into placeholder positions (token id == audio_token_id).
            if encoder_outputs is not None:
                if isinstance(encoder_outputs, (tuple, list)):
                    encoder_hidden_states = encoder_outputs[0]
                else:
                    encoder_hidden_states = encoder_outputs
                audio_features = encoder_hidden_states.reshape(-1, encoder_hidden_states.shape[-1])
                audio_features = audio_features.to(inputs_embeds.device, inputs_embeds.dtype)

                special_audio_mask = input_ids == audio_token_id  # [batch, seq]
                audio_cumsum = special_audio_mask.long().cumsum(dim=-1) - 1
                audio_cumsum = audio_cumsum.clamp(min=0)
                gather_indices = audio_cumsum.unsqueeze(-1).expand(-1, -1, inputs_embeds.shape[-1])
                audio_features_expanded = audio_features.unsqueeze(0).expand(inputs_embeds.shape[0], -1, -1)
                gathered_audio = torch.gather(audio_features_expanded, 1, gather_indices)
                mask_3d = special_audio_mask.unsqueeze(-1)
                inputs_embeds = torch.where(mask_3d, gathered_audio, inputs_embeds)

            outputs = llm.model(
                attention_mask=attention_mask,
                past_key_values=past_key_values,
                inputs_embeds=inputs_embeds,
                use_cache=True,
                cache_position=cache_position,
            )

            logits = llm.lm_head(outputs[0])

            past_kv = outputs.past_key_values
            flat_output = [logits]
            if isinstance(past_kv, DynamicCache):
                for layer in past_kv.layers:
                    flat_output.append(layer.keys)
                    flat_output.append(layer.values)
            elif past_kv is not None:
                legacy = past_kv if isinstance(past_kv, (list, tuple)) else past_kv.to_legacy_cache()
                for layer_kv in legacy:
                    flat_output.append(layer_kv[0])
                    flat_output.append(layer_kv[1])

            return tuple(flat_output)

        model.forward = patched_decoder_forward

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)

        if hasattr(self._model, "_orig_forward"):
            self._model.forward = self._model._orig_forward
            del self._model._orig_forward

        # Restore attention implementation on the LLM.
        if getattr(self, "_llm", None) is not None and getattr(self, "_orig_attn_implementation", None) is not None:
            self._llm.set_attn_implementation(self._orig_attn_implementation)

        # Unpatch SANM and adaptor attention layers.
        if getattr(self, "_sanm_layers", None) is not None:
            for layer in self._sanm_layers:
                attn = layer.self_attn
                if hasattr(attn, "_orig_forward"):
                    attn.forward = attn._orig_forward
                    del attn._orig_forward

        if getattr(self, "_adaptor_blocks", None) is not None:
            for block in self._adaptor_blocks:
                attn = block.self_attn
                if hasattr(attn, "_orig_forward"):
                    attn.forward = attn._orig_forward
                    del attn._orig_forward


class KokoroModelPatcher(ModelPatcher):
    """
    Patches the Kokoro TTS model for OpenVINO export by redirecting forward
    to forward_with_tokens, which takes (input_ids, ref_s, speed) and returns
    (audio_waveform, phonemes).
    """

    def __enter__(self):
        super().__enter__()
        self._model._orig_forward = self._model.forward
        self._model.forward = self._model.forward_with_tokens

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)
        self._model.forward = self._model._orig_forward


def _ltx2_connector_forward_patched(self, hidden_states, attention_mask=None, attn_mask_binarize_threshold=-9000.0):
    """
    Patched forward for LTX2ConnectorTransformer1d.

    Original does boolean-mask indexing `hidden_states[i, mask[i].bool(), :]`, whose output
    length depends on mask values and cannot be traced. Rewritten with fixed-shape sort +
    gather + arange mask (valid tokens left, registers right).

    Reference (diffusers==0.38.0): pipelines/ltx2/connectors.py,
    LTX2ConnectorTransformer1d.forward L279-330 (data-dependent indexing at L304).
    """
    batch_size, seq_len, hidden_dim = hidden_states.shape

    if self.learnable_registers is not None:
        if attention_mask is None:
            raise ValueError("attention_mask is required when learnable_registers are present")
        num_register_repeats = seq_len // self.num_learnable_registers
        registers = torch.tile(self.learnable_registers, (num_register_repeats, 1))  # [seq_len, dim]
        registers = registers.unsqueeze(0).expand(batch_size, -1, -1)  # [B, seq_len, dim]

        binary_attn_mask = (attention_mask >= attn_mask_binarize_threshold).to(torch.int64)
        if binary_attn_mask.ndim == 4:
            binary_attn_mask = binary_attn_mask.squeeze(1).squeeze(1)  # [B, L]

        # Sort mask descending to left-align valid tokens (preserving relative order via stable sort)
        _, sort_indices = binary_attn_mask.sort(dim=1, descending=True, stable=True)
        gather_indices = sort_indices.unsqueeze(-1).expand(-1, -1, hidden_dim)
        padded_hidden_states = torch.gather(hidden_states, dim=1, index=gather_indices)  # [B, L, D] valid left-aligned

        # Create mask: 1s for valid token positions (left), 0s for register positions (right)
        valid_counts = binary_attn_mask.sum(dim=1)  # [B]
        pos_indices = torch.arange(seq_len, device=hidden_states.device).unsqueeze(0)
        valid_mask = (
            (pos_indices < valid_counts.unsqueeze(1)).unsqueeze(-1).to(padded_hidden_states.dtype)
        )  # [B, L, 1]

        # Valid tokens at left positions, registers at right positions (matches original behavior)
        hidden_states = valid_mask * padded_hidden_states + (1 - valid_mask) * registers

        attention_mask = torch.zeros_like(attention_mask)

    rotary_emb = self.rope(batch_size, seq_len, device=hidden_states.device)

    for block in self.transformer_blocks:
        hidden_states = block(hidden_states, attention_mask=attention_mask, rotary_emb=rotary_emb)

    hidden_states = self.norm_out(hidden_states)
    return hidden_states, attention_mask


def _ltx2_connectors_top_level_forward_patched(
    self, text_encoder_hidden_states, attention_mask, padding_side="left", scale_factor=8
):
    """
    Patched top-level forward for LTX2TextConnectors: inlines per_layer_masked_mean_norm
    (masked_fill/arange/amin/amax, all fixed-shape) and hardcodes padding_side="left" so the
    connectors stack traces cleanly as a single graph.

    Reference (diffusers==0.38.0): pipelines/ltx2/connectors.py,
    LTX2TextConnectors.forward L397-476 and per_layer_masked_mean_norm L14-78.
    """
    if text_encoder_hidden_states.ndim == 3:
        text_encoder_hidden_states = text_encoder_hidden_states.unflatten(2, (self.config.caption_channels, -1))

    if self.config.get("per_modality_projections", False):
        import math

        from diffusers.pipelines.ltx2.connectors import per_token_rms_norm

        norm_text_encoder_hidden_states = per_token_rms_norm(text_encoder_hidden_states)
        norm_text_encoder_hidden_states = norm_text_encoder_hidden_states.flatten(2, 3)
        bool_mask = attention_mask.bool().unsqueeze(-1)
        norm_text_encoder_hidden_states = torch.where(
            bool_mask, norm_text_encoder_hidden_states, torch.zeros_like(norm_text_encoder_hidden_states)
        )
        video_scale_factor = math.sqrt(self.config.video_hidden_dim / self.config.caption_channels)
        video_norm_text_emb = norm_text_encoder_hidden_states * video_scale_factor
        audio_scale_factor = math.sqrt(self.config.audio_hidden_dim / self.config.caption_channels)
        audio_norm_text_emb = norm_text_encoder_hidden_states * audio_scale_factor
        video_text_emb_proj = self.video_text_proj_in(video_norm_text_emb)
        audio_text_emb_proj = self.audio_text_proj_in(audio_norm_text_emb)
    else:
        # Traceable version of per_layer_masked_mean_norm
        # text_encoder_hidden_states: [batch, seq, hidden_dim, num_layers]
        # attention_mask: [batch, seq] binary (1=valid, 0=pad)
        eps = 1e-6
        batch_size, seq_len, hidden_dim, num_layers = text_encoder_hidden_states.shape
        original_dtype = text_encoder_hidden_states.dtype

        # Create mask [batch, seq, 1, 1] from binary attention_mask
        mask = attention_mask[:, :, None, None].bool()

        # Compute masked mean
        masked_text_hidden_states = text_encoder_hidden_states.masked_fill(~mask, 0.0)
        num_valid_positions = (attention_mask.sum(dim=-1) * hidden_dim).view(batch_size, 1, 1, 1)
        masked_mean = masked_text_hidden_states.sum(dim=(1, 2), keepdim=True) / (num_valid_positions + eps)

        # Compute min/max
        x_min = text_encoder_hidden_states.masked_fill(~mask, float("inf")).amin(dim=(1, 2), keepdim=True)
        x_max = text_encoder_hidden_states.masked_fill(~mask, float("-inf")).amax(dim=(1, 2), keepdim=True)

        # Normalize
        normalized_hidden_states = (text_encoder_hidden_states - masked_mean) / (x_max - x_min + eps)
        normalized_hidden_states = normalized_hidden_states * scale_factor

        # Pack to 3D
        normalized_hidden_states = normalized_hidden_states.flatten(2)
        mask_flat = mask.squeeze(-1).expand(-1, -1, hidden_dim * num_layers)
        normalized_hidden_states = normalized_hidden_states.masked_fill(~mask_flat, 0.0)
        norm_text_encoder_hidden_states = normalized_hidden_states.to(dtype=original_dtype)

        text_emb_proj = self.text_proj_in(norm_text_encoder_hidden_states)
        video_text_emb_proj = text_emb_proj
        audio_text_emb_proj = text_emb_proj

    # Convert to additive attention mask for sub-connectors
    text_dtype = video_text_emb_proj.dtype
    add_attn_mask = (attention_mask.to(torch.int64) - 1).to(text_dtype)
    add_attn_mask = add_attn_mask.reshape(attention_mask.shape[0], 1, 1, attention_mask.shape[-1])
    add_attn_mask = add_attn_mask * torch.finfo(text_dtype).max

    video_text_embedding, video_attn_mask = self.video_connector(video_text_emb_proj, add_attn_mask)

    # Convert video attn mask to binary
    binary_attn_mask = (video_attn_mask < 1e-6).to(torch.int64)
    binary_attn_mask = binary_attn_mask.reshape(video_text_embedding.shape[0], video_text_embedding.shape[1], 1)
    video_text_embedding = video_text_embedding * binary_attn_mask

    audio_text_embedding, _ = self.audio_connector(audio_text_emb_proj, add_attn_mask)

    return video_text_embedding, audio_text_embedding, binary_attn_mask.squeeze(-1)


class LTX2ConnectorsPatcher(ModelPatcher):
    """
    Export patcher for LTX2TextConnectors: swaps in the trace-safe top-level and
    sub-connector forwards for the duration of the export, and monkey-patches
    apply_split_rotary_emb (module-level) to an out-of-place implementation so RoPE
    traces cleanly. Native SDPA attention (LTX2AudioVideoAttnProcessor) is left untouched.
    """

    def __enter__(self):
        super().__enter__()

        # Patch the top-level forward of LTX2TextConnectors
        self._model._orig_forward = self._model.forward
        self._model.forward = types.MethodType(_ltx2_connectors_top_level_forward_patched, self._model)

        # Patch both video_connector and audio_connector
        for connector_name in ["video_connector", "audio_connector"]:
            connector = getattr(self._model, connector_name, None)
            if connector is not None:
                connector._orig_forward = connector.forward
                connector.forward = types.MethodType(_ltx2_connector_forward_patched, connector)

        # Patch apply_split_rotary_emb at module level: the original does an in-place
        # addcmul_ on tensor views, which traces to ScatterNDUpdate in OpenVINO. Swap in
        # the out-of-place version; LTX2AudioVideoAttnProcessor picks it up via module-level
        # name lookup, so native SDPA attention needs no changes.
        self._orig_apply_split_rotary_emb = transformer_ltx2.apply_split_rotary_emb
        transformer_ltx2.apply_split_rotary_emb = _ltx2_apply_split_rotary_emb

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)

        # Restore top-level forward
        if hasattr(self._model, "_orig_forward"):
            self._model.forward = self._model._orig_forward

        for connector_name in ["video_connector", "audio_connector"]:
            connector = getattr(self._model, connector_name, None)
            if connector is not None and hasattr(connector, "_orig_forward"):
                connector.forward = connector._orig_forward

        # Restore original apply_split_rotary_emb
        if hasattr(self, "_orig_apply_split_rotary_emb"):
            transformer_ltx2.apply_split_rotary_emb = self._orig_apply_split_rotary_emb


def _ltx2_apply_split_rotary_emb(x, freqs):
    """
    Patched apply_split_rotary_emb. Original does in-place `addcmul_` on views of a slice
    (first_out/second_out), which produces an incorrect/unstable trace. Rewritten with pure
    out-of-place ops.

    Reference (diffusers==0.38.0): models/transformers/transformer_ltx2.py,
    apply_split_rotary_emb L46-84 (in-place addcmul_ on views at L75-76).
    """
    cos, sin = freqs
    x_dtype = x.dtype

    if x.ndim == 3 and cos.ndim == 4:
        b, h, t, _ = cos.shape
        x = x.reshape(b, t, h, -1).swapaxes(1, 2)
        needs_reshape = True
    else:
        needs_reshape = False

    last = x.shape[-1]
    r = last // 2

    split_x = x.reshape(*x.shape[:-1], 2, r).float()
    first_x = split_x[..., :1, :]
    second_x = split_x[..., 1:, :]

    cos_u = cos.unsqueeze(-2)
    sin_u = sin.unsqueeze(-2)

    first_out = first_x * cos_u - sin_u * second_x
    second_out = second_x * cos_u + sin_u * first_x

    out = torch.cat([first_out, second_out], dim=-2).reshape(*split_x.shape[:-2], last)

    if needs_reshape:
        out = out.swapaxes(1, 2).reshape(b, t, -1)

    out = out.to(dtype=x_dtype)
    return out


class _LTX2TraceSafeAttnProcessor:
    """
    Transformer attention processor made trace-safe: replaces `prepare_attention_mask`
    (data-dependent branches) and SDPA with a fixed-shape mask reshape + manual attention,
    and uses the out-of-place RoPE above instead of the in-place `addcmul_` original.

    Reference (diffusers==0.38.0): models/transformers/transformer_ltx2.py,
    LTX2AudioVideoAttnProcessor.__call__ L161-228 (prepare_attention_mask at L175).
    """

    def __call__(
        self,
        attn,
        hidden_states,
        encoder_hidden_states=None,
        attention_mask=None,
        query_rotary_emb=None,
        key_rotary_emb=None,
    ):
        # Use trace-safe RoPE — original has in-place addcmul_ on views which can break tracing
        apply_rotary = _ltx2_apply_split_rotary_emb

        batch_size, sequence_length, _ = (
            hidden_states.shape if encoder_hidden_states is None else encoder_hidden_states.shape
        )

        if attention_mask is not None:
            # Trace-safe: reshape mask to [batch, heads, 1, seq_len] without data-dependent branches.
            # Incoming mask is [batch, 1, seq_len] (additive bias from transformer forward).
            # Simply expand to heads dimension — no padding or repeat_interleave needed.
            attention_mask = attention_mask.unsqueeze(1)  # [batch, 1, 1, seq_len]

        if encoder_hidden_states is None:
            encoder_hidden_states = hidden_states

        if attn.to_gate_logits is not None:
            gate_logits = attn.to_gate_logits(hidden_states)

        query = attn.to_q(hidden_states)
        key = attn.to_k(encoder_hidden_states)
        value = attn.to_v(encoder_hidden_states)

        query = attn.norm_q(query)
        key = attn.norm_k(key)

        if query_rotary_emb is not None:
            query = apply_rotary(query, query_rotary_emb)
            key = apply_rotary(key, key_rotary_emb if key_rotary_emb is not None else query_rotary_emb)

        query = query.unflatten(2, (attn.heads, -1))
        key = key.unflatten(2, (attn.heads, -1))
        value = value.unflatten(2, (attn.heads, -1))

        # Manual attention with epsilon (avoids SDPA op in IR)
        query = query.transpose(1, 2)
        key = key.transpose(1, 2)
        value = value.transpose(1, 2)

        scale = 1.0 / (query.shape[-1] ** 0.5)
        attn_weights = torch.matmul(query, key.transpose(-2, -1)) * scale

        if attention_mask is not None:
            attn_weights = attn_weights + attention_mask

        attn_weights = torch.nn.functional.softmax(attn_weights, dim=-1)

        eps = 1e-30
        hidden_states = torch.matmul(attn_weights + eps, value)

        hidden_states = hidden_states.transpose(1, 2).flatten(2, 3)
        hidden_states = hidden_states.to(query.dtype)

        if attn.to_gate_logits is not None:
            hidden_states = hidden_states.unflatten(2, (attn.heads, -1))
            gates = 2.0 * torch.sigmoid(gate_logits)
            hidden_states = hidden_states * gates.unsqueeze(-1)
            hidden_states = hidden_states.flatten(2, 3)

        hidden_states = attn.to_out[0](hidden_states)
        hidden_states = attn.to_out[1](hidden_states)
        return hidden_states


class LTX2TextEncoderPatcher(ModelPatcher):
    """
    Export patcher for the text encoder. Forces output_hidden_states, builds an explicit
    causal mask (the connectors consume every hidden-state layer), and returns a flat dict so
    each `hidden_states.{i}` becomes a named export output.
    """

    def __init__(self, config, model, model_kwargs=None):
        model.config.output_hidden_states = True
        super().__init__(config, model, model_kwargs)

        orig_forward = self.orig_forward

        def patched_forward(input_ids, attention_mask=None, **kwargs):
            if attention_mask is not None and attention_mask.dim() == 2:
                bsz, seq_len = attention_mask.shape
                causal_mask = attention_mask[:, None, None, :].to(dtype=torch.float32)
                causal_mask = causal_mask.expand(bsz, 1, seq_len, seq_len).clone()
                causal_positions = torch.tril(
                    torch.ones(seq_len, seq_len, dtype=torch.float32, device=attention_mask.device)
                )
                causal_mask = causal_mask * causal_positions[None, None, :, :]
                causal_mask = (1.0 - causal_mask) * torch.finfo(torch.float32).min
                attention_mask = {"full_attention": causal_mask, "sliding_attention": causal_mask}
            outputs = orig_forward(input_ids=input_ids, attention_mask=attention_mask, output_hidden_states=True)
            result = {"last_hidden_state": outputs.hidden_states[-1]}
            for i, hs in enumerate(outputs.hidden_states):
                result[f"hidden_states.{i}"] = hs
            return result

        self.patched_forward = patched_forward


class LTX2TransformerPatcher(ModelPatcher):
    """
    Export patcher for the LTX2 transformer: installs the trace-safe attention processor and
    wraps forward to force return_dict=False and emit a named-output dict.
    """

    def __enter__(self):
        super().__enter__()

        # Replace attention processors with trace-safe version
        # (original prepare_attention_mask has data-dependent branches that break tracing)
        self._orig_processors = {}
        for name, module in self._model.named_modules():
            if hasattr(module, "processor") and hasattr(module, "set_processor"):
                self._orig_processors[name] = module.processor
                module.set_processor(_LTX2TraceSafeAttnProcessor())

        # Wrap forward to return dict (needed for output naming) and force return_dict=False internally
        self._orig_model_forward = self._model.forward

        import functools

        @functools.wraps(self._orig_model_forward)
        def patched_forward(
            hidden_states,
            audio_hidden_states,
            encoder_hidden_states,
            audio_encoder_hidden_states,
            timestep,
            encoder_attention_mask=None,
            audio_encoder_attention_mask=None,
            num_frames=None,
            height=None,
            width=None,
            fps=24.0,
            audio_num_frames=None,
            video_coords=None,
            audio_coords=None,
            **kwargs,
        ):
            result = self._orig_model_forward(
                hidden_states=hidden_states,
                audio_hidden_states=audio_hidden_states,
                encoder_hidden_states=encoder_hidden_states,
                audio_encoder_hidden_states=audio_encoder_hidden_states,
                timestep=timestep,
                encoder_attention_mask=encoder_attention_mask,
                audio_encoder_attention_mask=audio_encoder_attention_mask,
                num_frames=num_frames,
                height=height,
                width=width,
                fps=fps,
                audio_num_frames=audio_num_frames,
                video_coords=video_coords,
                audio_coords=audio_coords,
                return_dict=False,
                **kwargs,
            )
            if isinstance(result, tuple):
                return {"out_sample": result[0], "audio_out_sample": result[1]}
            return result

        self._model.forward = patched_forward

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)
        self._model.forward = self._orig_model_forward

        # Restore original attention processors
        for name, module in self._model.named_modules():
            if name in self._orig_processors and hasattr(module, "set_processor"):
                module.set_processor(self._orig_processors[name])


# ------------------------------------------------------------------------------
# MuseGlimmer (native transformers VLM) export patchers.
#
# The native MuseGlimmer model already applies rotary embeddings with real-valued
# cos/sin tensors (``apply_rotary_pos_emb`` / ``apply_rotary_pos_emb_vision``), so
# unlike the earlier flat trust_remote_code "onyx" model there is no complex-RoPE
# to work around. The language patcher only rewires the forward to consume
# ``inputs_embeds`` + a legacy KV tuple for the stateful text-generation export.
# The vision patcher reimplements the encoder over ``pixel_values`` plus the
# grid-derived tensors (attention masks, window reordering, rotary position ids,
# bilinear position gathers and the pixel-shuffle permutation) passed as inputs,
# so the graph is resolution-agnostic and free of the untraceable grid ops.
# ------------------------------------------------------------------------------
class MuseGlimmerVisionEmbeddingsModelPatcher(ModelPatcher):
    """Export the native MuseGlimmer vision stack as one resolution-agnostic graph.

    Reimplements ``vision_tower`` -> ``vision_adapter`` -> ``vision_projection`` ->
    ``perception_emb_norm`` consuming only ``pixel_values`` and ``image_grid_thw``.
    All grid-derived tensors (attention masks, rotary position ids, bilinear
    position gathers, pixel-shuffle permutation) are recomputed *inside* the graph
    from ``image_grid_thw`` with pure tensor arithmetic, so no ``.tolist()`` /
    ``int()`` / dynamic-reshape ops bake the resolution and no extra inputs are
    needed. Window attention is expressed as a block-diagonal equality mask in the
    original patch order (equivalent to the native reorder-attend-reverse) so the
    untraceable window-index gather is avoided.
    """

    def __init__(self, config, model, model_kwargs=None):
        from transformers.models.muse_glimmer.modeling_muse_glimmer import apply_rotary_pos_emb_vision

        output_names = list(config.outputs.keys())

        def _vision_attention(attn, hidden_states, attention_mask, position_embeddings):
            seq_length = hidden_states.shape[0]
            query_states = attn.q_proj(hidden_states).reshape(1, seq_length, -1, attn.head_dim)
            key_states = attn.k_proj(hidden_states).reshape(1, seq_length, -1, attn.head_dim)
            value_states = attn.v_proj(hidden_states).reshape(1, seq_length, -1, attn.head_dim)

            cos, sin = position_embeddings
            query_states, key_states = apply_rotary_pos_emb_vision(query_states, key_states, cos, sin)

            query_states = query_states.transpose(2, 1)
            key_states = key_states.transpose(2, 1)
            value_states = value_states.transpose(2, 1)

            attn_weights = torch.matmul(query_states, key_states.transpose(-1, -2)) * attn.scaling
            attn_weights = attn_weights + attention_mask.to(attn_weights.dtype)
            attn_weights = torch.nn.functional.softmax(attn_weights, dim=-1, dtype=torch.float32).to(
                query_states.dtype
            )
            attn_output = torch.matmul(attn_weights, value_states)
            attn_output = attn_output.transpose(2, 1).reshape(seq_length, -1)
            return attn.proj(attn_output)

        model.__orig_forward = model.forward

        def image_embed_forward(self, pixel_values, image_grid_thw):
            vision_model = self.model
            vision_tower = vision_model.vision_tower
            patch_embedder = vision_tower.patch_embedder
            cfg = vision_tower.config
            device = pixel_values.device

            # --- per-patch grid coordinates (vectorised over all images/frames) ---
            grid = image_grid_thw
            counts = grid[:, 0] * grid[:, 1] * grid[:, 2]
            per_h = torch.repeat_interleave(grid[:, 1], counts)
            per_w = torch.repeat_interleave(grid[:, 2], counts)
            img_start = torch.repeat_interleave(torch.nn.functional.pad(counts.cumsum(0)[:-1], (1, 0)), counts)
            seq_len = pixel_values.shape[0]
            ar = torch.arange(seq_len, device=device)
            within = ar - img_start
            hw = per_h * per_w
            frame = within // hw
            within_frame = within - frame * hw
            row = within_frame // per_w
            col = within_frame - row * per_w
            # absolute start index of this patch's (image, frame) segment -> unique full-attn id
            seg_id = img_start + frame * hw
            window = cfg.pos_emb_height  # window size in patches (spatial_merge_size == 1)
            win_r = row // window
            win_c = col // window

            # --- learned position-embedding bilinear resample (raster order) ---
            # Native uses a custom grid_sample(align_corners=False, padding="zeros")
            # equivalent: half-pixel sample centres + zeroed out-of-bounds corners.
            side = patch_embedder.num_grid_per_side
            h_grid = (row.float() + 0.5) * (side / per_h.float()) - 0.5
            w_grid = (col.float() + 0.5) * (side / per_w.float()) - 0.5
            h_floor = torch.floor(h_grid)
            w_floor = torch.floor(w_grid)
            h_ceil = h_floor + 1
            w_ceil = w_floor + 1
            h_frac = h_grid - h_floor
            w_frac = w_grid - w_floor
            h_fv = (h_floor >= 0) & (h_floor <= side - 1)
            h_cv = (h_ceil >= 0) & (h_ceil <= side - 1)
            w_fv = (w_floor >= 0) & (w_floor <= side - 1)
            w_cv = (w_ceil >= 0) & (w_ceil <= side - 1)
            h_fl = h_floor.clamp(0, side - 1).long()
            h_cl = h_ceil.clamp(0, side - 1).long()
            w_fl = w_floor.clamp(0, side - 1).long()
            w_cl = w_ceil.clamp(0, side - 1).long()
            bilinear_indices = torch.stack(
                [h_fl * side + w_fl, h_fl * side + w_cl, h_cl * side + w_fl, h_cl * side + w_cl], dim=1
            )
            bilinear_weights = torch.stack(
                [
                    (1 - h_frac) * (1 - w_frac) * (h_fv & w_fv),
                    (1 - h_frac) * w_frac * (h_fv & w_cv),
                    h_frac * (1 - w_frac) * (h_cv & w_fv),
                    h_frac * w_frac * (h_cv & w_cv),
                ],
                dim=1,
            )

            # --- additive attention masks (block-diagonal, original patch order) ---
            neg = torch.finfo(pixel_values.dtype).min
            same_seg = seg_id[:, None] == seg_id[None, :]
            full_mask = torch.zeros(seq_len, seq_len, dtype=pixel_values.dtype, device=device).masked_fill(
                ~same_seg, neg
            )[None, None]
            same_win = same_seg & (win_r[:, None] == win_r[None, :]) & (win_c[:, None] == win_c[None, :])
            window_mask = torch.zeros(seq_len, seq_len, dtype=pixel_values.dtype, device=device).masked_fill(
                ~same_win, neg
            )[None, None]

            # --- rotary position ids (raster (h, w) flipped + 1, matches native) ---
            position_ids = torch.stack([row, col], dim=-1).flip(-1) + 1
            position_ids = position_ids[None]

            # --- pixel-shuffle gather (merge_size x merge_size block reorder) ---
            factor = cfg.merge_size
            blocks_w = per_w // factor
            ps_in_col = within_frame % factor
            ps_in_row = (within_frame // factor) % factor
            ps_block_col = (within_frame // (factor * factor)) % blocks_w
            ps_block_row = within_frame // (factor * factor * blocks_w)
            ps_src = (ps_block_row * factor + ps_in_row) * per_w + (ps_block_col * factor + ps_in_col)
            pixel_shuffle_index = seg_id + ps_src

            # --- encoder ---
            target_dtype = patch_embedder.patch_embedding.weight.dtype
            patch_embeds = patch_embedder.patch_embedding(pixel_values.to(dtype=target_dtype))
            embeddings = patch_embeds.reshape(seq_len, -1)
            pos_embeds = (
                patch_embedder.position_embedding_table(bilinear_indices) * bilinear_weights[:, :, None]
            ).sum(1)
            hidden_states = embeddings + pos_embeds.to(embeddings.dtype)

            hidden_states = vision_tower.ln_pre(hidden_states)
            position_embeddings = vision_tower.rotary_emb(hidden_states, position_ids)

            layer_types = cfg.layer_types
            for i, block in enumerate(vision_tower.layers):
                mask = full_mask if layer_types[i] == "full_attention" else window_mask
                hidden_states = hidden_states + _vision_attention(
                    block.attn, block.norm1(hidden_states), mask, position_embeddings
                )
                hidden_states = hidden_states + block.mlp(block.norm2(hidden_states))

            hidden_states = vision_tower.ln_post(hidden_states)

            dim = hidden_states.shape[-1]
            hidden_states = hidden_states[pixel_shuffle_index]
            hidden_states = (
                hidden_states.view(-1, factor * factor, dim).permute(0, 2, 1).reshape(-1, dim * factor * factor)
            )

            vision_features = vision_model.vision_adapter(hidden_states)
            vision_features = vision_model.vision_projection(vision_features)
            vision_features = vision_model.perception_emb_norm(vision_features)
            return {output_names[0]: vision_features}

        model.forward = types.MethodType(image_embed_forward, model)
        super().__init__(config, model, model_kwargs)

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)
        self._model.forward = self._model.__orig_forward


class MuseGlimmerLanguageModelPatcher(OVDecoderModelPatcher):
    """Patch the MuseGlimmer language model to consume ``inputs_embeds`` + a legacy
    KV tuple for the stateful text-generation export (native real-valued RoPE)."""

    def __init__(self, config, model, model_kwargs=None):
        model.__orig_forward = model.forward

        def forward_wrap(
            self,
            attention_mask,
            position_ids=None,
            past_key_values=None,
            inputs_embeds=None,
            input_ids=None,
            use_cache=True,
        ):
            if is_transformers_version("<", "5"):
                new_past_key_values = DynamicCache.from_legacy_cache(past_key_values)
            else:
                new_past_key_values = DynamicCache(past_key_values)

            result = self.__orig_forward(
                input_ids=input_ids,
                inputs_embeds=inputs_embeds,
                attention_mask=attention_mask,
                position_ids=position_ids,
                past_key_values=new_past_key_values,
                use_cache=use_cache,
            )
            if past_key_values is not None:
                result["past_key_values"] = postprocess_past_key_values(result["past_key_values"])
            return result

        model.forward = types.MethodType(forward_wrap, model)
        super().__init__(config, model, model_kwargs)

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)
        self._model.forward = self._model.__orig_forward


# Caption sequence length of the dummy input used to trace the ZImage transformer.
# It only sets the shape of the tracing example: caption length is a dynamic dimension
# of the exported model, and at inference _OVZImageTransformerAdapter pads each batch to
# its own longest caption.
ZIMAGE_CAP_SEQ = 128


def _z_image_rope_embedder_call(self, ids: "torch.Tensor"):
    """
    Patched RopeEmbedder.__call__ for OV export.

    Returns a real-valued tensor of shape [seq_len, total_freq, 2]
    where [..., 0] = cos and [..., 1] = sin.
    This avoids complex-tensor indexing which OV cannot convert.
    """
    device = ids.device

    # Lazily precompute real (cos, sin) lookup tables
    if not hasattr(self, "_ov_freqs_cos") or self._ov_freqs_cos is None:
        raw_freqs = self.precompute_freqs_cis(self.axes_dims, self.axes_lens, theta=self.theta)
        self._ov_freqs_cos = [f.real.float() for f in raw_freqs]
        self._ov_freqs_sin = [f.imag.float() for f in raw_freqs]
        self.freqs_cis = raw_freqs  # keep original for non-export use

    # Move to the correct device
    if self._ov_freqs_cos[0].device != device:
        self._ov_freqs_cos = [f.to(device) for f in self._ov_freqs_cos]
        self._ov_freqs_sin = [f.to(device) for f in self._ov_freqs_sin]

    result_cos, result_sin = [], []
    for i in range(len(self.axes_dims)):
        # ids is [..., seq_len, 3]: 2D for a batch-shared grid, 3D when every batch item
        # carries its own position ids. Indexing on the last axis handles both.
        index = ids[..., i]  # [..., seq_len] integer indices
        result_cos.append(self._ov_freqs_cos[i][index])  # [..., seq_len, freq_i] real
        result_sin.append(self._ov_freqs_sin[i][index])  # [..., seq_len, freq_i] real

    cos = torch.cat(result_cos, dim=-1)  # [..., seq_len, total_freq]
    sin = torch.cat(result_sin, dim=-1)  # [..., seq_len, total_freq]
    # Stack as [..., seq_len, total_freq, 2] where last dim = [cos, sin]
    return torch.stack([cos, sin], dim=-1)


def _z_image_attn_proc_call(
    self,
    attn,
    hidden_states: "torch.Tensor",
    encoder_hidden_states=None,
    attention_mask=None,
    freqs_cis=None,
):
    """
    Patched ZSingleStreamAttnProcessor.__call__ for OV export.

    Replaces torch.view_as_complex / view_as_real with real-number RoPE.
    freqs_cis is now [batch, seq_len, head_dim//2, 2] (cos, sin stacked).
    """

    def apply_rotary_emb_real(x_in, freqs_cis_real):
        """Real-number RoPE: avoids view_as_complex/view_as_real."""
        # x_in:          [batch, seq, heads, head_dim]
        # freqs_cis_real:[batch, seq, head_dim//2, 2]  (last dim: [cos, sin])
        cos = freqs_cis_real[..., 0]  # [batch, seq, head_dim//2]
        sin = freqs_cis_real[..., 1]  # [batch, seq, head_dim//2]

        x_float = x_in.float()
        x_pairs = x_float.reshape(*x_float.shape[:-1], -1, 2)  # [batch, seq, heads, head_dim//2, 2]

        # Broadcast cos/sin over the heads dimension
        cos = cos.unsqueeze(2)  # [batch, seq, 1, head_dim//2]
        sin = sin.unsqueeze(2)

        out_real = x_pairs[..., 0] * cos - x_pairs[..., 1] * sin  # [batch, seq, heads, head_dim//2]
        out_imag = x_pairs[..., 0] * sin + x_pairs[..., 1] * cos
        out = torch.stack([out_real, out_imag], dim=-1).flatten(-2)  # [batch, seq, heads, head_dim]
        return out.type_as(x_in)

    query = attn.to_q(hidden_states)
    key = attn.to_k(hidden_states)
    value = attn.to_v(hidden_states)

    query = query.unflatten(-1, (attn.heads, -1))
    key = key.unflatten(-1, (attn.heads, -1))
    value = value.unflatten(-1, (attn.heads, -1))

    if attn.norm_q is not None:
        query = attn.norm_q(query)
    if attn.norm_k is not None:
        key = attn.norm_k(key)

    if freqs_cis is not None:
        query = apply_rotary_emb_real(query, freqs_cis)
        key = apply_rotary_emb_real(key, freqs_cis)

    dtype = query.dtype
    query, key = query.to(dtype), key.to(dtype)

    if attention_mask is not None and attention_mask.ndim == 2:
        attention_mask = attention_mask[:, None, None, :]

    if attention_mask is not None and attention_mask.dtype == torch.bool:
        # Eager-style additive mask: OpenVINO handles a float bias added to the attention
        # scores more predictably than a boolean Select, so convert before SDPA.
        attention_mask = torch.zeros_like(attention_mask, dtype=query.dtype).masked_fill(
            ~attention_mask, torch.finfo(query.dtype).min
        )

    # Standard SDPA
    hidden_states = torch.nn.functional.scaled_dot_product_attention(
        query.transpose(1, 2),
        key.transpose(1, 2),
        value.transpose(1, 2),
        attn_mask=attention_mask.to(query.dtype) if attention_mask is not None else None,
        dropout_p=0.0,
        is_causal=False,
    ).transpose(1, 2)

    hidden_states = hidden_states.flatten(2, 3)
    hidden_states = hidden_states.to(dtype)

    output = attn.to_out[0](hidden_states)
    if len(attn.to_out) > 1:
        output = attn.to_out[1](output)

    return output


def _patched_z_image_batched_forward(
    model,
    hidden_states: "torch.Tensor",
    timestep: "torch.Tensor",
    encoder_hidden_states: "torch.Tensor",
    encoder_attention_mask: "torch.Tensor",
    txt_ids: "torch.Tensor",
    img_ids: "torch.Tensor",
    patch_size: int = 2,
    f_patch_size: int = 1,
):
    """
    Natively batched, resolution-agnostic forward for ZImageTransformer2DModel (non-omni).

    The stock forward is built around Python lists holding one entry per batch item, so it
    bakes both the batch size and the token count into the IR:

        x_seqlens = [len(xi) for xi in x]     # e.g. [1024] — static
        list(x.split(x_seqlens, dim=0))       # VariadicSplit — wrong at any other size

    This rewrite keeps everything as [B, ...] tensors, so batch size, height, width and
    caption length are all dynamic dimensions of the exported model.

    Position ids are inputs rather than something the graph derives, following the same
    design as the Flux export. That is what lets one infer request serve prompts of
    different lengths: upstream offsets the image tokens past the caption
    (``pos_start=(cap_len + 1, 0, 0)``) using each item's own caption length rounded up to
    SEQ_MULTI_OF, so in a ragged batch the *image* position ids differ per item too. A
    graph that computed them from shapes could only ever produce one shared grid.

    Inputs:
      hidden_states          [B, C, H, W]
      timestep               [B]
      encoder_hidden_states  [B, M, cap_dim]  captions batch-padded to M
      encoder_attention_mask [B, M]           eager additive mask over *real* caption
                                              tokens: 0 on a real token, a large negative
                                              value elsewhere
      txt_ids                [B, M, 3]        caption position ids, 1..T_i then 0 past T_i
      img_ids                [B, N, 3]        image position ids, offset by each T_i

    Returns: sample [B, C_out, H, W]

    The two caption padding levels upstream keeps distinct are encoded in these inputs:

      * SEQ_MULTI_OF padding (real length L_i up to the rounded T_i) is *attended*, with
        the embedding replaced by the learned ``cap_pad_token``. Those slots are masked in
        ``encoder_attention_mask`` but carry a non-zero ``txt_ids`` position.
      * batch padding (past T_i, up to M) is masked out of attention entirely. Those slots
        carry position id 0, which is what marks them — real caption positions are 1-based.

    Masks are eager/additive floats (0 to keep, ``finfo.min`` to drop) rather than booleans,
    so the attention bias is a plain add rather than a Select in the exported graph.
    """
    pH = pW = patch_size
    pF = f_patch_size
    key = f"{patch_size}-{f_patch_size}"
    device = hidden_states.device

    # ── Timestep embedding ──────────────────────────────────────────────────────
    adaln_input = model.t_embedder(timestep * model.t_scale).type_as(hidden_states)

    # ── Caption ─────────────────────────────────────────────────────────────────
    # Everything past a real token gets cap_pad_token. For the batch-padded tail that is
    # irrelevant work — those positions are masked out of attention below — but it keeps
    # the SEQ_MULTI_OF slots exactly as upstream sets them without a second mask input.
    cap = model.cap_embedder(encoder_hidden_states)
    cap = torch.where(
        (encoder_attention_mask >= 0).unsqueeze(-1),
        cap,
        model.cap_pad_token.view(1, 1, -1),
    )
    cap_freqs = _z_image_rope_embedder_call(model.rope_embedder, txt_ids)
    # Position id 0 on the first axis marks batch padding; upstream numbers real caption
    # positions from 1. Build the attention bias the same way the input mask is expressed.
    keep = torch.zeros_like(encoder_attention_mask)
    drop = torch.full_like(encoder_attention_mask, torch.finfo(encoder_attention_mask.dtype).min)
    cap_bias = torch.where(txt_ids[..., 0] > 0, keep, drop)
    for layer in model.context_refiner:
        cap = layer(cap, cap_bias, cap_freqs)

    # ── Image: patchify, then pad out to the length img_ids declares ────────────
    x = hidden_states.unsqueeze(2)  # [B, C, H, W] -> [B, C, 1, H, W]
    batch, channels, frames, height, width = x.shape
    f_tokens, h_tokens, w_tokens = frames // pF, height // pH, width // pW

    # "b c (f pf) (h ph) (w pw) -> b (f h w) (pf ph pw c)"
    x = x.reshape(batch, channels, f_tokens, pF, h_tokens, pH, w_tokens, pW)
    x = x.permute(0, 2, 4, 6, 3, 5, 7, 1)
    x = x.reshape(batch, f_tokens * h_tokens * w_tokens, pF * pH * pW * channels)

    # Image tokens are uniform across the batch (one resolution per call), so the padded
    # length and pad mask are shared; only the position ids in img_ids differ per item.
    ori_len = f_tokens * h_tokens * w_tokens
    total_len = img_ids.shape[1]
    idx = torch.arange(total_len, device=device)
    x_pad_mask = idx >= ori_len
    x = x.index_select(1, torch.minimum(idx, idx * 0 + ori_len - 1))

    x = model.all_x_embedder[key](x)
    x = torch.where(x_pad_mask.view(1, -1, 1), model.x_pad_token.view(1, 1, -1), x)
    x_freqs = _z_image_rope_embedder_call(model.rope_embedder, img_ids)
    for layer in model.noise_refiner:
        x = layer(x, None, x_freqs, adaln_input, None, None, None)

    # ── Unified sequence, basic-mode order [x, cap] ─────────────────────────────
    unified = torch.cat([x, cap], dim=1)
    unified_freqs = torch.cat([x_freqs, cap_freqs], dim=1)
    # Image tokens are always attended (bias 0); the caption tail may not be.
    unified_bias = torch.cat([torch.zeros_like(x[..., 0]), cap_bias], dim=1)

    for layer in model.layers:
        unified = layer(unified, unified_bias, unified_freqs, adaln_input, None, None, None)

    unified = model.all_final_layer[key](unified, c=adaln_input)

    # ── Unpatchify: drop the caption tail and the SEQ_MULTI_OF padding ──────────
    tokens = unified.index_select(1, torch.arange(ori_len, device=device))
    # "b (f h w) (pf ph pw c) -> b c (f pf) (h ph) (w pw)"
    out = tokens.reshape(batch, f_tokens, h_tokens, w_tokens, pF, pH, pW, model.out_channels)
    out = out.permute(0, 7, 1, 4, 2, 5, 3, 6)
    out = out.reshape(batch, model.out_channels, frames, height, width)

    return out.squeeze(2)  # [B, C_out, 1, H, W] -> [B, C_out, H, W]


class ZImageTransformerModelPatcher(ModelPatcher):
    """
    Model patcher for ZImageTransformer2DModel OV export (non-omni mode).

    Patches:
    - RopeEmbedder.__call__: returns real [seq, freq, 2] instead of complex, which OV
      cannot represent
    - ZSingleStreamAttnProcessor.__call__: real-number RoPE, avoids view_as_complex
    - ZImageTransformer2DModel.forward: replaced by _patched_z_image_batched_forward,
      a natively batched rewrite that keeps everything as [B, ...] tensors.  The stock
      forward is written around per-item Python lists and bakes both the batch size and
      the token count into the IR:
        x_seqlens = [len(xi) for xi in x]       # burned as static [1024]
        list(x.split(x_seqlens, dim=0))          # VariadicSplit — wrong at other sizes
      The rewrite leaves batch size, height, width and caption length as dynamic
      dimensions of the exported model.

    The attention processor is patched at class level, not on the instance: Python looks
    up special methods such as __call__ on the type, so an instance-level patch is
    ignored.
    """

    def __enter__(self):
        super().__enter__()

        from diffusers.models.transformers.transformer_z_image import ZSingleStreamAttnProcessor as _ZAttnProc

        # 1. Real-valued RoPE in the attention processor (class level — see docstring)
        _ZAttnProc._orig_ov_call = _ZAttnProc.__call__
        _ZAttnProc.__call__ = _z_image_attn_proc_call

        # 2. Replace forward with the batched, resolution-agnostic implementation
        #    hidden_states:          [B, C, H, W]   (the frame dim is added internally)
        #    timestep:               [B]
        #    encoder_hidden_states:  [B, seq_len, cap_feat_dim]
        #    encoder_attention_mask: [B, seq_len]
        #    txt_ids:                [B, seq_len, 3]
        #    img_ids:                [B, img_seq_len, 3]
        _model_ref = self._model

        def patched_forward(hidden_states, timestep, encoder_hidden_states, encoder_attention_mask, txt_ids, img_ids):
            return _patched_z_image_batched_forward(
                _model_ref, hidden_states, timestep, encoder_hidden_states, encoder_attention_mask, txt_ids, img_ids
            )

        self._model.forward = patched_forward

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)

        # Restore ZSingleStreamAttnProcessor class-level patch
        try:
            from diffusers.models.transformers.transformer_z_image import ZSingleStreamAttnProcessor as _ZAttnProc

            if hasattr(_ZAttnProc, "_orig_ov_call"):
                _ZAttnProc.__call__ = _ZAttnProc._orig_ov_call
                del _ZAttnProc._orig_ov_call
        except ImportError:
            pass

        # Forward is restored by the base ModelPatcher via the _orig_forward mechanism.
        # No model methods are patched: _patched_z_image_batched_forward reimplements
        # patchify / pad / unpatchify inline rather than overriding them.


class ZImageTextEncoderModelPatcher(ModelPatcher):
    """
    Model patcher for the Qwen3-based text encoder used in ZImagePipeline.

    The pipeline uses hidden_states[-2] from the Qwen3 model as text features.
    This patcher wraps forward to return hidden_states[-2] directly as the
    last_hidden_state output so it matches the CLIPText export interface.
    """

    def __init__(
        self,
        config: "OpenVINOConfig",
        model: "PreTrainedModel",
        model_kwargs=None,
    ):
        super().__init__(config, model, model_kwargs)
        _orig_forward = self.orig_forward

        @functools.wraps(_orig_forward)
        def patched_forward(input_ids, attention_mask):
            out = _orig_forward(
                input_ids=input_ids,
                attention_mask=attention_mask,
                output_hidden_states=True,
            )
            # Return second-to-last hidden state as the text features
            # (ZImagePipeline uses prompt_embeds[i][prompt_masks[i]] from hidden_states[-2])
            # Must return a dict so ts_patched_forward can call .values() on it.
            return {"last_hidden_state": out.hidden_states[-2]}

        self.patched_forward = patched_forward

    def __enter__(self):
        super().__enter__()
        # Ensure SDPA is used for tracing (avoids boolean mask issues with eager mode)
        if hasattr(self._model, "config") and hasattr(self._model.config, "_attn_implementation"):
            self._model.config._orig_ov_attn_impl = self._model.config._attn_implementation
            self._model.config._attn_implementation = "sdpa"

    def __exit__(self, exc_type, exc_value, traceback):
        super().__exit__(exc_type, exc_value, traceback)
        if hasattr(self._model, "config") and hasattr(self._model.config, "_orig_ov_attn_impl"):
            self._model.config._attn_implementation = self._model.config._orig_ov_attn_impl
            del self._model.config._orig_ov_attn_impl
