import base64
import copy
import enum
import hashlib
import importlib
import inspect
import io
import logging
import math
import os
import shutil
import sys
import threading
import types
import warnings
from abc import abstractmethod
from collections import OrderedDict
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Tuple, Union

import numpy as np
import openvino
import openvino as ov
import torch
from huggingface_hub import hf_hub_download, snapshot_download
from huggingface_hub.constants import HUGGINGFACE_HUB_CACHE
from huggingface_hub.utils import EntryNotFoundError
from openvino._offline_transformations import apply_moc_transformations, compress_model_transformation
from transformers import (
    AutoConfig,
    AutoImageProcessor,
    AutoModel,
    AutoModelForImageTextToText,
    GenerationConfig,
    GenerationMixin,
    PretrainedConfig,
    PreTrainedTokenizer,
)
from transformers.modeling_outputs import BaseModelOutputWithPooling
from transformers.models.qwen2_5_vl.modeling_qwen2_5_vl import Qwen2_5_VLModel
from transformers.models.qwen2_vl.modeling_qwen2_vl import Qwen2VLModel, VisionRotaryEmbedding
from transformers.utils import ModelOutput

from optimum.exporters.openvino import main_export
from optimum.exporters.openvino.stateful import ensure_stateful_is_available, model_has_input_output_name
from optimum.exporters.openvino.utils import save_config
from optimum.intel.openvino.configuration import OVConfig, OVQuantizationConfigBase, OVWeightQuantizationConfig
from optimum.intel.openvino.modeling_base import OVBaseModel, OVModelPart
from optimum.intel.openvino.modeling_decoder import CausalLMOutputWithPast, OVModelForCausalLM
from optimum.intel.openvino.utils import (
    OV_LANGUAGE_MODEL_NAME,
    OV_TEXT_EMBEDDINGS_MODEL_NAME,
    OV_VISION_EMBEDDINGS_MODEL_NAME,
    TemporaryDirectory,
    classproperty,
)
from optimum.intel.utils.import_utils import is_transformers_version


if is_transformers_version(">=", "4.57"):
    from transformers.models.qwen3_omni_moe.processing_qwen3_omni_moe import _get_feat_extract_output_lengths
    from transformers.models.qwen3_vl.modeling_qwen3_vl import (
        Qwen3VLModel,
        Qwen3VLVisionModel,
        Qwen3VLVisionRotaryEmbedding,
    )


if is_transformers_version(">=", "5.0.0"):
    from transformers import AutoModelForMultimodalLM

    transformers_auto_class = AutoModelForMultimodalLM
else:
    transformers_auto_class = AutoModelForImageTextToText


if is_transformers_version(">=", "5.2"):
    from transformers.models.qwen3_5.modeling_qwen3_5 import (
        Qwen3_5Model,
        Qwen3_5VisionModel,
        Qwen3_5VisionRotaryEmbedding,
    )


if TYPE_CHECKING:
    from PIL.Image import Image
    from transformers.image_utils import VideoInput

logger = logging.getLogger(__name__)

core = ov.Core()


class InputMode(enum.Enum):
    LANGUAGE = 0
    VISION = 1
    SPEECH = 2
    VISION_SPEECH = 3


class OVModelWithEmbedForCausalLM(OVModelForCausalLM):
    def __init__(
        self,
        model: ov.Model,
        text_embeds_model: ov.Model,
        config: PretrainedConfig = None,
        device: str = "CPU",
        dynamic_shapes: bool = None,
        ov_config: Optional[Dict[str, str]] = None,
        model_save_dir: Optional[Union[str, Path, TemporaryDirectory]] = None,
        quantization_config: Optional[Union[OVWeightQuantizationConfig, Dict]] = None,
        **kwargs,
    ):
        self.model = model
        self.text_emb_model = text_embeds_model
        self.request = None
        self.text_emb_request = None
        compile_only = kwargs.get("compile_only", False)
        if compile_only:
            self.text_emb_request = self.text_emb_model
            self.request = self.model.create_infer_request()

        super().__init__(
            model=model,
            config=config,
            device=device,
            dynamic_shapes=dynamic_shapes,
            ov_config=ov_config,
            model_save_dir=model_save_dir,
            quantization_config=quantization_config,
            **kwargs,
        )

    @property
    def _ov_model_names(self) -> List[str]:
        return ["model", "text_emb_model"]

    def compile(self):
        if self.request is None:
            logger.info(f"Compiling the Language model to {self._device} ...")
            super().compile()
        self._compile_text_emb()

    def _compile_text_emb(self):
        if self.text_emb_request is None:
            logger.info(f"Compiling the Text embeddings model to {self._device} ...")
            if self._compile_only:
                self.text_emb_request = self.text_emb_model
            else:
                logger.info(f"Compiling the Text embeddings model to {self._device} ...")
                self.text_emb_request = self._compile_model(
                    self.text_emb_model, self._device, self.ov_config, self.model_save_dir
                )

    def clear_requests(self):
        if self._compile_only:
            raise ValueError(
                "`clear_requests()` is not supported with `compile_only` mode, please initialize model without this option"
            )
        self.request = None
        self.text_emb_request = None

    def embed_tokens(self, input_ids: torch.LongTensor):
        self._compile_text_emb()
        res = self.text_emb_request(input_ids, share_inputs=True)
        return res[0]

    def prepare_inputs(
        self,
        input_ids: torch.LongTensor,
        attention_mask: Optional[torch.LongTensor] = None,
        past_key_values: Optional[Tuple[Tuple[torch.FloatTensor]]] = None,
        position_ids: Optional[torch.LongTensor] = None,
        inputs_embeds: Optional[torch.FloatTensor] = None,
        token_type_ids: Optional[torch.LongTensor] = None,
        visual_pos_masks: Optional[torch.FloatTensor] = None,
        deepstack_visual_embeds: Optional[torch.FloatTensor] = None,
        **kwargs,
    ):
        if input_ids is None and inputs_embeds is None:
            raise ValueError("Either `input_ids` or `inputs_embeds` must be provided.")
        batch_size = input_ids.shape[0] if input_ids is not None else inputs_embeds.shape[0]

        inputs = {}
        # past_key_values are not used explicitly, instead they are handled inside the model
        if past_key_values is None:
            # This is the first iteration in a sequence, reset all states
            if self.request is not None:
                self.request.reset_state()
                # Set initial value for the next beam_idx input that will be used at the current iteration
                # and will be optionally updated by _reorder_cache at the next iterations if beam_search is used
                self.next_beam_idx = np.arange(batch_size, dtype=int)
                self._past_length = 0
        past_len = self._get_past_length(past_key_values)

        if inputs_embeds is None:
            inputs_embeds = self.embed_tokens(input_ids if past_key_values is None else input_ids[:, -1:])

            if hasattr(self.config, "scale_emb"):
                inputs_embeds = inputs_embeds * self.config.scale_emb
        inputs["inputs_embeds"] = inputs_embeds

        # Add the attention_mask inputs when needed
        if "attention_mask" in self.input_names or "position_ids" in self.input_names:
            if attention_mask is not None:
                attention_mask = attention_mask.cpu().numpy()
            else:
                attention_mask = np.ones((inputs_embeds.shape[0], inputs_embeds.shape[1] + past_len), dtype=int)

        if "attention_mask" in self.input_names:
            inputs["attention_mask"] = attention_mask

        if "position_ids" in self.input_names:
            if position_ids is not None:
                position_ids = position_ids.cpu().numpy()
            else:
                position_ids = np.cumsum(attention_mask, axis=1) - 1
                position_ids[attention_mask == 0] = 1
            if past_len:
                position_ids = position_ids[..., -inputs_embeds.shape[1] :]

            if self.config.model_type in ["qwen3_5", "qwen3_5_moe"] and position_ids.ndim != 3:
                position_ids = np.repeat(np.expand_dims(position_ids, 0), 4, axis=0)
            elif (self.config.model_type in ["qwen2_vl", "qwen2_5_vl", "qwen3_vl"]) and position_ids.ndim == 2:
                # Qwen2-VL and Qwen3-VL use 3D mrope (3 spatial dimensions)
                position_ids = np.repeat(np.expand_dims(position_ids, 0), 3, axis=0)
            elif self.config.model_type == "qwen3_omni_moe" and position_ids.ndim == 2:
                # Qwen3-Omni uses 4D mrope (temporal + 3 spatial dimensions)
                position_ids = np.repeat(np.expand_dims(position_ids, 0), 4, axis=0)

            inputs["position_ids"] = position_ids

        if "visual_pos_masks" in self.input_names:
            if visual_pos_masks is not None:
                inputs["visual_pos_masks"] = visual_pos_masks
            else:
                # Placeholder mask when no visual tokens present; shape must match inputs_embeds for traced deepstack ops.
                seq_len = inputs_embeds.shape[1] if inputs_embeds is not None else 1
                inputs["visual_pos_masks"] = torch.zeros(batch_size, seq_len, dtype=torch.bool)

        if "deepstack_visual_embeds" in self.input_names:
            if deepstack_visual_embeds is not None:
                inputs["deepstack_visual_embeds"] = torch.Tensor(deepstack_visual_embeds)
            else:
                thinker_cfg = getattr(self.config, "thinker_config", self.config)
                vision_cfg = getattr(thinker_cfg, "vision_config", self.config)
                text_cfg = getattr(thinker_cfg, "text_config", self.config)
                num_layers = len(vision_cfg.deepstack_visual_indexes)
                emb_dim = text_cfg.hidden_size
                # Placeholder deepstack tensor; count must match batch*seq_len for the traced cumsum/gather ops.
                seq_len = inputs_embeds.shape[1] if inputs_embeds is not None else 1
                inputs["deepstack_visual_embeds"] = torch.zeros(
                    (num_layers, batch_size * seq_len, emb_dim), dtype=torch.float32
                )

        if "token_type_ids" in self.input_names:
            if token_type_ids is None:
                token_type_ids = np.zeros(inputs_embeds.shape[:2], dtype=int)
            inputs["token_type_ids"] = token_type_ids

        if "beam_idx" in self.input_names:
            inputs["beam_idx"] = (
                self.next_beam_idx if self.next_beam_idx is not None else np.arange(batch_size, dtype=int)
            )

        if "per_layer_inputs" in self.input_names:
            per_layer_inputs = kwargs.pop("per_layer_inputs", None)
            if per_layer_inputs is None:
                raise ValueError("Expected 'per_layer_inputs', but it was not passed")
            inputs["per_layer_inputs"] = torch.Tensor(per_layer_inputs)

        return inputs

    def forward(
        self,
        input_ids: torch.LongTensor,
        attention_mask: Optional[torch.LongTensor] = None,
        past_key_values: Optional[Tuple[Tuple[torch.FloatTensor]]] = None,
        position_ids: Optional[torch.LongTensor] = None,
        inputs_embeds: Optional[torch.LongTensor] = None,
        visual_pos_masks: Optional[torch.FloatTensor] = None,
        deepstack_visual_embeds: Optional[torch.FloatTensor] = None,
        **kwargs,
    ):
        self.compile()
        inputs = self.prepare_inputs(
            input_ids=input_ids,
            attention_mask=attention_mask,
            past_key_values=past_key_values,
            position_ids=position_ids,
            inputs_embeds=inputs_embeds,
            visual_pos_masks=visual_pos_masks,
            deepstack_visual_embeds=deepstack_visual_embeds,
            **kwargs,
        )
        self.request.start_async(inputs, share_inputs=True)
        self.request.wait()
        logits = self.request.get_tensor("logits").data
        logits = torch.from_numpy(logits).clone().to(self.device)
        past_key_values = ((),)
        self._past_length += inputs["inputs_embeds"].shape[1]

        collecting = getattr(self, "_collecting_hidden_states", False)
        hidden_states_out = None
        if collecting and "hidden_states" in self.output_names:
            hs = self.request.get_tensor("hidden_states").data
            hidden_states_out = torch.from_numpy(hs).clone().to(self.device)
        intermediate_hidden = None
        if collecting and "intermediate_hidden_states" in self.output_names:
            ihs = self.request.get_tensor("intermediate_hidden_states").data
            intermediate_hidden = torch.from_numpy(ihs).clone().to(self.device)

        result = CausalLMOutputWithPast(logits=logits, past_key_values=past_key_values)
        result.last_hidden_state = hidden_states_out
        result.intermediate_hidden_state = intermediate_hidden
        return result


class OVVisionEmbedding(OVModelPart):
    _model_name = "vision_embeddings"

    def __init__(self, model: ov.Model, parent_model: OVBaseModel) -> None:
        super().__init__(model, parent_model, model_name=self._model_name)
        self.output_dtypes = {key.get_any_name(): key.get_element_type().get_type_name() for key in self.model.outputs}
        self.output_names = {key.get_any_name(): idx for idx, key in enumerate(self.model.outputs)}
        self.input_names = {key.get_any_name(): idx for idx, key in enumerate(self.model.inputs)}
        self.hidden_states_output_names = []
        if len(self.model.outputs) > 2:
            self.hidden_states_output_names = [
                key.get_any_name() for key in self.model.outputs[2:] if "hidden_states" in key.get_any_name()
            ]
        self.input_names = {key.get_any_name(): idx for idx, key in enumerate(self.model.inputs)}
        if model_has_input_output_name(self.model, "images"):
            self._main_input = "images"
        elif model_has_input_output_name(self.model, "hidden_states"):
            self._main_input = "hidden_states"
        else:
            self._main_input = "pixel_values"

    def forward(self, pixel_values, **kwargs):
        self.compile()
        inputs = {self._main_input: pixel_values}
        if len(self.input_names) > 1:
            for name in self.input_names:
                if name in kwargs:
                    inputs[name] = kwargs[name]
        result = self.request(inputs)
        last_hidden_state = result[0]
        hidden_states = None
        pooler_out = None
        if len(result) > 1:
            pooler_out = result[1]
            if self.hidden_states_output_names:
                hidden_states = []
                for out in self.hidden_states_output_names:
                    hidden_states.append(result[out])
        return BaseModelOutputWithPooling(
            pooler_output=pooler_out, last_hidden_state=last_hidden_state, hidden_states=hidden_states
        )


class OVResampler(OVModelPart):
    _model_name = "resampler"

    def __init__(self, model: ov.Model, parent_model: OVBaseModel) -> None:
        super().__init__(model, parent_model, model_name=self._model_name)
        self.output_dtypes = {key.get_any_name(): key.get_element_type().get_type_name() for key in self.model.outputs}
        self.output_names = {key.get_any_name(): idx for idx, key in enumerate(self.model.outputs)}

    def forward(self, image_feature, pos_embed, key_padding_mask):
        self.compile()
        result = self.request(
            {"image_feature": image_feature, "pos_embed": pos_embed, "key_padding_mask": key_padding_mask}
        )[0]
        return result


class OVVisionProjection(OVModelPart):
    _model_name = "vision_projection"

    def forward(self, img_features):
        self.compile()
        return self.request(img_features)[0]


class OVVisionResampler(OVVisionProjection):
    _model_name = "vision_resampler"


class OVMultiModalProjector(OVVisionProjection):
    _model_name = "multi_modal_projector"


class OVMTPModel(OVModelPart):
    """
    Wrapper for the stateful MTP (Multi-Token Prediction) head submodel.

    Registering the MTP head as a model part makes it visible to `_ov_model_names`,
    so it is loaded, saved and — importantly — weight-compressed together with the
    other submodels (e.g. by `optimum-cli export openvino --weight-format int4`).
    """

    _model_name = "mtp"

    def forward(self, **kwargs):
        self.compile()
        inputs = {name: kwargs[name] for name in self.input_names if name in kwargs}
        return self.request(inputs)


class OVAudioEmbeddings(OVModelPart):
    _model_name = "audio_embeddings"

    def forward(self, audio_signal):
        self.compile()
        return self.request(audio_signal)[0]


class OVAudioEncoder(OVModelPart):
    _model_name = "audio_encoder"

    def forward(self, *args, **kwargs):
        self.compile()
        if args:
            input_names = list(self.input_names.keys())
            inputs = {input_names[i]: arg for i, arg in enumerate(args)}
        else:
            inputs = {k: v for k, v in kwargs.items() if k in self.input_names}
        return self.request(inputs)[0]


class OVTalkerDecoder(OVModelPart):
    """Qwen3-Omni Talker decoder with stateful past for audio generation."""

    _model_name = "talker"

    def __init__(self, model: ov.Model, parent_model: OVBaseModel) -> None:
        super().__init__(model, parent_model, model_name=self._model_name)
        self.next_beam_idx = None
        self._past_length = 0
        self._infer_request = None

    def compile(self):
        super().compile()
        if self._infer_request is None and self.request is not None:
            compiled = self.request if isinstance(self.request, ov.CompiledModel) else None
            if compiled is not None:
                self._infer_request = compiled.create_infer_request()
            else:
                self._infer_request = self.request

    def forward(
        self,
        inputs_embeds: torch.FloatTensor,
        attention_mask: Optional[torch.LongTensor] = None,
        past_key_values: Optional[Tuple] = None,
        position_ids: Optional[torch.LongTensor] = None,
        **kwargs,
    ):
        self.compile()
        if self._infer_request is None:
            raise ValueError("Talker model not loaded or compilation failed. Cannot generate audio.")
        batch_size = inputs_embeds.shape[0]

        inputs = {}
        if past_key_values is None:
            self._infer_request.reset_state()
            self.next_beam_idx = np.arange(batch_size, dtype=int)
            self._past_length = 0

        past_len = self._past_length
        inputs["inputs_embeds"] = inputs_embeds

        if attention_mask is not None:
            inputs["attention_mask"] = np.array(attention_mask)
        else:
            inputs["attention_mask"] = np.ones((batch_size, inputs_embeds.shape[1] + past_len), dtype=int)

        if position_ids is not None:
            inputs["position_ids"] = np.array(position_ids)
        else:
            attn = inputs["attention_mask"]
            pos = np.cumsum(attn, axis=1) - 1
            pos[attn == 0] = 1
            if past_len:
                pos = pos[:, -inputs_embeds.shape[1] :]
            inputs["position_ids"] = pos

        if "beam_idx" in self.input_names:
            inputs["beam_idx"] = (
                self.next_beam_idx if self.next_beam_idx is not None else np.arange(batch_size, dtype=int)
            )

        self._infer_request.start_async(inputs, share_inputs=True)
        self._infer_request.wait()

        logits = torch.from_numpy(self._infer_request.get_tensor("logits").data).clone()
        hidden_states = torch.from_numpy(self._infer_request.get_tensor("hidden_states").data).clone()
        self._past_length += inputs_embeds.shape[1]

        return logits, hidden_states

    def reset(self):
        if self._infer_request is not None:
            self._infer_request.reset_state()
        self._past_length = 0
        self.next_beam_idx = None


class OVCodePredictorDecoder(OVModelPart):
    """Single-step CodePredictor with stateful KV cache.

    Each call runs one inner generation step and grows the hidden KV state; the Python-side loop
    in `_run_talker_generation` invokes it num_code_groups-1 times, feeding each step's `token_embed`
    back as the next step's input. Sampling stays in-graph (Gumbel-max) so a sampled code can be
    turned into its codec embedding within the same call.
    """

    _model_name = "code_predictor"

    def __init__(self, model: ov.Model, parent_model: OVBaseModel) -> None:
        super().__init__(model, parent_model, model_name=self._model_name)
        self.next_beam_idx = None
        self._past_length = 0
        self._infer_request = None

    def compile(self):
        super().compile()
        if self._infer_request is None and self.request is not None:
            compiled = self.request if isinstance(self.request, ov.CompiledModel) else None
            self._infer_request = compiled.create_infer_request() if compiled is not None else self.request

    def reset(self):
        if self._infer_request is not None:
            self._infer_request.reset_state()
        self._past_length = 0
        self.next_beam_idx = None

    def forward(
        self,
        inputs_embeds: torch.Tensor,
        step: int,
        seed: int,
        temperature: float,
        top_k: int,
        is_prefill: bool = False,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        self.compile()
        if self._infer_request is None:
            raise ValueError("CodePredictor model not loaded or compilation failed.")

        # `is_prefill` marks the first call of a talker step; it resets the KV state so each
        # talker token starts the inner code sequence from scratch.
        if is_prefill:
            self.reset()

        embeds_np = inputs_embeds if isinstance(inputs_embeds, np.ndarray) else inputs_embeds.numpy()
        batch_size, seq_len = embeds_np.shape[0], embeds_np.shape[1]
        if is_prefill:
            self.next_beam_idx = np.arange(batch_size, dtype=int)

        past_len = self._past_length
        attention_mask = np.ones((batch_size, seq_len + past_len), dtype=int)
        position_ids = np.cumsum(attention_mask, axis=1) - 1
        position_ids[attention_mask == 0] = 1
        if past_len:
            position_ids = position_ids[:, -seq_len:]

        inputs = {
            "inputs_embeds": embeds_np,
            "attention_mask": attention_mask,
            "position_ids": position_ids,
            "step": np.array(step, dtype=np.int64),
            "seed": np.array(seed, dtype=np.int64),
            "temperature": np.array(temperature, dtype=np.float32),
            "top_k": np.array(top_k, dtype=np.int64),
        }
        if "beam_idx" in self.input_names:
            inputs["beam_idx"] = (
                self.next_beam_idx if self.next_beam_idx is not None else np.arange(batch_size, dtype=int)
            )

        self._infer_request.start_async(inputs, share_inputs=True)
        self._infer_request.wait()

        code = torch.from_numpy(self._infer_request.get_tensor("code").data).clone()
        token_embed = torch.from_numpy(self._infer_request.get_tensor("token_embed").data).clone()
        self._past_length += seq_len
        return code, token_embed


class OVCode2Wav(OVModelPart):
    """Converts quantized audio codes to waveform output.

    Supports async chunked inference along the time axis: when `chunk_size` is set and the
    incoming codes are longer, the time axis is split into fixed-size windows submitted via
    `start_async` against a pool of infer requests created from the same CompiledModel. When
    `chunk_overlap > 0`, adjacent windows are crossfaded linearly over the overlap region.
    """

    _model_name = "code2wav"

    def __init__(self, model: ov.Model, parent_model: OVBaseModel) -> None:
        super().__init__(model, parent_model, model_name=self._model_name)
        # `chunk_size=None` disables chunking; forward() falls back to a single synchronous call.
        self.chunk_size: Optional[int] = None
        self.chunk_overlap: int = 0
        self._async_infer_requests: List[Any] = []

    def _ensure_infer_pool(self, size: int) -> None:
        if not isinstance(self.request, ov.CompiledModel):
            return
        while len(self._async_infer_requests) < size:
            self._async_infer_requests.append(self.request.create_infer_request())

    @staticmethod
    def _estimate_samples_per_step(codes_dim_t: int, waveform_samples: int) -> int:
        if codes_dim_t <= 0:
            return 0
        return waveform_samples // codes_dim_t

    def _run_single(self, codes_chunk) -> np.ndarray:
        result = self.request({"codes": codes_chunk})
        # Result may be indexed by name or position; the code2wav graph has a single output.
        if isinstance(result, dict):
            return next(iter(result.values()))
        return result[0]

    def _run_chunked(self, codes: torch.Tensor, chunk_size: int, chunk_overlap: int) -> torch.Tensor:
        codes_np = codes.detach().cpu().numpy() if isinstance(codes, torch.Tensor) else np.asarray(codes)
        if codes_np.ndim != 3:
            raise ValueError(f"Expected codes shape (B, G, T); got {codes_np.shape}")
        batch, groups, total_t = codes_np.shape
        if batch != 1:
            raise ValueError(f"Chunked code2wav only supports batch_size=1; got {batch}")
        if chunk_overlap >= chunk_size:
            raise ValueError(f"chunk_overlap ({chunk_overlap}) must be strictly less than chunk_size ({chunk_size})")

        stride = chunk_size - chunk_overlap
        starts = list(range(0, max(total_t - chunk_overlap, 1), stride))
        if starts[-1] + chunk_size < total_t:
            starts.append(total_t - chunk_size) if total_t >= chunk_size else None

        # Cap concurrency to avoid creating many more infer requests than available inference
        # compute; a small fan-out (<=4) covers typical CPU/GPU plugins without oversubscribing.
        self._ensure_infer_pool(min(len(starts), 4))
        pool = self._async_infer_requests or [self.request]

        segments: List[np.ndarray] = []
        for i, start in enumerate(starts):
            end = min(start + chunk_size, total_t)
            chunk = codes_np[:, :, start:end]
            req = pool[i % len(pool)] if pool else None
            if isinstance(req, ov.InferRequest):
                req.start_async({"codes": chunk}, share_inputs=True)
                req.wait()
                seg = req.get_output_tensor(0).data
            else:
                seg = self._run_single(chunk)
            segments.append(np.ascontiguousarray(seg))

        if not segments:
            return torch.zeros(1, 0, dtype=torch.float32)

        # Stitch segments back with a linear crossfade over `chunk_overlap` codes worth of samples.
        # Audio is assumed to be last-dim; we estimate samples-per-code step from the first segment.
        samples_per_step = self._estimate_samples_per_step(chunk_size, segments[0].shape[-1])
        overlap_samples = samples_per_step * chunk_overlap if samples_per_step > 0 else 0

        if overlap_samples <= 0 or len(segments) == 1:
            waveform = np.concatenate(segments, axis=-1)
        else:
            pieces = [segments[0]]
            for seg in segments[1:]:
                prev = pieces[-1]
                if prev.shape[-1] < overlap_samples or seg.shape[-1] < overlap_samples:
                    # Not enough samples to crossfade; fall back to a hard concat.
                    pieces.append(seg)
                    continue
                fade_in = np.linspace(0.0, 1.0, overlap_samples, dtype=seg.dtype)
                fade_out = 1.0 - fade_in
                merged_overlap = prev[..., -overlap_samples:] * fade_out + seg[..., :overlap_samples] * fade_in
                pieces[-1] = prev[..., :-overlap_samples]
                pieces.append(merged_overlap)
                pieces.append(seg[..., overlap_samples:])
            waveform = np.concatenate(pieces, axis=-1)

        return torch.from_numpy(waveform).clone()

    def forward(self, codes: torch.Tensor) -> torch.Tensor:
        self.compile()
        chunk_size = self.chunk_size
        codes_len = codes.shape[-1] if isinstance(codes, torch.Tensor) else np.asarray(codes).shape[-1]
        if chunk_size is None or chunk_size <= 0 or codes_len <= chunk_size:
            return torch.from_numpy(self._run_single(codes)).clone()
        return self._run_chunked(codes, chunk_size, max(0, int(self.chunk_overlap)))


class OVTalkerProjections(OVModelPart):
    """Dual projections for Qwen3-Omni Talker: text and hidden state."""

    _model_name = "talker_projections"

    def __init__(self, model: ov.Model, parent_model: OVBaseModel) -> None:
        super().__init__(model, parent_model, model_name=self._model_name)

    def forward(self, hidden_state: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        self.compile()
        result = self.request({"hidden_state": hidden_state})
        return torch.from_numpy(result[0]).clone(), torch.from_numpy(result[1]).clone()

    def text_projection(self, hidden_state: torch.Tensor) -> torch.Tensor:
        return self.forward(hidden_state)[0]

    def hidden_projection(self, hidden_state: torch.Tensor) -> torch.Tensor:
        return self.forward(hidden_state)[1]


class OVQwen3OmniMoeVisionEmbeddings(OVModelPart):
    _model_name = "vision_embeddings"

    def __init__(self, model: ov.Model, parent_model: OVBaseModel) -> None:
        super().__init__(model, parent_model, model_name=self._model_name)

    def forward(
        self,
        hidden_states,
        pos_embeds,
        attention_mask,
        rotary_pos_emb,
    ):
        self.compile()
        result = self.request(
            {
                "hidden_states": hidden_states,
                "pos_embeds": pos_embeds,
                "attention_mask": attention_mask,
                "rotary_pos_emb": rotary_pos_emb,
            }
        )
        return result[0], result[1]


MODEL_PARTS_CLS_MAPPING = {
    "resampler": OVResampler,
    "language_model": OVModelWithEmbedForCausalLM,
    "text_embeddings_per_layer": OVVisionProjection,
    "vision_embeddings": OVVisionEmbedding,
    "vision_projection": OVVisionProjection,
    "vision_resampler": OVVisionResampler,
    "multi_modal_projector": OVMultiModalProjector,
    "vision_embeddings_merger": OVVisionEmbedding,
    "vision_embeddings_tiles": OVVisionEmbedding,
    "vision_embeddings_pos": OVVisionProjection,
    "audio_embeddings": OVAudioEmbeddings,
    "audio_forward_embeddings": OVAudioEmbeddings,
    "audio_encoder": OVAudioEncoder,
    "audio_vision_projection": OVAudioEmbeddings,
    "audio_speech_projection": OVAudioEmbeddings,
    "talker": OVTalkerDecoder,
    "talker_text_embeddings": OVVisionProjection,
    "talker_projections": OVTalkerProjections,
    "code_predictor": OVCodePredictorDecoder,
    "code2wav": OVCode2Wav,
    "mtp": OVMTPModel,
}


class OVModelForVisualCausalLM(OVBaseModel, GenerationMixin):
    export_feature = "image-text-to-text"
    additional_parts = []
    auto_model_class = AutoModelForImageTextToText

    @classproperty
    def _all_ov_model_paths(cls) -> Dict[str, str]:
        model_paths = {
            "lm_model": OV_LANGUAGE_MODEL_NAME,
            "text_embeddings_model": OV_TEXT_EMBEDDINGS_MODEL_NAME,
            "vision_embeddings_model": OV_VISION_EMBEDDINGS_MODEL_NAME,
        }
        for part in cls.additional_parts:
            model_paths[f"{part}_model"] = f"openvino_{part}_model.xml"
        return model_paths

    def __init__(
        self,
        language_model: ov.Model,
        text_embeddings: ov.Model,
        vision_embeddings: ov.Model,
        config: PretrainedConfig = None,
        device: str = "CPU",
        dynamic_shapes: bool = None,
        ov_config: Optional[Dict[str, str]] = None,
        model_save_dir: Optional[Union[str, Path, TemporaryDirectory]] = None,
        quantization_config: Union[OVWeightQuantizationConfig, Dict] = None,
        **kwargs,
    ):
        if dynamic_shapes is not None:
            logger.warning(
                f"`dynamic_shapes` was set to {dynamic_shapes}, but this value will be ignored as only dynamic shapes are supported."
            )

        self.is_dynamic = True
        self.config = config
        self.use_cache = kwargs.get("use_cache", True)
        self.model_save_dir = model_save_dir
        self._device = device.upper()
        self.ov_config = {} if ov_config is None else {**ov_config}
        self.preprocessors = kwargs.get("preprocessors", [])
        self._supports_cache_class = False
        self.main_input_name = "input_ids"
        self._compile_only = kwargs.get("compile_only", False)
        self.export_feature = kwargs.get("export_feature", "image-text-to-text")

        for part in self.additional_parts:
            setattr(self, f"{part}_model", kwargs.get(part))

        enable_compilation = kwargs.get("compile", True)
        self.generation_config = kwargs.get("generation_config", GenerationConfig.from_model_config(config))
        self._openvino_config = None
        if quantization_config:
            self._openvino_config = OVConfig(quantization_config=quantization_config)
        self._set_ov_config_parameters()
        self.language_model = OVModelWithEmbedForCausalLM(
            language_model,
            text_embeddings,
            config=config,
            device=device,
            ov_config=ov_config,
            model_save_dir=model_save_dir,
            quantization_config=quantization_config,
            compile=self._compile_only or enable_compilation,
            compile_only=self._compile_only,
        )
        self.vision_embeddings = OVVisionEmbedding(vision_embeddings, self)
        for part in self.additional_parts:
            model_part = getattr(self, f"{part}_model", None)
            if model_part is not None:
                model_part = MODEL_PARTS_CLS_MAPPING[part](model_part, self)
            setattr(self, part, model_part)

        if enable_compilation and not self._compile_only:
            self.compile()

        # Avoid warnings when creating a transformers pipeline
        AutoConfig.register(self.base_model_prefix, AutoConfig)
        self.auto_model_class.register(AutoConfig, self.__class__)

    def clear_requests(self):
        if self._compile_only:
            raise ValueError(
                "`clear_requests()` is not supported with `compile_only` mode, please initialize model without this option"
            )

        for component in self.components.values():
            component.clear_requests()

    def compile(self):
        for component in self.components.values():
            component.compile()

    def _save_config(self, save_directory):
        """
        Saves a model configuration into a directory, so that it can be re-loaded using the
        [`from_pretrained`] class method.
        """
        save_config(self.config, save_directory)

    @classmethod
    def _from_pretrained(
        cls,
        model_id: Union[str, Path],
        config: PretrainedConfig,
        token: Optional[Union[bool, str]] = None,
        revision: Optional[str] = None,
        force_download: bool = False,
        cache_dir: str = HUGGINGFACE_HUB_CACHE,
        local_files_only: bool = False,
        load_in_8bit: bool = False,
        quantization_config: Union[OVWeightQuantizationConfig, Dict] = None,
        trust_remote_code: bool = False,
        **kwargs,
    ):
        """
        Loads a model and its configuration file from a directory or the HF Hub.

        Arguments:
            model_id (`str` or `Path`):
                The directory from which to load the model.
                Can be either:
                    - The model id of a pretrained model hosted inside a model repo on huggingface.co.
                    - The path to a directory containing the model weights.
            token (Optional[Union[bool, str]], defaults to `None`):
                The token to use as HTTP bearer authorization for remote files. If `True`, will use the token generated
                when running `huggingface-cli login` (stored in `~/.huggingface`).
            revision (`str`):
                The specific model version to use. It can be a branch name, a tag name, or a commit id.
            force_download (`bool`, *optional*, defaults to `False`):
                Whether or not to force the (re-)download of the model weights and configuration files, overriding the
                cached versions if they exist.
            cache_dir (`Union[str, Path]`, *optional*):
                The path to a directory in which a downloaded pretrained model configuration should be cached if the
                standard cache should not be used.
            encoder_file_name(`str`, *optional*):
                The encoder model file name. Overwrites the default file name openvino_encoder_model.xml and allows one to
                load the encoder model with a different name.
            decoder_file_name(`str`, *optional*):
                The decoder model file name. Overwrites the default file name openvino_decoder_model.xml and allows one to
                load the decoder model with a different name.
            decoder_with_past_file_name(`str`, *optional*):
                The decoder with past key values model file name overwriting the default file name
                openvino_decoder_with_past_model.xml, allowing to load the decoder model with a different name.
            local_files_only(`bool`, *optional*, defaults to `False`):
                Whether or not to only look at local files (i.e., do not try to download the model).
            trust_remote_code (`bool`, *optional*, defaults to `False`):
                Whether to trust remote code when loading model tokenizer/processor during quantization.
        """
        model_cls = MODEL_TYPE_TO_CLS_MAPPING[config.model_type]
        model_file_names = model_cls._all_ov_model_paths.copy()
        for k in tuple(model_file_names):
            model_file_names[f"{k}_bin"] = model_file_names[k].replace(".xml", ".bin")
        compile_only = kwargs.get("compile_only", False)
        if os.path.isdir(model_id):
            # Load model from a local directory
            model_save_dir = Path(model_id)
            file_names = {k: os.path.join(model_id, model_file_names[k]) for k in model_file_names}
        else:
            required_keys = {
                "lm_model",
                "lm_model_bin",
                "text_embeddings_model",
                "text_embeddings_model_bin",
                "vision_embeddings_model",
                "vision_embeddings_model_bin",
            }
            # Additional components (audio_encoder, talker, code_predictor, etc.) are optional
            # and model-specific. Skip gracefully if not present rather than failing.
            file_names = {}
            for name, file_name in model_file_names.items():
                try:
                    model_cache_path = hf_hub_download(
                        repo_id=model_id,
                        filename=file_name,
                        token=token,
                        revision=revision,
                        cache_dir=cache_dir,
                        force_download=force_download,
                        local_files_only=local_files_only,
                    )
                    file_names[name] = model_cache_path
                except EntryNotFoundError:
                    if name in required_keys:
                        raise
                    logger.info(f"Could not download '{file_name}' from Hub, skipping.")
            model_save_dir = Path(file_names["lm_model"]).parent
        if not compile_only:
            language_model = model_cls.load_model(file_names["lm_model"])
            text_embeddings = model_cls.load_model(file_names["text_embeddings_model"])
            vision_embeddings = model_cls.load_model(file_names["vision_embeddings_model"])
            for part in model_cls.additional_parts:
                part_file = file_names.get(f"{part}_model")
                if part_file and os.path.exists(part_file):
                    kwargs[part] = model_cls.load_model(part_file)
                else:
                    logger.info(f"Optional model part '{part}' not found, skipping.")
                    kwargs[part] = None
        else:
            language_model = model_cls._compile_model(
                file_names["lm_model"],
                kwargs.get("device", "CPU"),
                kwargs.get("ov_config"),
                model_save_dir,
            )
            text_embeddings = model_cls._compile_model(
                file_names["text_embeddings_model"],
                kwargs.get("device", "CPU"),
                kwargs.get("ov_config"),
                model_save_dir,
            )
            vision_embeddings = model_cls._compile_model(
                file_names["vision_embeddings_model"],
                kwargs.get("device", "CPU"),
                kwargs.get("ov_config"),
                model_save_dir,
            )
            for part in model_cls.additional_parts:
                part_file = file_names.get(f"{part}_model")
                if part_file and os.path.exists(part_file):
                    kwargs[part] = model_cls._compile_model(
                        part_file,
                        kwargs.get("device", "CPU"),
                        kwargs.get("ov_config"),
                        model_save_dir,
                    )
                else:
                    logger.info(f"Optional model part '{part}' not found, skipping.")
                    kwargs[part] = None
        try:
            generation_config = GenerationConfig.from_pretrained(
                model_id,
                token=token,
                revision=revision,
                cache_dir=cache_dir,
                force_download=force_download,
                local_files_only=local_files_only,
            )
            kwargs["generation_config"] = generation_config
        except Exception:
            pass

        quantization_config = quantization_config or (OVWeightQuantizationConfig(bits=8) if load_in_8bit else None)
        compile_model = kwargs.pop("compile", True)
        model = model_cls(
            language_model=language_model,
            text_embeddings=text_embeddings,
            vision_embeddings=vision_embeddings,
            config=config,
            model_save_dir=model_save_dir,
            quantization_config=quantization_config,
            compile=compile_model and not quantization_config,
            **kwargs,
        )

        if quantization_config:
            if hasattr(config, "name_or_path"):
                model_id = config.name_or_path
            else:
                logger.warning(
                    "`model_id` could not be determined from the config. In the case there are default quantization "
                    "configurations for this model, they will not be applied."
                )
            quantization_config = cls._resolve_default_quantization_config(model_id, quantization_config)
            model._apply_quantization(quantization_config, compile_only, compile_model, model_id, trust_remote_code)

        return model

    @classmethod
    def _export(
        cls,
        model_id: str,
        config: PretrainedConfig,
        token: Optional[Union[bool, str]] = None,
        revision: Optional[str] = None,
        force_download: bool = False,
        cache_dir: str = HUGGINGFACE_HUB_CACHE,
        subfolder: str = "",
        local_files_only: bool = False,
        task: Optional[str] = None,
        use_cache: bool = True,
        trust_remote_code: bool = False,
        load_in_8bit: Optional[bool] = None,
        quantization_config: Union[OVWeightQuantizationConfig, Dict] = None,
        **kwargs,
    ):
        compile_only = kwargs.pop("compile_only", False)
        if compile_only:
            logger.warning(
                "`compile_only` mode will be disabled because it does not support model export."
                "Please provide openvino model obtained using optimum-cli or saved on disk using `save_pretrained`"
            )
            compile_only = False
        save_dir = TemporaryDirectory()
        save_dir_path = Path(save_dir.name)

        # This attribute is needed to keep one reference on the temporary directory, since garbage collecting
        # would end-up removing the directory containing the underlying OpenVINO model
        cls._model_save_dir_tempdirectory_instance = save_dir

        if task is None:
            task = cls.export_feature

        # If load_in_8bit and quantization_config not specified then ov_config is set to None and will be set by default in convert depending on the model size
        if load_in_8bit is None and not quantization_config:
            ov_config = None
        else:
            # Export in fp32 if compression won't be applied later
            ov_config = OVConfig(dtype="fp32" if load_in_8bit is False else "auto")

        stateful = kwargs.pop("stateful", ensure_stateful_is_available(warn=False) and use_cache)
        variant = kwargs.pop("variant", None)

        main_export(
            model_name_or_path=model_id,
            output=save_dir_path,
            task=task,
            subfolder=subfolder,
            revision=revision,
            cache_dir=cache_dir,
            token=token,
            local_files_only=local_files_only,
            force_download=force_download,
            trust_remote_code=trust_remote_code,
            ov_config=ov_config,
            stateful=stateful,
            variant=variant,
        )
        name_or_path = config.name_or_path
        config = AutoConfig.from_pretrained(save_dir_path, trust_remote_code=trust_remote_code)
        # Keep the original name_or_path to be able to resolve default quantization config later
        config.name_or_path = name_or_path
        return cls._from_pretrained(
            model_id=save_dir_path,
            config=config,
            use_cache=use_cache,
            load_in_8bit=load_in_8bit,
            quantization_config=quantization_config,
            trust_remote_code=trust_remote_code,
            **kwargs,
        )

    @property
    def _component_names(self) -> List[str]:
        base_components = ["language_model", "vision_embeddings"]
        additional_components = [
            part for part in self.additional_parts if hasattr(self, part) and getattr(self, part) is not None
        ]
        return base_components + additional_components

    @property
    def _ov_model_names(self):
        # TODO (nikita.savelyevv): Consider deprecating `lm_model` in favor of `language_model`
        model_names = ["lm_model", "text_embeddings_model", "vision_embeddings_model"]
        for part in self.additional_parts:
            if hasattr(self, part) and getattr(self, part) is not None:
                model_names.append(part + "_model")
        return model_names

    @property
    def ov_models(self) -> Dict[str, Union[openvino.Model, openvino.CompiledModel]]:
        ov_models = {}
        for ov_model_name in self._ov_model_names:
            if ov_model_name == "lm_model":
                ov_model = self.language_model.model
            elif ov_model_name == "text_embeddings_model":
                ov_model = self.language_model.text_emb_model
            else:
                ov_model = getattr(self, ov_model_name.replace("_model", "")).model
            ov_models[ov_model_name] = ov_model
        return ov_models

    def reshape(self, batch_size: int, sequence_length: int):
        logger.warning("Static shapes are not supported for causal language model.")
        return self

    def half(self):
        """
        Converts all the model weights to FP16 for more efficient inference on GPU.
        """
        for ov_model in self.ov_models.values():
            apply_moc_transformations(ov_model, cf=False)
            compress_model_transformation(ov_model)
        return self

    def to(self, device):
        self.language_model.to(device)
        super().to(device)
        return self

    def forward(
        self,
        input_ids,
        pixel_values=None,
        past_key_values=None,
        inputs_embeds=None,
        image_sizes=None,
        attention_mask=None,
        position_ids=None,
        image_bound=None,
        tgt_sizes=None,
        pixel_values_videos=None,
        image_grid_thw=None,
        video_grid_thw=None,
        rope_deltas=None,
        images=None,
        second_per_grid_ts=None,
        token_type_ids=None,
        pixel_attention_mask=None,
        input_image_embeds: Optional[torch.FloatTensor] = None,
        image_pixel_values: Optional[torch.FloatTensor] = None,
        image_attention_mask=None,
        audio_input_features: Optional[torch.FloatTensor] = None,
        input_audio_embeds: Optional[torch.FloatTensor] = None,
        audio_embed_sizes=None,
        audio_attention_mask=None,
        input_mode=None,
        **kwargs,
    ):
        if pixel_values is None:
            pixel_values = images if images is not None else image_pixel_values
        inputs_embeds, attention_mask, position_ids, *extra_outputs = self.get_multimodal_embeddings(
            input_ids,
            pixel_values,
            inputs_embeds=inputs_embeds,
            image_sizes=image_sizes,
            attention_mask=attention_mask,
            position_ids=position_ids,
            past_key_values=past_key_values,
            image_bound=image_bound,
            tgt_sizes=tgt_sizes,
            pixel_values_videos=pixel_values_videos,
            image_grid_thw=image_grid_thw,
            video_grid_thw=video_grid_thw,
            rope_deltas=rope_deltas,
            second_per_grid_ts=second_per_grid_ts,
            pixel_attention_mask=pixel_attention_mask,
            input_image_embeds=input_image_embeds,
            image_attention_mask=image_attention_mask,
            input_audio_embeds=input_audio_embeds if input_audio_embeds is not None else audio_input_features,
            audio_embed_sizes=audio_embed_sizes,
            audio_attention_mask=audio_attention_mask,
            input_mode=input_mode,
            **kwargs,
        )

        # Prepare additional kwargs for qwen3_vl models
        additional_kwargs = {}
        if self.config.model_type in ("qwen3_vl", "qwen3_omni_moe") and extra_outputs:
            additional_kwargs["visual_pos_masks"] = extra_outputs[0]
            additional_kwargs["deepstack_visual_embeds"] = extra_outputs[1]

        if (
            self.config.model_type
            in (
                "gemma3n",
                "gemma4",
            )
            and extra_outputs
        ):
            additional_kwargs["per_layer_inputs"] = extra_outputs[0]

        return self.language_model.forward(
            input_ids=None,
            inputs_embeds=inputs_embeds,
            attention_mask=attention_mask,
            position_ids=position_ids,
            token_type_ids=token_type_ids,
            past_key_values=past_key_values,
            **additional_kwargs,
            **kwargs,
        )

    def _reorder_cache(self, past_key_values, beam_idx):
        return self.language_model._reorder_cache(past_key_values, beam_idx)

    def get_vision_embeddings(self, pixel_values, **kwargs):
        raise NotImplementedError

    def get_text_embeddings(self, input_ids, **kwargs):
        return self.language_model.embed_tokens(input_ids)

    def merge_vision_text_embeddings(
        self, vision_embeds, inputs_embeds, input_ids=None, attention_mask=None, position_ids=None, **kwargs
    ):
        raise NotImplementedError

    def get_multimodal_embeddings(
        self, input_ids, pixel_values=None, attention_mask=None, position_ids=None, **kwargs
    ):
        embeds_from_args = kwargs.pop("inputs_embeds", None)
        inputs_embeds = (
            embeds_from_args if embeds_from_args is not None else self.get_text_embeddings(input_ids, **kwargs)
        )
        if pixel_values is not None:
            vision_embeds = self.get_vision_embeddings(pixel_values, input_ids=input_ids, **kwargs)
            if vision_embeds is not None:
                inputs_embeds, attention_mask, position_ids = self.merge_vision_text_embeddings(
                    vision_embeds,
                    inputs_embeds,
                    input_ids=input_ids,
                    attention_mask=attention_mask,
                    position_ids=position_ids,
                    **kwargs,
                )
        return inputs_embeds, attention_mask, position_ids

    # Adopted from https://github.com/huggingface/transformers/blob/v4.44.2/src/transformers/models/llava/modeling_llava.py#L521
    def prepare_inputs_for_generation(
        self,
        input_ids,
        past_key_values=None,
        inputs_embeds=None,
        pixel_values=None,
        image_sizes=None,
        attention_mask=None,
        **kwargs,
    ):
        if past_key_values is not None:
            past_length = self.language_model._get_past_length(past_key_values)

            # Keep only the unprocessed tokens:
            # 1 - If the length of the attention_mask exceeds the length of input_ids, then we are in a setting where
            # some of the inputs are exclusively passed as part of the cache (e.g. when passing input_embeds as
            # input)
            if attention_mask is not None and past_length + 1 > input_ids.shape[1]:
                input_discount = max(attention_mask.shape[1] - past_length, 1)
                input_ids = input_ids[:, -input_discount:]
            # 2 - If the past_length is smaller than input_ids', then input_ids holds all input tokens. We can discard
            # input_ids based on the past_length.llava
            elif past_length < input_ids.shape[1]:
                input_ids = input_ids[:, past_length:]
            # 3 - Otherwise (past_length >= input_ids.shape[1]), let's assume input_ids only has unprocessed tokens.
            elif getattr(self.config, "image_token_index", -1) in input_ids:
                input_ids = input_ids[:, input_ids.shape[1] - 1 :]

        position_ids = kwargs.get("position_ids", None)
        if attention_mask is not None and position_ids is None:
            position_ids = attention_mask.long().cumsum(-1) - 1
            position_ids.masked_fill_(attention_mask == 0, 1)

            # position_ids in Gemma3 are 1-indexed
            if self.config.model_type == "gemma3":
                position_ids += 1

            if past_key_values is not None:
                position_ids = position_ids[:, -input_ids.shape[1] :]

        # if `inputs_embeds` are passed, we only want to use them in the 1st generation step
        if inputs_embeds is not None and past_key_values is None:
            model_inputs = {"inputs_embeds": inputs_embeds}
        else:
            model_inputs = {"input_ids": input_ids}

        if pixel_values is None:
            pixel_values = kwargs.get("input_image_embeds", kwargs.get("images", kwargs.get("image_pixel_values")))

        model_inputs.update(
            {
                "position_ids": position_ids,
                "past_key_values": past_key_values,
                "use_cache": kwargs.get("use_cache"),
                "attention_mask": attention_mask,
                "pixel_values": pixel_values,
                "image_sizes": image_sizes,
                "image_bound": kwargs.get("image_bound"),
                "tgt_sizes": kwargs.get("tgt_sizes"),
                "pixel_values_videos": kwargs.get("pixel_values_videos"),
                "image_grid_thw": kwargs.get("image_grid_thw"),
                "video_grid_thw": kwargs.get("video_grid_thw"),
                "token_type_ids": kwargs.get("token_type_ids"),
                "pixel_attention_mask": kwargs.get("pixel_attention_mask"),
                "image_attention_mask": kwargs.get("image_attention_mask"),
                "input_audio_embeds": kwargs.get("input_audio_embeds", kwargs.get("audio_input_features")),
                "audio_embed_sizes": kwargs.get("audio_embed_sizes"),
                "input_mode": kwargs.get("input_mode"),
            }
        )
        return model_inputs

    def can_generate(self):
        """Returns True to validate the check that the model using `GenerationMixin.generate()` can indeed generate."""
        return True

    @staticmethod
    @abstractmethod
    def preprocess_inputs(
        text: str,
        image: Optional["Image"] = None,
        processor: Optional[AutoImageProcessor] = None,
        tokenizer: Optional[PreTrainedTokenizer] = None,
        config: Optional[PretrainedConfig] = None,
        video: Optional["VideoInput"] = None,
        audio: Optional[np.ndarray] = None,
    ):
        """
        Preprocess input instruction and an image.
        """

    # modified from https://github.com/huggingface/transformers/blob/v4.55.0/src/transformers/generation/utils.py#L1992
    def _prepare_cache_for_generation(self, *args, **kwargs):
        """
        This function is used to prepare the cache : when calling `generate` before the first inference, an instance of `DynamicCache` will be created.
        For OVModel, we don't want model_kwargs to be updated before generation.
        """
        return

    def _preprocess_quantization_config(
        self,
        quantization_config: OVQuantizationConfigBase,
        model_name_or_path: str,
    ) -> OVQuantizationConfigBase:
        if quantization_config.processor is None or quantization_config.tokenizer is None:
            quantization_config = quantization_config.clone()
            if quantization_config.processor is None:
                potential_processor_id = (
                    self.config.mm_vision_tower if isinstance(self, _OVNanoLlavaForCausalLM) else model_name_or_path
                )
                quantization_config.processor = potential_processor_id
            if quantization_config.tokenizer is None:
                quantization_config.tokenizer = model_name_or_path
        return quantization_config


class _OVLlavaForCausalLM(OVModelForVisualCausalLM):
    def __init__(
        self,
        language_model: ov.Model,
        text_embeddings: ov.Model,
        vision_embeddings: ov.Model,
        config: PretrainedConfig = None,
        device: str = "CPU",
        dynamic_shapes: bool = None,
        ov_config: Optional[Dict[str, str]] = None,
        model_save_dir: Optional[Union[str, Path, TemporaryDirectory]] = None,
        quantization_config: Union[OVWeightQuantizationConfig, Dict] = None,
        **kwargs,
    ):
        super().__init__(
            language_model=language_model,
            text_embeddings=text_embeddings,
            vision_embeddings=vision_embeddings,
            config=config,
            device=device,
            dynamic_shapes=dynamic_shapes,
            ov_config=ov_config,
            model_save_dir=model_save_dir,
            quantization_config=quantization_config,
            **kwargs,
        )
        self._support_new_processing = hasattr(self.config, "image_seq_length")

    def get_vision_embeddings(self, pixel_values, input_ids=None, **kwargs):
        if input_ids is not None and input_ids.shape[1] == 1:
            return None
        if not isinstance(pixel_values, list):
            image_features = self.vision_embeddings(pixel_values).last_hidden_state
        else:
            image_features = []
            for patch in pixel_values:
                if isinstance(patch, list):
                    patch_feats = []
                    for patch_value in patch:
                        patch_feats.append(self.vision_embeddings(np.expand_dims(patch_value, 0)).last_hidden_state)
                    patch_feats = np.concatenate(patch_feats, axis=1)
                else:
                    patch_feats = self.vision_embeddings(patch).last_hidden_state
                image_features.append(patch_feats)
            image_features = np.concatenate(image_features, 0)

        return image_features

    # Adopted from https://github.com/huggingface/transformers/blob/d7950bff82b18c823193d17d72188c5e46d06c83/src/transformers/models/llava/modeling_llava.py#L297C9-L297C45
    def merge_vision_text_embeddings(
        self,
        vision_embeds,
        inputs_embeds,
        input_ids,
        attention_mask,
        position_ids=None,
        legacy_processing=False,
        **kwargs,
    ):
        image_features = torch.from_numpy(vision_embeds) if isinstance(vision_embeds, np.ndarray) else vision_embeds
        inputs_embeds = torch.from_numpy(inputs_embeds) if isinstance(inputs_embeds, np.ndarray) else inputs_embeds

        if legacy_processing:
            pad_token_id = self.config.pad_token_id if self.config.pad_token_id is not None else -1

            num_images, num_image_patches, embed_dim = image_features.shape
            batch_size, sequence_length = input_ids.shape
            left_padding = not torch.sum(input_ids[:, -1] == torch.tensor(pad_token_id))
            # 1. Create a mask to know where special image tokens are
            special_image_token_mask = input_ids == self.config.image_token_index
            num_special_image_tokens = torch.sum(special_image_token_mask, dim=-1)
            # Compute the maximum embed dimension
            max_embed_dim = (num_special_image_tokens.max() * (num_image_patches - 1)) + sequence_length
            batch_indices, non_image_indices = torch.where(input_ids != self.config.image_token_index)

            # 2. Compute the positions where text should be written
            # Calculate new positions for text tokens in merged image-text sequence.
            # `special_image_token_mask` identifies image tokens. Each image token will be replaced by `nb_text_tokens_per_images - 1` text tokens.
            # `torch.cumsum` computes how each image token shifts subsequent text token positions.
            # - 1 to adjust for zero-based indexing, as `cumsum` inherently increases indices by one.
            new_token_positions = torch.cumsum((special_image_token_mask * (num_image_patches - 1) + 1), -1) - 1
            nb_image_pad = max_embed_dim - 1 - new_token_positions[:, -1]
            if left_padding:
                new_token_positions += nb_image_pad[:, None]  # offset for left padding
            text_to_overwrite = new_token_positions[batch_indices, non_image_indices]

            # 3. Create the full embedding, already padded to the maximum position
            final_embedding = torch.zeros(
                batch_size, max_embed_dim, embed_dim, dtype=inputs_embeds.dtype, device=inputs_embeds.device
            )
            final_attention_mask = torch.zeros(
                batch_size, max_embed_dim, dtype=attention_mask.dtype, device=inputs_embeds.device
            )

            # 4. Fill the embeddings based on the mask. If we have ["hey" "<image>", "how", "are"]
            # we need to index copy on [0, 577, 578, 579] for the text and [1:576] for the image features
            final_embedding[batch_indices, text_to_overwrite] = inputs_embeds[batch_indices, non_image_indices]
            final_attention_mask[batch_indices, text_to_overwrite] = attention_mask[batch_indices, non_image_indices]
            # 5. Fill the embeddings corresponding to the images. Anything that is not `text_positions` needs filling (#29835)
            image_to_overwrite = torch.full(
                (batch_size, max_embed_dim), True, dtype=torch.bool, device=inputs_embeds.device
            )
            image_to_overwrite[batch_indices, text_to_overwrite] = False
            image_to_overwrite &= image_to_overwrite.cumsum(-1) - 1 >= nb_image_pad[:, None]

            if image_to_overwrite.sum() != image_features.shape[:-1].numel():
                raise ValueError(
                    f"The input provided to the model a/pre-releasesre wrong. The number of image tokens is {torch.sum(special_image_token_mask)} while"
                    f" the number of image given to the model is {num_images}. This prevents correct indexing and breaks batch generation."
                )

            final_embedding[image_to_overwrite] = image_features.contiguous().reshape(-1, embed_dim)
            final_attention_mask |= image_to_overwrite
            position_ids = (final_attention_mask.cumsum(-1) - 1).masked_fill_((final_attention_mask == 0), 1)

            # 6. Mask out the embedding at padding positions, as we later use the past_key_value value to determine the non-attended tokens.
            batch_indices, pad_indices = torch.where(input_ids == pad_token_id)
            indices_to_mask = new_token_positions[batch_indices, pad_indices]

            final_embedding[batch_indices, indices_to_mask] = 0
        else:
            special_image_mask = (input_ids == self.config.image_token_index).unsqueeze(-1).expand_as(inputs_embeds)
            image_features = image_features.to(inputs_embeds.dtype)
            final_embedding = inputs_embeds.masked_scatter(special_image_mask, image_features)
            final_attention_mask = attention_mask

        return final_embedding, final_attention_mask, position_ids

    def get_multimodal_embeddings(
        self, input_ids, pixel_values=None, attention_mask=None, position_ids=None, past_key_values=None, **kwargs
    ):
        if pixel_values is not None and self._support_new_processing and past_key_values is None:
            legacy_processing = (input_ids == self.config.image_token_index).sum(
                1
            ).max() < self.config.image_seq_length
        else:
            legacy_processing = True
        inputs_embeds, attention_mask, position_ids = super().get_multimodal_embeddings(
            input_ids, pixel_values, attention_mask, position_ids, legacy_processing=legacy_processing, **kwargs
        )

        if legacy_processing and pixel_values is not None and past_key_values is not None:
            attention_mask, position_ids = self._filter_unattended_tokens(input_ids, attention_mask, past_key_values)

        return inputs_embeds, attention_mask, position_ids

    def _filter_unattended_tokens(self, input_ids, attention_mask, past_key_values):
        # Get the target length
        target_length = input_ids.shape[1]
        past_length = self.language_model._get_past_length(past_key_values)

        extended_attention_mask = torch.ones(
            (attention_mask.shape[0], past_length),
            dtype=attention_mask.dtype,
            device=attention_mask.device,
        )

        attention_mask = torch.cat((extended_attention_mask, attention_mask[:, -target_length:]), dim=1)
        position_ids = torch.cumsum(attention_mask, axis=1) - 1
        position_ids[attention_mask == 0] = 1
        return attention_mask, position_ids

    @staticmethod
    def preprocess_inputs(
        text: str,
        image: Optional["Image"] = None,
        processor: Optional[AutoImageProcessor] = None,
        tokenizer: Optional[PreTrainedTokenizer] = None,
        config: Optional[PretrainedConfig] = None,
        video: Optional["VideoInput"] = None,
        audio: Optional[np.ndarray] = None,
    ):
        if processor is None:
            raise ValueError("Processor is required.")
        if video is not None:
            raise ValueError("Video input is not supported")
        if audio is not None:
            raise ValueError("Audio input is not supported")
        if getattr(processor, "chat_template", None) is not None:
            chat_prompt = [{"role": "user", "content": [{"type": "text", "text": text}]}]
            if image is not None:
                chat_prompt[0]["content"].append({"type": "image"})
            prompt = processor.apply_chat_template(chat_prompt, add_generation_prompt=True, tokenize=False)
        else:
            if image is not None and "<image>" not in text:
                prompt = "<image>\n" + text
            else:
                prompt = text

        if getattr(processor, "patch_size", None) is None:
            if (
                getattr(config, "vision_config", None) is not None
                and getattr(config.vision_config, "patch_size", None) is not None
            ):
                processor.patch_size = config.vision_config.patch_size
            else:
                raise ValueError(
                    "Processor does not have `patch_size` attribute. Please fix the processor or provide `patch_size` in the config."
                )

        inputs = processor(images=image, text=prompt, return_tensors="pt")
        return inputs


class _OVLlavaNextForCausalLM(_OVLlavaForCausalLM):
    # Adopted from https://github.com/huggingface/transformers/blob/main/src/transformers/models/llava_next/modeling_llava_next.py#L655
    def pack_image_features(self, image_features, image_sizes, image_newline=None):
        from transformers.models.llava_next.modeling_llava_next import get_anyres_image_grid_shape, unpad_image

        """
        Reshape, unpad and then pack each image_feature into a single image_features tensor containing all visual vectors.

        Args:
            image_features (`List[torch.Tensor]` of length num_images, each of shape `(num_patches, image_length, embed_dim)`)
                List of image feature tensor, each contains all the visual feature of all patches.
            image_sizes (`torch.Tensor` of shape `(num_images, 2)`)
                Actual image size of each images (H, W).
            image_newline (`torch.Tensor` of shape `(embed_dim)`)
                New line embedding vector.
        Returns:
            image_features (`torch.Tensor` of shape `(all_feat_len, embed_dim)`)
            feature_lens (`List[int]`)
                token length of each image in image_features
        """
        new_image_features = []
        feature_lens = []
        for image_idx, image_feature in enumerate(image_features):
            if image_feature.shape[0] > 1:
                base_image_feature = image_feature[0]
                image_feature = image_feature[1:]
                height = width = self.config.vision_config.image_size // self.config.vision_config.patch_size
                if height * width != base_image_feature.shape[0]:
                    raise ValueError("The number of patches is not consistent with the image size.")
                num_patch_width, num_patch_height = get_anyres_image_grid_shape(
                    image_sizes[image_idx],
                    self.config.image_grid_pinpoints,
                    self.config.vision_config.image_size,
                )
                image_feature = image_feature.view(num_patch_height, num_patch_width, height, width, -1)
                image_feature = image_feature.permute(4, 0, 2, 1, 3).contiguous()
                image_feature = image_feature.flatten(1, 2).flatten(2, 3)
                image_feature = unpad_image(image_feature, image_sizes[image_idx])
                if image_newline is not None:
                    image_feature = torch.cat(
                        (
                            image_feature,
                            image_newline[:, None, None].expand(*image_feature.shape[:-1], 1).to(image_feature.dtype),
                        ),
                        dim=-1,
                    )
                image_feature = image_feature.flatten(1, 2).transpose(0, 1)
                image_feature = torch.cat((base_image_feature, image_feature), dim=0)
            else:
                image_feature = image_feature[0]
                if image_newline is not None:
                    image_feature = torch.cat((image_feature, image_newline[None].to(image_feature)), dim=0)
            new_image_features.append(image_feature)
            feature_lens.append(image_feature.size(0))
        image_features = torch.cat(new_image_features, dim=0)
        feature_lens = torch.tensor(feature_lens, dtype=torch.long, device=image_features.device)
        return image_features, feature_lens

    def add_image_features(
        self,
        input_ids,
        inputs_embeds,
        pixel_values,
        attention_mask,
        position_ids,
        image_sizes,
        legacy_processing,
        **kwargs,
    ):
        from transformers.models.llava_next.modeling_llava_next import image_size_to_num_patches

        # ! infer image_num_patches from image_sizes
        image_num_patches = [
            image_size_to_num_patches(
                image_size=imsize,
                grid_pinpoints=self.config.image_grid_pinpoints,
                patch_size=self.config.vision_config.image_size,
            )
            for imsize in image_sizes
        ]
        # figure out if pixel_values is concatenated or stacked
        if pixel_values.dim() == 5:
            # stacking when input is (batch_size, num_patches, num_channels, height, width)
            _pixel_values_list = [pix_val[:num_patch] for pix_val, num_patch in zip(pixel_values, image_num_patches)]
            pixel_values = torch.cat(_pixel_values_list, dim=0)
        elif pixel_values.dim() != 4:
            # otherwise has to be stacked from list of (num_patches, num_channels, height, width)
            raise ValueError(f"pixel_values of shape {pixel_values.shape}, expect to be of 4 or 5 dimensions")
        vision_embeds = self.get_vision_embeddings(pixel_values, input_ids=input_ids, **kwargs)
        if vision_embeds is not None:
            image_newline = torch.tensor(self.config.image_newline)
            image_features = torch.split(torch.from_numpy(vision_embeds), image_num_patches, dim=0)
            image_features, feature_lens = self.pack_image_features(
                image_features,
                image_sizes,
                image_newline=image_newline,
            )
            inputs_embeds, attention_mask, position_ids = self.merge_vision_text_embeddings(
                image_features,
                inputs_embeds,
                feature_lens=feature_lens,
                input_ids=input_ids,
                attention_mask=attention_mask,
                position_ids=position_ids,
                legacy_processing=legacy_processing,
                **kwargs,
            )
        return inputs_embeds, attention_mask, position_ids

    # Adopted from https://github.com/huggingface/transformers/blob/main/src/transformers/models/llava_next/modeling_llava_next.py#L416
    def get_multimodal_embeddings(
        self,
        input_ids,
        pixel_values=None,
        attention_mask=None,
        position_ids=None,
        past_key_values=None,
        image_sizes=None,
        **kwargs,
    ):
        embeds_from_args = kwargs.pop("inputs_embeds", None)
        inputs_embeds = (
            embeds_from_args if embeds_from_args is not None else self.get_text_embeddings(input_ids, **kwargs)
        )

        if pixel_values is not None and self._support_new_processing and past_key_values is None:
            legacy_processing = (input_ids == self.config.image_token_index).sum(
                1
            ).max() < self.config.image_seq_length
        else:
            legacy_processing = True

        if pixel_values is not None and pixel_values.size(0) > 0:
            inputs_embeds, attention_mask, position_ids = self.add_image_features(
                input_ids,
                inputs_embeds,
                pixel_values,
                attention_mask,
                position_ids,
                image_sizes,
                legacy_processing,
                **kwargs,
            )

        if legacy_processing and pixel_values is not None and past_key_values is not None and input_ids.shape[1] == 1:
            attention_mask, position_ids = self._filter_unattended_tokens(input_ids, attention_mask, past_key_values)

        return inputs_embeds, attention_mask, position_ids

    def merge_vision_text_embeddings(
        self,
        vision_embeds,
        inputs_embeds,
        feature_lens,
        input_ids,
        attention_mask,
        position_ids=None,
        legacy_processing=False,
        image_token_index=None,
        **kwargs,
    ):
        image_token_index = self.config.image_token_index if image_token_index is None else image_token_index
        image_features = torch.from_numpy(vision_embeds) if isinstance(vision_embeds, np.ndarray) else vision_embeds
        inputs_embeds = torch.from_numpy(inputs_embeds) if isinstance(inputs_embeds, np.ndarray) else inputs_embeds

        if legacy_processing:
            with torch.no_grad():
                # ! in llava 1.6, number of patches is variable
                num_images = feature_lens.size(0)
                num_image_features, embed_dim = image_features.shape
                if feature_lens.sum() != num_image_features:
                    raise ValueError(f"{feature_lens=} / {feature_lens.sum()} != {image_features.shape=}")
                batch_size = input_ids.shape[0]
                _left_padding = torch.any(attention_mask[:, 0] == 0)
                _right_padding = torch.any(attention_mask[:, -1] == 0)

                left_padding = True
                if batch_size > 1:
                    if _left_padding and not _right_padding:
                        left_padding = True
                    elif not _left_padding and _right_padding:
                        left_padding = False
                    elif not _left_padding and not _right_padding:
                        left_padding = True
                    else:
                        # invalid attention_mask
                        raise ValueError(f"both side of attention_mask has zero, invalid. {attention_mask}")

                # Whether to turn off right padding
                # 1. Create a mask to know where special image tokens are
                special_image_token_mask = input_ids == image_token_index
                # special_image_token_mask: [bsz, seqlen]
                num_special_image_tokens = torch.sum(special_image_token_mask, dim=-1)
                # num_special_image_tokens: [bsz]
                # Reserve for padding of num_images
                total_num_special_image_tokens = torch.sum(special_image_token_mask)
                if total_num_special_image_tokens != num_images:
                    raise ValueError(
                        f"Number of image tokens in input_ids ({total_num_special_image_tokens}) different from num_images ({num_images})."
                    )
                # Compute the maximum embed dimension
                # max_image_feature_lens is max_feature_lens per batch
                feature_lens = feature_lens.to(input_ids.device)
                feature_lens_batch = feature_lens.split(num_special_image_tokens.tolist(), dim=0)
                feature_lens_batch_sum = torch.tensor([x.sum() for x in feature_lens_batch], device=input_ids.device)
                embed_sequence_lengths = (
                    (attention_mask == 1).long().sum(-1) - num_special_image_tokens + feature_lens_batch_sum
                )
                max_embed_dim = embed_sequence_lengths.max()

                batch_indices, non_image_indices = torch.where(
                    (input_ids != image_token_index) & (attention_mask == 1)
                )
                # 2. Compute the positions where text should be written
                # Calculate new positions for text tokens in merged image-text sequence.
                # `special_image_token_mask` identifies image tokens. Each image token will be replaced by `nb_text_tokens_per_images` text tokens.
                # `torch.cumsum` computes how each image token shifts subsequent text token positions.
                # - 1 to adjust for zero-based indexing, as `cumsum` inherently increases indices by one.
                # ! instead of special_image_token_mask * (num_image_patches - 1)
                #   special_image_token_mask * (num_feature_len - 1)
                special_image_token_mask = special_image_token_mask.long()
                special_image_token_mask[special_image_token_mask == 1] = feature_lens - 1
                new_token_positions = torch.cumsum((special_image_token_mask + 1), -1) - 1
                if left_padding:
                    # shift right token positions so that they are ending at the same number
                    # the below here was incorrect? new_token_positions += new_token_positions[:, -1].max() - new_token_positions[:, -1:]
                    new_token_positions += max_embed_dim - 1 - new_token_positions[:, -1:]

                text_to_overwrite = new_token_positions[batch_indices, non_image_indices]

            # 3. Create the full embedding, already padded to the maximum position
            final_embedding = torch.zeros(
                batch_size, max_embed_dim, embed_dim, dtype=inputs_embeds.dtype, device=inputs_embeds.device
            )
            final_attention_mask = torch.zeros(
                batch_size, max_embed_dim, dtype=attention_mask.dtype, device=inputs_embeds.device
            )
            # In case the Vision model or the Language model has been offloaded to CPU, we need to manually
            # set the corresponding tensors into their correct target device.
            target_device = inputs_embeds.device
            batch_indices, non_image_indices, text_to_overwrite = (
                batch_indices.to(target_device),
                non_image_indices.to(target_device),
                text_to_overwrite.to(target_device),
            )
            attention_mask = attention_mask.to(target_device)
            input_ids = input_ids.to(target_device)

            # 4. Fill the embeddings based on the mask. If we have ["hey" "<image>", "how", "are"]
            # we need to index copy on [0, 577, 578, 579] for the text and [1:576] for the image features
            final_embedding[batch_indices, text_to_overwrite] = inputs_embeds[batch_indices, non_image_indices]
            final_attention_mask[batch_indices, text_to_overwrite] = attention_mask[batch_indices, non_image_indices]

            # 5. Fill the embeddings corresponding to the images. Anything that is not `text_positions` needs filling (#29835)
            with torch.no_grad():
                image_to_overwrite = torch.full(
                    (batch_size, max_embed_dim), True, dtype=torch.bool, device=inputs_embeds.device
                )
                image_to_overwrite[batch_indices, text_to_overwrite] = False
                embed_indices = torch.arange(max_embed_dim).unsqueeze(0).to(target_device)
                embed_indices = embed_indices.expand(batch_size, max_embed_dim)
                embed_seq_lens = embed_sequence_lengths[:, None].to(target_device)

                if left_padding:
                    # exclude padding on the left
                    max_embed_dim = max_embed_dim.to(target_device)
                    val = (max_embed_dim - embed_indices) <= embed_seq_lens
                else:
                    # exclude padding on the right
                    val = embed_indices < embed_seq_lens
                image_to_overwrite &= val

                if image_to_overwrite.sum() != num_image_features:
                    raise ValueError(
                        f"{image_to_overwrite.sum()=} != {num_image_features=} The input provided to the model are wrong. "
                        f"The number of image tokens is {torch.sum(special_image_token_mask)} while"
                        f" the number of image given to the model is {num_images}. "
                        f"This prevents correct indexing and breaks batch generation."
                    )
            final_embedding[image_to_overwrite] = image_features.contiguous().reshape(-1, embed_dim).to(target_device)
            final_attention_mask |= image_to_overwrite
            position_ids = (final_attention_mask.cumsum(-1) - 1).masked_fill_((final_attention_mask == 0), 1)
        else:
            special_image_mask = (input_ids == image_token_index).unsqueeze(-1).expand_as(inputs_embeds)
            image_features = image_features.to(inputs_embeds.dtype)
            final_embedding = inputs_embeds.masked_scatter(special_image_mask, image_features)
            final_attention_mask = attention_mask

        return final_embedding, final_attention_mask, position_ids

    def get_text_embeddings(self, input_ids, **kwargs):
        for_inputs_embeds_ids = input_ids.clone()
        for_inputs_embeds_ids[(input_ids == self.config.image_token_index)] = 0
        return super().get_text_embeddings(for_inputs_embeds_ids, **kwargs)


class _OVLlavaNextVideoForCausalLM(_OVLlavaNextForCausalLM):
    additional_parts = ["vision_resampler", "multi_modal_projector"]

    def get_vision_embeddings(self, pixel_values, input_ids=None, **kwargs):
        if input_ids is not None and input_ids.shape[1] == 1:
            return None
        image_features = self.vision_embeddings(pixel_values).last_hidden_state
        image_features = self.multi_modal_projector(image_features)
        return image_features

    def pack_image_features(self, image_features, image_sizes, image_newline=None):
        """
        Reshape, unpad and then pack each image_feature into a single image_features tensor containing all visual vectors.

        Args:
            image_features (`List[torch.Tensor]` of length num_images, each of shape `(num_patches, image_length, embed_dim)`)
                List of image feature tensor, each contains all the visual feature of all patches.
            image_sizes (`torch.Tensor` of shape `(num_images, 2)`)
                Actual image size of each images (H, W).
            vision_feature_select_strategy (`str`)
                The feature selection strategy used to select the vision feature from the vision backbone.
            image_newline (`torch.Tensor` of shape `(embed_dim)`)
                New line embedding vector.
        Returns:
            image_features (`torch.Tensor` of shape `(all_feat_len, embed_dim)`)
            feature_lens (`List[int]`)
                token length of each image in image_features
        """
        from transformers.models.llava_next_video.modeling_llava_next_video import (
            get_anyres_image_grid_shape,
            unpad_image,
        )

        new_image_features = []
        feature_lens = []
        vision_feature_select_strategy = self.config.vision_feature_select_strategy
        for image_idx, image_feature in enumerate(image_features):
            if image_feature.shape[0] > 1:
                base_image_feature = image_feature[0]
                image_feature = image_feature[1:]
                height = width = self.config.vision_config.image_size // self.config.vision_config.patch_size

                num_patch_height, num_patch_width = get_anyres_image_grid_shape(
                    image_sizes[image_idx],
                    self.config.image_grid_pinpoints,
                    self.config.vision_config.image_size,
                )

                if (
                    np.prod(image_feature.shape) % (num_patch_height * num_patch_width * height * width) != 0
                    and vision_feature_select_strategy == "default"
                ):
                    logger.warning_once(
                        "Image feature shape does not line up with the provided patch size. "
                        "You may be using the `default` vision_feature_select_strategy with a"
                        " visual encoder that does not have CLS."
                    )

                image_feature = image_feature.view(num_patch_height, num_patch_width, height, width, -1)
                image_feature = image_feature.permute(4, 0, 2, 1, 3).contiguous()
                image_feature = image_feature.flatten(1, 2).flatten(2, 3)
                image_feature = unpad_image(image_feature, image_sizes[image_idx])
                if image_newline is not None:
                    image_feature = torch.cat(
                        (
                            image_feature,
                            image_newline[:, None, None]
                            .expand(*image_feature.shape[:-1], 1)
                            .to(image_feature.device, image_feature.dtype),
                        ),
                        dim=-1,
                    )
                image_feature = image_feature.flatten(1, 2).transpose(0, 1)
                image_feature = torch.cat((base_image_feature, image_feature), dim=0)
            else:
                image_feature = image_feature[0]
                if image_newline is not None:
                    image_feature = torch.cat((image_feature, image_newline[None].to(image_feature)), dim=0)
            new_image_features.append(image_feature)
            feature_lens.append(image_feature.size(0))
        image_features = torch.cat(new_image_features, dim=0)
        feature_lens = torch.tensor(feature_lens, dtype=torch.long, device=image_features.device)
        return image_features, feature_lens

    @staticmethod
    def preprocess_inputs(
        text: str,
        image: Optional["Image"] = None,
        processor: Optional[AutoImageProcessor] = None,
        tokenizer: Optional[PreTrainedTokenizer] = None,
        config: Optional[PretrainedConfig] = None,
        video: Optional["VideoInput"] = None,
        audio: Optional[np.ndarray] = None,
    ):
        if processor is None:
            raise ValueError("Processor is required.")
        if audio is not None:
            raise ValueError("Audio input is not supported")
        if getattr(processor, "chat_template", None) is not None:
            chat_prompt = [{"role": "user", "content": [{"type": "text", "text": text}]}]
            if image is not None:
                chat_prompt[0]["content"].append({"type": "image"})
            if video is not None:
                chat_prompt[0]["content"].append({"type": "video"})
            prompt = processor.apply_chat_template(chat_prompt, add_generation_prompt=True, tokenize=False)
        else:
            prompt = text
            if image is not None and "<image>" not in prompt:
                prompt = "<image>\n" + prompt
            if video is not None and "<video>" not in prompt:
                prompt = "<video>\n" + prompt

        if getattr(processor, "patch_size", None) is None:
            if (
                getattr(config, "vision_config", None) is not None
                and getattr(config.vision_config, "patch_size", None) is not None
            ):
                processor.patch_size = config.vision_config.patch_size
            else:
                raise ValueError(
                    "Processor does not have `patch_size` attribute. Please fix the processor or provide `patch_size` in the config."
                )

        inputs = processor(images=image, text=prompt, videos=video, return_tensors="pt")
        return inputs

    def get_multimodal_embeddings(
        self,
        input_ids,
        pixel_values=None,
        attention_mask=None,
        position_ids=None,
        past_key_values=None,
        image_sizes=None,
        pixel_values_videos=None,
        **kwargs,
    ):
        embeds_from_args = kwargs.pop("inputs_embeds", None)
        inputs_embeds = (
            embeds_from_args if embeds_from_args is not None else self.get_text_embeddings(input_ids, **kwargs)
        )

        if (
            pixel_values is not None
            and pixel_values.size(0) > 0
            and self._support_new_processing
            and past_key_values is None
        ):
            legacy_processing = (
                (input_ids == self.config.image_token_index).sum(1).max() < self.config.image_seq_length
            ).item()
        elif (
            pixel_values_videos is not None
            and pixel_values_videos.size(0) > 0
            and self._support_new_processing
            and past_key_values is None
        ):
            legacy_processing = (
                (input_ids == self.config.video_token_index).sum(1).max() < self.config.video_seq_length
            ).item()
        else:
            legacy_processing = True

        legacy_processing = (
            legacy_processing.item() if isinstance(legacy_processing, torch.Tensor) else legacy_processing
        )

        if pixel_values is not None and pixel_values.size(0) > 0:
            inputs_embeds, attention_mask, position_ids = self.add_image_features(
                input_ids,
                inputs_embeds,
                pixel_values,
                attention_mask,
                position_ids,
                image_sizes,
                legacy_processing,
                **kwargs,
            )

        if pixel_values_videos is not None and pixel_values_videos.size(0) > 0:
            inputs_embeds, attention_mask, position_ids = self.add_video_features(
                input_ids,
                inputs_embeds,
                pixel_values_videos,
                attention_mask,
                position_ids,
                legacy_processing=legacy_processing,
                **kwargs,
            )

        if legacy_processing and pixel_values is not None and past_key_values is not None and input_ids.shape[1] == 1:
            attention_mask, position_ids = self._filter_unattended_tokens(input_ids, attention_mask, past_key_values)

        return inputs_embeds, attention_mask, position_ids

    def add_video_features(
        self,
        input_ids,
        inputs_embeds,
        pixel_values_videos,
        attention_mask,
        position_ids,
        legacy_processing,
        **kwargs,
    ):
        # Adopted from https://github.com/huggingface/transformers/blob/v4.49.0/src/transformers/models/llava_next_video/modeling_llava_next_video.py#L732-L751
        video_features = self.get_video_features(pixel_values_videos, input_ids)
        if video_features is not None and len(video_features) != 0:
            video_features = [feature.flatten(0, 1) for feature in video_features]
            video_feature_lens = [feature.size(0) for feature in video_features]
            video_features = torch.cat(video_features, dim=0)
            video_feature_lens = torch.tensor(video_feature_lens, dtype=torch.long, device=video_features.device)

            if legacy_processing:
                inputs_embeds, attention_mask, position_ids = self.merge_vision_text_embeddings(
                    video_features,
                    inputs_embeds,
                    video_feature_lens,
                    input_ids,
                    attention_mask,
                    position_ids,
                    legacy_processing,
                    self.config.video_token_index,
                )
            else:
                inputs_embeds = (
                    torch.from_numpy(inputs_embeds) if isinstance(inputs_embeds, np.ndarray) else inputs_embeds
                )
                special_image_mask = (input_ids == self.config.video_token_index).unsqueeze(-1)
                special_image_mask = special_image_mask.expand_as(inputs_embeds)
                if inputs_embeds[special_image_mask].numel() != video_features.numel():
                    n_video_tokens = (input_ids == self.config.video_token_index).sum().item()
                    n_video_features = video_features.shape[0]
                    raise ValueError(
                        f"Video features and video tokens do not match: tokens: {n_video_tokens}, features {n_video_features}"
                    )
                inputs_embeds = inputs_embeds.masked_scatter(special_image_mask, video_features)
        return inputs_embeds, attention_mask, position_ids

    def get_video_features(self, pixel_values, input_ids=None, **kwargs):
        # Adopted from https://github.com/huggingface/transformers/blob/v4.49.0/src/transformers/models/llava_next_video/modeling_llava_next_video.py#L835
        if input_ids is not None and input_ids.shape[1] == 1:
            return None
        batch_size, frames, channels, height, width = pixel_values.shape
        pixel_values = pixel_values.reshape(batch_size * frames, channels, height, width)
        selected_video_features = self.vision_embeddings(pixel_values).last_hidden_state
        video_features = self.vision_resampler(selected_video_features)
        video_features = self.multi_modal_projector(video_features)
        video_features = torch.split(torch.from_numpy(video_features), frames, dim=0)
        return video_features


class _OVMistral3ForCausalLM(OVModelForVisualCausalLM):
    additional_parts = ["multi_modal_projector"]

    def get_vision_embeddings(self, pixel_values, input_ids=None, image_sizes=None, **kwargs):
        if input_ids is not None and input_ids.shape[1] == 1:
            return None

        image_features = self.vision_embeddings(pixel_values).last_hidden_state
        image_features = torch.from_numpy(image_features) if isinstance(image_features, np.ndarray) else image_features

        # Adopted from https://github.com/huggingface/transformers/blob/v5.2.0/src/transformers/models/mistral3/modeling_mistral3.py#L75-L96
        patch_size = self.config.vision_config.patch_size
        spatial_merge_size = self.config.spatial_merge_size
        d = image_features.shape[-1]

        if image_sizes is None:
            # MistralCommonTokenizer, used for checkpoints published in Mistral's own format such as
            # Mistral-Small-3.2-24B-Instruct-2506, returns pixel_values without image_sizes. It does not pad
            # images, so the spatial dimensions of the tensor are the image sizes.
            image_sizes = [pixel_values.shape[-2:]] * pixel_values.shape[0]

        image_sizes_scaled = [(size[0] // patch_size, size[1] // patch_size) for size in image_sizes]
        tokens_per_image = [h * w for h, w in image_sizes_scaled]

        permuted_tensor = []
        for image_index, image_tokens in enumerate(image_features.split(tokens_per_image)):
            h, w = image_sizes_scaled[image_index]
            image_grid = image_tokens.view(h, w, d).permute(2, 0, 1).unsqueeze(0)
            grid = torch.nn.functional.unfold(
                image_grid,
                kernel_size=spatial_merge_size,
                stride=spatial_merge_size,
            )
            grid = grid.view(d * spatial_merge_size**2, -1).t()
            permuted_tensor.append(grid)

        image_features = torch.cat(permuted_tensor, dim=0)
        image_features = self.multi_modal_projector(image_features)

        return image_features

    # Adopted from https://github.com/huggingface/transformers/blob/v5.2.0/src/transformers/models/mistral3/modeling_mistral3.py#L258-L280
    # and https://github.com/huggingface/transformers/blob/v5.2.0/src/transformers/models/mistral3/modeling_mistral3.py#L313-L324
    def merge_vision_text_embeddings(
        self,
        vision_embeds,
        inputs_embeds,
        input_ids=None,
        attention_mask=None,
        position_ids=None,
        **kwargs,
    ):
        image_features = torch.from_numpy(vision_embeds) if isinstance(vision_embeds, np.ndarray) else vision_embeds
        inputs_embeds = torch.from_numpy(inputs_embeds) if isinstance(inputs_embeds, np.ndarray) else inputs_embeds

        special_image_mask = (input_ids == self.config.image_token_id).unsqueeze(-1)
        special_image_mask = special_image_mask.expand_as(inputs_embeds).to(inputs_embeds.device)
        image_features = image_features.to(inputs_embeds.device, inputs_embeds.dtype)
        inputs_embeds = inputs_embeds.masked_scatter(special_image_mask, image_features)

        return inputs_embeds, attention_mask, position_ids

    @staticmethod
    def preprocess_inputs(
        text: str,
        image: Optional["Image"] = None,
        processor: Optional[AutoImageProcessor] = None,
        tokenizer: Optional[PreTrainedTokenizer] = None,
        config: Optional[PretrainedConfig] = None,
        video: Optional["VideoInput"] = None,
        audio: Optional[np.ndarray] = None,
    ):
        if processor is None:
            raise ValueError("Processor is required.")
        if video is not None or audio is not None:
            raise ValueError("Video/Audio input is not supported for Mistral3")

        conversation = [
            {
                "role": "user",
                "content": [{"type": "text", "text": text}],
            }
        ]

        if not hasattr(processor, "image_processor"):
            # Checkpoints published in Mistral's own format, such as Mistral-Small-3.2-24B-Instruct-2506, only
            # provide tekken.json and are loaded as MistralCommonTokenizer. It tokenizes text and images in a
            # single call and accepts images as an URL only, so in-memory images are passed as a data URL.
            if image is not None:
                buffer = io.BytesIO()
                image.convert("RGB").save(buffer, format="PNG")
                image_url = f"data:image/png;base64,{base64.b64encode(buffer.getvalue()).decode()}"
                conversation[0]["content"].insert(0, {"type": "image", "url": image_url})
            return processor.apply_chat_template(conversation, return_dict=True, return_tensors="pt")

        if image is not None:
            conversation[0]["content"].insert(0, {"type": "image"})

        prompt = processor.apply_chat_template(conversation, add_generation_prompt=True)
        inputs = processor(images=image, text=prompt, return_tensors="pt")
        return inputs


class _OVInternVLForCausalLM(OVModelForVisualCausalLM):
    def get_vision_embeddings(self, pixel_values, input_ids=None, **kwargs):
        if input_ids is not None and input_ids.shape[1] == 1:
            return None
        image_features = self.vision_embeddings(pixel_values, **kwargs).last_hidden_state
        return image_features

    def merge_vision_text_embeddings(
        self, vision_embeds, input_embeds, input_ids, attention_mask, position_ids=None, **kwargs
    ):
        input_embeds = torch.from_numpy(input_embeds) if isinstance(input_embeds, np.ndarray) else input_embeds
        vision_embeds = torch.from_numpy(vision_embeds) if isinstance(vision_embeds, np.ndarray) else vision_embeds
        B, N, C = input_embeds.shape
        input_embeds = input_embeds.reshape(B * N, C)

        input_ids = input_ids.reshape(B * N)
        selected = input_ids == self.config.img_context_token_id
        assert selected.sum() != 0
        input_embeds[selected] = vision_embeds.reshape(-1, C)

        input_embeds = input_embeds.reshape(B, N, C)
        return input_embeds, attention_mask, position_ids

    @staticmethod
    def preprocess_inputs(
        text: str,
        image: Optional["Image"] = None,
        processor: Optional[AutoImageProcessor] = None,
        tokenizer: Optional[PreTrainedTokenizer] = None,
        config: Optional[PretrainedConfig] = None,
        video: Optional["VideoInput"] = None,
        audio: Optional[np.ndarray] = None,
    ):
        if tokenizer is None:
            raise ValueError("Tokenizer is required.")
        if video is not None:
            raise ValueError("Video input is not supported")
        if audio is not None:
            raise ValueError("Audio input is not supported")
        import torchvision.transforms as T
        from torchvision.transforms.functional import InterpolationMode

        IMG_START_TOKEN = "<img>"
        IMG_END_TOKEN = "</img>"
        IMG_CONTEXT_TOKEN = "<IMG_CONTEXT>"

        IMAGENET_MEAN = (0.485, 0.456, 0.406)
        IMAGENET_STD = (0.229, 0.224, 0.225)

        def build_transform(input_size):
            MEAN, STD = IMAGENET_MEAN, IMAGENET_STD
            transform = T.Compose(
                [
                    T.Lambda(lambda img: img.convert("RGB") if img.mode != "RGB" else img),
                    T.Resize((input_size, input_size), interpolation=InterpolationMode.BICUBIC),
                    T.ToTensor(),
                    T.Normalize(mean=MEAN, std=STD),
                ]
            )
            return transform

        def find_closest_aspect_ratio(aspect_ratio, target_ratios, width, height, image_size):
            best_ratio_diff = float("inf")
            best_ratio = (1, 1)
            area = width * height
            for ratio in target_ratios:
                target_aspect_ratio = ratio[0] / ratio[1]
                ratio_diff = abs(aspect_ratio - target_aspect_ratio)
                if ratio_diff < best_ratio_diff:
                    best_ratio_diff = ratio_diff
                    best_ratio = ratio
                elif ratio_diff == best_ratio_diff:
                    if area > 0.5 * image_size * image_size * ratio[0] * ratio[1]:
                        best_ratio = ratio
            return best_ratio

        def dynamic_preprocess(image, min_num=1, max_num=12, image_size=28, use_thumbnail=False):
            orig_width, orig_height = image.size
            aspect_ratio = orig_width / orig_height

            # calculate the existing image aspect ratio
            target_ratios = {
                (i, j)
                for n in range(min_num, max_num + 1)
                for i in range(1, n + 1)
                for j in range(1, n + 1)
                if i * j <= max_num and i * j >= min_num
            }
            target_ratios = sorted(target_ratios, key=lambda x: x[0] * x[1])

            # find the closest aspect ratio to the target
            target_aspect_ratio = find_closest_aspect_ratio(
                aspect_ratio, target_ratios, orig_width, orig_height, image_size
            )

            # calculate the target width and height
            target_width = image_size * target_aspect_ratio[0]
            target_height = image_size * target_aspect_ratio[1]
            blocks = target_aspect_ratio[0] * target_aspect_ratio[1]

            # resize the image
            resized_img = image.resize((target_width, target_height))
            processed_images = []
            for i in range(blocks):
                box = (
                    (i % (target_width // image_size)) * image_size,
                    (i // (target_width // image_size)) * image_size,
                    ((i % (target_width // image_size)) + 1) * image_size,
                    ((i // (target_width // image_size)) + 1) * image_size,
                )
                # split the image
                split_img = resized_img.crop(box)
                processed_images.append(split_img)
            assert len(processed_images) == blocks
            if use_thumbnail and len(processed_images) != 1:
                thumbnail_img = image.resize((image_size, image_size))
                processed_images.append(thumbnail_img)
            return processed_images

        def load_image(image, input_size=448, max_num=12):
            transform = build_transform(input_size=input_size)
            images = dynamic_preprocess(image, image_size=input_size, use_thumbnail=True, max_num=max_num)
            pixel_values = [transform(image) for image in images]
            pixel_values = torch.stack(pixel_values)
            return pixel_values

        if image is not None and "<image>" not in text:
            text = "<image>\n" + text

        if tokenizer.chat_template is not None:
            text = tokenizer.apply_chat_template(
                [{"role": "user", "content": text}], add_generation_prompt=True, tokenize=False
            )

        inputs = {}

        if image is not None:
            if config is None:
                raise ValueError("Config is required.")
            pixel_values = load_image(image, input_size=config.vision_config.image_size)
            num_patches = pixel_values.shape[0]
            num_image_token = int(
                (config.vision_config.image_size // config.vision_config.patch_size) ** 2
                * (config.downsample_ratio**2)
            )
            image_tokens = IMG_START_TOKEN + IMG_CONTEXT_TOKEN * num_image_token * num_patches + IMG_END_TOKEN
            text = text.replace("<image>", image_tokens, 1)
            inputs.update({"pixel_values": pixel_values})
        inputs.update(tokenizer(text, return_tensors="pt"))
        return inputs

    # internvl has issue with check  _get_non_default_parameters, as workaround override _prepare_generation_config
    def _prepare_generation_config(
        self, generation_config: Optional[GenerationConfig], use_model_defaults: Optional[bool] = None, **kwargs: Dict
    ) -> Tuple[GenerationConfig, Dict]:
        using_model_generation_config = False
        if generation_config is None:
            if (
                self.generation_config._from_model_config  # 1)
                and self.generation_config._original_object_hash == hash(self.generation_config)  # 2)
            ):
                new_generation_config = GenerationConfig.from_model_config(self.config)
                if new_generation_config != self.generation_config:  # 4)
                    warnings.warn(
                        "You have modified the pretrained model configuration to control generation. This is a"
                        " deprecated strategy to control generation and will be removed in v5."
                        " Please use and modify the model generation configuration (see"
                        " https://huggingface.co/docs/transformers/generation_strategies#default-text-generation-configuration )",
                        UserWarning,
                    )
                    self.generation_config = new_generation_config

            generation_config = self.generation_config
            using_model_generation_config = True

        generation_config = copy.deepcopy(generation_config)
        model_kwargs = generation_config.update(**kwargs)
        # If `generation_config` is provided, let's fallback ALL special tokens to the default values for the model
        if not using_model_generation_config:
            if generation_config.bos_token_id is None:
                generation_config.bos_token_id = self.generation_config.bos_token_id
            if generation_config.eos_token_id is None:
                generation_config.eos_token_id = self.generation_config.eos_token_id
            if generation_config.pad_token_id is None:
                generation_config.pad_token_id = self.generation_config.pad_token_id
            if generation_config.decoder_start_token_id is None:
                generation_config.decoder_start_token_id = self.generation_config.decoder_start_token_id

        return generation_config, model_kwargs


class _OVMiniCPMVForCausalLM(OVModelForVisualCausalLM):
    additional_parts = ["resampler"]

    def __init__(
        self,
        language_model: ov.Model,
        text_embeddings: ov.Model,
        vision_embeddings: ov.Model,
        config: PretrainedConfig = None,
        device: str = "CPU",
        dynamic_shapes: bool = None,
        ov_config: Optional[Dict[str, str]] = None,
        model_save_dir: Optional[Union[str, Path, TemporaryDirectory]] = None,
        quantization_config: Union[OVWeightQuantizationConfig, Dict] = None,
        **kwargs,
    ):
        super().__init__(
            language_model=language_model,
            text_embeddings=text_embeddings,
            vision_embeddings=vision_embeddings,
            config=config,
            device=device,
            dynamic_shapes=dynamic_shapes,
            ov_config=ov_config,
            model_save_dir=model_save_dir,
            quantization_config=quantization_config,
            **kwargs,
        )

        self.embed_dim = self.language_model.config.hidden_size
        max_size = self.config.vision_config.image_size // self.config.vision_config.patch_size
        self._pos_embeds = torch.from_numpy(self._get_2d_sincos_pos_embed(self.embed_dim, max_size)).float()
        self.max_size = (max_size, max_size)

    def get_vision_embeddings(self, pixel_values, input_ids=None, **kwargs):
        if input_ids is not None and input_ids.shape[1] == 1:
            return None
        tgt_sizes = kwargs["tgt_sizes"]
        pixel_values_list = pixel_values
        vision_hidden_states = []
        all_pixel_values = []
        img_cnt = []
        for pixel_value in pixel_values_list:
            img_cnt.append(len(pixel_value))
            all_pixel_values.extend([i.flatten(end_dim=1).permute(1, 0) for i in pixel_value])

        vision_embedding = None
        # exist image
        if all_pixel_values:
            tgt_sizes = [tgt_size for tgt_size in tgt_sizes if isinstance(tgt_size, torch.Tensor)]
            tgt_sizes = torch.vstack(tgt_sizes).type(torch.int32)

            max_patches = torch.max(tgt_sizes[:, 0] * tgt_sizes[:, 1])

            all_pixel_values = torch.nn.utils.rnn.pad_sequence(all_pixel_values, batch_first=True, padding_value=0.0)
            B, L, _ = all_pixel_values.shape
            all_pixel_values = all_pixel_values.permute(0, 2, 1).reshape(B, 3, -1, L)

            patch_attn_mask = torch.zeros((B, 1, max_patches), dtype=torch.bool)
            for i in range(B):
                patch_attn_mask[i, 0, : tgt_sizes[i][0] * tgt_sizes[i][1]] = True
            position_ids = self._prepare_vis_position_ids(
                all_pixel_values,
                patch_attn_mask,
                tgt_sizes,
                self.config.vision_config.patch_size,
                self.config.vision_config.image_size // self.config.patch_size,
            )
            vision_embedding = torch.from_numpy(
                self.vision_embeddings(
                    pixel_values=all_pixel_values, patch_attention_mask=patch_attn_mask, position_ids=position_ids
                )[0]
            )
            vision_embedding = self.resampling(vision_embedding, tgt_sizes)

            start = 0
            for pixel_value in pixel_values_list:
                img_cnt = len(pixel_value)
                if img_cnt > 0:
                    vision_hidden_states.append(vision_embedding[start : start + img_cnt])
                    start += img_cnt
                else:
                    vision_hidden_states.append([])
        else:  # no image
            dummy_feature = []
            for _ in range(len(pixel_values_list)):
                vision_hidden_states.append(dummy_feature)
        return vision_hidden_states

    def resampling(self, x, tgt_sizes):
        bs = x.shape[0]

        patch_len = tgt_sizes[:, 0] * tgt_sizes[:, 1]

        self._adjust_pos_cache(tgt_sizes)

        max_patch_len = torch.max(patch_len)
        key_padding_mask = torch.zeros((bs, max_patch_len), dtype=torch.bool)

        pos_embed = []
        for i in range(bs):
            tgt_h, tgt_w = tgt_sizes[i]
            pos_embed.append(self._pos_embeds[:tgt_h, :tgt_w, :].reshape((tgt_h * tgt_w, -1)))  # patches * D
            key_padding_mask[i, patch_len[i] :] = True

        pos_embed = torch.nn.utils.rnn.pad_sequence(pos_embed, batch_first=True, padding_value=0.0).permute(
            1, 0, 2
        )  # BLD => L * B * D
        res = torch.from_numpy(self.resampler(image_feature=x, pos_embed=pos_embed, key_padding_mask=key_padding_mask))
        return res

    def _set_2d_pos_cache(self, max_size):
        pos_embed = torch.from_numpy(self._get_2d_sincos_pos_embed(self.embed_dim, max_size)).float()
        self._pos_embeds = pos_embed

    def _adjust_pos_cache(self, tgt_sizes):
        max_h = torch.max(tgt_sizes[:, 0])
        max_w = torch.max(tgt_sizes[:, 1])
        if max_h > self.max_size[0] or max_w > self.max_size[1]:
            self.max_size = [max(max_h, self.max_size[0]), max(max_w, self.max_size[1])]
            self._set_2d_pos_cache(self.max_size)

    def _get_2d_sincos_pos_embed(self, embed_dim, image_size):
        """
        image_size: image_size or (image_height, image_width)
        return:
        pos_embed: [image_height, image_width, embed_dim]
        """
        if isinstance(image_size, int):
            grid_h_size, grid_w_size = image_size, image_size
        else:
            grid_h_size, grid_w_size = image_size[0], image_size[1]

        grid_h = np.arange(grid_h_size, dtype=np.float32)
        grid_w = np.arange(grid_w_size, dtype=np.float32)
        grid = np.meshgrid(grid_w, grid_h)  # here w goes first
        grid = np.stack(grid, axis=0)

        pos_embed = self._get_2d_sincos_pos_embed_from_grid(embed_dim, grid)
        return pos_embed

    def _get_2d_sincos_pos_embed_from_grid(self, embed_dim, grid):
        assert embed_dim % 2 == 0

        # use half of dimensions to encode grid_h
        emb_h = self._get_1d_sincos_pos_embed_from_grid_new(embed_dim // 2, grid[0])  # (H, W, D/2)
        emb_w = self._get_1d_sincos_pos_embed_from_grid_new(embed_dim // 2, grid[1])  # (H, W, D/2)

        emb = np.concatenate([emb_h, emb_w], axis=-1)  # (H, W, D)
        return emb

    def _get_1d_sincos_pos_embed_from_grid_new(self, embed_dim, pos):
        """
        embed_dim: output dimension for each position
        pos: a list of positions to be encoded: size (H, W)
        out: (H, W, D)
        """
        assert embed_dim % 2 == 0
        omega = np.arange(embed_dim // 2, dtype=np.float32)
        omega /= embed_dim / 2.0
        omega = 1.0 / 10000**omega  # (D/2,)

        out = np.einsum("hw,d->hwd", pos, omega)  # (H, W, D/2), outer product

        emb_sin = np.sin(out)  # (H, W, D/2)
        emb_cos = np.cos(out)  # (H, W, D/2)

        emb = np.concatenate([emb_sin, emb_cos], axis=-1)  # (H, W, D)
        return emb

    def _prepare_vis_position_ids(
        self, pixel_values, patch_attention_mask, tgt_sizes, patch_size, num_patches_per_side
    ):
        batch_size = pixel_values.size(0)
        max_im_h, max_im_w = pixel_values.size(2), pixel_values.size(3)
        max_nb_patches_h, max_nb_patches_w = max_im_h // patch_size, max_im_w // patch_size
        boundaries = torch.arange(1 / num_patches_per_side, 1.0, 1 / num_patches_per_side)
        position_ids = torch.full(size=(batch_size, max_nb_patches_h * max_nb_patches_w), fill_value=0)

        for batch_idx, p_attn_mask in enumerate(patch_attention_mask):
            if tgt_sizes is not None:
                nb_patches_h = tgt_sizes[batch_idx][0]
                nb_patches_w = tgt_sizes[batch_idx][1]
            else:
                nb_patches_h = p_attn_mask[:, 0].sum()
                nb_patches_w = p_attn_mask[0].sum()

            fractional_coords_h = torch.arange(0, 1 - 1e-6, 1 / nb_patches_h)
            fractional_coords_w = torch.arange(0, 1 - 1e-6, 1 / nb_patches_w)

            bucket_coords_h = torch.bucketize(fractional_coords_h, boundaries, right=True)
            bucket_coords_w = torch.bucketize(fractional_coords_w, boundaries, right=True)

            pos_ids = (bucket_coords_h[:, None] * num_patches_per_side + bucket_coords_w).flatten()
            position_ids[batch_idx][p_attn_mask.view(-1).cpu()] = pos_ids

        return position_ids

    def merge_vision_text_embeddings(
        self, vision_embeds, input_embeds, input_ids, attention_mask, position_ids=None, **kwargs
    ):
        bs = input_ids.shape[0]
        image_bound = kwargs["image_bound"]
        vllm_embedding = torch.from_numpy(input_embeds)
        for i in range(bs):
            cur_vs_hs = vision_embeds[i]
            if len(cur_vs_hs) > 0:
                cur_vllm_emb = vllm_embedding[i]
                cur_image_bound = image_bound[i]
                if len(cur_image_bound) > 0:
                    image_indices = torch.stack([torch.arange(r[0], r[1], dtype=torch.long) for r in cur_image_bound])

                    cur_vllm_emb.scatter_(
                        0,
                        image_indices.view(-1, 1).repeat(1, cur_vllm_emb.shape[-1]),
                        cur_vs_hs.view(-1, cur_vs_hs.shape[-1]),
                    )
        return vllm_embedding, attention_mask, position_ids

    @staticmethod
    def preprocess_inputs(
        text: str,
        image: Optional["Image"] = None,
        processor: Optional[AutoImageProcessor] = None,
        tokenizer: Optional[PreTrainedTokenizer] = None,
        config: Optional[PretrainedConfig] = None,
        video: Optional["VideoInput"] = None,
        audio: Optional[np.ndarray] = None,
    ):
        if processor is None:
            raise ValueError("Processor is required.")
        if video is not None:
            raise ValueError("Video input is not supported")
        if audio is not None:
            raise ValueError("Audio input is not supported")
        if getattr(processor, "chat_template", None) is not None:
            messages = [{"role": "user", "content": text if image is None else "(<image>./</image>)\n" + text}]
            prompt = processor.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
        else:
            prompt = (
                f"<|im_start|>user\n(<image>./</image>)\n{text}<|im_end|>\n<|im_start|>assistant\n"
                if image is not None
                else text
            )
        inputs = processor([prompt], [image], return_tensors="pt")
        inputs.pop("image_sizes", None)
        return inputs


class _OVMiniCPMOForCausalLM(_OVMiniCPMVForCausalLM):
    def prepare_inputs_for_generation(
        self,
        input_ids,
        past_key_values=None,
        inputs_embeds=None,
        pixel_values=None,
        image_sizes=None,
        attention_mask=None,
        audio_bounds=None,
        spk_bounds=None,
        audio_features=None,
        audio_feature_lens=None,
        **kwargs,
    ):
        # Audio modality is not supported for MiniCPMO
        if audio_features is not None and len(audio_features) > 0:
            raise ValueError("Audio input is not supported for MiniCPMO")

        return super().prepare_inputs_for_generation(
            input_ids=input_ids,
            past_key_values=past_key_values,
            inputs_embeds=inputs_embeds,
            pixel_values=pixel_values,
            image_sizes=image_sizes,
            attention_mask=attention_mask,
            **kwargs,
        )

    @staticmethod
    def preprocess_inputs(
        text: str,
        image: Optional["Image"] = None,
        processor: Optional[AutoImageProcessor] = None,
        tokenizer: Optional[PreTrainedTokenizer] = None,
        config: Optional[PretrainedConfig] = None,
        video: Optional["VideoInput"] = None,
        audio: Optional[np.ndarray] = None,
    ):
        if processor is None:
            raise ValueError("Processor is required.")
        if video is not None:
            raise ValueError("Video input is not supported")
        if audio is not None:
            raise ValueError("Audio input is not supported")
        messages = [{"role": "user", "content": text if image is None else "(<image>./</image>)\n" + text}]
        prompt = processor.tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
        inputs = processor([prompt], [image], return_tensors="pt")
        inputs.pop("image_sizes", None)
        return inputs


class _OVNanoLlavaForCausalLM(OVModelForVisualCausalLM):
    def get_vision_embeddings(self, pixel_values, input_ids=None, **kwargs):
        if input_ids is not None and input_ids.shape[1] == 1:
            return None
        if isinstance(pixel_values, list) or pixel_values.ndim == 5:
            concat_images = torch.cat(pixel_values, dim=0) if isinstance(pixel_values, list) else pixel_values
            image_features = torch.from_numpy(self.vision_embeddings(concat_images).last_hidden_state)
            split_sizes = [image.shape[0] for image in pixel_values]
            image_features = torch.split(image_features, split_sizes, dim=0)
            image_features = [x.flatten(0, 1).to(self.device) for x in image_features]
        else:
            image_features = self.vision_embeddings(pixel_values).last_hidden_state

        return image_features

    def get_multimodal_embeddings(
        self, input_ids, pixel_values=None, attention_mask=None, position_ids=None, **kwargs
    ):
        vision_embeds = None
        IGNORE_INDEX = -100
        IMAGE_TOKEN_INDEX = -200
        if pixel_values is None and "images" in kwargs:
            pixel_values = kwargs["images"]
        if pixel_values is not None:
            vision_embeds = self.get_vision_embeddings(pixel_values, input_ids=input_ids, **kwargs)
        if vision_embeds is None:
            inputs_embeds = torch.from_numpy(self.get_text_embeddings(input_ids))
            past_len = self.language_model._get_past_length(kwargs.get("past_key_values"))
            if attention_mask is not None and attention_mask.shape[1] < past_len + input_ids.shape[1]:
                attention_mask = torch.cat(
                    [
                        attention_mask,
                        torch.ones(attention_mask.shape[0], past_len + input_ids.shape[1] - attention_mask.shape[1]),
                    ],
                    dim=1,
                )
                position_ids = None
            return inputs_embeds, attention_mask, position_ids

        vision_embeds = torch.from_numpy(vision_embeds) if isinstance(vision_embeds, np.ndarray) else vision_embeds

        if attention_mask is None:
            attention_mask = torch.ones_like(input_ids, dtype=torch.long)
        if position_ids is None:
            position_ids = torch.arange(0, input_ids.shape[1], dtype=torch.long, device=input_ids.device)
        labels = torch.full_like(input_ids, IGNORE_INDEX)

        # remove the padding using attention_mask -- TODO: double check
        input_ids = [
            cur_input_ids[cur_attention_mask]
            for cur_input_ids, cur_attention_mask in zip(input_ids, attention_mask.bool())
        ]
        labels = [
            cur_labels[cur_attention_mask] for cur_labels, cur_attention_mask in zip(labels, attention_mask.bool())
        ]

        new_input_embeds = []
        new_labels = []
        cur_image_idx = 0
        for batch_idx, cur_input_ids in enumerate(input_ids):
            num_images = (cur_input_ids == IMAGE_TOKEN_INDEX).sum()
            if num_images == 0:
                cur_image_features = vision_embeds[cur_image_idx]
                cur_input_embeds_1 = torch.from_numpy(self.get_text_embeddings(cur_input_ids.unsqueeze(0))[0])
                cur_input_embeds = torch.cat([cur_input_embeds_1, cur_image_features[0:0]], dim=0)
                new_input_embeds.append(cur_input_embeds)
                new_labels.append(labels[batch_idx])
                cur_image_idx += 1
                continue

            image_token_indices = (
                [-1] + torch.where(cur_input_ids == IMAGE_TOKEN_INDEX)[0].tolist() + [cur_input_ids.shape[0]]
            )
            cur_input_ids_noim = []
            cur_labels = labels[batch_idx]
            cur_labels_noim = []
            for i in range(len(image_token_indices) - 1):
                cur_input_ids_noim.append(cur_input_ids[image_token_indices[i] + 1 : image_token_indices[i + 1]])
                cur_labels_noim.append(cur_labels[image_token_indices[i] + 1 : image_token_indices[i + 1]])
            split_sizes = [x.shape[0] for x in cur_labels_noim]
            cur_input_embeds = torch.from_numpy(
                self.get_text_embeddings(torch.cat(cur_input_ids_noim).unsqueeze(0))[0]
            )
            cur_input_embeds_no_im = torch.split(cur_input_embeds, split_sizes, dim=0)
            cur_new_input_embeds = []
            cur_new_labels = []

            for i in range(num_images + 1):
                cur_new_input_embeds.append(cur_input_embeds_no_im[i])
                cur_new_labels.append(cur_labels_noim[i])
                if i < num_images:
                    cur_image_features = vision_embeds[cur_image_idx]
                    cur_image_idx += 1
                    cur_new_input_embeds.append(cur_image_features)
                    cur_new_labels.append(
                        torch.full(
                            (cur_image_features.shape[0],),
                            IGNORE_INDEX,
                            device=cur_labels.device,
                            dtype=cur_labels.dtype,
                        )
                    )

            cur_new_input_embeds = torch.cat(cur_new_input_embeds)
            cur_new_labels = torch.cat(cur_new_labels)

            new_input_embeds.append(cur_new_input_embeds)
            new_labels.append(cur_new_labels)

        # Truncate sequences to max length as image embeddings can make the sequence longer
        tokenizer_model_max_length = getattr(self.config, "tokenizer_model_max_length", None)
        if tokenizer_model_max_length is not None:
            new_input_embeds = [x[:tokenizer_model_max_length] for x in new_input_embeds]
            new_labels = [x[:tokenizer_model_max_length] for x in new_labels]

        # Combine them
        max_len = max(x.shape[0] for x in new_input_embeds)
        batch_size = len(new_input_embeds)

        new_input_embeds_padded = []
        new_labels_padded = torch.full(
            (batch_size, max_len), IGNORE_INDEX, dtype=new_labels[0].dtype, device=new_labels[0].device
        )
        attention_mask = torch.zeros((batch_size, max_len), dtype=attention_mask.dtype, device=attention_mask.device)
        position_ids = torch.zeros((batch_size, max_len), dtype=position_ids.dtype, device=position_ids.device)

        for i, (cur_new_embed, cur_new_labels) in enumerate(zip(new_input_embeds, new_labels)):
            cur_len = cur_new_embed.shape[0]
            if getattr(self.config, "tokenizer_padding_side", "right") == "left":
                new_input_embeds_padded.append(
                    torch.cat(
                        (
                            torch.zeros(
                                (max_len - cur_len, cur_new_embed.shape[1]),
                                dtype=cur_new_embed.dtype,
                                device=cur_new_embed.device,
                            ),
                            cur_new_embed,
                        ),
                        dim=0,
                    )
                )
                if cur_len > 0:
                    new_labels_padded[i, -cur_len:] = cur_new_labels
                    attention_mask[i, -cur_len:] = True
                    position_ids[i, -cur_len:] = torch.arange(
                        0, cur_len, dtype=position_ids.dtype, device=position_ids.device
                    )
            else:
                new_input_embeds_padded.append(
                    torch.cat(
                        (
                            cur_new_embed,
                            torch.zeros(
                                (max_len - cur_len, cur_new_embed.shape[1]),
                                dtype=cur_new_embed.dtype,
                                device=cur_new_embed.device,
                            ),
                        ),
                        dim=0,
                    )
                )
                if cur_len > 0:
                    new_labels_padded[i, :cur_len] = cur_new_labels
                    attention_mask[i, :cur_len] = True
                    position_ids[i, :cur_len] = torch.arange(
                        0, cur_len, dtype=position_ids.dtype, device=position_ids.device
                    )

        new_input_embeds = torch.stack(new_input_embeds_padded, dim=0)

        return new_input_embeds, attention_mask, position_ids

    @staticmethod
    def preprocess_inputs(
        text: str,
        image: Optional["Image"] = None,
        processor: Optional[AutoImageProcessor] = None,
        tokenizer: Optional[PreTrainedTokenizer] = None,
        config: Optional[PretrainedConfig] = None,
        video: Optional["VideoInput"] = None,
        audio: Optional[np.ndarray] = None,
    ):
        if tokenizer is None:
            raise ValueError("Tokenizer is required.")
        if video is not None:
            raise ValueError("Video input is not supported")
        if audio is not None:
            raise ValueError("Audio input is not supported")
        if image is not None and processor is None:
            raise ValueError("Processor is required.")
        text = f"<image>\n{text}" if image is not None else text
        messages = [{"role": "user", "content": text}]
        if tokenizer.chat_template is not None:
            text = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
        if image is not None:
            text_chunks = [tokenizer(chunk).input_ids for chunk in text.split("<image>")]
            input_ids = torch.tensor(text_chunks[0] + [-200] + text_chunks[1], dtype=torch.long).unsqueeze(0)
        else:
            input_ids = tokenizer(text, return_tensors="pt").input_ids
        attention_mask = torch.ones_like(input_ids, dtype=torch.int64)
        result = {"input_ids": input_ids, "attention_mask": attention_mask}

        if image is not None:
            result["images"] = processor(images=[image], return_tensors="pt")["pixel_values"]
        return result


class _OVPhi3VisionForCausalLM(OVModelForVisualCausalLM):
    additional_parts = ["vision_projection"]

    def __init__(
        self,
        language_model: ov.Model,
        text_embeddings: ov.Model,
        vision_embeddings: ov.Model,
        config: PretrainedConfig = None,
        device: str = "CPU",
        dynamic_shapes: bool = None,
        ov_config: Optional[Dict[str, str]] = None,
        model_save_dir: Optional[Union[str, Path, TemporaryDirectory]] = None,
        quantization_config: Union[OVWeightQuantizationConfig, Dict] = None,
        **kwargs,
    ):
        super().__init__(
            language_model=language_model,
            text_embeddings=text_embeddings,
            vision_embeddings=vision_embeddings,
            config=config,
            device=device,
            dynamic_shapes=dynamic_shapes,
            ov_config=ov_config,
            model_save_dir=model_save_dir,
            quantization_config=quantization_config,
            **kwargs,
        )

        self.sub_GN = torch.tensor(self.config.sub_GN)
        self.glb_GN = torch.tensor(self.config.glb_GN)
        self.image_dim_out = self.config.img_processor["image_dim_out"]

    def get_vision_embeddings(self, pixel_values, image_sizes, **kwargs):
        num_images, num_crops, c, h, w = pixel_values.shape
        img_features = self.vision_embeddings(pixel_values.flatten(0, 1)).last_hidden_state.reshape(
            num_images, num_crops, -1, self.image_dim_out
        )
        image_features_proj = self.hd_feature_transform(img_features, image_sizes)
        return image_features_proj

    def hd_feature_transform(self, image_features, image_sizes):
        """
        image_features: (num_images, num_crops+1, 24*24, 1024)
        """

        image_features = torch.from_numpy(image_features)
        global_image_features = image_features[:, 0]  # (num_images, 24*24, 1024)
        # global feature can be viewed as a special HD case with num_crops 1x1
        global_image_features_hd = self.reshape_hd_patches_2x2merge(global_image_features, 1, 1)
        global_image_features_hd_newline = self.add_image_newline(global_image_features_hd)

        all_image_embeddings = []
        # need a for loop to process each image because of different image sizes
        # (patch arrangement is different for each image)
        for i, img_size in enumerate(image_sizes):
            h, w = img_size
            h_crop = h // 336
            w_crop = w // 336
            num_crops = h_crop * w_crop

            # NOTE: real num_crops is padded
            # (num_crops, 24*24, 1024)
            sub_image_features = image_features[i, 1 : 1 + num_crops]
            sub_image_features_hd = self.reshape_hd_patches_2x2merge(sub_image_features, h_crop, w_crop)
            sub_image_features_hd_newline = self.add_image_newline(sub_image_features_hd)

            # [sub features, separator, global features]
            all_image_embeddings.extend(
                [
                    sub_image_features_hd_newline.squeeze(0),  # (h_crop*12*(w_crop*12+1), 4096)
                    self.glb_GN.squeeze(0),
                    global_image_features_hd_newline[i],
                ]
            )
        image_features_proj = self.vision_projection(torch.cat(all_image_embeddings, dim=0).unsqueeze(0))[0]

        return image_features_proj

    def reshape_hd_patches_2x2merge(self, image_features, h_crop, w_crop):
        """
        image_features: (num_images*num_crops, 24*24, 1024)
        output: (num_images, h_crop*12, w_crop*12, 4096), h_crop*w_crop == num_crops
        """
        N, L, C = image_features.shape
        assert L == 24 * 24 and C == 1024 and N % (h_crop * w_crop) == 0
        num_images = N // (h_crop * w_crop)
        H = int(L**0.5)
        image_features_hd = (
            image_features.reshape(N, H, H, C)  # N, 24, 24, 1024
            .reshape(N, H // 2, 2, H // 2, 2, C)  # N, 12, 2, 12, 2, 1024
            .permute(0, 1, 3, 2, 4, 5)  # N, 12, 12, 2, 2, 1024
            .reshape(N, -1, 4 * C)  # N, 144, 4096
            .reshape(num_images, h_crop, w_crop, H // 2, H // 2, -1)  # n_img, h_crop, w_crop, 12, 12, 4096
            .permute(0, 1, 3, 2, 4, 5)  # n_img, h_crop, 12, w_crop, 12, 4096
            .reshape(num_images, h_crop * H // 2, w_crop * H // 2, 4 * C)  # n_img, h_crop*12, w_crop*12, 4096
        )

        return image_features_hd

    def add_image_newline(self, image_features_hd):
        """
        image_features_hd: (num_images, h_crop*12, w_crop*12, 4096)
        output: (num_images, (h_crop*12) * (w_crop*12+1), 4096)
        """
        num_images, h, w, hid_dim = image_features_hd.shape
        # add the newline token to the HD image feature patches
        newline_embeddings = self.sub_GN.expand(num_images, h, -1, -1)  # (n_img, h, 1, hid_dim)
        image_features_hd_newline = torch.cat([image_features_hd, newline_embeddings], dim=2).reshape(
            num_images, -1, hid_dim
        )
        return image_features_hd_newline

    def get_multimodal_embeddings(
        self, input_ids, pixel_values=None, attention_mask=None, position_ids=None, image_sizes=None, **kwargs
    ):
        MAX_INPUT_ID = int(1e9)
        input_shape = input_ids.size()
        input_ids = input_ids.view(-1, input_shape[-1])

        # positions for image tokens
        positions = torch.nonzero((input_ids < 0) & (input_ids > -MAX_INPUT_ID), as_tuple=True)
        has_image = len(positions[0].tolist()) > 0
        input_ids = input_ids.clamp_min(0).clamp_max(self.config.vocab_size)
        inputs_embeds = torch.from_numpy(self.get_text_embeddings(input_ids, **kwargs))
        if has_image:
            vision_embeds = self.get_vision_embeddings(
                pixel_values, input_ids=input_ids, image_sizes=image_sizes, **kwargs
            )
            image_features_proj = torch.from_numpy(vision_embeds)
            inputs_embeds = inputs_embeds.index_put(positions, image_features_proj, accumulate=False)

        return inputs_embeds, attention_mask, position_ids

    @staticmethod
    def preprocess_inputs(
        text: str,
        image: Optional["Image"] = None,
        processor: Optional[AutoImageProcessor] = None,
        tokenizer: Optional[PreTrainedTokenizer] = None,
        config: Optional[PretrainedConfig] = None,
        video: Optional["VideoInput"] = None,
        audio: Optional[np.ndarray] = None,
    ):
        if processor is None:
            raise ValueError("Processor is required.")
        if video is not None:
            raise ValueError("Video input is not supported")
        if audio is not None:
            raise ValueError("Audio input is not supported")
        if image is not None and "<|image_1|>" not in text:
            text = "<|image_1|>\n" + text
        if getattr(processor.tokenizer, "chat_template", None) is not None:
            chat_prompt = [{"role": "user", "content": text}]
            text = processor.tokenizer.apply_chat_template(chat_prompt, add_generation_prompt=True, tokenize=False)
        inputs = processor(images=image, text=text, return_tensors="pt")
        return inputs


@dataclass
class QWen2VLModelOutputWithPast(ModelOutput):
    loss: Optional[torch.FloatTensor] = None
    logits: torch.FloatTensor = None
    past_key_values: Optional[Tuple[Tuple[torch.FloatTensor]]] = None
    hidden_states: Optional[Tuple[torch.FloatTensor, ...]] = None
    attentions: Optional[Tuple[torch.FloatTensor, ...]] = None
    rope_deltas: Optional[torch.FloatTensor] = None
    second_per_grid_ts: Optional[torch.FloatTensor] = None


class _OVQwen2VLForCausalLM(OVModelForVisualCausalLM):
    additional_parts = ["vision_embeddings_merger"]

    def __init__(
        self,
        language_model: ov.Model,
        text_embeddings: ov.Model,
        vision_embeddings: ov.Model,
        config: PretrainedConfig = None,
        device: str = "CPU",
        dynamic_shapes: bool = None,
        ov_config: Optional[Dict[str, str]] = None,
        model_save_dir: Optional[Union[str, Path, TemporaryDirectory]] = None,
        quantization_config: Union[OVWeightQuantizationConfig, Dict] = None,
        **kwargs,
    ):
        if is_transformers_version("<", "4.57"):
            raise Exception("Qwen2VL is not supported in transformers versions earlier than 4.57.")

        super().__init__(
            language_model=language_model,
            text_embeddings=text_embeddings,
            vision_embeddings=vision_embeddings,
            config=config,
            device=device,
            dynamic_shapes=dynamic_shapes,
            ov_config=ov_config,
            model_save_dir=model_save_dir,
            quantization_config=quantization_config,
            **kwargs,
        )
        self.rope_deltas = None  # cache rope_deltas here
        self._rotary_pos_emb = VisionRotaryEmbedding(
            self.config.vision_config.embed_dim // self.config.vision_config.num_heads // 2
        )

    def prepare_inputs_for_generation(
        self,
        input_ids,
        past_key_values=None,
        attention_mask=None,
        inputs_embeds=None,
        cache_position=None,
        position_ids=None,
        use_cache=True,
        pixel_values=None,
        pixel_values_videos=None,
        image_grid_thw=None,
        video_grid_thw=None,
        mm_token_type_ids=None,
        is_first_iteration=False,
        next_sequence_length=None,
        **kwargs,
    ):
        # reconstruct cache_position as partially removed in v5.3 and totally removed in v5.5
        if is_transformers_version(">=", "5.3") and (
            cache_position is None or (not is_first_iteration and cache_position[0] == 0)
        ):
            if next_sequence_length is not None:
                past_len = input_ids.shape[1] - next_sequence_length
                cache_position = torch.arange(past_len, past_len + next_sequence_length, device=input_ids.device)
            elif not is_first_iteration and attention_mask is not None:
                # v5.3 decode step: input_ids is already sliced to 1 token, use attention_mask length
                past_len = attention_mask.shape[1] - 1
                cache_position = torch.tensor([past_len], device=input_ids.device)
            else:
                cache_position = torch.arange(input_ids.shape[1], device=input_ids.device)

        # Overwritten -- in specific circumstances we don't want to forward image inputs to the model
        if past_key_values is not None:
            if inputs_embeds is not None and input_ids.shape[1] == 0:  # Exception 4
                inputs_embeds = inputs_embeds[:, -cache_position.shape[0] :]
            elif inputs_embeds is not None:
                input_ids = input_ids[:, -cache_position.shape[0] :]
            elif input_ids.shape[1] != cache_position.shape[0]:  # Default case (the "else", a no op, is Exception 2)
                input_ids = input_ids[:, cache_position]

        if cache_position[0] != 0:
            pixel_values = None
            pixel_values_videos = None

        # if `inputs_embeds` are passed, we only want to use them in the 1st generation step
        if inputs_embeds is not None and len(cache_position) == inputs_embeds.shape[1]:
            model_inputs = {"inputs_embeds": inputs_embeds, "input_ids": None}
        else:
            model_inputs = {"input_ids": input_ids, "inputs_embeds": None}

        model_inputs.update(
            {
                "position_ids": position_ids,
                "past_key_values": past_key_values,
                "use_cache": use_cache,
                "attention_mask": attention_mask,
                "pixel_values": pixel_values,
                "pixel_values_videos": pixel_values_videos,
                "image_grid_thw": image_grid_thw,
                "video_grid_thw": video_grid_thw,
                "cache_position": cache_position,
                "mm_token_type_ids": mm_token_type_ids,
            }
        )
        return model_inputs

    # Copied from https://github.com/huggingface/transformers/blob/v4.45.2/src/transformers/models/qwen2_vl/modeling_qwen2_vl.py#L1602
    def _update_model_kwargs_for_generation(
        self,
        outputs: ModelOutput,
        model_kwargs: Dict[str, Any],
        is_encoder_decoder: bool = False,
        num_new_tokens: int = 1,
    ) -> Dict[str, Any]:
        model_kwargs = super()._update_model_kwargs_for_generation(
            outputs=outputs,
            model_kwargs=model_kwargs,
            is_encoder_decoder=is_encoder_decoder,
            num_new_tokens=num_new_tokens,
        )

        if getattr(outputs, "rope_deltas", None) is not None:
            model_kwargs["rope_deltas"] = outputs.rope_deltas

        return model_kwargs

    def get_vision_embeddings(self, pixel_values, grid_thw, **kwargs):
        hidden_states = self.vision_embeddings(pixel_values)[0]
        rotary_pos_emb = self.rot_pos_emb(grid_thw)
        cu_seqlens = torch.repeat_interleave(grid_thw[:, 1] * grid_thw[:, 2], grid_thw[:, 0]).cumsum(
            dim=0, dtype=torch.int32
        )
        cu_seqlens = torch.nn.functional.pad(cu_seqlens, (1, 0), value=0)
        attention_mask = torch.zeros((1, hidden_states.shape[0], hidden_states.shape[0]), dtype=torch.bool)
        causal_mask = torch.zeros_like(attention_mask, dtype=torch.float32)
        for i in range(1, len(cu_seqlens)):
            attention_mask[..., cu_seqlens[i - 1] : cu_seqlens[i], cu_seqlens[i - 1] : cu_seqlens[i]] = True

        causal_mask.masked_fill_(torch.logical_not(attention_mask), float("-inf"))

        res = self.vision_embeddings_merger(
            pixel_values=hidden_states, attention_mask=causal_mask, rotary_pos_emb=rotary_pos_emb
        )[0]
        return res

    # Adopted from https://github.com/huggingface/transformers/blob/v4.45.2/src/transformers/models/qwen2_vl/modeling_qwen2_vl.py#L1089
    # Use config values instead of model attributes, replace self.rotary_pos_emb -> self._rotary_pos_emb
    def rot_pos_emb(self, grid_thw):
        pos_ids = []
        for t, h, w in grid_thw:
            hpos_ids = torch.arange(h).unsqueeze(1).expand(-1, w)
            hpos_ids = hpos_ids.reshape(
                h // self.config.vision_config.spatial_merge_size,
                self.config.vision_config.spatial_merge_size,
                w // self.config.vision_config.spatial_merge_size,
                self.config.vision_config.spatial_merge_size,
            )
            hpos_ids = hpos_ids.permute(0, 2, 1, 3)
            hpos_ids = hpos_ids.flatten()

            wpos_ids = torch.arange(w).unsqueeze(0).expand(h, -1)
            wpos_ids = wpos_ids.reshape(
                h // self.config.vision_config.spatial_merge_size,
                self.config.vision_config.spatial_merge_size,
                w // self.config.vision_config.spatial_merge_size,
                self.config.vision_config.spatial_merge_size,
            )
            wpos_ids = wpos_ids.permute(0, 2, 1, 3)
            wpos_ids = wpos_ids.flatten()
            pos_ids.append(torch.stack([hpos_ids, wpos_ids], dim=-1).repeat(t, 1))
        pos_ids = torch.cat(pos_ids, dim=0)
        max_grid_size = grid_thw[:, 1:].max()
        rotary_pos_emb_full = self._rotary_pos_emb(max_grid_size)
        rotary_pos_emb = rotary_pos_emb_full[pos_ids].flatten(1)
        return rotary_pos_emb

    def get_multimodal_embeddings(
        self,
        input_ids,
        pixel_values=None,
        attention_mask=None,
        position_ids=None,
        pixel_values_videos=None,
        image_grid_thw=None,
        video_grid_thw=None,
        cache_position=None,
        **kwargs,
    ):
        inputs_embeds = torch.from_numpy(self.get_text_embeddings(input_ids))
        if pixel_values is not None and input_ids.shape[1] != 1:
            image_embeds = torch.from_numpy(self.get_vision_embeddings(pixel_values, image_grid_thw))
            image_mask = input_ids == self.config.image_token_id
            inputs_embeds[image_mask] = image_embeds
        if pixel_values_videos is not None and input_ids.shape[1] != 1:
            pixel_values_videos = pixel_values_videos
            video_embeds = torch.from_numpy(self.get_vision_embeddings(pixel_values_videos, video_grid_thw))
            video_mask = input_ids == self.config.video_token_id
            inputs_embeds[video_mask] = video_embeds

        # if we get 4D attention mask we cannot calculate rope deltas anymore.
        if (
            (position_ids is None or position_ids.ndim < 3)
            and input_ids is not None
            and (attention_mask is None or attention_mask.ndim == 2)
        ):
            # calculate RoPE index once per generation in the pre-fill stage only
            if (cache_position is not None and cache_position[0] == 0) or self.rope_deltas is None:
                if is_transformers_version(">=", "5.3.0"):
                    # since transformers v5.3, get_rope_index requires mm_token_type_ids
                    mm_token_type_ids = kwargs.get("mm_token_type_ids")
                    if mm_token_type_ids is None:
                        mm_token_type_ids = torch.zeros_like(input_ids, dtype=torch.int32)
                        mm_token_type_ids[input_ids == self.config.image_token_id] = 1
                        mm_token_type_ids[input_ids == self.config.video_token_id] = 2
                    position_ids, rope_deltas = self.get_rope_index(
                        input_ids,
                        mm_token_type_ids,
                        image_grid_thw,
                        video_grid_thw,
                        attention_mask,
                    )
                else:
                    position_ids, rope_deltas = self.get_rope_index(
                        input_ids,
                        image_grid_thw,
                        video_grid_thw,
                        attention_mask,
                    )

                self.rope_deltas = rope_deltas
            # then use the prev pre-calculated rope-deltas to get the correct position ids
            else:
                batch_size, seq_length, _ = inputs_embeds.shape
                delta = cache_position[0] + self.rope_deltas if cache_position is not None else 0
                position_ids = torch.arange(seq_length, device=inputs_embeds.device)
                position_ids = position_ids.view(1, -1).expand(batch_size, -1)
                if cache_position is not None:  # otherwise `deltas` is an int `0`
                    delta = delta.repeat_interleave(batch_size // delta.shape[0], dim=0)
                position_ids = position_ids.add(delta)
                position_ids = position_ids.unsqueeze(0).expand(3, -1, -1)

        return inputs_embeds, attention_mask, position_ids

    def forward(
        self,
        input_ids,
        pixel_values=None,
        past_key_values=None,
        inputs_embeds=None,
        image_sizes=None,
        attention_mask=None,
        position_ids=None,
        image_bound=None,
        tgt_sizes=None,
        pixel_values_videos=None,
        image_grid_thw=None,
        video_grid_thw=None,
        rope_deltas=None,
        **kwargs,
    ):
        result = super().forward(
            input_ids,
            pixel_values,
            past_key_values,
            inputs_embeds,
            image_sizes,
            attention_mask,
            position_ids,
            image_bound,
            tgt_sizes,
            pixel_values_videos,
            image_grid_thw,
            video_grid_thw,
            rope_deltas,
            **kwargs,
        )
        final_result = QWen2VLModelOutputWithPast(
            logits=result.logits, past_key_values=result.past_key_values, rope_deltas=rope_deltas
        )
        return final_result

    @staticmethod
    def preprocess_inputs(
        text: str,
        image: Optional["Image"] = None,
        processor: Optional[AutoImageProcessor] = None,
        tokenizer: Optional[PreTrainedTokenizer] = None,
        config: Optional[PretrainedConfig] = None,
        video: Optional["VideoInput"] = None,
        audio: Optional[np.ndarray] = None,
    ):
        if processor is None:
            raise ValueError("Processor is required.")
        if audio is not None:
            raise ValueError("Audio input is not supported")
        conversation = [
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": text},
                ],
            }
        ]
        if image is not None:
            conversation[0]["content"].insert(0, {"type": "image"})
        if video is not None:
            conversation[0]["content"].insert(0, {"type": "video"})

        text_prompt = processor.apply_chat_template(conversation, add_generation_prompt=True)

        inputs = processor(images=image, text=text_prompt, videos=video, return_tensors="pt")
        return inputs


class _OVQwen2_5_VLForCausalLM(OVModelForVisualCausalLM):
    additional_parts = ["vision_embeddings_merger"]

    def __init__(
        self,
        language_model: ov.Model,
        text_embeddings: ov.Model,
        vision_embeddings: ov.Model,
        config: PretrainedConfig = None,
        device: str = "CPU",
        dynamic_shapes: bool = None,
        ov_config: Optional[Dict[str, str]] = None,
        model_save_dir: Optional[Union[str, Path, TemporaryDirectory]] = None,
        quantization_config: Union[OVWeightQuantizationConfig, Dict] = None,
        **kwargs,
    ):
        if is_transformers_version("<", "4.57"):
            raise Exception("Qwen2_5_VL is not supported in transformers versions earlier than 4.57.")

        super().__init__(
            language_model=language_model,
            text_embeddings=text_embeddings,
            vision_embeddings=vision_embeddings,
            config=config,
            device=device,
            dynamic_shapes=dynamic_shapes,
            ov_config=ov_config,
            model_save_dir=model_save_dir,
            quantization_config=quantization_config,
            **kwargs,
        )
        self.rope_deltas = None  # cache rope_deltas here

        class Qwen2_5_VisionRotaryEmbedding(torch.nn.Module):
            def __init__(self, dim: int, theta: float = 10000.0) -> None:
                super().__init__()
                inv_freq = 1.0 / (theta ** (torch.arange(0, dim, 2, dtype=torch.float) / dim))
                self.register_buffer("inv_freq", inv_freq, persistent=False)

            def forward(self, seqlen: int) -> torch.Tensor:
                seq = torch.arange(seqlen, device=self.inv_freq.device, dtype=self.inv_freq.dtype)
                freqs = torch.outer(seq, self.inv_freq)
                return freqs

        head_dim = config.vision_config.hidden_size // config.vision_config.num_heads
        self._rotary_pos_emb = Qwen2_5_VisionRotaryEmbedding(head_dim // 2)

    def prepare_inputs_for_generation(
        self,
        input_ids,
        past_key_values=None,
        attention_mask=None,
        inputs_embeds=None,
        cache_position=None,
        position_ids=None,
        use_cache=True,
        pixel_values=None,
        pixel_values_videos=None,
        image_grid_thw=None,
        video_grid_thw=None,
        second_per_grid_ts=None,
        mm_token_type_ids=None,
        is_first_iteration=False,
        next_sequence_length=None,
        **kwargs,
    ):
        # reconstruct cache_position as partially removed in v5.3 and totally removed in v5.5
        if is_transformers_version(">=", "5.3") and (
            cache_position is None or (not is_first_iteration and cache_position[0] == 0)
        ):
            if next_sequence_length is not None:
                past_len = input_ids.shape[1] - next_sequence_length
                cache_position = torch.arange(past_len, past_len + next_sequence_length, device=input_ids.device)
            elif not is_first_iteration and attention_mask is not None:
                # v5.3 decode step: input_ids is already sliced to 1 token, use attention_mask length
                past_len = attention_mask.shape[1] - 1
                cache_position = torch.tensor([past_len], device=input_ids.device)
            else:
                cache_position = torch.arange(input_ids.shape[1], device=input_ids.device)

        if past_key_values is not None:
            if inputs_embeds is not None and input_ids.shape[1] == 0:
                inputs_embeds = inputs_embeds[:, -cache_position.shape[0] :]
            elif inputs_embeds is not None:
                input_ids = input_ids[:, -cache_position.shape[0] :]
            elif input_ids.shape[1] != cache_position.shape[0]:  # Default case (the "else", a no op, is Exception 2)
                input_ids = input_ids[:, cache_position]

        if cache_position[0] != 0:
            pixel_values = None
            pixel_values_videos = None

        # if `inputs_embeds` are passed, we only want to use them in the 1st generation step
        if inputs_embeds is not None and len(cache_position) == inputs_embeds.shape[1]:
            model_inputs = {"inputs_embeds": inputs_embeds, "input_ids": None}
        else:
            model_inputs = {"input_ids": input_ids, "inputs_embeds": None}

        model_inputs.update(
            {
                "position_ids": position_ids,
                "past_key_values": past_key_values,
                "use_cache": use_cache,
                "attention_mask": attention_mask,
                "pixel_values": pixel_values,
                "pixel_values_videos": pixel_values_videos,
                "image_grid_thw": image_grid_thw,
                "video_grid_thw": video_grid_thw,
                "cache_position": cache_position,
                "second_per_grid_ts": second_per_grid_ts,
                "mm_token_type_ids": mm_token_type_ids,
            }
        )
        return model_inputs

    def rot_pos_emb(self, grid_thw):
        pos_ids = []
        for t, h, w in grid_thw:
            hpos_ids = torch.arange(h).unsqueeze(1).expand(-1, w)
            hpos_ids = hpos_ids.reshape(
                h // self.config.vision_config.spatial_merge_size,
                self.config.vision_config.spatial_merge_size,
                w // self.config.vision_config.spatial_merge_size,
                self.config.vision_config.spatial_merge_size,
            )
            hpos_ids = hpos_ids.permute(0, 2, 1, 3)
            hpos_ids = hpos_ids.flatten()

            wpos_ids = torch.arange(w).unsqueeze(0).expand(h, -1)
            wpos_ids = wpos_ids.reshape(
                h // self.config.vision_config.spatial_merge_size,
                self.config.vision_config.spatial_merge_size,
                w // self.config.vision_config.spatial_merge_size,
                self.config.vision_config.spatial_merge_size,
            )
            wpos_ids = wpos_ids.permute(0, 2, 1, 3)
            wpos_ids = wpos_ids.flatten()
            pos_ids.append(torch.stack([hpos_ids, wpos_ids], dim=-1).repeat(t, 1))
        pos_ids = torch.cat(pos_ids, dim=0)
        max_grid_size = grid_thw[:, 1:].max()
        rotary_pos_emb_full = self._rotary_pos_emb(max_grid_size)
        rotary_pos_emb = rotary_pos_emb_full[pos_ids].flatten(1)
        return rotary_pos_emb

    def get_multimodal_embeddings(
        self,
        input_ids,
        pixel_values=None,
        attention_mask=None,
        position_ids=None,
        pixel_values_videos=None,
        image_grid_thw=None,
        video_grid_thw=None,
        cache_position=None,
        second_per_grid_ts: Optional[torch.Tensor] = None,
        **kwargs,
    ):
        # Adopted from https://github.com/huggingface/transformers/blob/v4.49.0/src/transformers/models/qwen2_5_vl/modeling_qwen2_5_vl.py#L1791-L1861
        inputs_embeds = torch.from_numpy(self.get_text_embeddings(input_ids))
        if pixel_values is not None and input_ids.shape[1] != 1:
            image_embeds = torch.from_numpy(self.get_vision_embeddings(pixel_values, image_grid_thw))
            n_image_tokens = (input_ids == self.config.image_token_id).sum().item()
            n_image_features = image_embeds.shape[0]
            if n_image_tokens != n_image_features:
                raise ValueError(
                    f"Image features and image tokens do not match: tokens: {n_image_tokens}, features {n_image_features}"
                )

            mask = input_ids == self.config.image_token_id
            mask_unsqueezed = mask.unsqueeze(-1)
            mask_expanded = mask_unsqueezed.expand_as(inputs_embeds)
            image_mask = mask_expanded.to(inputs_embeds.device)

            image_embeds = image_embeds.to(inputs_embeds.device, inputs_embeds.dtype)
            inputs_embeds = inputs_embeds.masked_scatter(image_mask, image_embeds)
        if pixel_values_videos is not None and input_ids.shape[1] != 1:
            video_embeds = torch.from_numpy(self.get_vision_embeddings(pixel_values_videos, video_grid_thw))
            n_video_tokens = (input_ids == self.config.video_token_id).sum().item()
            n_video_features = video_embeds.shape[0]
            if n_video_tokens != n_video_features:
                raise ValueError(
                    f"Video features and video tokens do not match: tokens: {n_video_tokens}, features {n_video_features}"
                )

            mask = input_ids == self.config.video_token_id
            mask_unsqueezed = mask.unsqueeze(-1)
            mask_expanded = mask_unsqueezed.expand_as(inputs_embeds)
            video_mask = mask_expanded.to(inputs_embeds.device)

            video_embeds = video_embeds.to(inputs_embeds.device, inputs_embeds.dtype)
            inputs_embeds = inputs_embeds.masked_scatter(video_mask, video_embeds)

        # if we get 4D attention mask we cannot calculate rope deltas anymore.
        if (
            (position_ids is None or position_ids.ndim < 3)
            and input_ids is not None
            and (attention_mask is None or attention_mask.ndim == 2)
        ):
            # calculate RoPE index once per generation in the pre-fill stage only
            if (cache_position is not None and cache_position[0] == 0) or self.rope_deltas is None:
                if is_transformers_version(">=", "5.3.0"):
                    # since transformers v5.3, get_rope_index requires mm_token_type_ids
                    mm_token_type_ids = kwargs.get("mm_token_type_ids")
                    if mm_token_type_ids is None:
                        mm_token_type_ids = torch.zeros_like(input_ids, dtype=torch.int32)
                        mm_token_type_ids[input_ids == self.config.image_token_id] = 1
                        mm_token_type_ids[input_ids == self.config.video_token_id] = 2
                    position_ids, rope_deltas = self.get_rope_index(
                        input_ids,
                        mm_token_type_ids,
                        image_grid_thw,
                        video_grid_thw,
                        second_per_grid_ts,
                        attention_mask,
                    )
                else:
                    position_ids, rope_deltas = self.get_rope_index(
                        input_ids,
                        image_grid_thw,
                        video_grid_thw,
                        second_per_grid_ts,
                        attention_mask,
                    )
                self.rope_deltas = rope_deltas
            # then use the prev pre-calculated rope-deltas to get the correct position ids
            else:
                batch_size, seq_length, _ = inputs_embeds.shape
                delta = cache_position[0] + self.rope_deltas if cache_position is not None else 0
                position_ids = torch.arange(seq_length, device=inputs_embeds.device)
                position_ids = position_ids.view(1, -1).expand(batch_size, -1)
                if cache_position is not None:  # otherwise `deltas` is an int `0`
                    delta = delta.repeat_interleave(batch_size // delta.shape[0], dim=0)
                position_ids = position_ids.add(delta)
                position_ids = position_ids.unsqueeze(0).expand(3, -1, -1)

        return inputs_embeds, attention_mask, position_ids

    def get_vision_embeddings(self, pixel_values, grid_thw, **kwargs):
        hidden_states = self.vision_embeddings(pixel_values)[0]
        rotary_pos_emb = self.rot_pos_emb(grid_thw)
        window_index, cu_window_seqlens = self.get_window_index(grid_thw)
        cu_window_seqlens = torch.tensor(
            cu_window_seqlens,
            dtype=torch.int32,
        )
        cu_window_seqlens = torch.unique_consecutive(cu_window_seqlens)
        cu_seqlens = torch.repeat_interleave(grid_thw[:, 1] * grid_thw[:, 2], grid_thw[:, 0]).cumsum(
            dim=0, dtype=torch.int32
        )
        cu_seqlens = torch.nn.functional.pad(cu_seqlens, (1, 0), value=0)
        attention_mask = torch.zeros((1, hidden_states.shape[0], hidden_states.shape[0]), dtype=torch.bool)
        causal_mask = torch.zeros_like(attention_mask, dtype=torch.float32)
        for i in range(1, len(cu_seqlens)):
            attention_mask[..., cu_seqlens[i - 1] : cu_seqlens[i], cu_seqlens[i - 1] : cu_seqlens[i]] = True

        causal_mask.masked_fill_(torch.logical_not(attention_mask), float("-inf"))

        window_attention_mask = torch.zeros((1, hidden_states.shape[0], hidden_states.shape[0]), dtype=torch.bool)
        window_causal_mask = torch.zeros_like(attention_mask, dtype=torch.float32)
        for i in range(1, len(cu_window_seqlens)):
            window_attention_mask[
                ..., cu_window_seqlens[i - 1] : cu_window_seqlens[i], cu_window_seqlens[i - 1] : cu_window_seqlens[i]
            ] = True

        window_causal_mask.masked_fill_(torch.logical_not(window_attention_mask), float("-inf"))

        res = self.vision_embeddings_merger(
            pixel_values=hidden_states,
            attention_mask=causal_mask,
            window_attention_mask=window_causal_mask,
            window_index=window_index,
            rotary_pos_emb=rotary_pos_emb,
        )[0]
        return res

    def get_window_index(self, grid_thw):
        window_index: list = []
        cu_window_seqlens: list = [0]
        window_index_id = 0
        vit_merger_window_size = (
            self.config.vision_config.window_size
            // self.config.vision_config.spatial_merge_size
            // self.config.vision_config.patch_size
        )
        spatial_merge_unit = (
            self.config.vision_config.spatial_merge_size * self.config.vision_config.spatial_merge_size
        )

        for grid_t, grid_h, grid_w in grid_thw:
            llm_grid_h, llm_grid_w = (
                grid_h // self.config.vision_config.spatial_merge_size,
                grid_w // self.config.vision_config.spatial_merge_size,
            )
            index = torch.arange(grid_t * llm_grid_h * llm_grid_w).reshape(grid_t, llm_grid_h, llm_grid_w)
            pad_h = vit_merger_window_size - llm_grid_h % vit_merger_window_size
            pad_w = vit_merger_window_size - llm_grid_w % vit_merger_window_size
            num_windows_h = (llm_grid_h + pad_h) // vit_merger_window_size
            num_windows_w = (llm_grid_w + pad_w) // vit_merger_window_size
            index_padded = torch.nn.functional.pad(index, (0, pad_w, 0, pad_h), "constant", -100)
            index_padded = index_padded.reshape(
                grid_t,
                num_windows_h,
                vit_merger_window_size,
                num_windows_w,
                vit_merger_window_size,
            )
            index_padded = index_padded.permute(0, 1, 3, 2, 4).reshape(
                grid_t,
                num_windows_h * num_windows_w,
                vit_merger_window_size,
                vit_merger_window_size,
            )
            seqlens = (index_padded != -100).sum([2, 3]).reshape(-1)
            index_padded = index_padded.reshape(-1)
            index_new = index_padded[index_padded != -100]
            window_index.append(index_new + window_index_id)
            cu_seqlens_tmp = seqlens.cumsum(0) * spatial_merge_unit + cu_window_seqlens[-1]
            cu_window_seqlens.extend(cu_seqlens_tmp.tolist())
            window_index_id += (grid_t * llm_grid_h * llm_grid_w).item()
        window_index = torch.cat(window_index, dim=0)

        return window_index, cu_window_seqlens

    @staticmethod
    def preprocess_inputs(
        text: str,
        image: Optional["Image"] = None,
        processor: Optional[AutoImageProcessor] = None,
        tokenizer: Optional[PreTrainedTokenizer] = None,
        config: Optional[PretrainedConfig] = None,
        video: Optional["VideoInput"] = None,
        audio: Optional[np.ndarray] = None,
    ):
        if processor is None:
            raise ValueError("Processor is required.")
        if audio is not None:
            raise ValueError("Audio input is not supported")
        conversation = [
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": text},
                ],
            }
        ]
        if image is not None:
            conversation[0]["content"].insert(0, {"type": "image"})
        if video is not None:
            conversation[0]["content"].insert(0, {"type": "video"})

        text_prompt = processor.apply_chat_template(conversation, add_generation_prompt=True)

        inputs = processor(images=image, text=text_prompt, videos=video, return_tensors="pt")

        # since transformers v5.3, get_rope_index consumes one second_per_grid_ts entry per
        # non-text token group (images and videos), but the processor only populates it for videos
        if is_transformers_version(">=", "5.3.0") and "second_per_grid_ts" in inputs and "mm_token_type_ids" in inputs:
            non_text_groups = inputs["mm_token_type_ids"][0].unique_consecutive()
            non_text_groups = non_text_groups[non_text_groups != 0].tolist()
            video_ts_iter = iter(inputs["second_per_grid_ts"].tolist())
            full_ts = [next(video_ts_iter, 1.0) if g == 2 else 1.0 for g in non_text_groups]
            inputs["second_per_grid_ts"] = torch.tensor(full_ts, dtype=inputs["second_per_grid_ts"].dtype)

        return inputs


if is_transformers_version(">=", "4.57"):
    _OVQwen2VLForCausalLM.get_rope_index = Qwen2VLModel.get_rope_index
    _OVQwen2VLForCausalLM.get_vision_position_ids = getattr(Qwen2VLModel, "get_vision_position_ids", None)
    _OVQwen2_5_VLForCausalLM.get_rope_index = Qwen2_5_VLModel.get_rope_index
    _OVQwen2_5_VLForCausalLM.get_vision_position_ids = getattr(Qwen2_5_VLModel, "get_vision_position_ids", None)


class _OVQwen3VLForCausalLM(OVModelForVisualCausalLM):
    additional_parts = ["vision_embeddings_merger", "vision_embeddings_pos"]

    def __init__(
        self,
        language_model: ov.Model,
        text_embeddings: ov.Model,
        vision_embeddings: ov.Model,
        config: PretrainedConfig = None,
        device: str = "CPU",
        dynamic_shapes: bool = None,
        ov_config: Optional[Dict[str, str]] = None,
        model_save_dir: Optional[Union[str, Path, TemporaryDirectory]] = None,
        quantization_config: Union[OVWeightQuantizationConfig, Dict] = None,
        **kwargs,
    ):
        if is_transformers_version("<", "4.57.0"):
            raise Exception("Qwen3VL is not supported in transformers versions earlier than 4.57.0.")

        super().__init__(
            language_model=language_model,
            text_embeddings=text_embeddings,
            vision_embeddings=vision_embeddings,
            config=config,
            device=device,
            dynamic_shapes=dynamic_shapes,
            ov_config=ov_config,
            model_save_dir=model_save_dir,
            quantization_config=quantization_config,
            **kwargs,
        )
        self.rope_deltas = None  # cache rope_deltas here

        self._rotary_pos_emb = Qwen3VLVisionRotaryEmbedding(
            self.config.vision_config.hidden_size // self.config.vision_config.num_heads // 2
        )
        self.num_grid_per_side = int(config.vision_config.num_position_embeddings**0.5)
        self.spatial_merge_size = config.vision_config.spatial_merge_size
        head_dim = config.vision_config.hidden_size // config.vision_config.num_heads
        self.rotary_pos_emb = Qwen3VLVisionRotaryEmbedding(head_dim // 2)

    def __setattr__(self, name, value):
        OVModelForVisualCausalLM.__setattr__(self, name, value)

    # Adapted from https://github.com/huggingface/transformers/blob/v5.0.0/src/transformers/models/qwen3_vl/modeling_qwen3_vl.py#L1471-1537
    def prepare_inputs_for_generation(
        self,
        input_ids,
        past_key_values=None,
        attention_mask=None,
        inputs_embeds=None,
        cache_position=None,
        position_ids=None,
        use_cache=True,
        pixel_values=None,
        pixel_values_videos=None,
        image_grid_thw=None,
        video_grid_thw=None,
        mm_token_type_ids=None,
        is_first_iteration=False,
        next_sequence_length=None,
        **kwargs,
    ):
        # reconstruct cache_position as partially removed in v5.3 and totally removed in v5.5
        if is_transformers_version(">=", "5.3") and (
            cache_position is None or (not is_first_iteration and cache_position[0] == 0)
        ):
            if next_sequence_length is not None:
                past_len = input_ids.shape[1] - next_sequence_length
                cache_position = torch.arange(past_len, past_len + next_sequence_length, device=input_ids.device)
            elif not is_first_iteration and attention_mask is not None:
                # v5.3 decode step: input_ids is already sliced to 1 token, use attention_mask length
                past_len = attention_mask.shape[1] - 1
                cache_position = torch.tensor([past_len], device=input_ids.device)
            else:
                cache_position = torch.arange(input_ids.shape[1], device=input_ids.device)

        # Overwritten -- in specific circumstances we don't want to forward image inputs to the model
        if past_key_values is not None:
            if inputs_embeds is not None and input_ids.shape[1] == 0:  # Exception 4
                inputs_embeds = inputs_embeds[:, -cache_position.shape[0] :]
            elif inputs_embeds is not None:
                input_ids = input_ids[:, -cache_position.shape[0] :]
            elif input_ids.shape[1] != cache_position.shape[0]:  # Default case (the "else", a no op, is Exception 2)
                input_ids = input_ids[:, cache_position]

        if cache_position[0] != 0:
            pixel_values = None
            pixel_values_videos = None

        # if `inputs_embeds` are passed, we only want to use them in the 1st generation step
        if inputs_embeds is not None and len(cache_position) == inputs_embeds.shape[1]:
            model_inputs = {"inputs_embeds": inputs_embeds, "input_ids": None}
        else:
            model_inputs = {"input_ids": input_ids, "inputs_embeds": None}

        model_inputs.update(
            {
                "position_ids": position_ids,
                "past_key_values": past_key_values,
                "use_cache": use_cache,
                "attention_mask": attention_mask,
                "pixel_values": pixel_values,
                "pixel_values_videos": pixel_values_videos,
                "image_grid_thw": image_grid_thw,
                "video_grid_thw": video_grid_thw,
                "cache_position": cache_position,
                "mm_token_type_ids": mm_token_type_ids,
            }
        )
        return model_inputs

    # Adapted from https://github.com/huggingface/transformers/blob/8ac2b916b042b1f78b75c9eb941c0f5d2cdd8e10/src/transformers/models/qwen3_vl/modeling_qwen3_vl.py#L642
    # This method needs to be changed, as instead of running self.pos_embed of type nn.Embedding, openvino model needs to be inferred (self.vision_embeddings_pos)
    # and self.vision_embeddings_pos does not have some attributes like weights or device, which are used in the original method
    def fast_pos_embed_interpolate(self, grid_thw):
        grid_ts, grid_hs, grid_ws = grid_thw[:, 0], grid_thw[:, 1], grid_thw[:, 2]

        idx_list = [[] for _ in range(4)]
        weight_list = [[] for _ in range(4)]

        for t, h, w in zip(grid_ts, grid_hs, grid_ws):
            h_idxs = torch.linspace(0, self.num_grid_per_side - 1, h)
            w_idxs = torch.linspace(0, self.num_grid_per_side - 1, w)

            h_idxs_floor = h_idxs.int()
            w_idxs_floor = w_idxs.int()
            h_idxs_ceil = (h_idxs.int() + 1).clip(max=self.num_grid_per_side - 1)
            w_idxs_ceil = (w_idxs.int() + 1).clip(max=self.num_grid_per_side - 1)

            dh = h_idxs - h_idxs_floor
            dw = w_idxs - w_idxs_floor

            base_h = h_idxs_floor * self.num_grid_per_side
            base_h_ceil = h_idxs_ceil * self.num_grid_per_side

            indices = [
                (base_h[None].T + w_idxs_floor[None]).flatten(),
                (base_h[None].T + w_idxs_ceil[None]).flatten(),
                (base_h_ceil[None].T + w_idxs_floor[None]).flatten(),
                (base_h_ceil[None].T + w_idxs_ceil[None]).flatten(),
            ]

            weights = [
                ((1 - dh)[None].T * (1 - dw)[None]).flatten(),
                ((1 - dh)[None].T * dw[None]).flatten(),
                (dh[None].T * (1 - dw)[None]).flatten(),
                (dh[None].T * dw[None]).flatten(),
            ]

            for i in range(4):
                idx_list[i].extend(indices[i].tolist())
                weight_list[i].extend(weights[i].tolist())

        idx_tensor = torch.tensor(idx_list)
        weight_tensor = torch.tensor(weight_list)
        pos_embeds = torch.from_numpy(self.vision_embeddings_pos(idx_tensor)) * weight_tensor[:, :, None]
        patch_pos_embeds = pos_embeds[0] + pos_embeds[1] + pos_embeds[2] + pos_embeds[3]

        patch_pos_embeds = patch_pos_embeds.split([h * w for h, w in zip(grid_hs, grid_ws)])

        patch_pos_embeds_permute = []
        merge_size = self.config.vision_config.spatial_merge_size
        for pos_embed, t, h, w in zip(patch_pos_embeds, grid_ts, grid_hs, grid_ws):
            pos_embed = pos_embed.repeat(t, 1)
            pos_embed = (
                pos_embed.view(t, h // merge_size, merge_size, w // merge_size, merge_size, -1)
                .permute(0, 1, 3, 2, 4, 5)
                .flatten(0, 4)
            )
            patch_pos_embeds_permute.append(pos_embed)
        patch_pos_embeds = torch.cat(patch_pos_embeds_permute)
        return patch_pos_embeds

    # Adapted from https://github.com/huggingface/transformers/blob/v5.0.0/src/transformers/models/qwen3_vl/modeling_qwen3_vl.py#L758-814
    def get_vision_embeddings(self, pixel_values, grid_thw, **kwargs):
        hidden_states = torch.from_numpy(self.vision_embeddings(pixel_values)[0])

        pos_embeds = self.fast_pos_embed_interpolate(grid_thw)
        hidden_states = hidden_states + pos_embeds

        rotary_pos_emb = self.rot_pos_emb(grid_thw)
        seq_len, _ = hidden_states.size()
        hidden_states = hidden_states.reshape(seq_len, -1)
        rotary_pos_emb = rotary_pos_emb.reshape(seq_len, -1)
        cu_seqlens = torch.repeat_interleave(grid_thw[:, 1] * grid_thw[:, 2], grid_thw[:, 0]).cumsum(
            dim=0, dtype=torch.int32
        )
        cu_seqlens = torch.nn.functional.pad(cu_seqlens, (1, 0), value=0)
        attention_mask = torch.zeros((1, hidden_states.shape[0], hidden_states.shape[0]), dtype=torch.bool)
        causal_mask = torch.zeros_like(attention_mask, dtype=torch.float32)
        for i in range(1, len(cu_seqlens)):
            attention_mask[..., cu_seqlens[i - 1] : cu_seqlens[i], cu_seqlens[i - 1] : cu_seqlens[i]] = True

        causal_mask.masked_fill_(torch.logical_not(attention_mask), float("-inf"))

        res = self.vision_embeddings_merger(
            pixel_values=hidden_states, attention_mask=causal_mask, rotary_pos_emb=rotary_pos_emb
        )
        return res[0], res[1]

    # Adapted from https://github.com/huggingface/transformers/blob/08810b1e278938278c50153ee1edfd7a20a759da/src/transformers/models/qwen3_vl/modeling_qwen3_vl.py#L1110-1131
    def get_image_features(self, pixel_values: torch.FloatTensor, image_grid_thw: Optional[torch.LongTensor] = None):
        """
        Encodes images into continuous embeddings that can be forwarded to the language model. The deepstack visual features are also returned.

        Args:
            pixel_values (`torch.FloatTensor` of shape `(batch_size, num_channels, image_size, image_size)`):
                The tensors corresponding to the input images.
            image_grid_thw (`torch.LongTensor` of shape `(num_images, 3)`, *optional*):
                The temporal, height and width of feature shape of each image in LLM.
        """
        image_embeds, deepstack_image_embeds = self.get_vision_embeddings(pixel_values, image_grid_thw)
        image_embeds, deepstack_image_embeds = (
            torch.from_numpy(image_embeds),
            torch.from_numpy(deepstack_image_embeds),
        )
        deepstack_image_embeds = deepstack_image_embeds.tolist()
        split_sizes = (image_grid_thw.prod(-1) // self.spatial_merge_size**2).tolist()
        image_embeds = torch.split(image_embeds, split_sizes)
        return image_embeds, deepstack_image_embeds

    # Adapted from https://github.com/huggingface/transformers/blob/v5.0.0/src/transformers/models/qwen3_vl/modeling_qwen3_vl.py#L1176-1290
    def get_multimodal_embeddings(
        self,
        input_ids,
        pixel_values=None,
        attention_mask=None,
        position_ids=None,
        pixel_values_videos=None,
        image_grid_thw=None,
        video_grid_thw=None,
        cache_position=None,
        **kwargs,
    ):
        image_mask = None
        video_mask = None
        inputs_embeds = torch.from_numpy(self.get_text_embeddings(input_ids))

        if pixel_values is not None:
            image_embeds, deepstack_image_embeds = self.get_image_features(pixel_values, image_grid_thw)
            image_embeds = torch.cat(image_embeds, dim=0)
            image_mask, _ = self.get_placeholder_mask(
                input_ids, inputs_embeds=inputs_embeds, image_features=image_embeds
            )
            inputs_embeds = inputs_embeds.masked_scatter(image_mask, image_embeds)

        if pixel_values_videos is not None:
            video_embeds, deepstack_video_embeds = self.get_video_features(pixel_values_videos, video_grid_thw)
            video_embeds = torch.cat(video_embeds, dim=0)
            _, video_mask = self.get_placeholder_mask(
                input_ids, inputs_embeds=inputs_embeds, video_features=video_embeds
            )
            inputs_embeds = inputs_embeds.masked_scatter(video_mask, video_embeds)

        visual_pos_masks = None
        deepstack_visual_embeds = None
        if image_mask is not None and video_mask is not None:
            # aggregate visual_pos_masks and deepstack_visual_embeds
            image_mask = image_mask[..., 0]
            video_mask = video_mask[..., 0]
            visual_pos_masks = image_mask | video_mask
            deepstack_visual_embeds = []
            image_mask_joint = image_mask[visual_pos_masks]
            video_mask_joint = video_mask[visual_pos_masks]
            for img_embed, vid_embed in zip(deepstack_image_embeds, deepstack_video_embeds):
                embed_joint = np.zeros((visual_pos_masks.sum(), len(img_embed[0])))
                embed_joint[image_mask_joint, :] = img_embed
                embed_joint[video_mask_joint, :] = vid_embed
                deepstack_visual_embeds.append(embed_joint)
        elif image_mask is not None:
            image_mask = image_mask[..., 0]
            visual_pos_masks = image_mask
            deepstack_visual_embeds = deepstack_image_embeds
        elif video_mask is not None:
            video_mask = video_mask[..., 0]
            visual_pos_masks = video_mask
            deepstack_visual_embeds = deepstack_video_embeds

        if position_ids is None or position_ids.ndim < 3:
            attention_mask_tensor = (
                attention_mask if not isinstance(attention_mask, dict) else attention_mask["full_attention"]
            )
            if attention_mask_tensor is not None and attention_mask_tensor.ndim == 4:
                attention_mask_tensor = torch.diagonal(attention_mask_tensor[:, 0], dim1=1, dim2=2)
                # Only apply conversion for floating point tensors (inverted masks)
                if attention_mask_tensor.dtype.is_floating_point:
                    attention_mask_tensor = attention_mask_tensor / torch.finfo(attention_mask_tensor.dtype).min
                    attention_mask_tensor = (1.0 - attention_mask_tensor).int()

            # Calculate RoPE index once per generation in the pre-fill stage only.
            # When compiling, we can't check tensor values thus we check only input length
            # It is safe to assume that `length!=1` means we're in pre-fill because compiled
            # models currently cannot do asssisted decoding
            if self.rope_deltas is None:
                if is_transformers_version(">=", "5.3.0"):
                    # since transformers v5.3, get_rope_index requires mm_token_type_ids
                    mm_token_type_ids = kwargs.get("mm_token_type_ids")
                    if mm_token_type_ids is None:
                        mm_token_type_ids = torch.zeros_like(input_ids, dtype=torch.int32)
                        mm_token_type_ids[input_ids == self.config.image_token_id] = 1
                        mm_token_type_ids[input_ids == self.config.video_token_id] = 2
                    position_ids, rope_deltas = self.get_rope_index(
                        input_ids,
                        mm_token_type_ids,
                        image_grid_thw,
                        video_grid_thw,
                        attention_mask=attention_mask_tensor,
                    )
                else:
                    position_ids, rope_deltas = self.get_rope_index(
                        input_ids,
                        image_grid_thw,
                        video_grid_thw,
                        attention_mask=attention_mask_tensor,
                    )
                self.rope_deltas = rope_deltas
            # then use the prev pre-calculated rope-deltas to get the correct position ids
            else:
                batch_size, seq_length, _ = inputs_embeds.shape
                delta = (
                    (cache_position[0] + self.rope_deltas).to(inputs_embeds.device)
                    if cache_position is not None
                    else 0
                )
                position_ids = torch.arange(seq_length, device=inputs_embeds.device)
                position_ids = position_ids.view(1, -1).expand(batch_size, -1)
                if cache_position is not None:  # otherwise `deltas` is an int `0`
                    delta = delta.repeat_interleave(batch_size // delta.shape[0], dim=0)
                position_ids = position_ids.add(delta)
                position_ids = position_ids.unsqueeze(0).expand(3, -1, -1)
        return inputs_embeds, attention_mask, position_ids, visual_pos_masks, deepstack_visual_embeds

    @staticmethod
    def preprocess_inputs(
        text: str,
        image: Optional["Image"] = None,
        processor: Optional[AutoImageProcessor] = None,
        tokenizer: Optional[PreTrainedTokenizer] = None,
        config: Optional[PretrainedConfig] = None,
        video: Optional["VideoInput"] = None,
        audio: Optional[np.ndarray] = None,
    ):
        if processor is None:
            raise ValueError("Processor is required.")
        if audio is not None:
            raise ValueError("Audio input is not supported")
        conversation = [
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": text},
                ],
            }
        ]
        if image is not None:
            conversation[0]["content"].insert(0, {"type": "image"})
        if video is not None:
            conversation[0]["content"].insert(0, {"type": "video"})

        text_prompt = processor.apply_chat_template(conversation, add_generation_prompt=True)

        inputs = processor(images=image, text=text_prompt, videos=video, return_tensors="pt")
        return inputs

    def forward(
        self,
        input_ids,
        pixel_values=None,
        past_key_values=None,
        inputs_embeds=None,
        image_sizes=None,
        attention_mask=None,
        position_ids=None,
        image_bound=None,
        tgt_sizes=None,
        pixel_values_videos=None,
        image_grid_thw=None,
        video_grid_thw=None,
        rope_deltas=None,
        **kwargs,
    ):
        result = super().forward(
            input_ids,
            pixel_values,
            past_key_values,
            inputs_embeds,
            image_sizes,
            attention_mask,
            position_ids,
            image_bound,
            tgt_sizes,
            pixel_values_videos,
            image_grid_thw,
            video_grid_thw,
            rope_deltas,
            **kwargs,
        )
        if self.export_feature == "feature-extraction":
            return ModelOutput(last_hidden_state=result.logits)

        final_result = QWen2VLModelOutputWithPast(
            logits=result.logits, past_key_values=result.past_key_values, rope_deltas=rope_deltas
        )
        return final_result

    def generate(self, *args, **kwargs):
        # Clear cached rope delta from previous generations
        self.rope_deltas = None

        return super().generate(*args, **kwargs)


if is_transformers_version(">=", "4.57"):
    _OVQwen3VLForCausalLM.get_placeholder_mask = Qwen3VLModel.get_placeholder_mask
    _OVQwen3VLForCausalLM.get_rope_index = Qwen3VLModel.get_rope_index
    _OVQwen3VLForCausalLM.get_video_features = Qwen3VLModel.get_video_features
    _OVQwen3VLForCausalLM.rot_pos_emb = Qwen3VLVisionModel.rot_pos_emb
    _OVQwen3VLForCausalLM.get_vision_position_ids = getattr(Qwen3VLModel, "get_vision_position_ids", None)


class _OVQwen3OmniMoeForCausalLM(OVModelForVisualCausalLM):
    additional_parts = [
        "vision_embeddings_pos",
        "audio_encoder",
        "talker",
        "talker_text_embeddings",
        "talker_projections",
        "code_predictor",
        "code2wav",
    ]

    def __init__(
        self,
        language_model: ov.Model,
        text_embeddings: ov.Model,
        vision_embeddings: ov.Model,
        config: PretrainedConfig = None,
        device: str = "CPU",
        dynamic_shapes: bool = None,
        ov_config: Optional[Dict[str, str]] = None,
        model_save_dir: Optional[Union[str, Path, TemporaryDirectory]] = None,
        quantization_config: Union[OVWeightQuantizationConfig, Dict] = None,
        **kwargs,
    ):
        if is_transformers_version("<", "4.57.0"):
            raise Exception("Qwen3-Omni-MoE is not supported in transformers versions earlier than 4.57.0.")

        # Extract per-component device / ov_config overrides before passing ov_config to the
        # OpenVINO core. Keys of the form "<component>.device" (e.g. "audio_encoder.device") pin
        # that single component to a specific plugin; "<component>.ov_config" merges extra
        # config into that component only. The base ov_config keeps only global keys.
        ov_config_in = {} if ov_config is None else {**ov_config}
        component_device_overrides, component_ov_config_overrides, base_ov_config = self._split_component_overrides(
            ov_config_in
        )
        self._component_device_overrides = component_device_overrides
        self._component_ov_config_overrides = component_ov_config_overrides

        # Defer compile so we can apply per-component overrides before the first compile runs.
        enable_compilation = kwargs.pop("compile", True)

        super().__init__(
            language_model=language_model,
            text_embeddings=text_embeddings,
            vision_embeddings=vision_embeddings,
            config=config,
            device=device,
            dynamic_shapes=dynamic_shapes,
            ov_config=base_ov_config,
            model_save_dir=model_save_dir,
            quantization_config=quantization_config,
            compile=False,
            **kwargs,
        )
        # OVQwen3OmniMoeVisionEmbeddings merges deepstack into the vision graph; swap in for the default wrapper.
        self.vision_embeddings = OVQwen3OmniMoeVisionEmbeddings(self.vision_embeddings.model, self)

        self._apply_component_device_overrides()
        if enable_compilation and not self._compile_only:
            self.compile()

        self.rope_deltas = None
        self._collecting_hidden_states = False
        self._collected_hidden_states = []
        self._hs_lock = threading.Lock()
        self.num_grid_per_side = None
        self.spatial_merge_size = None
        self.rotary_pos_emb = None

        # Segment-level LRUs survive across generate() calls. Keys are blake2b fingerprints
        # (see _projection_key / _audio_key). Default capacity trades memory for hit rate;
        # a single projected segment can be several MB, so 32 is a safe starting point.
        # Not thread-safe: assumes single-threaded inference per model instance.
        self._projection_cache: OrderedDict = OrderedDict()
        self._audio_cache: OrderedDict = OrderedDict()
        self._projection_cache_capacity = 32
        self._audio_cache_capacity = 8

        thinker_config = getattr(config, "thinker_config", config)
        vision_config = getattr(thinker_config, "vision_config", None)
        if vision_config is not None:
            self.num_grid_per_side = int(vision_config.num_position_embeddings**0.5)
            self.spatial_merge_size = vision_config.spatial_merge_size
            head_dim = vision_config.hidden_size // vision_config.num_heads
            self.rotary_pos_emb = Qwen3VLVisionRotaryEmbedding(head_dim // 2)

    def _set_ov_config_parameters(self):
        super()._set_ov_config_parameters()
        # MoE models require FP32 activation precision to avoid numerical errors from BF16
        # inference; expert routing errors otherwise compound through layers. This governs
        # activations only and remains compatible with INT4/INT8 weight compression.
        if self.ov_config.get("INFERENCE_PRECISION_HINT") is None:
            self.ov_config["INFERENCE_PRECISION_HINT"] = "f32"

    def _save_pretrained(self, save_directory):
        super()._save_pretrained(save_directory)

        dest_preprocessor = Path(save_directory) / "preprocessor_config.json"
        if not dest_preprocessor.exists():
            source_model_path = getattr(self.config, "_name_or_path", None)
            if source_model_path:
                source_preprocessor = Path(source_model_path) / "preprocessor_config.json"
                if source_preprocessor.exists():
                    try:
                        shutil.copy2(source_preprocessor, dest_preprocessor)
                        logger.info("Copied preprocessor_config.json from source model")
                    except OSError as ex:
                        logger.warning(f"Failed to copy preprocessor_config.json: {ex}")

    def fast_pos_embed_interpolate(self, grid_thw):
        thinker_config = getattr(self.config, "thinker_config", self.config)
        vision_config = getattr(thinker_config, "vision_config", thinker_config)
        grid_ts, grid_hs, grid_ws = grid_thw[:, 0], grid_thw[:, 1], grid_thw[:, 2]

        idx_list = [[] for _ in range(4)]
        weight_list = [[] for _ in range(4)]

        for t, h, w in zip(grid_ts, grid_hs, grid_ws):
            h_idxs = torch.linspace(0, self.num_grid_per_side - 1, h)
            w_idxs = torch.linspace(0, self.num_grid_per_side - 1, w)
            h_idxs_floor = h_idxs.int()
            w_idxs_floor = w_idxs.int()
            h_idxs_ceil = (h_idxs.int() + 1).clip(max=self.num_grid_per_side - 1)
            w_idxs_ceil = (w_idxs.int() + 1).clip(max=self.num_grid_per_side - 1)
            dh = h_idxs - h_idxs_floor
            dw = w_idxs - w_idxs_floor
            base_h = h_idxs_floor * self.num_grid_per_side
            base_h_ceil = h_idxs_ceil * self.num_grid_per_side
            indices = [
                (base_h[None].T + w_idxs_floor[None]).flatten(),
                (base_h[None].T + w_idxs_ceil[None]).flatten(),
                (base_h_ceil[None].T + w_idxs_floor[None]).flatten(),
                (base_h_ceil[None].T + w_idxs_ceil[None]).flatten(),
            ]
            weights = [
                ((1 - dh)[None].T * (1 - dw)[None]).flatten(),
                ((1 - dh)[None].T * dw[None]).flatten(),
                (dh[None].T * (1 - dw)[None]).flatten(),
                (dh[None].T * dw[None]).flatten(),
            ]
            for i in range(4):
                idx_list[i].extend(indices[i].tolist())
                weight_list[i].extend(weights[i].tolist())

        idx_tensor = torch.tensor(idx_list)
        weight_tensor = torch.tensor(weight_list)
        pos_embeds = torch.from_numpy(self.vision_embeddings_pos(idx_tensor)) * weight_tensor[:, :, None]
        patch_pos_embeds = pos_embeds[0] + pos_embeds[1] + pos_embeds[2] + pos_embeds[3]
        patch_pos_embeds = patch_pos_embeds.split([h * w for h, w in zip(grid_hs, grid_ws)])

        merge_size = vision_config.spatial_merge_size
        patch_pos_embeds_permute = []
        for pos_embed, t, h, w in zip(patch_pos_embeds, grid_ts, grid_hs, grid_ws):
            pos_embed = pos_embed.repeat(t, 1)
            pos_embed = (
                pos_embed.view(t, h // merge_size, merge_size, w // merge_size, merge_size, -1)
                .permute(0, 1, 3, 2, 4, 5)
                .flatten(0, 4)
            )
            patch_pos_embeds_permute.append(pos_embed)
        return torch.cat(patch_pos_embeds_permute)

    def rot_pos_emb(self, grid_thw):
        pos_ids = []
        for t, h, w in grid_thw:
            hpos_ids = torch.arange(h).unsqueeze(1).expand(-1, w)
            wpos_ids = torch.arange(w).unsqueeze(0).expand(h, -1)
            hpos_ids = (
                hpos_ids.reshape(
                    h // self.spatial_merge_size,
                    self.spatial_merge_size,
                    w // self.spatial_merge_size,
                    self.spatial_merge_size,
                )
                .permute(0, 2, 1, 3)
                .flatten()
            )
            wpos_ids = (
                wpos_ids.reshape(
                    h // self.spatial_merge_size,
                    self.spatial_merge_size,
                    w // self.spatial_merge_size,
                    self.spatial_merge_size,
                )
                .permute(0, 2, 1, 3)
                .flatten()
            )
            pos_ids.append(torch.stack([hpos_ids, wpos_ids], dim=-1).repeat(t, 1))
        pos_ids = torch.cat(pos_ids, dim=0)
        max_grid_size = grid_thw[:, 1:].max()
        rotary_pos_emb_full = self.rotary_pos_emb(max_grid_size)
        rotary_pos_emb = rotary_pos_emb_full[pos_ids].flatten(1)
        return rotary_pos_emb

    def get_vision_embeddings(self, pixel_values, grid_thw, **kwargs):
        if self.rotary_pos_emb is None:
            raise ValueError("Vision components not available — model was loaded without vision_config.")

        pos_embeds = self.fast_pos_embed_interpolate(grid_thw)
        rotary_pos_emb = self.rot_pos_emb(grid_thw)

        seq_len = pos_embeds.shape[0]
        rotary_pos_emb = rotary_pos_emb.reshape(seq_len, -1)

        cu_seqlens = torch.repeat_interleave(grid_thw[:, 1] * grid_thw[:, 2], grid_thw[:, 0]).cumsum(
            dim=0, dtype=torch.int32
        )
        cu_seqlens = torch.nn.functional.pad(cu_seqlens, (1, 0), value=0)
        attention_mask = torch.zeros((1, seq_len, seq_len), dtype=torch.bool)
        causal_mask = torch.zeros_like(attention_mask, dtype=torch.float32)
        for i in range(1, len(cu_seqlens)):
            attention_mask[..., cu_seqlens[i - 1] : cu_seqlens[i], cu_seqlens[i - 1] : cu_seqlens[i]] = True
        causal_mask.masked_fill_(torch.logical_not(attention_mask), float("-inf"))

        res = self.vision_embeddings(pixel_values, pos_embeds, causal_mask, rotary_pos_emb)
        return np.array(res[0]), np.array(res[1])

    def get_multimodal_embeddings(
        self,
        input_ids,
        pixel_values=None,
        attention_mask=None,
        position_ids=None,
        image_grid_thw=None,
        audio_features=None,
        audio_feature_lens=None,
        cache_position=None,
        **kwargs,
    ):
        inputs_embeds = torch.from_numpy(self.get_text_embeddings(input_ids))
        thinker_config = getattr(self.config, "thinker_config", self.config)

        visual_pos_masks = None
        deepstack_visual_embeds = None

        if pixel_values is not None and image_grid_thw is not None:
            image_embeds, deepstack_image_embeds = self.get_vision_embeddings(pixel_values, image_grid_thw)
            image_embeds = torch.from_numpy(image_embeds)
            image_token_id = getattr(thinker_config, "image_token_id", None)
            if image_token_id is not None:
                image_mask = (input_ids == image_token_id).unsqueeze(-1).expand_as(inputs_embeds)
                inputs_embeds = inputs_embeds.masked_scatter(image_mask, image_embeds)
                visual_pos_masks = image_mask[..., 0]
                deepstack_visual_embeds = deepstack_image_embeds

        if audio_features is not None:
            audio_embeds = (
                torch.from_numpy(audio_features) if not isinstance(audio_features, torch.Tensor) else audio_features
            )
            audio_token_id = getattr(thinker_config, "audio_token_id", None)
            if audio_token_id is not None:
                audio_mask = (input_ids == audio_token_id).unsqueeze(-1).expand_as(inputs_embeds)
                inputs_embeds = inputs_embeds.masked_scatter(audio_mask, audio_embeds)

        if position_ids is None:
            batch_size, seq_length, _ = inputs_embeds.shape
            if (cache_position is not None and cache_position[0] == 0) or self.rope_deltas is None:
                position_ids = torch.arange(seq_length, device=inputs_embeds.device)
                position_ids = position_ids.view(1, -1).expand(batch_size, -1)
                position_ids = position_ids.unsqueeze(0).expand(4, -1, -1)
                max_position_ids = position_ids.max(0, keepdim=False)[0].max(-1, keepdim=True)[0]
                self.rope_deltas = max_position_ids + 1 - seq_length
            else:
                delta = (
                    (cache_position[0] + self.rope_deltas).to(inputs_embeds.device)
                    if cache_position is not None
                    else 0
                )
                position_ids = torch.arange(seq_length, device=inputs_embeds.device)
                position_ids = position_ids.view(1, -1).expand(batch_size, -1)
                if cache_position is not None:
                    delta = delta.repeat_interleave(batch_size // delta.shape[0], dim=0)
                position_ids = position_ids.add(delta)
                position_ids = position_ids.unsqueeze(0).expand(4, -1, -1)

        return inputs_embeds, attention_mask, position_ids, visual_pos_masks, deepstack_visual_embeds

    def prepare_inputs_for_generation(
        self,
        input_ids,
        past_key_values=None,
        attention_mask=None,
        inputs_embeds=None,
        cache_position=None,
        position_ids=None,
        use_cache=True,
        pixel_values=None,
        image_grid_thw=None,
        audio_features=None,
        audio_feature_lens=None,
        **kwargs,
    ):
        if past_key_values is not None and cache_position is not None:
            if inputs_embeds is not None and input_ids.shape[1] == 0:
                inputs_embeds = inputs_embeds[:, -cache_position.shape[0] :]
            elif inputs_embeds is not None:
                input_ids = input_ids[:, -cache_position.shape[0] :]
            elif input_ids.shape[1] != cache_position.shape[0]:
                input_ids = input_ids[:, cache_position]

        if cache_position is not None and cache_position[0] != 0:
            pixel_values = None
            audio_features = None
            audio_feature_lens = None

        if cache_position is not None and inputs_embeds is not None and len(cache_position) == inputs_embeds.shape[1]:
            model_inputs = {"inputs_embeds": inputs_embeds, "input_ids": None}
        else:
            model_inputs = {"input_ids": input_ids, "inputs_embeds": None}

        model_inputs.update(
            {
                "position_ids": position_ids,
                "past_key_values": past_key_values,
                "use_cache": use_cache,
                "attention_mask": attention_mask,
                "pixel_values": pixel_values,
                "image_grid_thw": image_grid_thw,
                "audio_features": audio_features,
                "audio_feature_lens": audio_feature_lens,
                "cache_position": cache_position,
            }
        )
        return model_inputs

    @staticmethod
    def preprocess_inputs(
        text: str,
        image: Optional["Image"] = None,
        processor: Optional[AutoImageProcessor] = None,
        tokenizer: Optional[PreTrainedTokenizer] = None,
        config: Optional[PretrainedConfig] = None,
        video: Optional["VideoInput"] = None,
        audio: Optional[np.ndarray] = None,
    ):
        if processor is None:
            raise ValueError("Processor is required.")
        if video is not None:
            raise ValueError("Video input is not supported")
        if isinstance(audio, (list, tuple)) and len(audio) == 1:
            audio = audio[0]
        sampling_rate = None
        if isinstance(audio, tuple) and len(audio) == 2:
            audio, sampling_rate = audio

        conversation = [{"role": "user", "content": [{"type": "text", "text": text}]}]
        if image is not None:
            conversation[0]["content"].insert(0, {"type": "image"})
        if audio is not None:
            conversation[0]["content"].insert(0, {"type": "audio"})

        text_prompt = processor.apply_chat_template(conversation, add_generation_prompt=True)
        processor_kwargs = {}
        if sampling_rate is not None:
            processor_kwargs["sampling_rate"] = sampling_rate
        inputs = processor(images=image, text=text_prompt, audio=audio, return_tensors="pt", **processor_kwargs)
        return inputs

    def forward(
        self,
        input_ids,
        pixel_values=None,
        past_key_values=None,
        inputs_embeds=None,
        image_sizes=None,
        attention_mask=None,
        position_ids=None,
        image_bound=None,
        tgt_sizes=None,
        image_grid_thw=None,
        audio_features=None,
        audio_feature_lens=None,
        rope_deltas=None,
        **kwargs,
    ):
        result = super().forward(
            input_ids,
            pixel_values,
            past_key_values,
            inputs_embeds,
            image_sizes,
            attention_mask,
            position_ids,
            image_bound,
            tgt_sizes,
            None,
            image_grid_thw,
            None,
            rope_deltas,
            audio_features=audio_features,
            audio_feature_lens=audio_feature_lens,
            **kwargs,
        )
        output = QWen2VLModelOutputWithPast(
            logits=result.logits, past_key_values=result.past_key_values, rope_deltas=rope_deltas
        )

        # Talker pipeline needs per-step hidden states; collect when flagged, else let parent handle.
        if self._collecting_hidden_states:
            self._collected_hidden_states.append((result.last_hidden_state, result.intermediate_hidden_state))

        return output

    def _process_audio_inputs(self, input_features, feature_attention_mask):
        cache_key = self._audio_key(input_features, feature_attention_mask)
        cached = self._lru_get(self._audio_cache, cache_key)
        if cached is not None:
            cached_features, cached_lens = cached
            return cached_features.clone(), cached_lens.clone()

        thinker_config = getattr(self.config, "thinker_config", self.config)
        audio_config = getattr(thinker_config, "audio_config", None)
        n_window = getattr(audio_config, "n_window", 100) if audio_config else 100
        n_window_infer = getattr(audio_config, "n_window_infer", 400) if audio_config else 400

        feature_lens = feature_attention_mask.sum(-1).to(torch.int64)
        if feature_lens.sum() == 0:
            raise ValueError("feature_attention_mask is all-zero; no valid audio frames to process.")
        audio_flat = input_features.permute(0, 2, 1)[feature_attention_mask.bool()].permute(1, 0)

        aftercnn_lens = _get_feat_extract_output_lengths(feature_lens)
        chunk_num = torch.ceil(feature_lens / (n_window * 2)).long()
        chunk_lengths = torch.tensor([n_window * 2] * chunk_num.sum(), dtype=torch.long)
        tail_chunk_index = torch.nn.functional.pad(chunk_num, (1, 0), value=-1).cumsum(0)[1:]
        chunk_lengths[tail_chunk_index] = feature_lens % (n_window * 2)
        chunk_lengths[chunk_lengths == 0] = n_window * 2

        chunk_list = audio_flat.T.split(chunk_lengths.tolist(), dim=0)
        padded_feature = torch.nn.utils.rnn.pad_sequence(chunk_list, batch_first=True).transpose(1, 2)
        feature_lens_after_cnn = _get_feat_extract_output_lengths(chunk_lengths)
        padded_mask_after_cnn = torch.nn.utils.rnn.pad_sequence(
            [torch.ones(length, dtype=torch.bool) for length in feature_lens_after_cnn],
            batch_first=True,
        )

        # cu_seqlens are required by the audio encoder's windowed attention kernels.
        window_aftercnn = padded_mask_after_cnn.shape[-1] * (n_window_infer // (n_window * 2))
        cu_chunk_lens = [0]
        for cnn_len in aftercnn_lens:
            cnn_len_val = cnn_len.item()
            cu_chunk_lens += [window_aftercnn] * (cnn_len_val // window_aftercnn)
            remainder = cnn_len_val % window_aftercnn
            if remainder != 0:
                cu_chunk_lens += [remainder]
        cu_seqlens = torch.tensor(cu_chunk_lens, device=aftercnn_lens.device).cumsum(-1, dtype=torch.int32)

        if self.audio_encoder is None:
            raise ValueError("Audio encoder model not loaded. Cannot process audio inputs.")
        audio_out = self.audio_encoder(
            padded_feature=padded_feature,
            padded_mask_after_cnn=padded_mask_after_cnn,
            aftercnn_lens=aftercnn_lens,
            cu_seqlens=cu_seqlens,
        )
        audio_out = torch.from_numpy(audio_out) if not isinstance(audio_out, torch.Tensor) else audio_out

        # Encoder returns padded [N_chunks, aftercnn_time, dim]; drop pad frames per chunk before concatenation.
        if audio_out.ndim == 3:
            valid_tokens = []
            for i, length in enumerate(feature_lens_after_cnn):
                valid_tokens.append(audio_out[i, : length.item()])
            audio_features = torch.cat(valid_tokens, dim=0)
        else:
            audio_features = audio_out
        self._lru_put(
            self._audio_cache,
            cache_key,
            (audio_features.clone(), aftercnn_lens.clone()),
            self._audio_cache_capacity,
        )
        return audio_features, aftercnn_lens

    @property
    def has_talker(self) -> bool:
        return self.talker is not None and self.code2wav is not None

    @staticmethod
    def _tensor_bytes(t):
        if isinstance(t, torch.Tensor):
            return t.detach().cpu().contiguous().numpy().tobytes()
        if isinstance(t, np.ndarray):
            return np.ascontiguousarray(t).tobytes()
        return bytes(t)

    @staticmethod
    def _lru_get(cache: OrderedDict, key):
        if key in cache:
            cache.move_to_end(key)
            return cache[key]
        return None

    @staticmethod
    def _lru_put(cache: OrderedDict, key, value, capacity: int):
        cache[key] = value
        cache.move_to_end(key)
        while len(cache) > capacity:
            cache.popitem(last=False)

    def _projection_key(self, role: str, input_ids_slice, mm_mask_slice):
        h = hashlib.blake2b(digest_size=16)
        h.update(role.encode("utf-8"))
        h.update(self._tensor_bytes(input_ids_slice))
        h.update(self._tensor_bytes(mm_mask_slice))
        return h.digest()

    def _audio_key(self, input_features, feature_attention_mask):
        h = hashlib.blake2b(digest_size=16)
        shape_bytes = np.asarray(tuple(input_features.shape), dtype=np.int64).tobytes()
        h.update(shape_bytes)
        raw = self._tensor_bytes(input_features)
        # Large feature tensors are expensive to hash whole; 8 KB prefix + 8 KB suffix keeps
        # collisions negligible for realistic audio inputs at < 1 ms cost.
        if len(raw) > 16 * 1024:
            h.update(raw[:8192])
            h.update(raw[-8192:])
            h.update(np.int64(len(raw)).tobytes())
        else:
            h.update(raw)
        h.update(self._tensor_bytes(feature_attention_mask))
        return h.digest()

    def clear_projection_cache(self) -> None:
        self._projection_cache.clear()

    def clear_audio_cache(self) -> None:
        self._audio_cache.clear()

    # Components accepting per-component device / ov_config overrides. Keys outside this set
    # (with a "<name>.device" or "<name>.ov_config" shape) are left in the base ov_config, so
    # OpenVINO will raise if they do not match a valid plugin property.
    _PER_COMPONENT_OVERRIDE_NAMES = frozenset(
        {
            "language_model",
            "vision_embeddings",
            "vision_embeddings_pos",
            "audio_encoder",
            "talker",
            "talker_text_embeddings",
            "talker_projections",
            "code_predictor",
            "code2wav",
        }
    )

    @classmethod
    def _split_component_overrides(
        cls, ov_config: Dict[str, Any]
    ) -> Tuple[Dict[str, str], Dict[str, Dict[str, Any]], Dict[str, Any]]:
        device_overrides: Dict[str, str] = {}
        ov_config_overrides: Dict[str, Dict[str, Any]] = {}
        base: Dict[str, Any] = {}
        for key, value in ov_config.items():
            if isinstance(key, str) and "." in key:
                component, _, suffix = key.partition(".")
                if component in cls._PER_COMPONENT_OVERRIDE_NAMES:
                    if suffix == "device" and isinstance(value, str):
                        device_overrides[component] = value.upper()
                        continue
                    if suffix == "ov_config" and isinstance(value, dict):
                        ov_config_overrides[component] = {**value}
                        continue
            base[key] = value
        return device_overrides, ov_config_overrides, base

    def _component_parts(self) -> Dict[str, Any]:
        parts: Dict[str, Any] = {}
        if getattr(self, "language_model", None) is not None:
            parts["language_model"] = self.language_model
        if getattr(self, "vision_embeddings", None) is not None:
            parts["vision_embeddings"] = self.vision_embeddings
        for name in self.additional_parts:
            value = getattr(self, name, None)
            if value is not None and not isinstance(value, ov.Model):
                parts[name] = value
        return parts

    def _apply_component_device_overrides(self) -> None:
        if not self._component_device_overrides and not self._component_ov_config_overrides:
            return
        parts = self._component_parts()
        for name, device in self._component_device_overrides.items():
            part = parts.get(name)
            if part is None:
                logger.warning("Per-component device override '%s.device' has no matching part; ignoring.", name)
                continue
            if hasattr(part, "_device_override"):
                # OVModelPart path: the override attribute is consulted by the _device property.
                part._device_override = device
                continue
            # OVBaseModel-derived parts (e.g. language_model) expose _device as a plain attribute.
            descriptor_cls = next((cls_ for cls_ in type(part).__mro__ if "_device" in cls_.__dict__), None)
            if descriptor_cls is None or not isinstance(descriptor_cls.__dict__["_device"], property):
                part._device = device
        for name, extra in self._component_ov_config_overrides.items():
            part = parts.get(name)
            if part is None:
                logger.warning("Per-component ov_config override '%s.ov_config' has no matching part; ignoring.", name)
                continue
            merged = {**getattr(part, "ov_config", {}), **extra}
            part.ov_config = merged

    def _get_talker_user_parts(
        self, im_start_index, segment_end_index, multimodal_mask, thinker_hidden, thinker_embed, input_ids=None
    ):
        talker_config = getattr(self.config, "talker_config", None)
        if talker_config is None:
            raise ValueError("talker_config is required for talker input construction")
        text_config = getattr(talker_config, "text_config", None)
        if text_config is None:
            raise ValueError("talker_config.text_config not found in model configuration.")
        hidden_size = text_config.hidden_size
        batch_size = thinker_embed.shape[0]
        user_mm_mask = multimodal_mask[:, im_start_index:segment_end_index]

        cache_key = None
        if input_ids is not None:
            id_slice = input_ids[:, im_start_index:segment_end_index]
            cache_key = self._projection_key("user", id_slice, user_mm_mask)
            cached = self._lru_get(self._projection_cache, cache_key)
            if cached is not None:
                return cached.clone()

        user_talker_part = torch.zeros(
            (batch_size, segment_end_index - im_start_index, hidden_size), dtype=torch.float32
        )

        if user_mm_mask.any():
            user_thinker_hidden_mm = thinker_hidden[:, im_start_index:segment_end_index][user_mm_mask]
            if user_thinker_hidden_mm.ndim == 2:
                user_thinker_hidden_mm = user_thinker_hidden_mm.unsqueeze(0)
            mm_hidden = self.talker_projections.hidden_projection(user_thinker_hidden_mm)
            mm_hidden = mm_hidden.squeeze(0) if mm_hidden.ndim == 3 else mm_hidden
            user_talker_part[user_mm_mask] = mm_hidden.float()

        user_thinker_embed = thinker_embed[:, im_start_index:segment_end_index][~user_mm_mask]
        if user_thinker_embed.ndim == 2:
            user_thinker_embed = user_thinker_embed.unsqueeze(0)
        user_text_hidden = self.talker_projections.text_projection(user_thinker_embed)
        user_text_hidden = user_text_hidden.squeeze(0) if user_text_hidden.ndim == 3 else user_text_hidden
        user_talker_part[~user_mm_mask] = user_text_hidden.float()

        if cache_key is not None:
            self._lru_put(self._projection_cache, cache_key, user_talker_part.clone(), self._projection_cache_capacity)
        return user_talker_part

    def _get_talker_assistant_parts(
        self, im_start_index, segment_end_index, speaker_id, thinker_embed, tts_pad_embed, tts_bos_embed, tts_eos_embed
    ):
        segment_len = segment_end_index - im_start_index
        if segment_len < 5:
            raise ValueError(
                f"Assistant segment too short ({segment_len} tokens, need >= 5) for talker input construction"
            )

        talker_config = getattr(self.config, "talker_config", None)
        if talker_config is None:
            raise ValueError("talker_config is required for talker input construction")
        text_config = getattr(talker_config, "text_config", None)
        if text_config is None:
            raise ValueError("talker_config.text_config not found in model configuration.")
        hidden_size = text_config.hidden_size

        assistant_hidden = self.talker_projections.text_projection(
            thinker_embed[:, im_start_index:segment_end_index]
        ).float()

        assistant_text_hidden = torch.cat(
            (
                assistant_hidden[:, :3],
                tts_pad_embed.expand(-1, 4, -1),
                tts_bos_embed,
                assistant_hidden[:, 3:4],
            ),
            dim=1,
        )

        codec_special_tokens = torch.tensor(
            [
                [
                    talker_config.codec_nothink_id,
                    talker_config.codec_think_bos_id,
                    talker_config.codec_think_eos_id,
                    speaker_id,
                    talker_config.codec_pad_id,
                    talker_config.codec_bos_id,
                ]
            ],
            dtype=torch.long,
        )
        codec_embeds = self.talker_text_embeddings(codec_special_tokens)
        if isinstance(codec_embeds, np.ndarray):
            codec_embeds = torch.from_numpy(codec_embeds)

        batch_size = thinker_embed.shape[0]
        assistant_codec_hidden = torch.cat(
            (
                torch.zeros((batch_size, 3, hidden_size), dtype=torch.float32),
                codec_embeds.float(),
            ),
            dim=1,
        )

        trailing_text_hidden = torch.cat(
            (assistant_hidden[:, 4:], tts_eos_embed),
            dim=1,
        )

        input_embeds = assistant_text_hidden + assistant_codec_hidden
        return input_embeds, trailing_text_hidden

    def _run_talker_generation(
        self,
        talker_input_embeds,
        trailing_text_hidden,
        tts_pad_embed,
        talker_kwargs,
    ):
        batch_size = talker_input_embeds.shape[0]
        if batch_size != 1:
            raise ValueError(f"Talker generation only supports batch_size=1, got {batch_size}")

        talker_config = getattr(self.config, "talker_config", None)
        if talker_config is None:
            raise ValueError("talker_config is required for talker generation")
        max_new_tokens = talker_kwargs.get("max_new_tokens", 4096)
        temperature = float(talker_kwargs.get("temperature", 0.9))
        top_k = int(talker_kwargs.get("top_k", 50))
        eos_token_id = talker_kwargs.get("eos_token_id", talker_config.codec_eos_token_id)
        num_code_groups = (
            talker_config.code_predictor_config.num_code_groups
            if hasattr(talker_config, "code_predictor_config")
            else 16
        )
        num_inner_steps = max(0, num_code_groups - 1)
        # Single numpy RNG drives all per-step seeds; caller can pin reproducibility via talker_seed.
        rng = np.random.default_rng(talker_kwargs.get("seed"))

        self.talker.reset()
        logits, hidden_states = self.talker(inputs_embeds=talker_input_embeds)

        all_codec_codes = []
        trailing_idx = 0

        for _ in range(max_new_tokens):
            next_logits = logits[:, -1, :]
            # Replace any non-finite logits (NaN/Inf can appear with extreme or untrained weights) so
            # softmax/multinomial below receive a valid probability distribution instead of crashing.
            next_logits = torch.nan_to_num(next_logits, nan=0.0, posinf=0.0, neginf=float("-inf"))

            if temperature > 0:
                scaled_logits = next_logits / temperature if temperature != 1.0 else next_logits
                if top_k > 0:
                    indices_to_remove = scaled_logits < torch.topk(scaled_logits, top_k)[0][..., -1, None]
                    scaled_logits = scaled_logits.masked_fill(indices_to_remove, float("-inf"))
                probs = torch.nn.functional.softmax(scaled_logits, dim=-1)
                next_token = torch.multinomial(probs, num_samples=1).squeeze(-1)
            else:
                next_token = next_logits.argmax(dim=-1)

            if next_token.item() == eos_token_id:
                break

            first_code = next_token.item()
            next_token_tensor = next_token.unsqueeze(0)
            first_code_embed = self.talker_text_embeddings(next_token_tensor)
            if isinstance(first_code_embed, np.ndarray):
                first_code_embed = torch.from_numpy(first_code_embed).float()

            step_codes = [first_code]

            if self.code_predictor is not None and num_inner_steps > 0:
                # Single-step CP: loop num_inner_steps calls, feeding each step's codec embedding back
                # as the next step's input. The prefill call sees [prefix_hidden, first_code_embed];
                # subsequent calls see the previous step's token_embed. Accumulation mirrors the
                # original graph: codec_hiddens_sum = first_code_embed + sum(token_embed_i).
                cp_prefill = torch.cat([hidden_states[:, -1:, :].float(), first_code_embed.float()], dim=1)
                seeds = rng.integers(1, np.iinfo(np.int64).max, size=num_inner_steps, dtype=np.int64)
                cp_temperature = temperature if temperature > 0 else 1.0
                cp_top_k = top_k if top_k > 0 else 1

                codec_hiddens_sum = first_code_embed
                cp_input = cp_prefill
                for cp_step in range(num_inner_steps):
                    code, token_embed = self.code_predictor(
                        inputs_embeds=cp_input,
                        step=int(cp_step),
                        seed=int(seeds[cp_step]),
                        temperature=cp_temperature,
                        top_k=cp_top_k,
                        is_prefill=(cp_step == 0),
                    )
                    step_codes.append(int(code.reshape(-1)[0]))
                    codec_hiddens_sum = codec_hiddens_sum + token_embed
                    cp_input = token_embed

                next_embed = first_code_embed + codec_hiddens_sum
            else:
                next_embed = first_code_embed

            all_codec_codes.append(step_codes)

            if trailing_idx < trailing_text_hidden.shape[1]:
                next_input = next_embed + trailing_text_hidden[:, trailing_idx : trailing_idx + 1, :]
                trailing_idx += 1
            else:
                next_input = next_embed + tts_pad_embed

            logits, hidden_states = self.talker(
                inputs_embeds=next_input,
                past_key_values=((),),
            )

        if not all_codec_codes:
            return None

        codes_tensor = torch.tensor(all_codec_codes, dtype=torch.long).unsqueeze(0).permute(0, 2, 1)
        return codes_tensor

    def _split_talker_thinker_kwargs(self, kwargs):
        # Strip `talker_`/`thinker_` prefixes: talker_* keys go to a separate dict,
        # thinker_* keys are folded back into kwargs and thus override plain keys.
        talker_kwargs = {}
        thinker_kwargs = {}
        for key in list(kwargs.keys()):
            if key.startswith("talker_"):
                talker_kwargs[key[len("talker_") :]] = kwargs.pop(key)
            elif key.startswith("thinker_"):
                thinker_kwargs[key[len("thinker_") :]] = kwargs.pop(key)
        for k, v in thinker_kwargs.items():
            kwargs[k] = v
        return talker_kwargs

    def _run_thinker_and_collect_hidden_states(self, args, kwargs):
        # Lock ensures concurrent generate(return_audio=True) calls don't corrupt shared collection buffers.
        # The _collecting_hidden_states flag reads in forward() are safe: they run inside super().generate()
        # which executes within the lock, so no concurrent thread can observe a stale flag value.
        with self._hs_lock:
            self._collecting_hidden_states = True
            self.language_model._collecting_hidden_states = True
            self._collected_hidden_states = []
            try:
                thinker_result = super().generate(*args, **kwargs)
            finally:
                self._collecting_hidden_states = False
                self.language_model._collecting_hidden_states = False

            if not self._collected_hidden_states or self._collected_hidden_states[0][0] is None:
                self._collected_hidden_states = []
                return thinker_result, None

            # Prefer intermediate states from accept_hidden_layer for talker projection; fall back to final-layer.
            if self._collected_hidden_states[0][1] is not None:
                thinker_hidden = torch.cat([hs[1] for hs in self._collected_hidden_states], dim=1)
            else:
                thinker_hidden = torch.cat([hs[0] for hs in self._collected_hidden_states], dim=1)
            self._collected_hidden_states = []

        return thinker_result, thinker_hidden

    def _build_tts_special_embeds(self):
        # Returns (bos, eos, pad) projected embeds, or None when any TTS token id is missing from config.
        tts_bos_token_id = getattr(self.config, "tts_bos_token_id", None)
        tts_eos_token_id = getattr(self.config, "tts_eos_token_id", None)
        tts_pad_token_id = getattr(self.config, "tts_pad_token_id", None)
        if tts_bos_token_id is None or tts_eos_token_id is None or tts_pad_token_id is None:
            return None
        tts_special_tokens = torch.tensor(
            [[tts_bos_token_id, tts_eos_token_id, tts_pad_token_id]],
            dtype=torch.long,
        )
        tts_special_embeds = self.language_model.embed_tokens(tts_special_tokens)
        tts_special_projected = self.talker_projections.text_projection(tts_special_embeds).float()
        tts_bos_embed, tts_eos_embed, tts_pad_embed = tts_special_projected.chunk(3, dim=1)
        return tts_bos_embed, tts_eos_embed, tts_pad_embed

    def generate(self, *args, **kwargs):
        self.rope_deltas = None
        return_audio = kwargs.pop("return_audio", False)
        speaker = kwargs.pop("speaker", "Ethan")

        input_features = kwargs.pop("input_features", None)
        feature_attention_mask = kwargs.pop("feature_attention_mask", None)
        if input_features is not None and feature_attention_mask is not None:
            audio_features, audio_feature_lens = self._process_audio_inputs(input_features, feature_attention_mask)
            kwargs["audio_features"] = audio_features
            kwargs["audio_feature_lens"] = audio_feature_lens

        if not return_audio:
            return super().generate(*args, **kwargs)

        if not self.has_talker:
            logger.warning("return_audio=True but model has no talker. Returning text-only result.")
            return super().generate(*args, **kwargs), None

        input_ids = kwargs.get("input_ids", args[0] if args else None)
        if input_ids is not None:
            input_ids = input_ids.clone()

        talker_kwargs = self._split_talker_thinker_kwargs(kwargs)

        thinker_result, thinker_hidden = self._run_thinker_and_collect_hidden_states(args, kwargs)
        if thinker_hidden is None:
            logger.warning("No hidden states collected during thinker generation, cannot produce audio.")
            return thinker_result, None

        # thinker_embed uses word embeddings (layer 0), not final-layer hidden states
        sequences = thinker_result.sequences if hasattr(thinker_result, "sequences") else thinker_result
        thinker_embed = self.get_text_embeddings(sequences)
        if isinstance(thinker_embed, np.ndarray):
            thinker_embed = torch.from_numpy(thinker_embed)

        thinker_config = getattr(self.config, "thinker_config", self.config)
        talker_config = getattr(self.config, "talker_config", None)
        if talker_config is None:
            logger.warning("talker_config not found in model config, cannot produce audio.")
            return thinker_result, None
        im_start_token_id = getattr(self.config, "im_start_token_id", None)
        system_token_id = getattr(self.config, "system_token_id", None)
        user_token_id = getattr(self.config, "user_token_id", None)
        assistant_token_id = getattr(self.config, "assistant_token_id", None)

        speaker_id_map = getattr(talker_config, "speaker_id", None) or {}
        speaker_id = speaker_id_map.get(speaker.lower()) if speaker_id_map else None
        if speaker_id is None:
            logger.warning(f"Speaker '{speaker}' not found, using first available speaker.")
            speaker_id = next(iter(speaker_id_map.values())) if speaker_id_map else 0

        audio_token_id = getattr(thinker_config, "audio_token_id", None)
        image_token_id = getattr(thinker_config, "image_token_id", None)
        video_token_id = getattr(thinker_config, "video_token_id", None)
        multimodal_mask = torch.zeros_like(sequences, dtype=torch.bool)
        if audio_token_id is not None:
            multimodal_mask |= sequences == audio_token_id
        if image_token_id is not None:
            multimodal_mask |= sequences == image_token_id
        if video_token_id is not None:
            multimodal_mask |= sequences == video_token_id

        if im_start_token_id is not None and input_ids is not None:
            im_start_indexes = torch.cat(
                (
                    torch.nonzero(input_ids[0] == im_start_token_id).squeeze(-1),
                    torch.tensor([sequences.shape[-1]]),
                ),
                dim=-1,
            )
        else:
            logger.warning("Cannot build talker input: im_start_token_id or input_ids not available.")
            return thinker_result, None

        tts_special_embeds = self._build_tts_special_embeds()
        if tts_special_embeds is None:
            logger.warning("TTS token IDs (tts_bos/eos/pad_token_id) not found in config, cannot produce audio.")
            return thinker_result, None
        tts_bos_embed, tts_eos_embed, tts_pad_embed = tts_special_embeds

        talker_input_embeds = []
        trailing_text_hidden = None

        for i in range(len(im_start_indexes) - 1):
            im_start_index = im_start_indexes[i].item()
            segment_end_index = im_start_indexes[i + 1].item()

            if im_start_index + 1 >= sequences.shape[-1]:
                continue
            role_token = input_ids[0][im_start_index + 1].item() if im_start_index + 1 < input_ids.shape[-1] else None

            if role_token == system_token_id:
                continue
            elif role_token == user_token_id:
                user_part = self._get_talker_user_parts(
                    im_start_index,
                    segment_end_index,
                    multimodal_mask,
                    thinker_hidden,
                    thinker_embed,
                    input_ids=input_ids,
                )
                talker_input_embeds.append(user_part)
            elif role_token == assistant_token_id and i == len(im_start_indexes) - 2:
                assistant_embeds, trailing_text_hidden = self._get_talker_assistant_parts(
                    im_start_index,
                    segment_end_index,
                    speaker_id,
                    thinker_embed,
                    tts_pad_embed,
                    tts_bos_embed,
                    tts_eos_embed,
                )
                talker_input_embeds.append(assistant_embeds)
            elif role_token == assistant_token_id:
                continue

        if not talker_input_embeds or trailing_text_hidden is None:
            logger.warning("Could not construct talker input, returning text-only result.")
            return thinker_result, None

        talker_input_embed = torch.cat(talker_input_embeds, dim=1)

        codes = self._run_talker_generation(
            talker_input_embed,
            trailing_text_hidden,
            tts_pad_embed,
            talker_kwargs,
        )

        if codes is None:
            return thinker_result, None

        # Forward optional chunking knobs to the code2wav submodel. When unset, chunking stays off.
        chunk_size = talker_kwargs.get("code2wav_chunk_size")
        chunk_overlap = talker_kwargs.get("code2wav_chunk_overlap", 0)
        if self.code2wav is not None:
            self.code2wav.chunk_size = int(chunk_size) if chunk_size else None
            self.code2wav.chunk_overlap = int(chunk_overlap) if chunk_overlap else 0

        waveform = self.code2wav(codes)
        if isinstance(waveform, np.ndarray):
            waveform = torch.from_numpy(waveform)

        return thinker_result, waveform.float()


class OVModelForMultimodalLM(OVBaseModel, GenerationMixin):
    export_feature = "image-text-to-text"
    auto_model_class = transformers_auto_class

    def __init__(self, *, _inner: _OVQwen3OmniMoeForCausalLM, **kwargs):
        object.__setattr__(self, "_inner", _inner)

        self.config = _inner.config
        self.model_save_dir = _inner.model_save_dir
        self._device = _inner._device
        self.ov_config = _inner.ov_config
        self._compile_only = _inner._compile_only
        self.use_cache = _inner.use_cache
        self.preprocessors = _inner.preprocessors

        GenerationMixin.__init__(self)

        self.generation_config = _inner.generation_config
        self.is_dynamic = _inner.is_dynamic
        self._supports_cache_class = False
        self.main_input_name = "input_ids"
        self._openvino_config = getattr(_inner, "_openvino_config", None)

        # Avoid warnings when creating a transformers pipeline
        AutoConfig.register(self.base_model_prefix, AutoConfig)
        self.auto_model_class.register(AutoConfig, self.__class__)

    @property
    def language_model(self):
        return self._inner.language_model

    @property
    def vision_embeddings(self):
        return self._inner.vision_embeddings

    @property
    def has_talker(self) -> bool:
        return self._inner.has_talker

    @property
    def audio_encoder(self):
        return self._inner.audio_encoder

    @property
    def talker(self):
        return self._inner.talker

    @property
    def talker_text_embeddings(self):
        return self._inner.talker_text_embeddings

    @property
    def talker_projections(self):
        return self._inner.talker_projections

    @property
    def code_predictor(self):
        return self._inner.code_predictor

    @property
    def code2wav(self):
        return self._inner.code2wav

    @property
    def components(self):
        return self._inner.components

    @property
    def _component_names(self) -> List[str]:
        return self._inner._component_names

    @property
    def _ov_model_names(self):
        return self._inner._ov_model_names

    @classproperty
    def _all_ov_model_paths(cls) -> Dict[str, str]:
        return _OVQwen3OmniMoeForCausalLM._all_ov_model_paths.copy()

    @property
    def ov_models(self) -> Dict[str, Union[openvino.Model, openvino.CompiledModel]]:
        return self._inner.ov_models

    def generate(self, *args, **kwargs):
        return self._inner.generate(*args, **kwargs)

    def forward(self, *args, **kwargs):
        return self._inner.forward(*args, **kwargs)

    @staticmethod
    def preprocess_inputs(
        text: str,
        image: Optional["Image"] = None,
        processor: Optional[AutoImageProcessor] = None,
        tokenizer: Optional[PreTrainedTokenizer] = None,
        config: Optional[PretrainedConfig] = None,
        video: Optional["VideoInput"] = None,
        audio: Optional[np.ndarray] = None,
    ):
        return _OVQwen3OmniMoeForCausalLM.preprocess_inputs(
            text=text,
            image=image,
            processor=processor,
            tokenizer=tokenizer,
            config=config,
            video=video,
            audio=audio,
        )

    def prepare_inputs_for_generation(self, *args, **kwargs):
        return self._inner.prepare_inputs_for_generation(*args, **kwargs)

    def compile(self):
        self._inner.compile()

    def clear_requests(self):
        self._inner.clear_requests()

    def clear_projection_cache(self) -> None:
        self._inner.clear_projection_cache()

    def clear_audio_cache(self) -> None:
        self._inner.clear_audio_cache()

    def half(self):
        self._inner.half()
        return self

    def to(self, device):
        self._inner.to(device)
        return self

    def reshape(self, batch_size: int, sequence_length: int):
        self._inner.reshape(batch_size, sequence_length)
        return self

    def _save_pretrained(self, save_directory):
        self._inner._save_pretrained(save_directory)

    def _save_config(self, save_directory):
        self._inner._save_config(save_directory)

    @classmethod
    def _from_pretrained(
        cls,
        model_id: Union[str, Path],
        config: PretrainedConfig,
        **kwargs,
    ):
        if getattr(config, "model_type", None) != "qwen3_omni_moe":
            raise ValueError(
                f"OVModelForMultimodalLM only supports qwen3_omni_moe models, "
                f"but got config.model_type={getattr(config, 'model_type', None)!r}. "
                f"Use OVModelForVisualCausalLM for other vision-language architectures."
            )
        inner = OVModelForVisualCausalLM._from_pretrained(model_id, config, **kwargs)
        return cls(_inner=inner)

    @classmethod
    def _export(
        cls,
        model_id: str,
        config: PretrainedConfig,
        **kwargs,
    ):
        if getattr(config, "model_type", None) != "qwen3_omni_moe":
            raise ValueError(
                f"OVModelForMultimodalLM only supports qwen3_omni_moe models, "
                f"but got config.model_type={getattr(config, 'model_type', None)!r}. "
                f"Use OVModelForVisualCausalLM for other vision-language architectures."
            )
        inner = OVModelForVisualCausalLM._export(model_id, config, **kwargs)
        return cls(_inner=inner)


class _OVMaira2ForCausalLM(_OVLlavaForCausalLM):
    @staticmethod
    def preprocess_inputs(
        text: str,
        image: Optional["Image"] = None,
        processor: Optional[AutoImageProcessor] = None,
        tokenizer: Optional[PreTrainedTokenizer] = None,
        config: Optional[PretrainedConfig] = None,
        video: Optional["VideoInput"] = None,
        audio: Optional[np.ndarray] = None,
    ):
        if processor is None:
            raise ValueError("processor is required")
        if video is not None:
            raise ValueError("Video input is not supported")
        if audio is not None:
            raise ValueError("Audio input is not supported")
        if image is None:
            return processor(text=text, return_tensors="pt")
        processed_inputs = processor.format_and_preprocess_phrase_grounding_input(
            frontal_image=image,
            phrase=text,
            return_tensors="pt",
        )
        return processed_inputs


class _OVGemma3ForCausalLM(OVModelForVisualCausalLM):
    def get_vision_embeddings(self, pixel_values, input_ids=None, **kwargs):
        if input_ids is not None and input_ids.shape[1] == 1:
            return None
        return self.vision_embeddings(pixel_values).last_hidden_state

    def merge_vision_text_embeddings(
        self, vision_embeds, inputs_embeds, input_ids=None, attention_mask=None, position_ids=None, **kwargs
    ):
        # Adopted from https://github.com/huggingface/transformers/blob/v4.49.0-Gemma-3/src/transformers/models/gemma3/modeling_gemma3.py#L1323-L1339
        image_features = torch.from_numpy(vision_embeds) if isinstance(vision_embeds, np.ndarray) else vision_embeds
        inputs_embeds = torch.from_numpy(inputs_embeds) if isinstance(inputs_embeds, np.ndarray) else inputs_embeds
        if input_ids is None:
            special_image_mask = inputs_embeds == torch.from_numpy(
                self.get_text_embeddings(torch.tensor([[self.config.image_token_index]], dtype=torch.long))[0]
            )
        else:
            special_image_mask = (input_ids == self.config.image_token_index).unsqueeze(-1)
            special_image_mask = special_image_mask.expand_as(inputs_embeds)

            image_features = image_features.to(inputs_embeds.dtype)
            inputs_embeds = inputs_embeds.masked_scatter(special_image_mask, image_features)

        return inputs_embeds, attention_mask, position_ids

    @staticmethod
    def preprocess_inputs(
        text: str,
        image: Optional["Image"] = None,
        processor: Optional[AutoImageProcessor] = None,
        tokenizer: Optional[PreTrainedTokenizer] = None,
        config: Optional[PretrainedConfig] = None,
        video: Optional["VideoInput"] = None,
        audio: Optional[np.ndarray] = None,
    ):
        if processor is None:
            raise ValueError("Processor is required.")
        if video is not None:
            raise ValueError("Video input is not supported")
        if audio is not None:
            raise ValueError("Audio input is not supported")
        conversation = [
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": text},
                ],
            }
        ]
        if image is not None:
            conversation[0]["content"].insert(0, {"type": "image"})

        text_prompt = processor.apply_chat_template(conversation, add_generation_prompt=True, tokenize=False)

        # switch off add_bos_token if chat template already includes it
        orig_add_bos_token = processor.tokenizer.add_bos_token
        if "bos_token" in processor.tokenizer.chat_template:
            processor.tokenizer.add_bos_token = False

        inputs = processor(images=image, text=text_prompt, videos=video, return_tensors="pt")

        # recover add_bos_token flag in tokenizer
        processor.tokenizer.add_bos_token = orig_add_bos_token

        return inputs

    def _update_model_kwargs_for_generation(
        self,
        outputs: ModelOutput,
        model_kwargs: Dict[str, Any],
        is_encoder_decoder: bool = False,
        num_new_tokens: int = 1,
    ) -> Dict[str, Any]:
        model_kwargs = super()._update_model_kwargs_for_generation(
            outputs=outputs,
            model_kwargs=model_kwargs,
            is_encoder_decoder=is_encoder_decoder,
            num_new_tokens=num_new_tokens,
        )

        # Token type ids used only for first inference mask generation
        model_kwargs.pop("token_type_ids", None)

        return model_kwargs


class _OVGemma4ForCausalLM(_OVGemma3ForCausalLM):
    additional_parts = ["text_embeddings_per_layer"]

    def get_vision_embeddings(self, pixel_values, input_ids=None, **kwargs):
        if input_ids is not None and input_ids.shape[1] == 1:
            return None
        return self.vision_embeddings(pixel_values, **kwargs).last_hidden_state

    def get_multimodal_embeddings(
        self, input_ids, pixel_values=None, attention_mask=None, position_ids=None, **kwargs
    ):
        embeds_from_args = kwargs.pop("inputs_embeds", None)
        inputs_embeds = (
            embeds_from_args if embeds_from_args is not None else self.get_text_embeddings(input_ids, **kwargs)
        )
        per_layer_inputs = self.text_embeddings_per_layer(input_ids)
        if pixel_values is not None:
            vision_embeds = self.get_vision_embeddings(pixel_values, input_ids=input_ids, **kwargs)

            if vision_embeds is not None:
                inputs_embeds, attention_mask, position_ids = self.merge_vision_text_embeddings(
                    vision_embeds,
                    inputs_embeds,
                    input_ids=input_ids,
                    attention_mask=attention_mask,
                    position_ids=position_ids,
                    vision_token_id=self.config.image_token_id,
                    **kwargs,
                )

        pixel_values_videos = kwargs.get("pixel_values_videos")
        video_position_ids = kwargs.get("video_position_ids")
        if pixel_values_videos is not None and video_position_ids is not None:
            flatten_pixel_values_videos = pixel_values_videos.flatten(0, 1)
            flatten_video_position_ids = video_position_ids.flatten(0, 1)
            video_embeds = self.get_vision_embeddings(
                flatten_pixel_values_videos, input_ids=input_ids, image_position_ids=flatten_video_position_ids
            )
            if video_embeds is not None:
                inputs_embeds, attention_mask, position_ids = self.merge_vision_text_embeddings(
                    video_embeds,
                    inputs_embeds,
                    input_ids=input_ids,
                    attention_mask=attention_mask,
                    position_ids=position_ids,
                    vision_token_id=self.config.video_token_id,
                    **kwargs,
                )

        return inputs_embeds, attention_mask, position_ids, per_layer_inputs

    def merge_vision_text_embeddings(
        self,
        vision_embeds,
        inputs_embeds,
        input_ids=None,
        attention_mask=None,
        position_ids=None,
        vision_token_id=None,
        **kwargs,
    ):
        if vision_token_id is None:
            raise ValueError("vision_token_id must be provided for merging vision and text embeddings")

        image_features = torch.from_numpy(vision_embeds) if isinstance(vision_embeds, np.ndarray) else vision_embeds
        inputs_embeds = torch.from_numpy(inputs_embeds) if isinstance(inputs_embeds, np.ndarray) else inputs_embeds
        if input_ids is None:
            special_image_mask = inputs_embeds == torch.from_numpy(
                self.get_text_embeddings(torch.tensor([[vision_token_id]], dtype=torch.long))[0]
            )
        else:
            special_image_mask = (input_ids == vision_token_id).unsqueeze(-1)
            special_image_mask = special_image_mask.expand_as(inputs_embeds)

            image_features = image_features.to(inputs_embeds.dtype)
            inputs_embeds = inputs_embeds.masked_scatter(special_image_mask, image_features)

        return inputs_embeds, attention_mask, position_ids

    def prepare_inputs_for_generation(
        self,
        input_ids,
        past_key_values=None,
        inputs_embeds=None,
        pixel_values=None,
        pixel_values_videos=None,
        image_sizes=None,
        attention_mask=None,
        mm_token_type_ids=None,
        image_position_ids=None,
        video_position_ids=None,
        **kwargs,
    ):
        model_inputs = super().prepare_inputs_for_generation(
            input_ids,
            past_key_values=past_key_values,
            inputs_embeds=inputs_embeds,
            pixel_values=pixel_values,
            image_sizes=image_sizes,
            attention_mask=attention_mask,
            **kwargs,
        )
        # Map mm_token_type_ids to token_type_ids for the OV language model input
        model_inputs["token_type_ids"] = mm_token_type_ids
        model_inputs["image_position_ids"] = image_position_ids if past_key_values is None else None
        model_inputs["pixel_values_videos"] = pixel_values_videos if past_key_values is None else None
        model_inputs["video_position_ids"] = video_position_ids if past_key_values is None else None
        return model_inputs

    def forward(self, input_ids, pixel_values=None, token_type_ids=None, **kwargs):
        # Map mm_token_type_ids (from Gemma4 processor) to token_type_ids (OV language model input)
        mm_token_type_ids = kwargs.pop("mm_token_type_ids", None)
        if token_type_ids is None and mm_token_type_ids is not None:
            token_type_ids = mm_token_type_ids
        return super().forward(
            input_ids=input_ids,
            pixel_values=pixel_values,
            token_type_ids=token_type_ids,
            **kwargs,
        )

    @staticmethod
    def preprocess_inputs(
        text: str,
        image: Optional["Image"] = None,
        processor: Optional[AutoImageProcessor] = None,
        tokenizer: Optional[PreTrainedTokenizer] = None,
        config: Optional[PretrainedConfig] = None,
        video: Optional["VideoInput"] = None,
        audio: Optional[np.ndarray] = None,
    ):
        if processor is None:
            raise ValueError("Processor is required.")
        if audio is not None:
            raise ValueError("Audio input is not supported")
        conversation = [
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": text},
                ],
            }
        ]
        if image is not None:
            conversation[0]["content"].insert(0, {"type": "image"})
        if video is not None:
            conversation[0]["content"].insert(0, {"type": "video"})

        text_prompt = processor.apply_chat_template(conversation, add_generation_prompt=True, tokenize=False)

        # switch off add_bos_token if chat template already includes it
        orig_add_bos_token = processor.tokenizer.add_bos_token
        if "bos_token" in processor.tokenizer.chat_template:
            processor.tokenizer.add_bos_token = False

        inputs = processor(images=image, text=text_prompt, videos=video, return_tensors="pt")

        # recover add_bos_token flag in tokenizer
        processor.tokenizer.add_bos_token = orig_add_bos_token

        return inputs

    def _update_model_kwargs_for_generation(
        self,
        outputs,
        model_kwargs,
        is_encoder_decoder=False,
        num_new_tokens=1,
    ):
        model_kwargs = super()._update_model_kwargs_for_generation(
            outputs=outputs,
            model_kwargs=model_kwargs,
            is_encoder_decoder=is_encoder_decoder,
            num_new_tokens=num_new_tokens,
        )
        model_kwargs.pop("mm_token_type_ids", None)
        model_kwargs.pop("image_position_ids", None)
        model_kwargs.pop("pixel_values_videos", None)
        model_kwargs.pop("video_position_ids", None)
        return model_kwargs


class _OVGemma4UnifiedForCausalLM(_OVGemma3ForCausalLM):
    # gemma4_unified (e.g. google/gemma-4-12B) has an encoder-free vision embedder and no
    # per-layer text embeddings. The vision embedder consumes pre-merged pixel patches plus
    # 2D patch position ids and returns one soft token per (pooled) patch.
    def get_vision_embeddings(self, pixel_values, input_ids=None, image_position_ids=None, **kwargs):
        if input_ids is not None and input_ids.shape[1] == 1:
            return None
        return self.vision_embeddings(pixel_values, image_position_ids=image_position_ids).last_hidden_state

    def get_multimodal_embeddings(
        self, input_ids, pixel_values=None, attention_mask=None, position_ids=None, **kwargs
    ):
        embeds_from_args = kwargs.pop("inputs_embeds", None)
        inputs_embeds = (
            embeds_from_args if embeds_from_args is not None else self.get_text_embeddings(input_ids, **kwargs)
        )

        if pixel_values is not None:
            image_embeds = self.get_vision_embeddings(pixel_values, input_ids=input_ids, **kwargs)
            if image_embeds is not None:
                inputs_embeds, attention_mask, position_ids = self.merge_vision_text_embeddings(
                    vision_embeds=image_embeds,
                    inputs_embeds=inputs_embeds,
                    input_ids=input_ids,
                    attention_mask=attention_mask,
                    position_ids=position_ids,
                    vision_token_id=self.config.image_token_id,
                    image_position_ids=kwargs.get("image_position_ids"),
                )

        pixel_values_videos = kwargs.get("pixel_values_videos")
        video_position_ids = kwargs.get("video_position_ids")
        if pixel_values_videos is not None and video_position_ids is not None:
            video_embeds = self.get_vision_embeddings(
                pixel_values_videos.flatten(0, 1),
                input_ids=input_ids,
                image_position_ids=video_position_ids.flatten(0, 1),
            )
            if video_embeds is not None:
                inputs_embeds, attention_mask, position_ids = self.merge_vision_text_embeddings(
                    vision_embeds=video_embeds,
                    inputs_embeds=inputs_embeds,
                    input_ids=input_ids,
                    attention_mask=attention_mask,
                    position_ids=position_ids,
                    vision_token_id=self.config.video_token_id,
                    image_position_ids=video_position_ids.flatten(0, 1),
                )

        return inputs_embeds, attention_mask, position_ids

    def merge_vision_text_embeddings(
        self,
        vision_embeds,
        inputs_embeds,
        input_ids=None,
        attention_mask=None,
        position_ids=None,
        vision_token_id=None,
        **kwargs,
    ):
        if vision_token_id is None:
            raise ValueError("vision_token_id must be provided for merging vision and text embeddings")

        image_features = torch.from_numpy(vision_embeds) if isinstance(vision_embeds, np.ndarray) else vision_embeds
        inputs_embeds = torch.from_numpy(inputs_embeds) if isinstance(inputs_embeds, np.ndarray) else inputs_embeds
        # The vision embedder keeps padding patches; drop them so the number of soft tokens
        # matches the number of image placeholder positions in the text sequence.
        # image_position_ids kwarg is used for both images and videos
        image_position_ids = kwargs.get("image_position_ids")
        if image_position_ids is not None:
            image_position_ids = (
                torch.from_numpy(image_position_ids)
                if isinstance(image_position_ids, np.ndarray)
                else image_position_ids
            )
            valid_mask = (image_position_ids != -1).all(dim=-1).reshape(-1)
            image_features = image_features.reshape(-1, image_features.shape[-1])[valid_mask]

        special_image_mask = (input_ids == vision_token_id).unsqueeze(-1)
        special_image_mask = special_image_mask.expand_as(inputs_embeds)
        image_features = image_features.to(inputs_embeds.dtype)
        inputs_embeds = inputs_embeds.masked_scatter(special_image_mask, image_features)
        return inputs_embeds, attention_mask, position_ids

    def prepare_inputs_for_generation(
        self,
        input_ids,
        past_key_values=None,
        inputs_embeds=None,
        pixel_values=None,
        image_sizes=None,
        attention_mask=None,
        mm_token_type_ids=None,
        image_position_ids=None,
        pixel_values_videos=None,
        video_position_ids=None,
        **kwargs,
    ):
        model_inputs = super().prepare_inputs_for_generation(
            input_ids,
            past_key_values=past_key_values,
            inputs_embeds=inputs_embeds,
            pixel_values=pixel_values,
            image_sizes=image_sizes,
            attention_mask=attention_mask,
            **kwargs,
        )
        # Map mm_token_type_ids (from the Gemma4Unified processor) to token_type_ids and
        # propagate the patch positions needed by the vision embedder.
        model_inputs["token_type_ids"] = mm_token_type_ids
        model_inputs["image_position_ids"] = image_position_ids if past_key_values is None else None
        model_inputs["pixel_values_videos"] = pixel_values_videos if past_key_values is None else None
        model_inputs["video_position_ids"] = video_position_ids if past_key_values is None else None
        return model_inputs

    def forward(self, input_ids, pixel_values=None, token_type_ids=None, **kwargs):
        mm_token_type_ids = kwargs.pop("mm_token_type_ids", None)
        if token_type_ids is None and mm_token_type_ids is not None:
            token_type_ids = mm_token_type_ids
        return super().forward(
            input_ids=input_ids,
            pixel_values=pixel_values,
            token_type_ids=token_type_ids,
            **kwargs,
        )

    @staticmethod
    def preprocess_inputs(
        text: str,
        image: Optional["Image"] = None,
        processor: Optional[AutoImageProcessor] = None,
        tokenizer: Optional[PreTrainedTokenizer] = None,
        config: Optional[PretrainedConfig] = None,
        video: Optional["VideoInput"] = None,
        audio: Optional[np.ndarray] = None,
    ):
        if processor is None:
            raise ValueError("Processor is required.")
        if audio is not None:
            raise ValueError("Audio input is not supported")

        if getattr(tokenizer, "chat_template", None) is None:
            if image is not None:
                # If chat template is not available we need to add image token manually, as there's a requirement
                # that image token number should match the number of provided images:
                # https://github.com/huggingface/transformers/blob/v5.10.0/src/transformers/models/gemma4_unified/processing_gemma4_unified.py#L187
                image_token = getattr(processor, "image_token", "<|image|>")
                if image_token not in text:
                    text = f"{image_token}{text}"
            if video is not None:
                video_token = getattr(processor, "video_token", "<|video|>")
                if video_token not in text:
                    text = f"{video_token}{text}"
            return processor(text=text, images=image, videos=video, return_tensors="pt")

        conversation = [
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": text},
                ],
            }
        ]
        if image is not None:
            conversation[0]["content"].insert(0, {"type": "image"})
        if video is not None:
            conversation[0]["content"].insert(0, {"type": "video"})

        text_prompt = processor.apply_chat_template(conversation, add_generation_prompt=True, tokenize=False)
        return processor(images=image, text=text_prompt, videos=video, return_tensors="pt")

    def _update_model_kwargs_for_generation(
        self,
        outputs,
        model_kwargs,
        is_encoder_decoder=False,
        num_new_tokens=1,
    ):
        model_kwargs = super()._update_model_kwargs_for_generation(
            outputs=outputs,
            model_kwargs=model_kwargs,
            is_encoder_decoder=is_encoder_decoder,
            num_new_tokens=num_new_tokens,
        )
        model_kwargs.pop("mm_token_type_ids", None)
        model_kwargs.pop("image_position_ids", None)
        model_kwargs.pop("pixel_values_videos", None)
        model_kwargs.pop("video_position_ids", None)
        return model_kwargs


class _OVGotOCR2ForCausalLM(OVModelForVisualCausalLM):
    def get_vision_embeddings(self, pixel_values, input_ids, **kwargs):
        if input_ids is not None and input_ids.shape[1] == 1 and kwargs.get("past_key_values") is not None:
            return None
        return self.vision_embeddings(pixel_values).last_hidden_state

    def merge_vision_text_embeddings(
        self, vision_embeds, inputs_embeds, input_ids=None, attention_mask=None, position_ids=None, **kwargs
    ):
        # Adopted from https://github.com/huggingface/transformers/blob/v4.49.0/src/transformers/models/got_ocr2/modeling_got_ocr2.py#L836-L845
        image_features = torch.from_numpy(vision_embeds) if isinstance(vision_embeds, np.ndarray) else vision_embeds
        inputs_embeds = torch.from_numpy(inputs_embeds) if isinstance(inputs_embeds, np.ndarray) else inputs_embeds
        n_image_tokens = (input_ids == self.config.image_token_index).sum()
        n_image_features = image_features.shape[0] * image_features.shape[1]
        if n_image_tokens != n_image_features:
            raise ValueError(
                f"Image features and image tokens do not match: tokens: {n_image_tokens}, features {n_image_features}"
            )
        special_image_mask = (input_ids == self.config.image_token_index).unsqueeze(-1)
        special_image_mask = special_image_mask.expand_as(inputs_embeds).to(inputs_embeds.device)
        image_features = image_features.to(inputs_embeds.device, inputs_embeds.dtype)
        inputs_embeds = inputs_embeds.masked_scatter(special_image_mask, image_features)

        return inputs_embeds, attention_mask, position_ids

    @staticmethod
    def preprocess_inputs(
        text: Optional[str] = None,
        image: Optional["Image"] = None,
        processor: Optional[AutoImageProcessor] = None,
        tokenizer: Optional[PreTrainedTokenizer] = None,
        config: Optional[PretrainedConfig] = None,
        video: Optional["VideoInput"] = None,
        audio: Optional[np.ndarray] = None,
    ):
        if processor is None:
            raise ValueError("processor is required")
        if video is not None:
            raise ValueError("Video input is not supported")
        if audio is not None:
            raise ValueError("Audio input is not supported")
        if image is None:
            raise ValueError("Image is required")
        processed_inputs = processor(image, return_tensors="pt")
        return processed_inputs


class _OVDeepseekOCR2ForCausalLM(OVModelForVisualCausalLM):
    """OpenVINO inference for DeepSeek-OCR-2 (``model_type == "deepseek_ocr2"``).

    The vision encoder is exported as two static-shape submodels: ``vision_embeddings`` for the
    1024x1024 global view (256 image tokens) and ``vision_embeddings_tiles`` for the 768x768 crop
    tiles (144 image tokens each). Both submodels already include the multimodal projector, so
    their output lives in the text-embedding space. The per-image visual feature is
    ``cat([local_tiles, global, view_separator])`` (mirroring the native
    ``DeepseekOcr2Model.get_image_features``), which is scattered into the text embeddings at the
    image placeholder positions (``config.image_token_id``).
    """

    additional_parts = ["vision_embeddings_tiles"]

    # Image token placeholder id used by DeepSeek-OCR-2 (fallback when config lacks image_token_id).
    _DEEPSEEK_OCR2_IMAGE_TOKEN_ID = 128815

    @property
    def image_token_id(self):
        return getattr(self.config, "image_token_id", self._DEEPSEEK_OCR2_IMAGE_TOKEN_ID)

    @property
    def view_separator(self):
        if getattr(self, "_view_separator", None) is None:
            self._view_separator = torch.tensor(self.config.view_separator, dtype=torch.float32)
        return self._view_separator

    def get_vision_embeddings(self, pixel_values, input_ids=None, **kwargs):
        # Skip vision on cached decode steps.
        if input_ids is not None and input_ids.shape[1] == 1 and kwargs.get("past_key_values") is not None:
            return None

        pixel_values = torch.as_tensor(pixel_values) if not isinstance(pixel_values, torch.Tensor) else pixel_values
        pixel_values_local = kwargs.get("pixel_values_local")
        num_local_patches = kwargs.get("num_local_patches")

        global_features = self.vision_embeddings(pixel_values.to(torch.float32)).last_hidden_state
        global_features = torch.from_numpy(global_features).to(torch.float32)  # (B, 256, txt)
        batch_size, hidden = global_features.shape[0], global_features.shape[-1]

        per_image_local = [None] * batch_size
        if pixel_values_local is not None and num_local_patches is not None:
            num_local_patches = torch.as_tensor(num_local_patches).reshape(-1).tolist()
            pixel_values_local = (
                torch.as_tensor(pixel_values_local)
                if not isinstance(pixel_values_local, torch.Tensor)
                else pixel_values_local
            )
            if pixel_values_local.shape[0] > 0:
                local_features = self.vision_embeddings_tiles(pixel_values_local.to(torch.float32)).last_hidden_state
                local_features = torch.from_numpy(local_features).to(torch.float32)  # (total, 144, txt)
                per_image_local = list(torch.split(local_features, num_local_patches, dim=0))

        view_sep = self.view_separator[None, :]  # (1, txt)
        features = []
        for idx in range(batch_size):
            global_flat = global_features[idx].reshape(-1, hidden)
            if per_image_local[idx] is not None:
                local_flat = per_image_local[idx].reshape(-1, per_image_local[idx].shape[-1])
                features.append(torch.cat([local_flat, global_flat, view_sep], dim=0))
            else:
                features.append(torch.cat([global_flat, view_sep], dim=0))
        return torch.cat(features, dim=0)

    def merge_vision_text_embeddings(
        self, vision_embeds, inputs_embeds, input_ids=None, attention_mask=None, position_ids=None, **kwargs
    ):
        vision_embeds = torch.from_numpy(vision_embeds) if isinstance(vision_embeds, np.ndarray) else vision_embeds
        inputs_embeds = torch.from_numpy(inputs_embeds) if isinstance(inputs_embeds, np.ndarray) else inputs_embeds
        mask = (input_ids == self.image_token_id).unsqueeze(-1).expand_as(inputs_embeds)
        inputs_embeds = inputs_embeds.masked_scatter(mask, vision_embeds.to(inputs_embeds.dtype))
        return inputs_embeds, attention_mask, position_ids

    def forward(self, input_ids, pixel_values=None, pixel_values_local=None, num_local_patches=None, **kwargs):
        return super().forward(
            input_ids,
            pixel_values=pixel_values,
            pixel_values_local=pixel_values_local,
            num_local_patches=num_local_patches,
            **kwargs,
        )

    def prepare_inputs_for_generation(
        self, input_ids, past_key_values=None, inputs_embeds=None, pixel_values=None, attention_mask=None, **kwargs
    ):
        model_inputs = super().prepare_inputs_for_generation(
            input_ids,
            past_key_values=past_key_values,
            inputs_embeds=inputs_embeds,
            pixel_values=pixel_values,
            attention_mask=attention_mask,
            **kwargs,
        )
        # Carry the extra DeepSeek-OCR-2 local-tile inputs on the prefill step only.
        if past_key_values is None:
            model_inputs["pixel_values_local"] = kwargs.get("pixel_values_local")
            model_inputs["num_local_patches"] = kwargs.get("num_local_patches")
        else:
            model_inputs["pixel_values"] = None
            model_inputs["pixel_values_local"] = None
            model_inputs["num_local_patches"] = None
        return model_inputs

    @staticmethod
    def preprocess_inputs(
        text: Optional[str] = None,
        image: Optional["Image"] = None,
        processor: Optional[AutoImageProcessor] = None,
        tokenizer: Optional[PreTrainedTokenizer] = None,
        config: Optional[PretrainedConfig] = None,
        video: Optional["VideoInput"] = None,
        audio: Optional[np.ndarray] = None,
    ):
        if processor is None:
            raise ValueError("processor is required")
        if video is not None or audio is not None:
            raise ValueError("Video/audio inputs are not supported")
        if image is None:
            raise ValueError("Image input is required for DeepSeek-OCR-2")
        if text is None:
            text = "Free OCR."
        if "<image>" not in text:
            text = "<image>\n" + text
        return processor(images=image, text=text, return_tensors="pt")


class _OVIdefics3ForCausalLM(OVModelForVisualCausalLM):
    def get_vision_embeddings(self, pixel_values, input_ids, **kwargs):
        # Adopted from https://github.com/huggingface/transformers/blob/v4.49.0-SmolVLM-2/src/transformers/models/smolvlm/modeling_smolvlm.py#L899-L942
        if input_ids is not None and input_ids.shape[1] == 1 and kwargs.get("past_key_values") is not None:
            return None
        batch_size, num_images, num_channels, height, width = pixel_values.shape
        pixel_values = pixel_values
        pixel_values = pixel_values.view(batch_size * num_images, *pixel_values.shape[2:])

        # Remove padding images - padding images are full 0.
        nb_values_per_image = pixel_values.shape[1:].numel()
        real_images_inds = (pixel_values == 0.0).sum(dim=(-1, -2, -3)) != nb_values_per_image

        if not any(real_images_inds):
            # no images, leave one empty image.
            real_images_inds[0] = True

        pixel_values = pixel_values[real_images_inds].contiguous()
        pixel_attention_mask = kwargs.get("pixel_attention_mask")

        # Handle the vision attention mask
        if pixel_attention_mask is None:
            pixel_attention_mask = torch.ones(
                size=[pixel_values.shape[i] for i in (0, 2, 3)],
                dtype=torch.bool,
                device=pixel_values.device,
            )
        else:
            # Remove padding images from the mask
            pixel_attention_mask = pixel_attention_mask.view(batch_size * num_images, *pixel_attention_mask.shape[2:])
            pixel_attention_mask = pixel_attention_mask[real_images_inds].contiguous()

        patch_size = self.config.vision_config.patch_size
        num_patches_per_side = self.config.vision_config.image_size // patch_size
        patches_subgrid = pixel_attention_mask.unfold(dimension=1, size=patch_size, step=patch_size)
        patches_subgrid = patches_subgrid.unfold(dimension=2, size=patch_size, step=patch_size)
        patch_attention_mask = (patches_subgrid.sum(dim=(-1, -2)) > 0).bool()
        batch_size_, _, max_im_h, max_im_w = pixel_values.shape
        max_nb_patches_h, max_nb_patches_w = max_im_h // patch_size, max_im_w // patch_size
        boundaries = torch.arange(1 / num_patches_per_side, 1.0, 1 / num_patches_per_side)
        position_ids = torch.full(size=(batch_size_, max_nb_patches_h * max_nb_patches_w), fill_value=0)

        for batch_idx, p_attn_mask in enumerate(patch_attention_mask):
            nb_patches_h = p_attn_mask[:, 0].sum()
            nb_patches_w = p_attn_mask[0].sum()
            if is_transformers_version("<", "4.55"):
                fractional_coords_h = torch.arange(0, 1 - 1e-6, 1 / nb_patches_h)
                fractional_coords_w = torch.arange(0, 1 - 1e-6, 1 / nb_patches_w)
            else:
                h_indices = torch.arange(nb_patches_h, device=pixel_values.device, dtype=pixel_values.dtype)
                w_indices = torch.arange(nb_patches_w, device=pixel_values.device, dtype=pixel_values.dtype)
                fractional_coords_h = h_indices / nb_patches_h * (1 - 1e-6)
                fractional_coords_w = w_indices / nb_patches_w * (1 - 1e-6)

            bucket_coords_h = torch.bucketize(fractional_coords_h, boundaries, right=True)
            bucket_coords_w = torch.bucketize(fractional_coords_w, boundaries, right=True)

            pos_ids = (bucket_coords_h[:, None] * num_patches_per_side + bucket_coords_w).flatten()
            position_ids[batch_idx][p_attn_mask.view(-1).cpu()] = pos_ids
        return self.vision_embeddings(
            pixel_values=pixel_values, patch_attention_mask=patch_attention_mask, patch_position_ids=position_ids
        ).last_hidden_state

    def merge_vision_text_embeddings(
        self, vision_embeds, inputs_embeds, input_ids=None, attention_mask=None, position_ids=None, **kwargs
    ):
        # Adopted from https://github.com/huggingface/transformers/blob/v4.49.0-SmolVLM-2/src/transformers/models/idefics3/modeling_idefics3.py#L881
        image_features = torch.from_numpy(vision_embeds) if isinstance(vision_embeds, np.ndarray) else vision_embeds
        inputs_embeds = torch.from_numpy(inputs_embeds) if isinstance(inputs_embeds, np.ndarray) else inputs_embeds
        vision_hidden_size = image_features.shape[2]
        special_image_token_mask = input_ids == self.config.image_token_id
        #  Fixes RuntimeError: a leaf Variable that requires grad is being used in an in-place operation.
        new_inputs_embeds = inputs_embeds.clone()
        reshaped_image_hidden_states = image_features.view(-1, vision_hidden_size)
        # cast to the dtype of the input_embeds to support quantized models
        reshaped_image_hidden_states = reshaped_image_hidden_states.to(inputs_embeds.device, inputs_embeds.dtype)
        new_inputs_embeds[special_image_token_mask] = reshaped_image_hidden_states
        inputs_embeds = new_inputs_embeds

        return inputs_embeds, attention_mask, position_ids

    @staticmethod
    def preprocess_inputs(
        text: str,
        image: Optional["Image"] = None,
        processor: Optional[AutoImageProcessor] = None,
        tokenizer: Optional[PreTrainedTokenizer] = None,
        config: Optional[PretrainedConfig] = None,
        video: Optional["VideoInput"] = None,
        audio: Optional[np.ndarray] = None,
    ):
        if processor is None:
            raise ValueError("Processor is required.")

        if video is not None:
            raise ValueError("video input is not supported")

        if audio is not None:
            raise ValueError("Audio input is not supported")
        conversation = [
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": text},
                ],
            }
        ]
        if image is not None:
            conversation[0]["content"].insert(0, {"type": "image"})

        text_prompt = processor.apply_chat_template(conversation, add_generation_prompt=True)

        inputs = processor(images=image, text=text_prompt, return_tensors="pt")
        return inputs


class _OVSmolVLForCasualLM(_OVIdefics3ForCausalLM):
    def merge_vision_text_embeddings(
        self, vision_embeds, inputs_embeds, input_ids=None, attention_mask=None, position_ids=None, **kwargs
    ):
        # Adopted from https://github.com/huggingface/transformers/blob/v4.49.0-SmolVLM-2/src/transformers/models/smolvlm/modeling_smolvlm.py#L803
        image_features = torch.from_numpy(vision_embeds) if isinstance(vision_embeds, np.ndarray) else vision_embeds
        inputs_embeds = torch.from_numpy(inputs_embeds) if isinstance(inputs_embeds, np.ndarray) else inputs_embeds
        _, patch_size, _ = image_features.shape

        image_mask = input_ids == self.config.image_token_id
        num_image_tokens = image_mask.sum(dim=1)
        if not torch.all(num_image_tokens % patch_size == 0):
            raise ValueError("At least one sample has <image> tokens not divisible by patch_size.")

        blocks_per_sample = num_image_tokens // patch_size

        offsets = torch.nn.functional.pad(blocks_per_sample.cumsum(dim=0), (1, 0), value=0)
        block_offset = offsets[:-1]
        row_cum = image_mask.cumsum(dim=-1)
        chunk_idx = (row_cum - 1) // patch_size
        local_idx = (row_cum - 1) % patch_size
        block_idx = block_offset.unsqueeze(1) + chunk_idx

        image_embeds = torch.zeros_like(inputs_embeds)
        image_embeds[image_mask] = image_features[block_idx[image_mask], local_idx[image_mask], :]

        inputs_embeds = torch.where(image_mask.unsqueeze(-1), image_embeds, inputs_embeds)

        return inputs_embeds, attention_mask, position_ids


class _OVPhi4MMForCausalLM(OVModelForVisualCausalLM):
    additional_parts = [
        "vision_projection",
        "audio_embeddings",
        "audio_forward_embeddings",
        "audio_encoder",
        "audio_vision_projection",
        "audio_speech_projection",
    ]

    def __init__(
        self,
        language_model: ov.Model,
        text_embeddings: ov.Model,
        vision_embeddings: ov.Model,
        config: PretrainedConfig = None,
        device: str = "CPU",
        dynamic_shapes: bool = None,
        ov_config: Optional[Dict[str, str]] = None,
        model_save_dir: Optional[Union[str, Path, TemporaryDirectory]] = None,
        quantization_config: Union[OVWeightQuantizationConfig, Dict] = None,
        **kwargs,
    ):
        super().__init__(
            language_model=language_model,
            text_embeddings=text_embeddings,
            vision_embeddings=vision_embeddings,
            config=config,
            device=device,
            dynamic_shapes=dynamic_shapes,
            ov_config=ov_config,
            model_save_dir=model_save_dir,
            quantization_config=quantization_config,
            **kwargs,
        )

        self.sub_GN = torch.tensor(self.config.sub_GN)
        self.glb_GN = torch.tensor(self.config.glb_GN)
        self.audio_config = (
            config.audio_processor["config"] if hasattr(config, "audio_processor") else config.audio_config.to_dict()
        )
        self.chunk_size = self.audio_config.get("chunk_size", -1)
        self.left_chunk = self.audio_config.get("left_chunk", 18)
        self.time_reduction = self.audio_config.get("time_reduction", 8)
        self.image_config = (
            config.img_processor if hasattr(config, "img_processor") else config.vision_config.to_dict()
        )
        self.image_size = self.image_config.get("crop_size", 448)
        self.patch_size = self.image_config.get("patch_size", 14)
        self.num_patches_per_side = self.image_size // self.patch_size
        self._IMAGE_SPECIAL_TOKEN_ID = (
            200010 if "image_token_id" not in self.image_config else self.image_config["image_token_id"]
        )
        self._AUDIO_SPECIAL_TOKEN_ID = (
            200011 if "audio_token_id" not in self.audio_config else self.audio_config["audio_token_id"]
        )
        self._COMPATIBLE_IMAGE_SPECIAL_TOKEN_ID_RANGE = [-9999, -1]  # For backward compatibility
        self._COMPATIBLE_AUDIO_SPECIAL_TOKEN_ID_RANGE = [float("-inf"), -10000]  # For backward compatibility
        self.image_dim_out = self.image_config.get("image_dim_out", self.image_config["hidden_size"])

    # Adopted from https://github.com/huggingface/transformers/blob/v4.51.3/src/transformers/models/phi4_multimodal/modeling_phi4_multimodal.py#L669
    def image_embed(
        self,
        input_ids: torch.LongTensor,
        image_pixel_values: torch.FloatTensor,
        image_attention_mask,
        inputs_embeds,
        image_sizes=None,
        **kwargs,
    ):
        input_shape = input_ids.size()
        input_ids = input_ids.view(-1, input_shape[-1])
        positions_tuple = torch.nonzero(input_ids == self._IMAGE_SPECIAL_TOKEN_ID, as_tuple=True)

        if len(positions_tuple[-1]) == 0:
            return None
        batch_size = image_pixel_values.shape[0]

        img_features = self.get_img_features(
            image_pixel_values.flatten(0, 1),
            image_attention_mask=image_attention_mask.flatten(0, 1).to(dtype=bool),
        )

        base_feat_size = int(np.sqrt(img_features.shape[1]))
        img_features = img_features.view(batch_size, -1, base_feat_size**2, self.image_dim_out)
        image_sizes = image_sizes.view(-1, 2)

        output_imgs = []
        for idx in range(batch_size):
            height, width = image_sizes[idx]
            height_ratio = height // self.image_size
            width_ratio = width // self.image_size
            area_ratio = height_ratio * width_ratio

            global_img = img_features[idx, :1]
            global_img = global_img.reshape(1, base_feat_size, base_feat_size, self.image_dim_out).contiguous()
            temporary_extensor = self.sub_GN.repeat(1, base_feat_size, 1, 1)
            global_img = torch.cat([global_img, temporary_extensor], dim=2).reshape(1, -1, self.image_dim_out)

            sub_img = img_features[idx, 1:]
            sub_img = sub_img[:area_ratio]
            sub_img = (
                sub_img.reshape(height_ratio, width_ratio, base_feat_size, base_feat_size, self.image_dim_out)
                .transpose(1, 2)
                .reshape(1, height_ratio * base_feat_size, width_ratio * base_feat_size, self.image_dim_out)
                .contiguous()
            )

            if image_attention_mask is not None:
                reshaped_image_attention_mask = (
                    image_attention_mask[idx, 1 : area_ratio + 1, 0::2, 0::2]
                    .reshape(height_ratio, width_ratio, base_feat_size, base_feat_size)
                    .transpose(1, 2)
                    .reshape(1, height_ratio * base_feat_size, width_ratio * base_feat_size)
                )
                useful_height = int(reshaped_image_attention_mask[0, :, 0].sum().item())
                useful_width = int(reshaped_image_attention_mask[0, 0, :].sum().item())
                sub_img = sub_img[:, :useful_height, :useful_width]
                temporary_extensor = self.sub_GN.repeat(1, useful_height, 1, 1)
            else:
                temporary_extensor = self.sub_GN.repeat(1, height_ratio * base_feat_size, 1, 1)

            sub_img = torch.cat([sub_img, temporary_extensor], dim=2).reshape(1, -1, self.image_dim_out)

            # Merge global and sub
            output_imgs.append(torch.cat([sub_img, self.glb_GN, global_img], dim=1))

        img_set_tensor = []
        for output_img in output_imgs:
            img_feature_proj = torch.from_numpy(self.vision_projection(output_img))
            img_set_tensor.append(img_feature_proj)

        merged_img_set_tensor = torch.cat(img_set_tensor, dim=1).squeeze(0)

        image_embeds = inputs_embeds.index_put(indices=positions_tuple, values=merged_img_set_tensor, accumulate=False)

        return image_embeds

    # Adopted from https://github.com/huggingface/transformers/blob/v4.51.3/src/transformers/models/phi4_multimodal/modeling_phi4_multimodal.py#L1241
    def audio_embed(
        self,
        input_ids: torch.LongTensor,
        audio_input_embeds: torch.FloatTensor,
        inputs_embeds,
        audio_embed_sizes=None,
        audio_projection_mode="speech",
        **kwargs,
    ):
        input_shape = input_ids.size()
        input_ids = input_ids.view(-1, input_shape[-1])

        positions_tuple = torch.nonzero(input_ids == self._AUDIO_SPECIAL_TOKEN_ID, as_tuple=True)

        if len(positions_tuple[-1]) == 0:
            return None

        audio_embeds = self.get_audio_features(audio_input_embeds, audio_projection_mode)

        merged_audio_embeds = torch.cat(
            [audio_embeds[i, : audio_embed_sizes[i], :] for i in range(len(audio_embed_sizes))], dim=0
        )
        inputs_embeds = inputs_embeds.index_put(indices=positions_tuple, values=merged_audio_embeds, accumulate=False)

        return inputs_embeds

    # Adopted from https://github.com/huggingface/transformers/blob/v4.51.3/src/transformers/models/phi4_multimodal/modeling_phi4_multimodal.py#L1165
    def get_audio_features(
        self,
        input_embeds: torch.FloatTensor,
        audio_projection_mode: str = "speech",
    ):
        xs_pad = self.audio_embeddings(input_embeds)
        input_tensor, pos_k, pos_v, hs_mask, masks = self.forward_embeddings(xs_pad)

        unfolded = False
        ori_bz, seq_len, D = input_tensor.shape
        max_seq_len = 500  # maximum position for absolute positional encoding
        masks_unfold = None
        if seq_len > max_seq_len:
            # audio sequence is longer than max_seq_len, unfold it into chunks of max_seq_len
            unfolded = True
            # the unfold op will drop residual frames, pad it to the multiple of max_seq_len
            if seq_len % max_seq_len > 0:
                chunk_pad_size = max_seq_len - (seq_len % max_seq_len)
            else:
                chunk_pad_size = 0
            if chunk_pad_size > 0:
                input_tensor_pad = torch.nn.functional.pad(
                    torch.from_numpy(input_tensor), (0, 0, 0, chunk_pad_size), "constant", 0
                )
                input_tensor = input_tensor_pad

            input_tensor = self.unfold_tensor(input_tensor, max_seq_len)
            if masks is not None:
                # revise hs_mask here because the previous calculated hs_mask did not consider extra pad
                subsampled_pad_mask = masks.squeeze(1)  # [bz, subsampled_unmask_seq_len]
                extra_padded_subsamlped_pad_mask = torch.nn.functional.pad(
                    subsampled_pad_mask, (0, chunk_pad_size), "constant", False
                )  # extra padding to the pad mask
                extra_padded_subsamlped_pad_mask = extra_padded_subsamlped_pad_mask.unsqueeze(-1).float()
                masks_unfold = self.unfold_tensor(
                    extra_padded_subsamlped_pad_mask, max_seq_len
                )  # unfold the pad mask like we did to the input tensor
                masks_unfold = masks_unfold.squeeze(-1).bool()  # unfold op does not support bool tensor
            else:
                masks_unfold = None
        hs_mask = self.calculate_hs_mask(input_tensor, masks_unfold)
        audio_features = self.audio_encoder(input_tensor, hs_mask)
        if unfolded:
            embed_dim = audio_features.shape[-1]
            audio_features = np.reshape(audio_features, (ori_bz, -1, embed_dim))
            # if we ever padded before unfolding, we need to remove the padding
            if chunk_pad_size > 0:
                audio_features = audio_features[:, :-chunk_pad_size, :]
        audio_encoder = (
            self.audio_vision_projection if audio_projection_mode == "vision" else self.audio_speech_projection
        )
        audio_set_tensor = audio_encoder(audio_features)

        return torch.from_numpy(audio_set_tensor)

    def _chunk_size_selection(self, chunk_size=None, left_chunk=None):
        """If chunk size is a list, we will randomly select a chunk size."""
        if isinstance(chunk_size, list):
            # Variable chunk size during training
            chunk_size_index = int(torch.randint(low=0, high=len(chunk_size), size=(1,)))
            chunk_size_train_eff = chunk_size[chunk_size_index]
            if not isinstance(left_chunk, list):
                raise ValueError("Since chunk_size is a list, left_chunk must be a list")
            if len(left_chunk) != len(chunk_size):
                raise ValueError("The length of left_chunk must be the same as length of chunk_size.")
            left_chunk_train_eff = left_chunk[chunk_size_index]
        else:
            chunk_size_train_eff = chunk_size
            left_chunk_train_eff = left_chunk

        return chunk_size_train_eff, left_chunk_train_eff

    # Adopted from https://github.com/huggingface/transformers/blob/v4.51.3/src/transformers/models/phi4_multimodal/modeling_phi4_multimodal.py#L1121
    def forward_embeddings(self, xs_pad, masks=None, chunk_size_nc=None, left_chunk_nc=None):
        """Forwarding the inputs through the top embedding layers

        Args:
            xs_pad: torch.Tensor
                input tensor
            masks: torch.Tensor
                input mask
            chunk_size_nc: (optional, default is None) chunk size for non-causal layers
            left_chunk_nc: (optional, default is None) # of left chunks for non-causal layers
        """
        seq_len = int(self.compute_lens_change(xs_pad.shape[1]))
        if seq_len <= 0:
            raise ValueError(
                f"""The sequence length after time reduction is invalid: {seq_len}.
                Your input feature is too short. Consider filtering out the very
                short sentence from data loader""",
            )

        batch_size = xs_pad.shape[0]

        enc_streaming_mask = self._streaming_mask(seq_len, batch_size, self.chunk_size, self.left_chunk)

        input_tensor = xs_pad

        input_tensor = self.audio_forward_embeddings(input_tensor)

        streaming_mask = enc_streaming_mask
        if streaming_mask is not None and masks is not None:
            hs_mask = masks & streaming_mask
        else:
            hs_mask = streaming_mask

        if chunk_size_nc is not None:
            enc_streaming_mask_nc = self._streaming_mask(seq_len, batch_size, chunk_size_nc, left_chunk_nc)
            if masks is not None:
                hs_mask_nc = masks & enc_streaming_mask_nc
            else:
                hs_mask_nc = enc_streaming_mask_nc
        else:
            hs_mask_nc = None

        if chunk_size_nc is None:
            return input_tensor, None, None, hs_mask, None
        return input_tensor, None, None, hs_mask, None, hs_mask_nc

    # Adopted from https://github.com/huggingface/transformers/blob/v4.51.3/src/transformers/models/phi4_multimodal/modeling_phi4_multimodal.py#L1101
    def _streaming_mask(self, seq_len, batch_size, chunk_size, left_chunk):
        chunk_size_train_eff, left_chunk_train_eff = self._chunk_size_selection(chunk_size, left_chunk)

        # Create mask matrix for streaming
        # S stores start index. if chunksize is 18, s is [0,18,36,....]
        chunk_start_idx = np.arange(0, seq_len, chunk_size_train_eff)
        # avoid randomness when run evaluation or decoding

        enc_streaming_mask = (
            self.adaptive_enc_mask(seq_len, chunk_start_idx, left_window=left_chunk_train_eff)
            .unsqueeze(0)
            .expand([batch_size, -1, -1])
        )
        return enc_streaming_mask

    def compute_lens_change(self, feature_lens):
        """feature_lens: int
        return updated feature lens.

        This used to return a different lambda function for each case that computed
        the right thing.  That does not work within Torchscript.  If you really
        need this to be faster, create nn.Module()-s for all the cases and return
        one of them.  Torchscript does support that.
        """
        nemo_conv_settings = self.audio_config.get("nemo_conv_settings")
        if nemo_conv_settings is None:
            nemo_conv_settings = {"conv_channels": self.audio_config["nemo_conv_channels"]}
        # Handle the special causal case
        subsampling_causal_cond = nemo_conv_settings.get("subsampling", "dw_striding") in [
            "dw_striding",
            "striding",
            "striding_conv1d",
        ]
        is_causal = nemo_conv_settings.get("is_causal", False)
        if is_causal and subsampling_causal_cond:
            lens_change = (
                torch.ceil(feature_lens / self.time_reduction).long()
                if isinstance(feature_lens, torch.Tensor)
                else math.ceil(feature_lens / self.time_reduction)
            )
            feature_lens_remainder = feature_lens % self.time_reduction
            if isinstance(feature_lens, torch.Tensor):
                lens_change[feature_lens_remainder != 1] += 1
            elif feature_lens_remainder != 1:
                lens_change += 1
                return lens_change
        ceil_func = math.ceil if isinstance(feature_lens, int) else torch.ceil
        return ceil_func(feature_lens / self.time_reduction)

    # Adopted from https://github.com/huggingface/transformers/blob/v4.51.3/src/transformers/models/phi4_multimodal/modeling_phi4_multimodal.py#L1146
    def calculate_hs_mask(self, xs_pad, mask):
        max_audio_length = xs_pad.shape[1]
        batch_size = xs_pad.shape[0]
        enc_streaming_mask = self._streaming_mask(max_audio_length, batch_size, self.chunk_size, self.left_chunk)
        if mask is None:
            return enc_streaming_mask

        feature_lens = mask.sum(1)
        padding_length = feature_lens
        pad_mask = torch.arange(0, max_audio_length).expand(padding_length.size(0), -1) < padding_length.unsqueeze(1)
        pad_mask = pad_mask.unsqueeze(1)
        pad_mask = pad_mask & enc_streaming_mask
        return pad_mask

    # Adopted from https://github.com/huggingface/transformers/blob/v4.51.3/src/transformers/models/phi4_multimodal/modeling_phi4_multimodal.py#L1034
    @staticmethod
    def unfold_tensor(xs_pad, max_seq_len):
        """
        For a given tensor with shape of (N, T, D), if sequence length T is longer than max_seq_len,
        this function unfold it to a (NT', max_seq_len, D) where T' is T // max_seq_len.
        Args:
            xs_pad: N, T, D
        """
        _, _, D = xs_pad.shape
        xs_pad = xs_pad.transpose(-1, -2)  # convert to N, D, T
        # N x D x 1 x T => N x (D x max_seq_len) x T'
        xs_pad = torch.nn.functional.unfold(
            xs_pad[..., None, :],
            kernel_size=(1, max_seq_len),
            stride=(1, max_seq_len),
        )

        new_bsz, _, slen = xs_pad.shape
        # N x D x max_seq_len x T'
        xs_pad = xs_pad.view(new_bsz, -1, max_seq_len, slen)
        # N x T' x max_seq_len x D
        xs_pad = xs_pad.permute(0, 3, 2, 1).contiguous()
        # NT' x max_seq_len x D
        xs_pad = xs_pad.view(-1, max_seq_len, D)
        return xs_pad

    # Adopted from https://github.com/huggingface/transformers/blob/v4.51.3/src/transformers/models/phi4_multimodal/modeling_phi4_multimodal.py#L1053
    @staticmethod
    def adaptive_enc_mask(x_len, chunk_start_idx, left_window=0, right_window=0):
        """
        The function is very important for Transformer Transducer Streaming mode
        Args:
            xs_len (int): sequence length
            chunk_start_idx (list): first idx of each chunk, such as [0,18,36,48]. It also supports adaptive chunk size [0,10,15,45]
            left_window (int): how many left chunks can be seen
            right_window (int): how many right chunks can be seen. It is used for chunk overlap model.
            Returns:
                mask (torch.Tensor): a mask tensor for streaming model
                Torch 1.0.1
                tensor([[1., 1., 0., 0.],
                        [0., 1., 1., 0.],
                        [0., 0., 1., 1.]])
                Torch 1.4.1
                tensor([[True., True., False., False.],
                        [False., True., True., False.],
                        [False., False., True., True.]])
        """
        chunk_start_idx = torch.Tensor(chunk_start_idx).long()  # first idx of each chunk, such as [0,18,36,48].
        start_pad = torch.nn.functional.pad(
            chunk_start_idx, (1, 0)
        )  # append 0 to the beginning, so it becomes [0, 0, 18, 36, 48]
        end_pad = torch.nn.functional.pad(
            chunk_start_idx, (0, 1), value=x_len
        )  # append x_len to the end, so it becomes [0,18,36,48, x_len]
        seq_range = torch.arange(0, x_len).unsqueeze(-1)  # seq_range size: [x_len, 1]
        idx = ((seq_range < end_pad) & (seq_range >= start_pad)).nonzero()[:, 1]  # idx size: [x_len]
        end_pad[idx]  # boundary size: [x_len]
        seq_range_expand = (
            torch.arange(0, x_len).unsqueeze(0).expand(x_len, -1)
        )  # seq_range_expand size [x_len, x_len]
        idx_left = idx - left_window
        idx_left[idx_left < 0] = 0
        boundary_left = start_pad[idx_left]
        mask_left = seq_range_expand >= boundary_left.unsqueeze(-1)
        idx_right = idx + right_window
        idx_right[idx_right > len(chunk_start_idx)] = len(chunk_start_idx)
        boundary_right = end_pad[idx_right]
        mask_right = seq_range_expand < boundary_right.unsqueeze(-1)
        return mask_left & mask_right

    # Adopted from https://github.com/huggingface/transformers/blob/v4.51.3/src/transformers/models/phi4_multimodal/modeling_phi4_multimodal.py#L494-L512
    @staticmethod
    def get_vision_position_ids(pixel_values, patch_attention_mask, patch_size=14, num_patches_per_side=32):
        batch_size = pixel_values.shape[0]
        max_im_h, max_im_w = pixel_values.size(2), pixel_values.size(3)
        max_nb_patches_h, max_nb_patches_w = max_im_h // patch_size, max_im_w // patch_size
        boundaries = torch.arange(1 / num_patches_per_side, 1.0, 1 / num_patches_per_side)
        position_ids = torch.full(
            size=(
                batch_size,
                max_nb_patches_h * max_nb_patches_w,
            ),
            fill_value=0,
        )

        for batch_idx, p_attn_mask in enumerate(patch_attention_mask):
            nb_patches_h = p_attn_mask[:, 0].sum()
            nb_patches_w = p_attn_mask[0].sum()

            fractional_coords_h = torch.arange(0, 1 - 1e-6, 1 / nb_patches_h)
            fractional_coords_w = torch.arange(0, 1 - 1e-6, 1 / nb_patches_w)

            bucket_coords_h = torch.bucketize(fractional_coords_h, boundaries, right=True)
            bucket_coords_w = torch.bucketize(fractional_coords_w, boundaries, right=True)

            pos_ids = (bucket_coords_h[:, None] * num_patches_per_side + bucket_coords_w).flatten()
            position_ids[batch_idx][p_attn_mask.view(-1)] = pos_ids
        return position_ids

    # Adopted from https://github.com/huggingface/transformers/blob/v4.51.3/src/transformers/models/phi4_multimodal/modeling_phi4_multimodal.py#L1561
    def embed_tokens_extend(
        self,
        input_ids: torch.LongTensor,
        input_image_embeds: torch.FloatTensor = None,
        input_audio_embeds: torch.FloatTensor = None,
        image_sizes=None,
        image_attention_mask=None,
        audio_embed_sizes=None,
        audio_projection_mode="speech",
        past_key_values=None,
    ):
        if past_key_values is not None:
            return self.language_model.embed_tokens(input_ids)

        new_input_ids = input_ids.clone()
        new_input_ids[
            (input_ids >= self._COMPATIBLE_IMAGE_SPECIAL_TOKEN_ID_RANGE[0])
            & (input_ids <= self._COMPATIBLE_IMAGE_SPECIAL_TOKEN_ID_RANGE[1])
        ] = self._IMAGE_SPECIAL_TOKEN_ID
        new_input_ids[
            (input_ids >= self._COMPATIBLE_AUDIO_SPECIAL_TOKEN_ID_RANGE[0])
            & (input_ids <= self._COMPATIBLE_AUDIO_SPECIAL_TOKEN_ID_RANGE[1])
        ] = self._AUDIO_SPECIAL_TOKEN_ID
        input_ids = new_input_ids
        image_position_mask = (input_ids == self._IMAGE_SPECIAL_TOKEN_ID).unsqueeze(-1)
        non_image_position_mask = ~image_position_mask
        hidden_states = torch.from_numpy(self.language_model.embed_tokens(input_ids))
        vision_hidden_states = self.image_embed(
            input_ids=input_ids,
            inputs_embeds=hidden_states,
            image_pixel_values=input_image_embeds,
            image_sizes=image_sizes,
            image_attention_mask=image_attention_mask,
        )
        audio_hidden_states = self.audio_embed(
            input_ids=input_ids,
            inputs_embeds=hidden_states,
            audio_input_embeds=input_audio_embeds,
            audio_embed_sizes=audio_embed_sizes,
            audio_projection_mode=audio_projection_mode,
        )
        if vision_hidden_states is not None and audio_hidden_states is not None:
            hidden_states = vision_hidden_states * image_position_mask + audio_hidden_states * non_image_position_mask
        elif vision_hidden_states is not None:
            hidden_states = vision_hidden_states
        elif audio_hidden_states is not None:
            hidden_states = audio_hidden_states

        return hidden_states

    def get_multimodal_embeddings(
        self,
        input_ids,
        pixel_values=None,
        attention_mask=None,
        position_ids=None,
        input_image_embeds: Optional[torch.FloatTensor] = None,
        image_sizes: Optional[torch.LongTensor] = None,
        image_attention_mask=None,
        input_audio_embeds: Optional[torch.FloatTensor] = None,
        audio_embed_sizes=None,
        input_mode=None,
        **kwargs,
    ):
        if pixel_values is not None and input_image_embeds is None:
            input_image_embeds = pixel_values
        audio_projection_mode = None
        if input_audio_embeds is not None:
            if isinstance(input_mode, torch.Tensor):
                assert len(input_mode) == 1
                input_mode = input_mode[0].item()
            if input_mode is None:
                input_mode = 1 if input_image_embeds is not None else 2
            input_mode = InputMode(input_mode)

            if input_mode in [InputMode.VISION_SPEECH, InputMode.VISION]:
                audio_projection_mode = "vision"
            elif input_mode == InputMode.SPEECH:
                audio_projection_mode = "speech"
            elif input_mode == InputMode.LANGUAGE:
                audio_projection_mode = "speech"
            else:
                raise ValueError(f"Invalid input_mode: {input_mode}")
        inputs_embeds = self.embed_tokens_extend(
            input_ids=input_ids,
            input_image_embeds=input_image_embeds,
            input_audio_embeds=input_audio_embeds,
            image_sizes=image_sizes,
            image_attention_mask=image_attention_mask,
            audio_embed_sizes=audio_embed_sizes,
            audio_projection_mode=audio_projection_mode,
            past_key_values=kwargs.get("past_key_values"),
        )
        return inputs_embeds, attention_mask, position_ids

    @staticmethod
    def preprocess_inputs(
        text: str,
        image: Optional["Image"] = None,
        processor: Optional[AutoImageProcessor] = None,
        tokenizer: Optional[PreTrainedTokenizer] = None,
        config: Optional[PretrainedConfig] = None,
        video: Optional["VideoInput"] = None,
        audio: Optional[np.ndarray] = None,
    ):
        if processor is None:
            raise ValueError("Processor is required.")
        if video is not None:
            raise ValueError("Video input is not supported")
        user_prompt = "<|user|>"
        assistant_prompt = "<|assistant|>"
        prompt_suffix = "<|end|>"
        image_token = getattr(processor.tokenizer, "image_token", "<|image_1|>")
        audio_token = getattr(processor.tokenizer, "audio_token", "<|audio_1|>")
        if audio is not None and audio_token not in text:
            text = audio_token + text
        if image is not None and image_token not in text:
            text = image_token + text
        if processor.tokenizer.chat_template is None:
            if not text.startswith(user_prompt):
                text = user_prompt + text + prompt_suffix + assistant_prompt
        else:
            text = processor.tokenizer.apply_chat_template(
                [{"role": "user", "content": text}], tokenize=False, add_generation_prompt=True
            )
        audio_input = {}
        if "audio" in inspect.signature(processor.__call__).parameters:
            sample_rate = None
            if isinstance(audio, tuple):
                audio, sample_rate = audio
            if isinstance(audio, list) and len(audio) == 1 and isinstance(audio[0], tuple):
                audio, sample_rate = audio[0]
            audio_input["audio"] = audio
            if sample_rate is not None:
                audio_input["sampling_rate"] = sample_rate
        else:
            audio_input["audios"] = audio
        inputs = processor(text=text, images=image, **audio_input, return_tensors="pt")
        return inputs

    def get_img_features(self, pixel_values, image_attention_mask):
        patch_position_ids = self.get_vision_position_ids(
            pixel_values, image_attention_mask, self.patch_size, self.num_patches_per_side
        )
        return torch.from_numpy(
            self.vision_embeddings(
                pixel_values=pixel_values,
                patch_attention_mask=image_attention_mask,
                patch_position_ids=patch_position_ids,
            )[0]
        )


class _OVLlama4ForCausalLM(OVModelForVisualCausalLM):
    def get_vision_embeddings(self, pixel_values, input_ids=None, **kwargs):
        if input_ids is not None and input_ids.shape[1] == 1:
            return None
        # Llama4 preprocessor creates bf16 tensor for pixel values, it can not be represented as numpy array
        if pixel_values.dtype != torch.float32:
            pixel_values.to(torch.float32)
        return self.vision_embeddings(pixel_values.to(torch.float32)).last_hidden_state

    # Adopted from https://github.com/huggingface/transformers/blob/v4.51.0/src/transformers/models/llama4/modeling_llama4.py#L1743-L1759
    def merge_vision_text_embeddings(
        self, vision_embeds, inputs_embeds, input_ids=None, attention_mask=None, position_ids=None, **kwargs
    ):
        image_features = torch.from_numpy(vision_embeds) if isinstance(vision_embeds, np.ndarray) else vision_embeds
        inputs_embeds = torch.from_numpy(inputs_embeds) if isinstance(inputs_embeds, np.ndarray) else inputs_embeds
        original_inputs_embeds_shape = inputs_embeds.shape
        special_image_mask = (input_ids == self.config.image_token_index).unsqueeze(-1)
        final_mask = special_image_mask.to(inputs_embeds.device)
        inputs_embeds = inputs_embeds.view(-1, inputs_embeds.size(-1))

        final_mask_1d = final_mask[..., 0].reshape(-1)
        num_tokens_to_fill = final_mask_1d.sum()

        if num_tokens_to_fill != image_features.size(0):
            raise ValueError(
                f"Mismatch: final_mask wants {num_tokens_to_fill} embeddings, "
                f"but multi_modal_projector returned {image_features.size(0)}"
            )

        expanded_mask = final_mask_1d.unsqueeze(-1).expand(-1, inputs_embeds.size(-1))
        inputs_embeds.masked_scatter_(expanded_mask, image_features)

        inputs_embeds = inputs_embeds.view(original_inputs_embeds_shape)

        return inputs_embeds, attention_mask, position_ids

    @staticmethod
    def preprocess_inputs(
        text: str,
        image: Optional["Image"] = None,
        processor: Optional[AutoImageProcessor] = None,
        tokenizer: Optional[PreTrainedTokenizer] = None,
        config: Optional[PretrainedConfig] = None,
        video: Optional["VideoInput"] = None,
    ):
        if processor is None:
            raise ValueError("Processor is required.")

        if video is not None:
            raise ValueError("video input is not supported")
        conversation = [
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": text},
                ],
            }
        ]
        if image is not None:
            conversation[0]["content"].insert(0, {"type": "image"})

        text_prompt = processor.apply_chat_template(conversation, add_generation_prompt=True)

        inputs = processor(images=image, text=text_prompt, return_tensors="pt")
        return inputs


class _OVVideoChatFlashQwenForCausalLM(OVModelForVisualCausalLM):
    auto_model_class = AutoModel
    additional_parts = ["vision_projection"]
    _videochat_model_dir_cache = {}  # Cache: model_ref -> model_dir to avoid repeated resolution

    @staticmethod
    def _resolve_videochat_source_dir(model_ref):
        if isinstance(model_ref, TemporaryDirectory):
            model_ref = model_ref.name

        model_dir = None
        if model_ref is not None:
            candidate = Path(model_ref).expanduser()
            if candidate.is_file():
                model_dir = candidate.parent
            elif candidate.is_dir():
                model_dir = candidate

        if model_dir is None and isinstance(model_ref, str) and model_ref:
            try:
                snapshot_dir = snapshot_download(
                    repo_id=model_ref,
                    allow_patterns=["*.py", "*.json"],
                    local_files_only=True,
                )
                model_dir = Path(snapshot_dir).resolve()
            except Exception as e:
                raise ValueError(
                    "Failed to resolve local model directory from model reference. "
                    "Pass a local model path, or ensure this Hub model is present in local cache."
                ) from e

        if not (model_dir and model_dir.is_dir()):
            raise ValueError("VideoChat model reference must resolve to a valid local model directory.")

        required_source_files = ["mm_utils.py", "vision_tower_builder.py"]
        missing_source_files = [name for name in required_source_files if not (model_dir / name).is_file()]
        if missing_source_files:
            missing_files_text = ", ".join(missing_source_files)
            raise ValueError(
                f"Model source directory '{model_dir}' is missing required files: {missing_files_text}. "
                "Pass a local model directory containing the original remote-code files, or ensure the full Hub snapshot is cached locally."
            )

        return model_dir

    @classmethod
    def _import_videochat_module(cls, module_name: str, model_ref):
        # Use cached model_dir to avoid repeated resolution
        if model_ref not in cls._videochat_model_dir_cache:
            cls._videochat_model_dir_cache[model_ref] = cls._resolve_videochat_source_dir(model_ref)
        model_dir = cls._videochat_model_dir_cache[model_ref]

        package_name = "_videochat_flash_local"
        local_pkg = sys.modules.get(package_name)
        if local_pkg is None:
            local_pkg = types.ModuleType(package_name)
            local_pkg.__path__ = [str(model_dir)]
            sys.modules[package_name] = local_pkg
        elif getattr(local_pkg, "__path__", None) != [str(model_dir)]:
            local_pkg.__path__ = [str(model_dir)]

        return importlib.import_module(f"{package_name}.{module_name}")

    def _resolve_hf_method_provider_dir(self, model_save_dir):
        model_dir = model_save_dir.name if isinstance(model_save_dir, TemporaryDirectory) else model_save_dir
        if model_dir is not None:
            model_dir_path = Path(model_dir).resolve()
            if model_dir_path.is_file():
                model_dir_path = model_dir_path.parent
            if model_dir_path.is_dir():
                return model_dir_path

        raise ValueError(
            "Failed to locate local model directory for building transformers method provider. "
            "Pass a valid local model_save_dir."
        )

    def _build_hf_method_provider(self, model_dir):
        config = AutoConfig.from_pretrained(str(model_dir), trust_remote_code=True, local_files_only=True)
        try:
            from accelerate import init_empty_weights

            build_ctx = init_empty_weights()
        except Exception:
            from contextlib import nullcontext

            build_ctx = nullcontext()

        with build_ctx:
            provider = self.auto_model_class.from_config(config, trust_remote_code=True)

        try:
            provider = self._patch_hf_provider_for_ov_inference(provider)
        except Exception as e:
            raise ValueError(f"Failed to patch HF provider for OV inference: {e}")

        return provider

    def _patch_hf_provider_for_ov_inference(self, provider):
        ov_model = self

        class _OVVisionTowerProxy(torch.nn.Module):
            def forward(self, images):
                # Adapted from https://huggingface.co/OpenGVLab/VideoChat-Flash-Qwen2_5-7B_InternVideo2-1B/blob/main/vision_tower_builder.py#L822-L832
                # Upstream preprocessing provides BTCHW, but the vision tower expects BCHWT,
                # so we permute dimensions before running the visual encoder.
                # We then keep patch tokens in [B, T*L, C] (dropping cls later) because
                # downstream token merging/projection operates on a flattened token sequence.
                T = images.shape[1]
                images = images.permute(0, 2, 1, 3, 4)
                if T == 1:
                    pos_embeds = ov_model.img_pos_embed.detach()
                else:
                    pos_embeds = ov_model.pos_embed.detach()
                image_embeds = ov_model.vision_embeddings(images, rotary_pos_emb=pos_embeds).last_hidden_state
                image_embeds = image_embeds[:, 1:, :]
                return torch.from_numpy(image_embeds) if isinstance(image_embeds, np.ndarray) else image_embeds

        class _OVMLPProxy(torch.nn.Module):
            # Only intercept the final MLP projection step inside mm_projector.forward().
            # The original mm_projector's reshape and merge_tokens logic runs as-is.
            def forward(self, x):
                result = ov_model.vision_projection(x)
                return torch.from_numpy(result) if isinstance(result, np.ndarray) else result

        # Patch only mm_projector.mlp to route the OV vision projection inference.
        # The rest of mm_projector.forward() (reshape, merge_tokens) runs from the original model code.
        mm_projector = provider.model.mm_projector
        mm_projector.mlp = _OVMLPProxy()

        class _OVMMProjectorProxy:
            def __init__(self, projector):
                self._projector = projector
                self.num_image_patches_per_side = getattr(projector, "num_image_patches_per_side", None)

            def __call__(self, *args, **kwargs):
                return self._projector(*args, **kwargs)

        class _OVBackboneProxy(torch.nn.Module):
            # Minimal proxy used only by prepare_inputs_labels_for_multimodal.
            # Use @property to transparently access OV model attributes instead of copying values.
            def __init__(self, projector_proxy):
                super().__init__()
                self.vision_tower = _OVVisionTowerProxy()
                self.mm_projector = projector_proxy

            @property
            def image_newline(self):
                return ov_model.image_newline if hasattr(ov_model, "image_newline") else None

            @property
            def frame_newline(self):
                return ov_model.frame_newline if hasattr(ov_model, "frame_newline") else None

            def get_vision_tower(self):
                return self.vision_tower

            def embed_tokens(self, input_ids):
                return torch.from_numpy(ov_model.get_text_embeddings(input_ids.unsqueeze(0))[0])

        backbone_proxy = _OVBackboneProxy(_OVMMProjectorProxy(mm_projector))
        provider.model = backbone_proxy
        provider.get_model = lambda: backbone_proxy
        provider.get_vision_tower = lambda: backbone_proxy.get_vision_tower()

        # Build a CPU-only execution context for prepare_inputs_labels_for_multimodal.
        # This avoids `x.to(self.device)` turning real tensors into meta tensors.
        class _HFPrepareContext:
            pass

        prepare_ctx = _HFPrepareContext()
        prepare_ctx.config = provider.config
        prepare_ctx.model = backbone_proxy
        prepare_ctx.training = False
        prepare_ctx.device = torch.device("cpu")
        prepare_ctx.get_model = lambda: backbone_proxy
        prepare_ctx.get_vision_tower = lambda: backbone_proxy.get_vision_tower()
        prepare_ctx.encode_video_image = types.MethodType(provider.encode_video_image.__func__, prepare_ctx)
        prepare_ctx.prepare_inputs_labels_for_multimodal = types.MethodType(
            provider.prepare_inputs_labels_for_multimodal.__func__, prepare_ctx
        )
        provider._ov_prepare_ctx = prepare_ctx

        # Safety guard: this helper provider is only for preprocessing, never for generation.
        def _forbid_hf_generate(*args, **kwargs):
            raise RuntimeError("HF generate should not be called here; OV model.generate is the only generation path.")

        provider.generate = _forbid_hf_generate

        return provider

    def __init__(
        self,
        language_model: ov.Model,
        text_embeddings: ov.Model,
        vision_embeddings: ov.Model,
        config: PretrainedConfig = None,
        device: str = "CPU",
        dynamic_shapes: bool = None,
        ov_config: Optional[Dict[str, str]] = None,
        model_save_dir: Optional[Union[str, Path, TemporaryDirectory]] = None,
        quantization_config: Union[OVWeightQuantizationConfig, Dict] = None,
        **kwargs,
    ):
        super().__init__(
            language_model=language_model,
            text_embeddings=text_embeddings,
            vision_embeddings=vision_embeddings,
            config=config,
            device=device,
            dynamic_shapes=dynamic_shapes,
            ov_config=ov_config,
            model_save_dir=model_save_dir,
            quantization_config=quantization_config,
            **kwargs,
        )
        model_dir = self._resolve_hf_method_provider_dir(model_save_dir)

        # Import position embedding utilities from the original model directory
        # Only needs to be called once during initialization to get the pos_embed computation function
        sys.path.insert(0, str(model_dir))
        try:
            import vision_tower_builder
        finally:
            sys.path.pop(0)
        vision_tower_builder = sys.modules.pop("vision_tower_builder")
        get_3d_sincos_pos_embed = vision_tower_builder.get_3d_sincos_pos_embed

        num_frames = config.mm_local_num_frames
        self.mm_num_attention_heads = config.mm_num_attention_heads
        self.patch_size = config.patch_size
        self.image_size = config.image_size
        self.grid_size = (
            num_frames,
            self.image_size // self.patch_size,
            self.image_size // self.patch_size,
        )  # (T, H, W)
        self.num_patches = self.grid_size[0] * self.grid_size[1] * self.grid_size[2]
        self.num_img_patches = self.grid_size[1] * self.grid_size[2]
        self.embed_dim = config.mm_hidden_size
        self.pos_embed = torch.nn.Parameter(torch.zeros(1, self.num_patches + 1, self.embed_dim))
        self.img_pos_embed = torch.nn.Parameter(torch.zeros(1, self.num_img_patches + 1, self.embed_dim))
        # Adopted from https://huggingface.co/OpenGVLab/VideoChat-Flash-Qwen2_5-7B_InternVideo2-1B/blob/main/vision_tower_builder.py#L559
        # pos_embed for video
        pos_embed = get_3d_sincos_pos_embed(
            self.pos_embed.shape[-1], self.grid_size[1], self.grid_size[0], cls_token=True
        )
        pos_embed = torch.from_numpy(pos_embed) if isinstance(pos_embed, np.ndarray) else pos_embed
        self.pos_embed.data.copy_(pos_embed.to(dtype=self.pos_embed.dtype).unsqueeze(0))

        # pos_embed for image
        img_pos_embed = get_3d_sincos_pos_embed(self.pos_embed.shape[-1], self.grid_size[1], 1, cls_token=True)
        img_pos_embed = torch.from_numpy(img_pos_embed) if isinstance(img_pos_embed, np.ndarray) else img_pos_embed
        self.img_pos_embed.data.copy_(img_pos_embed.to(dtype=self.img_pos_embed.dtype).unsqueeze(0))

        if "unpad" in getattr(config, "mm_patch_merge_type", ""):
            self.image_newline = torch.nn.Parameter(torch.empty(config.hidden_size, dtype=self.dtype))
        if (
            "nopad" in getattr(config, "mm_patch_merge_type", "")
            and getattr(self.config, "mm_newline_position", "nothing") != "nothing"
        ):
            self.frame_newline = torch.nn.Parameter(torch.empty(config.hidden_size, dtype=self.dtype))

        self._hf_method_provider = self._build_hf_method_provider(model_dir=model_dir)

    @staticmethod
    def preprocess_inputs(
        text: str,
        image: Optional["Image"] = None,
        processor: Optional[AutoImageProcessor] = None,
        tokenizer: Optional[PreTrainedTokenizer] = None,
        config: Optional[PretrainedConfig] = None,
        video: Optional["VideoInput"] = None,
        audio: Optional[np.ndarray] = None,
    ):
        if config is None:
            raise ValueError("Config is required.")

        # Import tokenizer/image utilities from the original model directory.
        # mm_utils relies on relative imports, so load it via a synthetic package root.
        model_ref = getattr(config, "_name_or_path", None)
        mm_utils = _OVVideoChatFlashQwenForCausalLM._import_videochat_module("mm_utils", model_ref)
        vision_tower_builder = _OVVideoChatFlashQwenForCausalLM._import_videochat_module(
            "vision_tower_builder", model_ref
        )
        tokenizer_image_token = mm_utils.tokenizer_image_token
        InternVideo2ImageProcessor = vision_tower_builder.InternVideo2ImageProcessor

        if audio is not None:
            raise ValueError("Audio input is not supported")
        if tokenizer is None:
            raise ValueError("Tokenizer is required.")
        image_sizes = []
        frames = []
        modalities = []
        results = {}
        local_num_frames = config.mm_local_num_frames
        # use default image preprocessing parameters from config
        # use default image_size from https://huggingface.co/OpenGVLab/VideoChat-Flash-Qwen2_5-7B_InternVideo2-1B/blob/main/vision_tower_builder.py#L682
        target_image_size = getattr(config, "image_size", 224)
        target_size = (target_image_size, target_image_size) if target_image_size is not None else None
        # use default image_mean and image_std from https://huggingface.co/OpenGVLab/VideoChat-Flash-Qwen2_5-7B_InternVideo2-1B/blob/main/vision_tower_builder.py#L682
        image_mean = getattr(config, "image_mean", (0.485, 0.456, 0.406))
        image_std = getattr(config, "image_std", (0.229, 0.224, 0.225))

        # Create image processor once for reuse
        image_processor = InternVideo2ImageProcessor(size=target_size, image_mean=image_mean, image_std=image_std)

        # preprocess text
        prompt = f"<image>\n{text}" if (image is not None or video is not None) else text
        if getattr(tokenizer, "chat_template", None) is not None:
            messages = [{"role": "user", "content": prompt}]
            text_prompt = tokenizer.apply_chat_template(
                messages,
                tokenize=False,
                add_generation_prompt=True,
            )
        else:
            text_prompt = prompt
        input_ids = tokenizer_image_token(text_prompt, tokenizer, return_tensors="pt").unsqueeze(0)
        results["input_ids"] = input_ids

        # preprocess video
        if video is not None:
            if isinstance(video, np.ndarray):
                num_frames = video.shape[0]
                image_size = video.shape[1:3]
                if num_frames % local_num_frames != 0:
                    pad_frames = local_num_frames - (num_frames % local_num_frames)
                    pad = np.repeat(video[-1:], pad_frames, axis=0)
                    video = np.concatenate([video, pad], axis=0)
            elif isinstance(video, list):
                num_frames = len(video)
                if isinstance(video[0], np.ndarray):
                    image_size = video[0].shape[:2]
                else:
                    width, height = video[0].size
                    image_size = (height, width)
                if num_frames % local_num_frames != 0:
                    pad_frames = local_num_frames - (num_frames % local_num_frames)
                    video = video + [video[-1]] * pad_frames
            else:
                raise ValueError(f"Unsupported video type: {type(video)}")

            image_sizes.append(image_size)
            processed_images = image_processor.preprocess(video, return_tensors="pt").pixel_values
            frames.append(processed_images)
            modalities.append("video")

        # preprocess image
        if image is not None:
            from PIL.Image import Image as PILImage

            if isinstance(image, PILImage):
                width, height = image.size
                image_size = (height, width)
            else:
                image_size = image.shape[:2]
            image_frame = image_processor.preprocess(image, return_tensors="pt").pixel_values
            frames.append(image_frame)
            image_sizes.append(image_size)
            modalities.append("image")

        if len(frames) >= 1:
            results["images"] = frames
            results["image_sizes"] = image_sizes
            results["modalities"] = modalities

        if tokenizer.pad_token_id is None and "qwen" in tokenizer.name_or_path.lower():
            logger.info("Using bos token as pad token for qwen model attention mask.")
            tokenizer.pad_token_id = tokenizer.bos_token_id
        attention_masks = (
            input_ids.ne(tokenizer.pad_token_id).long()
            if tokenizer.pad_token_id is not None
            else torch.ones_like(input_ids)
        )
        results["attention_mask"] = attention_masks

        return results

    def get_multimodal_embeddings(
        self,
        input_ids,
        pixel_values=None,
        attention_mask=None,
        position_ids=None,
        modalities=None,
        image_sizes=None,
        **kwargs,
    ):
        images = pixel_values

        if images is None:
            inputs_embeds = torch.from_numpy(self.get_text_embeddings(input_ids))
            return inputs_embeds, attention_mask, position_ids

        # Call prepare_inputs_labels_for_multimodal from the original transformers model.
        # This method handles complex multimodal input processing including video/image encoding,
        # token merging, and embedding preparation.
        prepare_ctx = self._hf_method_provider._ov_prepare_ctx
        _, position_ids, attention_mask, _, new_input_embeds, _ = prepare_ctx.prepare_inputs_labels_for_multimodal(
            input_ids=input_ids,
            position_ids=position_ids,
            attention_mask=attention_mask,
            past_key_values=None,  # Not used in get_multimodal_embeddings context
            labels=None,  # Labels not needed for embedding extraction
            images=images,
            modalities=modalities if modalities is not None else ["image"],
            image_sizes=image_sizes,
        )
        return new_input_embeds, attention_mask, position_ids

    def _update_model_kwargs_for_generation(
        self,
        outputs: ModelOutput,
        model_kwargs: Dict[str, Any],
        is_encoder_decoder: bool = False,
        num_new_tokens: int = 1,
    ) -> Dict[str, Any]:
        model_kwargs = super()._update_model_kwargs_for_generation(
            outputs=outputs,
            model_kwargs=model_kwargs,
            is_encoder_decoder=is_encoder_decoder,
            num_new_tokens=num_new_tokens,
        )

        # Vision inputs are only needed at the first step; later decoding uses cached states.
        model_kwargs.pop("images", None)
        model_kwargs.pop("image_sizes", None)
        past_len = self.language_model._past_length
        attn = model_kwargs.get("attention_mask")
        # Keep mask length aligned with cached sequence length during incremental decoding.
        if attn is not None and attn.shape[1] < past_len + 1:
            model_kwargs["attention_mask"] = torch.ones(
                (attn.shape[0], past_len + 1),
                dtype=attn.dtype,
                device=attn.device,
            )

        return model_kwargs

    # Keep modalities compatibility only for VideoChat.
    def prepare_inputs_for_generation(
        self,
        input_ids,
        past_key_values=None,
        inputs_embeds=None,
        pixel_values=None,
        image_sizes=None,
        modalities=None,
        attention_mask=None,
        **kwargs,
    ):
        model_inputs = super().prepare_inputs_for_generation(
            input_ids=input_ids,
            past_key_values=past_key_values,
            inputs_embeds=inputs_embeds,
            pixel_values=pixel_values,
            image_sizes=image_sizes,
            attention_mask=attention_mask,
            **kwargs,
        )
        model_inputs["modalities"] = modalities
        return model_inputs


class _OVQwen3_5ForCausalLM(OVModelForVisualCausalLM):
    # `mtp` is optional: only present for checkpoints exported with an MTP head
    # (e.g. Qwen3.6-35B-A3B). It is loaded/saved/compressed like any other part; if
    # the openvino_mtp_model.xml file is absent it is skipped gracefully.
    additional_parts = ["vision_embeddings_merger", "vision_embeddings_pos", "mtp"]

    def __init__(
        self,
        language_model: ov.Model,
        text_embeddings: ov.Model,
        vision_embeddings: ov.Model,
        config: PretrainedConfig = None,
        device: str = "CPU",
        dynamic_shapes: bool = None,
        ov_config: Optional[Dict[str, str]] = None,
        model_save_dir: Optional[Union[str, Path, TemporaryDirectory]] = None,
        quantization_config: Union[OVWeightQuantizationConfig, Dict] = None,
        **kwargs,
    ):
        if is_transformers_version("<", "5.2.0"):
            raise Exception("Qwen3.5 requires transformers >= 5.2.0; earlier versions are not supported.")

        super().__init__(
            language_model=language_model,
            text_embeddings=text_embeddings,
            vision_embeddings=vision_embeddings,
            config=config,
            device=device,
            dynamic_shapes=dynamic_shapes,
            ov_config=ov_config,
            model_save_dir=model_save_dir,
            quantization_config=quantization_config,
            **kwargs,
        )
        self.rope_deltas = None  # cache rope_deltas here

        self.num_grid_per_side = int(config.vision_config.num_position_embeddings**0.5)
        self.spatial_merge_size = config.vision_config.spatial_merge_size
        head_dim = config.vision_config.hidden_size // config.vision_config.num_heads
        self.rotary_pos_emb = Qwen3_5VisionRotaryEmbedding(head_dim // 2)

    def __setattr__(self, name, value):
        OVModelForVisualCausalLM.__setattr__(self, name, value)

    def prepare_inputs_for_generation(
        self,
        input_ids,
        past_key_values=None,
        attention_mask=None,
        inputs_embeds=None,
        cache_position=None,
        position_ids=None,
        use_cache=True,
        pixel_values=None,
        pixel_values_videos=None,
        image_grid_thw=None,
        video_grid_thw=None,
        **kwargs,
    ):
        # Overwritten -- in specific circumstances we don't want to forward image inputs to the model
        if past_key_values is not None:
            if inputs_embeds is not None and input_ids.shape[1] == 0:  # Exception 4
                inputs_embeds = inputs_embeds[:, -cache_position.shape[0] :]
            elif inputs_embeds is not None:
                input_ids = input_ids[:, -cache_position.shape[0] :]
            elif input_ids.shape[1] != cache_position.shape[0]:  # Default case (the "else", a no op, is Exception 2)
                input_ids = input_ids[:, cache_position]

        if cache_position[0] != 0:
            pixel_values = None
            pixel_values_videos = None

        # if `inputs_embeds` are passed, we only want to use them in the 1st generation step
        if inputs_embeds is not None and len(cache_position) == inputs_embeds.shape[1]:
            model_inputs = {"inputs_embeds": inputs_embeds, "input_ids": None}
        else:
            model_inputs = {"input_ids": input_ids, "inputs_embeds": None}

        model_inputs.update(
            {
                "position_ids": position_ids,
                "past_key_values": past_key_values,
                "use_cache": use_cache,
                "attention_mask": attention_mask,
                "pixel_values": pixel_values,
                "pixel_values_videos": pixel_values_videos,
                "image_grid_thw": image_grid_thw,
                "video_grid_thw": video_grid_thw,
                "cache_position": cache_position,
            }
        )
        return model_inputs

    # Adapted from Qwen3_5VisionModel.fast_pos_embed_interpolate
    # This method needs to be changed, as instead of running self.pos_embed of type nn.Embedding, openvino model needs to be inferred (self.vision_embeddings_pos)
    def fast_pos_embed_interpolate(self, grid_thw):
        grid_ts, grid_hs, grid_ws = grid_thw[:, 0], grid_thw[:, 1], grid_thw[:, 2]

        idx_list = [[] for _ in range(4)]
        weight_list = [[] for _ in range(4)]

        for t, h, w in zip(grid_ts, grid_hs, grid_ws):
            h_idxs = torch.linspace(0, self.num_grid_per_side - 1, h)
            w_idxs = torch.linspace(0, self.num_grid_per_side - 1, w)

            h_idxs_floor = h_idxs.int()
            w_idxs_floor = w_idxs.int()
            h_idxs_ceil = (h_idxs.int() + 1).clip(max=self.num_grid_per_side - 1)
            w_idxs_ceil = (w_idxs.int() + 1).clip(max=self.num_grid_per_side - 1)

            dh = h_idxs - h_idxs_floor
            dw = w_idxs - w_idxs_floor

            base_h = h_idxs_floor * self.num_grid_per_side
            base_h_ceil = h_idxs_ceil * self.num_grid_per_side

            indices = [
                (base_h[None].T + w_idxs_floor[None]).flatten(),
                (base_h[None].T + w_idxs_ceil[None]).flatten(),
                (base_h_ceil[None].T + w_idxs_floor[None]).flatten(),
                (base_h_ceil[None].T + w_idxs_ceil[None]).flatten(),
            ]

            weights = [
                ((1 - dh)[None].T * (1 - dw)[None]).flatten(),
                ((1 - dh)[None].T * dw[None]).flatten(),
                (dh[None].T * (1 - dw)[None]).flatten(),
                (dh[None].T * dw[None]).flatten(),
            ]

            for i in range(4):
                idx_list[i].extend(indices[i].tolist())
                weight_list[i].extend(weights[i].tolist())

        idx_tensor = torch.tensor(idx_list)
        weight_tensor = torch.tensor(weight_list)
        pos_embeds = torch.from_numpy(self.vision_embeddings_pos(idx_tensor)) * weight_tensor[:, :, None]
        patch_pos_embeds = pos_embeds[0] + pos_embeds[1] + pos_embeds[2] + pos_embeds[3]

        patch_pos_embeds = patch_pos_embeds.split([h * w for h, w in zip(grid_hs, grid_ws)])

        patch_pos_embeds_permute = []
        merge_size = self.config.vision_config.spatial_merge_size
        for pos_embed, t, h, w in zip(patch_pos_embeds, grid_ts, grid_hs, grid_ws):
            pos_embed = pos_embed.repeat(t, 1)
            pos_embed = (
                pos_embed.view(t, h // merge_size, merge_size, w // merge_size, merge_size, -1)
                .permute(0, 1, 3, 2, 4, 5)
                .flatten(0, 4)
            )
            patch_pos_embeds_permute.append(pos_embed)
        patch_pos_embeds = torch.cat(patch_pos_embeds_permute)
        return patch_pos_embeds

    def get_vision_embeddings(self, pixel_values, grid_thw, **kwargs):
        hidden_states = torch.from_numpy(self.vision_embeddings(pixel_values)[0])

        pos_embeds = self.fast_pos_embed_interpolate(grid_thw)
        hidden_states = hidden_states + pos_embeds

        rotary_pos_emb = self.rot_pos_emb(grid_thw)
        seq_len, _ = hidden_states.size()
        hidden_states = hidden_states.reshape(seq_len, -1)
        rotary_pos_emb = rotary_pos_emb.reshape(seq_len, -1)
        cu_seqlens = torch.repeat_interleave(grid_thw[:, 1] * grid_thw[:, 2], grid_thw[:, 0]).cumsum(
            dim=0, dtype=torch.int32
        )
        cu_seqlens = torch.nn.functional.pad(cu_seqlens, (1, 0), value=0)
        attention_mask = torch.zeros((1, hidden_states.shape[0], hidden_states.shape[0]), dtype=torch.bool)
        causal_mask = torch.zeros_like(attention_mask, dtype=torch.float32)
        for i in range(1, len(cu_seqlens)):
            attention_mask[..., cu_seqlens[i - 1] : cu_seqlens[i], cu_seqlens[i - 1] : cu_seqlens[i]] = True

        causal_mask.masked_fill_(torch.logical_not(attention_mask), float("-inf"))

        res = self.vision_embeddings_merger(
            pixel_values=hidden_states, attention_mask=causal_mask, rotary_pos_emb=rotary_pos_emb
        )
        return res[0]

    def get_image_features(self, pixel_values: torch.FloatTensor, image_grid_thw: Optional[torch.LongTensor] = None):
        """
        Encodes images into continuous embeddings that can be forwarded to the language model.
        """
        image_embeds = torch.from_numpy(self.get_vision_embeddings(pixel_values, image_grid_thw))
        split_sizes = (image_grid_thw.prod(-1) // self.spatial_merge_size**2).tolist()
        image_embeds = torch.split(image_embeds, split_sizes)
        return image_embeds

    def get_video_features(
        self, pixel_values_videos: torch.FloatTensor, video_grid_thw: Optional[torch.LongTensor] = None
    ):
        """
        Encodes videos into continuous embeddings that can be forwarded to the language model.
        """
        return self.get_image_features(pixel_values_videos, video_grid_thw)

    def get_multimodal_embeddings(
        self,
        input_ids,
        pixel_values=None,
        attention_mask=None,
        position_ids=None,
        pixel_values_videos=None,
        image_grid_thw=None,
        video_grid_thw=None,
        cache_position=None,
        **kwargs,
    ):
        inputs_embeds = torch.from_numpy(self.get_text_embeddings(input_ids))
        if pixel_values is not None and input_ids.shape[1] != 1:
            image_embeds = self.get_image_features(pixel_values, image_grid_thw)
            image_embeds = torch.cat(image_embeds, dim=0)
            n_image_tokens = (input_ids == self.config.image_token_id).sum().item()
            n_image_features = image_embeds.shape[0]
            if n_image_tokens != n_image_features:
                raise ValueError(
                    f"Image features and image tokens do not match: tokens: {n_image_tokens}, features {n_image_features}"
                )

            mask = input_ids == self.config.image_token_id
            mask_unsqueezed = mask.unsqueeze(-1)
            mask_expanded = mask_unsqueezed.expand_as(inputs_embeds)
            image_mask = mask_expanded.to(inputs_embeds.device)

            image_embeds = image_embeds.to(inputs_embeds.device, inputs_embeds.dtype)
            inputs_embeds = inputs_embeds.masked_scatter(image_mask, image_embeds)

        if pixel_values_videos is not None and input_ids.shape[1] != 1:
            video_embeds = self.get_video_features(pixel_values_videos, video_grid_thw)
            video_embeds = torch.cat(video_embeds, dim=0)
            n_video_tokens = (input_ids == self.config.video_token_id).sum().item()
            n_video_features = video_embeds.shape[0]
            if n_video_tokens != n_video_features:
                raise ValueError(
                    f"Video features and video tokens do not match: tokens: {n_video_tokens}, features {n_video_features}"
                )

            mask = input_ids == self.config.video_token_id
            mask_unsqueezed = mask.unsqueeze(-1)
            mask_expanded = mask_unsqueezed.expand_as(inputs_embeds)
            video_mask = mask_expanded.to(inputs_embeds.device)

            video_embeds = video_embeds.to(inputs_embeds.device, inputs_embeds.dtype)
            inputs_embeds = inputs_embeds.masked_scatter(video_mask, video_embeds)

        if position_ids is None and input_ids is not None and (attention_mask is None or attention_mask.ndim == 2):
            # calculate RoPE index once per generation in the pre-fill stage only
            if (cache_position is not None and cache_position[0] == 0) or self.rope_deltas is None:
                vision_positions, rope_deltas = self.get_rope_index(
                    input_ids,
                    image_grid_thw=image_grid_thw,
                    video_grid_thw=video_grid_thw,
                    attention_mask=attention_mask,
                )
                self.rope_deltas = rope_deltas
                # Compute text positions (simple cumsum) and concatenate as dim 0
                # to create shape (4, batch, seq_len): [text_pos, temporal, height, width]
                if attention_mask is not None:
                    text_positions = attention_mask.long().cumsum(-1) - 1
                    text_positions = text_positions.masked_fill(attention_mask == 0, 1)
                else:
                    text_positions = (
                        torch.arange(input_ids.shape[1], device=input_ids.device)
                        .unsqueeze(0)
                        .expand(input_ids.shape[0], -1)
                    )
                position_ids = torch.cat([text_positions.unsqueeze(0), vision_positions], dim=0)
            # then use the prev pre-calculated rope-deltas to get the correct position ids
            else:
                batch_size, seq_length, _ = inputs_embeds.shape
                delta = cache_position[0] + self.rope_deltas if cache_position is not None else 0
                position_ids = torch.arange(seq_length, device=inputs_embeds.device)
                position_ids = position_ids.view(1, -1).expand(batch_size, -1)
                if cache_position is not None:  # otherwise `deltas` is an int `0`
                    delta = delta.repeat_interleave(batch_size // delta.shape[0], dim=0)
                position_ids = position_ids.add(delta)
                position_ids = position_ids.unsqueeze(0).expand(3, -1, -1)
                # Prepend text positions for shape (4, batch, seq_len)
                text_positions = torch.arange(seq_length, device=inputs_embeds.device)
                text_positions = text_positions.view(1, -1).expand(batch_size, -1)
                if cache_position is not None:
                    text_positions = text_positions + cache_position[0]
                position_ids = torch.cat([text_positions.unsqueeze(0), position_ids], dim=0)

        return inputs_embeds, attention_mask, position_ids

    @staticmethod
    def preprocess_inputs(
        text: str,
        image: Optional["Image"] = None,
        processor: Optional[AutoImageProcessor] = None,
        tokenizer: Optional[PreTrainedTokenizer] = None,
        config: Optional[PretrainedConfig] = None,
        video: Optional["VideoInput"] = None,
        audio: Optional[np.ndarray] = None,
    ):
        if processor is None:
            raise ValueError("Processor is required.")
        if audio is not None:
            raise ValueError("Audio input is not supported")
        conversation = [
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": text},
                ],
            }
        ]
        if image is not None:
            conversation[0]["content"].insert(0, {"type": "image"})
        if video is not None:
            conversation[0]["content"].insert(0, {"type": "video"})

        text_prompt = processor.apply_chat_template(conversation, add_generation_prompt=True)

        inputs = processor(images=image, text=text_prompt, videos=video, return_tensors="pt")
        return inputs

    def forward(
        self,
        input_ids,
        pixel_values=None,
        past_key_values=None,
        inputs_embeds=None,
        image_sizes=None,
        attention_mask=None,
        position_ids=None,
        image_bound=None,
        tgt_sizes=None,
        pixel_values_videos=None,
        image_grid_thw=None,
        video_grid_thw=None,
        rope_deltas=None,
        **kwargs,
    ):
        result = super().forward(
            input_ids,
            pixel_values,
            past_key_values,
            inputs_embeds,
            image_sizes,
            attention_mask,
            position_ids,
            image_bound,
            tgt_sizes,
            pixel_values_videos,
            image_grid_thw,
            video_grid_thw,
            rope_deltas,
            **kwargs,
        )
        final_result = QWen2VLModelOutputWithPast(
            logits=result.logits, past_key_values=result.past_key_values, rope_deltas=rope_deltas
        )
        return final_result

    def _prepare_position_ids_for_generation(self, inputs_tensor, model_kwargs):
        # Mirrors Qwen3_5ForConditionalGeneration._prepare_position_ids_for_generation
        # Creates proper 4D position_ids: [text_positions, temporal, height, width]
        text_positions = GenerationMixin._prepare_position_ids_for_generation(self, inputs_tensor, model_kwargs)

        if "input_ids" in model_kwargs and model_kwargs["input_ids"].shape[1] > 0:
            inputs_tensor = model_kwargs["input_ids"]

        is_input_ids = len(inputs_tensor.shape) == 2 and inputs_tensor.dtype in [torch.int, torch.long]
        if is_input_ids and (
            model_kwargs.get("image_grid_thw") is not None or model_kwargs.get("video_grid_thw") is not None
        ):
            filtered_kwargs = {k: v for k, v in model_kwargs.items() if k != "input_ids"}
            vision_positions, rope_deltas = self.get_rope_index(inputs_tensor, **filtered_kwargs)
            self.rope_deltas = rope_deltas
        else:
            vision_positions = text_positions.unsqueeze(0).expand(3, -1, -1)
            self.rope_deltas = torch.zeros(inputs_tensor.shape[0], 1, dtype=torch.long, device=inputs_tensor.device)

        # Concatenate "text + vision" positions into [4, bs, seq-len]
        text_positions = text_positions[None, ...]
        position_ids = torch.cat([text_positions, vision_positions], dim=0)
        return position_ids

    def generate(self, *args, **kwargs):
        # Clear cached rope delta from previous generations
        self.rope_deltas = None

        return super().generate(*args, **kwargs)


if is_transformers_version(">=", "5.2"):
    _OVQwen3_5ForCausalLM.get_placeholder_mask = Qwen3_5Model.get_placeholder_mask
    _OVQwen3_5ForCausalLM.get_rope_index = Qwen3_5Model.get_rope_index
    _OVQwen3_5ForCausalLM.rot_pos_emb = Qwen3_5VisionModel.rot_pos_emb


class _OVMuseGlimmerForCausalLM(OVModelForVisualCausalLM):
    """OpenVINO runtime for the native MuseGlimmer VLM.

    The vision stack is exported as a single graph that consumes flattened patches
    ``pixel_values`` ``[num_patches, patch_dim]`` plus ``image_grid_thw``
    ``[num_images, 3]`` and returns the projected per-token features
    ``[num_out_tokens, text_hidden]`` (vision tower -> adapter -> projection ->
    perception norm, with the 2x2 patch merge). Features are scattered into the
    positions of the ``<image>`` / ``<video>`` tokens in the prompt.
    """

    def get_experts_implementation(self):
        # transformers>=5.15 `generate` queries the experts implementation to decide
        # on a decode-time MoE kernel swap; that swap is a no-op on CPU (OpenVINO),
        # since the MoE kernel is baked into the exported graph.
        return "openvino_impl"

    def set_experts_implementation(self, experts_implementation):
        # No-op: the MoE kernel is baked into the exported OpenVINO graph.
        return

    def get_vision_embeddings(self, pixel_values, input_ids=None, image_grid_thw=None, **kwargs):
        # Vision features are only consumed on the prefill step.
        if input_ids is not None and input_ids.shape[1] == 1:
            return None
        if pixel_values is None:
            return None

        pixel_values = pixel_values if isinstance(pixel_values, torch.Tensor) else torch.as_tensor(pixel_values)
        pixel_values = pixel_values.float()
        if image_grid_thw is None:
            raise ValueError("image_grid_thw is required for MuseGlimmer vision embeddings.")
        grid = image_grid_thw if isinstance(image_grid_thw, torch.Tensor) else torch.as_tensor(image_grid_thw)
        # The exported graph recomputes every grid-derived tensor internally, so it
        # only needs the flattened patches and image_grid_thw.
        feats = self.vision_embeddings(pixel_values=pixel_values, image_grid_thw=grid).last_hidden_state
        return torch.from_numpy(feats) if isinstance(feats, np.ndarray) else feats

    def get_multimodal_embeddings(
        self,
        input_ids,
        pixel_values=None,
        attention_mask=None,
        position_ids=None,
        pixel_values_videos=None,
        image_grid_thw=None,
        video_grid_thw=None,
        **kwargs,
    ):
        inputs_embeds = self.get_text_embeddings(input_ids)
        inputs_embeds = torch.from_numpy(inputs_embeds) if isinstance(inputs_embeds, np.ndarray) else inputs_embeds
        is_prefill = input_ids is not None and input_ids.shape[1] != 1
        # Images and videos share the same vision graph (video_grid_thw plays the role
        # of image_grid_thw); each modality is scattered into its own placeholder token.
        if is_prefill and pixel_values is not None:
            image_embeds = self.get_vision_embeddings(pixel_values, input_ids=input_ids, image_grid_thw=image_grid_thw)
            if image_embeds is not None:
                image_mask = input_ids == self.config.image_token_id
                inputs_embeds[image_mask] = image_embeds.to(inputs_embeds.dtype)
        if is_prefill and pixel_values_videos is not None:
            video_embeds = self.get_vision_embeddings(
                pixel_values_videos, input_ids=input_ids, image_grid_thw=video_grid_thw
            )
            if video_embeds is not None:
                video_mask = input_ids == self.config.video_token_id
                inputs_embeds[video_mask] = video_embeds.to(inputs_embeds.dtype)
        return inputs_embeds, attention_mask, position_ids

    @staticmethod
    def preprocess_inputs(
        text: str,
        image: Optional["Image"] = None,
        processor: Optional[AutoImageProcessor] = None,
        tokenizer: Optional[PreTrainedTokenizer] = None,
        config: Optional[PretrainedConfig] = None,
        video: Optional["VideoInput"] = None,
        audio: Optional[np.ndarray] = None,
    ):
        if processor is None:
            raise ValueError("Processor is required.")
        if audio is not None:
            raise ValueError("Audio input is not supported")

        content = []
        if image is not None:
            content.append({"type": "image"})
        if video is not None:
            content.append({"type": "video"})
        content.append({"type": "text", "text": text})
        messages = [{"role": "user", "content": content}]
        prompt = processor.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
        inputs = processor(
            text=prompt,
            images=[image] if image is not None else None,
            videos=[video] if video is not None else None,
            return_tensors="pt",
        )
        return inputs


MODEL_TYPE_TO_CLS_MAPPING = {
    "muse_glimmer": _OVMuseGlimmerForCausalLM,
    "llava": _OVLlavaForCausalLM,
    "llava_next": _OVLlavaNextForCausalLM,
    "llava_next_video": _OVLlavaNextVideoForCausalLM,
    "mistral3": _OVMistral3ForCausalLM,
    "minicpmv": _OVMiniCPMVForCausalLM,
    "llava-qwen2": _OVNanoLlavaForCausalLM,
    "maira2": _OVMaira2ForCausalLM,
    "phi3_v": _OVPhi3VisionForCausalLM,
    "internvl_chat": _OVInternVLForCausalLM,
    "qwen2_vl": _OVQwen2VLForCausalLM,
    "qwen2_vl_text": _OVQwen2VLForCausalLM,
    "qwen2_5_vl": _OVQwen2_5_VLForCausalLM,
    "qwen2_5_vl_text": _OVQwen2_5_VLForCausalLM,
    "got_ocr2": _OVGotOCR2ForCausalLM,
    "gemma3": _OVGemma3ForCausalLM,
    "gemma3n": _OVGemma4ForCausalLM,
    "gemma4": _OVGemma4ForCausalLM,
    "gemma4_unified": _OVGemma4UnifiedForCausalLM,
    "idefics3": _OVIdefics3ForCausalLM,
    "smolvlm": _OVSmolVLForCasualLM,
    "phi4mm": _OVPhi4MMForCausalLM,
    "phi4_multimodal": _OVPhi4MMForCausalLM,
    "llama4": _OVLlama4ForCausalLM,
    "qwen3_vl": _OVQwen3VLForCausalLM,
    "qwen3_5": _OVQwen3_5ForCausalLM,
    "qwen3_5_text": _OVQwen3_5ForCausalLM,
    "qwen3_5_moe": _OVQwen3_5ForCausalLM,
    "qwen3_5_moe_text": _OVQwen3_5ForCausalLM,
    "qwen3_omni_moe": _OVQwen3OmniMoeForCausalLM,
    "minicpmo": _OVMiniCPMOForCausalLM,
    "videochat_flash_qwen": _OVVideoChatFlashQwenForCausalLM,
    "deepseek_ocr2": _OVDeepseekOCR2ForCausalLM,
}
