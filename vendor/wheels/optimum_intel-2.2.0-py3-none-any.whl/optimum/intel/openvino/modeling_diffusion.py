#  Copyright 2022 The HuggingFace Team. All rights reserved.
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.

import importlib
import inspect
import logging
import os
import shutil
from abc import abstractmethod
from collections import OrderedDict
from pathlib import Path
from tempfile import gettempdir
from types import SimpleNamespace
from typing import Any, Dict, List, Optional, Tuple, Union

import numpy as np
import openvino
import torch
from diffusers import (
    AutoPipelineForImage2Image,
    AutoPipelineForInpainting,
    AutoPipelineForText2Image,
    DiffusionPipeline,
    LatentConsistencyModelImg2ImgPipeline,
    LatentConsistencyModelPipeline,
    StableDiffusionImg2ImgPipeline,
    StableDiffusionInpaintPipeline,
    StableDiffusionPipeline,
    StableDiffusionXLImg2ImgPipeline,
    StableDiffusionXLInpaintPipeline,
    StableDiffusionXLPipeline,
    pipelines,
)
from diffusers.configuration_utils import ConfigMixin
from diffusers.schedulers import SchedulerMixin
from diffusers.schedulers.scheduling_utils import SCHEDULER_CONFIG_NAME
from diffusers.utils.constants import CONFIG_NAME
from huggingface_hub import snapshot_download
from huggingface_hub.constants import HUGGINGFACE_HUB_CACHE
from huggingface_hub.utils import validate_hf_hub_args
from openvino import Core
from openvino._offline_transformations import compress_model_transformation
from transformers import CLIPImageProcessor, CLIPTokenizer
from transformers.modeling_outputs import ModelOutput
from transformers.utils import http_user_agent

from optimum.utils import (
    DIFFUSION_MODEL_TEXT_ENCODER_2_SUBFOLDER,
    DIFFUSION_MODEL_TEXT_ENCODER_SUBFOLDER,
    DIFFUSION_MODEL_UNET_SUBFOLDER,
    DIFFUSION_MODEL_VAE_DECODER_SUBFOLDER,
    DIFFUSION_MODEL_VAE_ENCODER_SUBFOLDER,
)

from ...exporters.openvino import main_export
from ..utils.import_utils import is_diffusers_version
from .configuration import OVConfig, OVQuantizationConfigBase, OVQuantizationMethod, OVWeightQuantizationConfig
from .loaders import OVTextualInversionLoaderMixin
from .modeling_base import OVBaseModel, OVModelHostMixin
from .utils import (
    ONNX_WEIGHTS_NAME,
    OV_TO_PT_TYPE,
    OV_XML_FILE_NAME,
    TemporaryDirectory,
    _print_compiled_model_properties,
    classproperty,
    model_has_dynamic_inputs,
    np_to_pt_generators,
)


if is_diffusers_version(">=", "0.25.0"):
    from diffusers.models.autoencoders.vae import DiagonalGaussianDistribution
else:
    from diffusers.models.vae import DiagonalGaussianDistribution

# Required EncoderDecoderCache object from transformers
if is_diffusers_version(">=", "0.32"):
    from diffusers import LTXImageToVideoPipeline, LTXPipeline
else:
    LTXPipeline = object
    LTXImageToVideoPipeline = object

if is_diffusers_version(">=", "0.38.0"):
    from diffusers import LTX2ImageToVideoPipeline, LTX2Pipeline
else:
    LTX2Pipeline = object
    LTX2ImageToVideoPipeline = object

if is_diffusers_version(">=", "0.29.0"):
    from diffusers import StableDiffusion3Img2ImgPipeline, StableDiffusion3Pipeline
else:
    StableDiffusion3Pipeline, StableDiffusion3Img2ImgPipeline = object, object

if is_diffusers_version(">=", "0.30.0"):
    from diffusers import FluxPipeline, StableDiffusion3InpaintPipeline
else:
    StableDiffusion3InpaintPipeline = object
    FluxPipeline = object


if is_diffusers_version(">=", "0.31.0"):
    from diffusers import FluxImg2ImgPipeline, FluxInpaintPipeline
else:
    FluxImg2ImgPipeline = object
    FluxInpaintPipeline = object

if is_diffusers_version(">=", "0.32.0"):
    from diffusers import FluxFillPipeline, SanaPipeline
else:
    FluxFillPipeline = object
    SanaPipeline = object

if is_diffusers_version(">=", "0.33.0"):
    from diffusers import SanaSprintPipeline
else:
    SanaSprintPipeline = object

if is_diffusers_version(">=", "0.37.0"):
    from diffusers import ZImageImg2ImgPipeline, ZImageInpaintPipeline, ZImagePipeline
else:
    ZImagePipeline = object
    ZImageImg2ImgPipeline = object
    ZImageInpaintPipeline = object


if is_diffusers_version(">=", "0.35.0"):
    from diffusers import QwenImagePipeline
    from diffusers.models.cache_utils import CacheMixin
else:
    CacheMixin = object
    QwenImagePipeline = object

if is_diffusers_version(">=", "0.37.0"):
    from diffusers import Flux2KleinPipeline
else:
    Flux2KleinPipeline = object

DIFFUSION_MODEL_TRANSFORMER_SUBFOLDER = "transformer"
DIFFUSION_MODEL_TEXT_ENCODER_3_SUBFOLDER = "text_encoder_3"
DIFFUSION_MODEL_CONNECTORS_SUBFOLDER = "connectors"
DIFFUSION_MODEL_AUDIO_VAE_DECODER_SUBFOLDER = "audio_vae_decoder"
DIFFUSION_MODEL_VOCODER_SUBFOLDER = "vocoder"

core = Core()

logger = logging.getLogger(__name__)


# TODO: support DiffusionPipeline.from_pipe()
# TODO: makes more sense to have a compositional OVMixin class
# TODO: instead of one bloated __init__, we should consider an __init__ per pipeline
class OVDiffusionPipeline(OVBaseModel, DiffusionPipeline):
    auto_model_class = DiffusionPipeline
    config_name = "model_index.json"
    _library_name = "diffusers"

    @classproperty
    def _all_ov_model_paths(cls) -> Dict[str, str]:
        models_paths = {
            "unet": os.path.join(DIFFUSION_MODEL_UNET_SUBFOLDER, OV_XML_FILE_NAME),
            "transformer": os.path.join(DIFFUSION_MODEL_TRANSFORMER_SUBFOLDER, OV_XML_FILE_NAME),
            "vae_decoder": os.path.join(DIFFUSION_MODEL_VAE_DECODER_SUBFOLDER, OV_XML_FILE_NAME),
            "vae_encoder": os.path.join(DIFFUSION_MODEL_VAE_ENCODER_SUBFOLDER, OV_XML_FILE_NAME),
            "text_encoder": os.path.join(DIFFUSION_MODEL_TEXT_ENCODER_SUBFOLDER, OV_XML_FILE_NAME),
            "text_encoder_2": os.path.join(DIFFUSION_MODEL_TEXT_ENCODER_2_SUBFOLDER, OV_XML_FILE_NAME),
            "text_encoder_3": os.path.join(DIFFUSION_MODEL_TEXT_ENCODER_3_SUBFOLDER, OV_XML_FILE_NAME),
            "connectors": os.path.join(DIFFUSION_MODEL_CONNECTORS_SUBFOLDER, OV_XML_FILE_NAME),
            "audio_vae_decoder": os.path.join(DIFFUSION_MODEL_AUDIO_VAE_DECODER_SUBFOLDER, OV_XML_FILE_NAME),
            "vocoder": os.path.join(DIFFUSION_MODEL_VOCODER_SUBFOLDER, OV_XML_FILE_NAME),
        }
        return models_paths

    def __init__(
        self,
        scheduler: SchedulerMixin,
        unet: Optional[openvino.Model] = None,
        vae_decoder: Optional[openvino.Model] = None,
        # optional pipeline models
        vae_encoder: Optional[openvino.Model] = None,
        text_encoder: Optional[openvino.Model] = None,
        text_encoder_2: Optional[openvino.Model] = None,
        text_encoder_3: Optional[openvino.Model] = None,
        transformer: Optional[openvino.Model] = None,
        # LTX2-specific optional models
        connectors: Optional[openvino.Model] = None,
        audio_vae_decoder: Optional[openvino.Model] = None,
        vocoder: Optional[openvino.Model] = None,
        # optional pipeline submodels
        tokenizer: Optional[CLIPTokenizer] = None,
        tokenizer_2: Optional[CLIPTokenizer] = None,
        tokenizer_3: Optional[CLIPTokenizer] = None,
        feature_extractor: Optional[CLIPImageProcessor] = None,
        # stable diffusion xl specific arguments
        force_zeros_for_empty_prompt: bool = True,
        requires_aesthetics_score: bool = False,
        add_watermarker: Optional[bool] = None,
        # openvino specific arguments
        device: str = "CPU",
        compile: bool = True,
        compile_only: bool = False,
        dynamic_shapes: bool = True,
        ov_config: Optional[Dict[str, str]] = None,
        model_save_dir: Optional[Union[str, Path, TemporaryDirectory]] = None,
        quantization_config: Optional[Union[OVWeightQuantizationConfig, Dict]] = None,
        **kwargs,
    ):
        self._device = device.upper()
        self.is_dynamic = dynamic_shapes
        self._compile_only = compile_only
        self.model_save_dir = model_save_dir
        self.ov_config = {} if ov_config is None else {**ov_config}
        self.preprocessors = kwargs.get("preprocessors", [])

        if self._compile_only:
            if not compile:
                raise ValueError(
                    "`compile_only` mode does not support disabling compilation."
                    "Please provide `compile=True` if you want to use `compile_only=True` or set `compile_only=False`"
                )

            main_model = unet if unet is not None else transformer
            if not isinstance(main_model, openvino.CompiledModel):
                raise ValueError("`compile_only` expect that already compiled model will be provided")

            model_is_dynamic = model_has_dynamic_inputs(main_model)
            if dynamic_shapes ^ model_is_dynamic:
                requested_shapes = "dynamic" if dynamic_shapes else "static"
                compiled_shapes = "dynamic" if model_is_dynamic else "static"
                raise ValueError(
                    f"Provided compiled model with {compiled_shapes} shapes but requested to use {requested_shapes}. "
                    f"Please set `compile_only=False` or `dynamic_shapes={model_is_dynamic}`"
                )

        self.unet = OVModelUnet(unet, self, DIFFUSION_MODEL_UNET_SUBFOLDER) if unet is not None else None
        transformer_cls = (
            OVModelQwenImageTransformer if self.__class__.__name__.startswith("OVQwenImage") else OVModelTransformer
        )
        self.transformer = (
            transformer_cls(transformer, self, DIFFUSION_MODEL_TRANSFORMER_SUBFOLDER)
            if transformer is not None
            else None
        )

        if unet is None and transformer is None:
            raise ValueError("`unet` or `transformer` model should be provided for pipeline work")
        self.vae_decoder = OVModelVaeDecoder(vae_decoder, self, DIFFUSION_MODEL_VAE_DECODER_SUBFOLDER)
        self.vae_encoder = (
            OVModelVaeEncoder(vae_encoder, self, DIFFUSION_MODEL_VAE_ENCODER_SUBFOLDER)
            if vae_encoder is not None
            else None
        )
        self.text_encoder = (
            OVModelTextEncoder(text_encoder, self, DIFFUSION_MODEL_TEXT_ENCODER_SUBFOLDER)
            if text_encoder is not None
            else None
        )
        self.text_encoder_2 = (
            OVModelTextEncoder(text_encoder_2, self, DIFFUSION_MODEL_TEXT_ENCODER_2_SUBFOLDER)
            if text_encoder_2 is not None
            else None
        )
        self.text_encoder_3 = (
            OVModelTextEncoder(text_encoder_3, self, DIFFUSION_MODEL_TEXT_ENCODER_3_SUBFOLDER)
            if text_encoder_3 is not None
            else None
        )
        # LTX2-specific models
        self.connectors = None
        self.audio_vae_decoder = None
        self.vocoder = None
        # We wrap the VAE Decoder & Encoder in a single object to simulate diffusers API
        self.vae = OVModelVae(decoder=self.vae_decoder, encoder=self.vae_encoder)

        self.scheduler = scheduler
        self.tokenizer = tokenizer
        self.tokenizer_2 = tokenizer_2
        self.tokenizer_3 = tokenizer_3
        self.feature_extractor = feature_extractor

        # we allow passing these as torch models for now
        self.image_encoder = kwargs.pop("image_encoder", None)  # TODO: maybe mplement OVModelImageEncoder
        self.safety_checker = kwargs.pop("safety_checker", None)  # TODO: maybe mplement OVModelSafetyChecker

        all_pipeline_init_args = {
            "vae": self.vae,
            "unet": self.unet,
            "transformer": self.transformer,
            "text_encoder": self.text_encoder,
            "text_encoder_2": self.text_encoder_2,
            "text_encoder_3": self.text_encoder_3,
            "safety_checker": self.safety_checker,
            "image_encoder": self.image_encoder,
            "scheduler": self.scheduler,
            "tokenizer": self.tokenizer,
            "tokenizer_2": self.tokenizer_2,
            "tokenizer_3": self.tokenizer_3,
            "feature_extractor": self.feature_extractor,
            "requires_aesthetics_score": requires_aesthetics_score,
            "force_zeros_for_empty_prompt": force_zeros_for_empty_prompt,
            "add_watermarker": add_watermarker,
        }

        diffusers_pipeline_args = {}
        for key in inspect.signature(self.auto_model_class).parameters.keys():
            if key in all_pipeline_init_args:
                diffusers_pipeline_args[key] = all_pipeline_init_args[key]
        # inits diffusers pipeline specific attributes (registers modules and config)
        self.auto_model_class.__init__(self, **diffusers_pipeline_args)
        # we use auto_model_class.__init__ here because we can't call super().__init__
        # as OptimizedModel already defines an __init__ which is the first in the MRO

        self._openvino_config = None
        if quantization_config:
            self._openvino_config = OVConfig(quantization_config=quantization_config)
        self._set_ov_config_parameters()

        if self.is_dynamic and not self._compile_only:
            self.reshape(batch_size=-1, height=-1, width=-1, num_images_per_prompt=-1)

        if compile and not self._compile_only:
            self.compile()

    @property
    def _component_names(self) -> List[str]:
        component_names = [name for name in self._all_ov_model_paths if getattr(self, name) is not None]
        return component_names

    @property
    def _ov_model_names(self) -> List[str]:
        return self._component_names

    @property
    def ov_models(self) -> Dict[str, openvino.Model]:
        return {name: getattr(component, "model") for name, component in self.components.items()}

    def _save_pretrained(self, save_directory: Union[str, Path]):
        """
        Saves the model to the OpenVINO IR format so that it can be re-loaded using the
        [`~optimum.intel.openvino.modeling.OVModel.from_pretrained`] class method.

        Arguments:
            save_directory (`str` or `Path`):
                The directory where to save the model files
        """
        if self._compile_only:
            raise ValueError(
                "`save_pretrained()` is not supported with `compile_only` mode, please initialize model without this option"
            )

        save_directory = Path(save_directory)

        models_to_save_paths = {
            component: save_directory / self._ov_model_paths[ov_component_name]
            for ov_component_name, component in self.components.items()
        }
        for model, dst_path in models_to_save_paths.items():
            save_path = dst_path.parent
            save_path.mkdir(parents=True, exist_ok=True)
            openvino.save_model(model.model, dst_path, compress_to_fp16=False)
            model_dir = (
                self.model_save_dir
                if not isinstance(self.model_save_dir, TemporaryDirectory)
                else self.model_save_dir.name
            )
            config_path = Path(model_dir) / save_path.name / CONFIG_NAME
            if config_path.is_file():
                config_save_path = save_path / CONFIG_NAME
                shutil.copyfile(config_path, config_save_path)
            else:
                if hasattr(model, "save_config"):
                    model.save_config(save_path)
                elif hasattr(model, "config") and hasattr(model.config, "save_pretrained"):
                    model.config.save_pretrained(save_path)

        self.scheduler.save_pretrained(save_directory / "scheduler")

        if self.tokenizer is not None:
            self.tokenizer.save_pretrained(save_directory / "tokenizer")
        if self.tokenizer_2 is not None:
            self.tokenizer_2.save_pretrained(save_directory / "tokenizer_2")
        if self.tokenizer_3 is not None:
            self.tokenizer_3.save_pretrained(save_directory / "tokenizer_3")
        if self.feature_extractor is not None:
            self.feature_extractor.save_pretrained(save_directory / "feature_extractor")
        if getattr(self, "safety_checker", None) is not None:
            self.safety_checker.save_pretrained(save_directory / "safety_checker")

        self._save_openvino_config(save_directory)

    def _save_config(self, save_directory):
        """
        Saves a model configuration into a directory, so that it can be re-loaded using the
        [`from_pretrained`] class method.
        """
        model_dir = (
            self.model_save_dir
            if not isinstance(self.model_save_dir, TemporaryDirectory)
            else self.model_save_dir.name
        )
        save_dir = Path(save_directory)
        original_config = Path(model_dir) / self.config_name
        if original_config.exists():
            if not save_dir.exists():
                save_dir.mkdir(parents=True)

            shutil.copy(original_config, save_dir)
        else:
            self.config.save_pretrained(save_dir)

    @classmethod
    def _from_pretrained(
        cls,
        model_id: Union[str, Path],
        config: Dict[str, Any],
        token: Optional[Union[bool, str]] = None,
        revision: Optional[str] = None,
        force_download: bool = False,
        local_files_only: bool = False,
        cache_dir: str = HUGGINGFACE_HUB_CACHE,
        unet_file_name: Optional[str] = None,
        vae_decoder_file_name: Optional[str] = None,
        vae_encoder_file_name: Optional[str] = None,
        text_encoder_file_name: Optional[str] = None,
        text_encoder_2_file_name: Optional[str] = None,
        text_encoder_3_file_name: Optional[str] = None,
        transformer_file_name: Optional[str] = None,
        connectors_file_name: Optional[str] = None,
        audio_vae_decoder_file_name: Optional[str] = None,
        vocoder_file_name: Optional[str] = None,
        from_onnx: bool = False,
        load_in_8bit: bool = False,
        quantization_config: Union[OVWeightQuantizationConfig, Dict] = None,
        model_save_dir: Optional[Union[str, Path, TemporaryDirectory]] = None,
        trust_remote_code: bool = False,
        export_model_id: Optional[str] = None,
        **kwargs,
    ):
        # same as DiffusionPipeline.from_pretraoned, if called directly, it loads the class in the config
        if cls.__name__ == "OVDiffusionPipeline":
            class_name = config["_class_name"]
            ov_pipeline_class = _get_ov_class(class_name)
        else:
            ov_pipeline_class = cls

        default_file_name = ONNX_WEIGHTS_NAME if from_onnx else OV_XML_FILE_NAME

        file_names = {
            "unet": unet_file_name or default_file_name,
            "vae_encoder": vae_encoder_file_name or default_file_name,
            "vae_decoder": vae_decoder_file_name or default_file_name,
            "text_encoder": text_encoder_file_name or default_file_name,
            "text_encoder_2": text_encoder_2_file_name or default_file_name,
            "text_encoder_3": text_encoder_3_file_name or default_file_name,
            "transformer": transformer_file_name or default_file_name,
            "connectors": connectors_file_name or default_file_name,
            "audio_vae_decoder": audio_vae_decoder_file_name or default_file_name,
            "vocoder": vocoder_file_name or default_file_name,
        }

        if not os.path.isdir(str(model_id)):
            all_components = {key for key in config.keys() if not key.startswith("_")} | {"vae_encoder", "vae_decoder"}
            allow_patterns = {os.path.join(component, "*") for component in all_components}
            allow_patterns.update(
                {
                    *file_names.values(),
                    *(file_name.replace(".xml", ".bin") for file_name in file_names.values()),
                    SCHEDULER_CONFIG_NAME,
                    cls.config_name,
                    CONFIG_NAME,
                }
            )
            ignore_patterns = ["*.msgpack", "*.safetensors", "*pytorch_model.bin"]
            if not from_onnx:
                ignore_patterns.extend(["*.onnx", "*.onnx_data"])

            model_save_folder = snapshot_download(
                model_id,
                cache_dir=cache_dir,
                force_download=force_download,
                local_files_only=local_files_only,
                revision=revision,
                token=token,
                user_agent=http_user_agent,
                allow_patterns=allow_patterns,
                ignore_patterns=ignore_patterns,
            )
        else:
            model_save_folder = str(model_id)

        model_save_path = Path(model_save_folder)

        if model_save_dir is None:
            model_save_dir = model_save_path

        submodels = {
            "scheduler": None,
            "tokenizer": None,
            "tokenizer_2": None,
            "tokenizer_3": None,
            "feature_extractor": None,
            "safety_checker": None,
            "image_encoder": None,
        }
        for name in submodels.keys():
            if name in kwargs:
                submodels[name] = kwargs.pop(name)
            elif config.get(name, (None, None))[0] is not None:
                module_name, module_class = config.get(name)
                if hasattr(pipelines, module_name):
                    module = getattr(pipelines, module_name)
                else:
                    module = importlib.import_module(module_name)
                class_obj = getattr(module, module_class)
                load_method = getattr(class_obj, "from_pretrained")
                # Check if the module is in a subdirectory
                if (model_save_path / name).is_dir():
                    submodels[name] = load_method(model_save_path / name)
                # For backward compatibility with models exported using previous optimum version, where safety_checker saving was disabled
                elif name == "safety_checker":
                    logger.warning(
                        "Pipeline config contains `safety_checker` subcomponent, while `safety_checker` is not available in model directory. "
                        "`safety_checker` will be disabled. If you want to enable it please set it explicitly to `from_pretrained` method "
                        "or reexport model with new optimum-intel version"
                    )
                    submodels[name] = None
                else:
                    submodels[name] = load_method(model_save_path)

        models = {
            ov_model_name: (model_save_path / ov_model_path).parent / file_names[ov_model_name]
            for ov_model_name, ov_model_path in cls._all_ov_model_paths.items()
        }
        for config_key, value in config.items():
            if config_key not in models and config_key not in kwargs and config_key not in submodels:
                kwargs[config_key] = value

        compile_only = kwargs.get("compile_only", False)
        if compile_only:
            ov_config = kwargs.get("ov_config", {})
            device = kwargs.get("device", "CPU")
            vae_ov_conifg = {**ov_config}
            for name, path in models.items():
                if name in kwargs:
                    models[name] = kwargs.pop(name)
                else:
                    models[name] = (
                        cls._compile_model(
                            path,
                            device,
                            ov_config if "vae" not in name else vae_ov_conifg,
                            Path(model_save_dir) / name,
                        )
                        if path.is_file()
                        else None
                    )
        else:
            for name, path in models.items():
                if name in kwargs:
                    models[name] = kwargs.pop(name)
                else:
                    models[name] = cls.load_model(path) if path.is_file() else None

        name_or_path = config.get("_name_or_path", str(model_id))
        quantization_config = quantization_config or (OVWeightQuantizationConfig(bits=8) if load_in_8bit else None)
        compile_model = kwargs.pop("compile", True)
        ov_pipeline = ov_pipeline_class(
            **models,
            **submodels,
            model_save_dir=model_save_dir,
            quantization_config=quantization_config,
            compile=compile_model and not quantization_config,
            **kwargs,
        )
        # same as in DiffusionPipeline.from_pretrained, we save where the model was instantiated from
        ov_pipeline.register_to_config(_name_or_path=name_or_path)

        if quantization_config:
            quantization_dataset = (
                quantization_config.dataset
                if isinstance(quantization_config, OVQuantizationConfigBase)
                else quantization_config.get("dataset", None)
            )
            if quantization_dataset is not None and ov_pipeline.export_feature != "text-to-image":
                raise NotImplementedError(
                    f"Data-aware quantization is not supported for {cls.__name__} with "
                    f"{ov_pipeline_class.export_feature} task."
                )
            # export_model_id is needed because _name_or_path is not necessarily present in the model config
            model_id = export_model_id or name_or_path
            quantization_config = cls._resolve_default_quantization_config(model_id, quantization_config)
            ov_pipeline._apply_quantization(
                quantization_config, compile_only, compile_model, model_id, trust_remote_code
            )

        return ov_pipeline

    @classmethod
    def _export(
        cls,
        model_id: str,
        config: Dict[str, Any],
        token: Optional[Union[bool, str]] = None,
        revision: Optional[str] = None,
        force_download: bool = False,
        cache_dir: str = HUGGINGFACE_HUB_CACHE,
        local_files_only: bool = False,
        load_in_8bit: Optional[bool] = None,
        quantization_config: Union[OVWeightQuantizationConfig, Dict] = None,
        compile_only: bool = False,
        **kwargs,
    ):
        if compile_only:
            logger.warning(
                "`compile_only` mode will be disabled because it does not support model export."
                "Please provide openvino model obtained using optimum-cli or saved on disk using `save_pretrained`"
            )
            compile_only = False

        # If load_in_8bit and quantization_config not specified then ov_config is set
        # to None and will be set by default in convert depending on the model size
        if load_in_8bit is None and not quantization_config:
            ov_config = None
        else:
            ov_config = OVConfig(dtype="auto")

        torch_dtype = kwargs.pop("torch_dtype", None)

        model_loading_kwargs = {}

        if torch_dtype is not None:
            model_loading_kwargs["torch_dtype"] = torch_dtype

        model_save_dir = TemporaryDirectory()
        model_save_path = Path(model_save_dir.name)
        variant = kwargs.pop("variant", None)

        main_export(
            model_name_or_path=model_id,
            output=model_save_path,
            do_validation=False,
            no_post_process=True,
            revision=revision,
            cache_dir=cache_dir,
            task=cls.export_feature,
            token=token,
            local_files_only=local_files_only,
            force_download=force_download,
            ov_config=ov_config,
            library_name=cls._library_name,
            variant=variant,
            model_loading_kwargs=model_loading_kwargs,
        )

        return cls._from_pretrained(
            model_id=model_save_path,
            config=config,
            from_onnx=False,
            token=token,
            revision=revision,
            cache_dir=cache_dir,
            force_download=force_download,
            local_files_only=local_files_only,
            model_save_dir=model_save_dir,
            quantization_config=quantization_config,
            load_in_8bit=load_in_8bit,
            compile_only=compile_only,
            export_model_id=model_id,  # needed to resolve default quantization config during export
            **kwargs,
        )

    def to(self, *args, device: Optional[str] = None, dtype: Optional[torch.dtype] = None):
        for arg in args:
            if isinstance(arg, str):
                device = arg
            elif isinstance(arg, torch.dtype):
                dtype = arg

        if isinstance(device, str):
            self._device = device.upper()
            self.clear_requests()
        elif device is not None:
            raise ValueError(
                "The `device` argument should be a string representing the device on which the model should be loaded."
            )

        if dtype is not None and dtype != self.dtype:
            raise NotImplementedError(
                f"Cannot change the dtype of the model from {self.dtype} to {dtype}. "
                f"Please export the model with the desired dtype."
            )

        return self

    @property
    def height(self) -> int:
        model = self.vae.decoder.model
        height = model.inputs[0].get_partial_shape()[-2]
        if height.is_dynamic:
            return -1
        return height.get_length() * (
            self.vae_scale_factor if hasattr(self, "vae_scale_factor") else self.vae_spatial_compression_ratio
        )

    @property
    def width(self) -> int:
        model = self.vae.decoder.model
        width = model.inputs[0].get_partial_shape()[-1]
        if width.is_dynamic:
            return -1
        return width.get_length() * (
            self.vae_scale_factor if hasattr(self, "vae_scale_factor") else self.vae_spatial_compression_ratio
        )

    @property
    def batch_size(self) -> int:
        model = self.unet.model if self.unet is not None else self.transformer.model
        batch_size = model.inputs[0].get_partial_shape()[0]
        if batch_size.is_dynamic:
            return -1
        return batch_size.get_length()

    def _preprocess_quantization_config(
        self,
        quantization_config: OVQuantizationConfigBase,
        model_name_or_path: str,
    ) -> OVQuantizationConfigBase:
        if isinstance(quantization_config, OVWeightQuantizationConfig) and quantization_config.dataset is not None:
            quantization_config = quantization_config.clone()
            quantization_config.quant_method = OVQuantizationMethod.HYBRID
        return quantization_config

    def _reshape_unet(
        self,
        model: openvino.Model,
        batch_size: int = -1,
        height: int = -1,
        width: int = -1,
        num_images_per_prompt: int = -1,
        tokenizer_max_length: int = -1,
    ):
        if batch_size == -1 or num_images_per_prompt == -1:
            batch_size = -1
        else:
            batch_size *= num_images_per_prompt
            # The factor of 2 comes from the guidance scale > 1
            if "timestep_cond" not in {inputs.get_any_name() for inputs in model.inputs}:
                batch_size *= 2

        height = height // self.vae_scale_factor if height > 0 else height
        width = width // self.vae_scale_factor if width > 0 else width
        shapes = {}
        for inputs in model.inputs:
            shapes[inputs] = inputs.get_partial_shape()
            if inputs.get_any_name() == "timestep":
                if shapes[inputs].rank == 1:
                    shapes[inputs][0] = 1
            elif inputs.get_any_name() == "sample":
                in_channels = self.unet.config.get("in_channels", None)
                if in_channels is None:
                    in_channels = shapes[inputs][1]
                    if in_channels.is_dynamic:
                        logger.warning(
                            "Could not identify `in_channels` from the unet configuration, to statically reshape the unet please provide a configuration."
                        )
                        self.is_dynamic = True

                shapes[inputs] = [batch_size, in_channels, height, width]
            elif inputs.get_any_name() == "text_embeds":
                shapes[inputs] = [batch_size, self.text_encoder_2.config["projection_dim"]]
            elif inputs.get_any_name() == "time_ids":
                shapes[inputs] = [batch_size, inputs.get_partial_shape()[1]]
            elif inputs.get_any_name() == "timestep_cond":
                shapes[inputs] = [batch_size, self.unet.config["time_cond_proj_dim"]]
            else:
                shapes[inputs][0] = batch_size
                shapes[inputs][1] = tokenizer_max_length
        model.reshape(shapes)
        return model

    def _reshape_transformer(
        self,
        model: openvino.Model,
        batch_size: int = -1,
        height: int = -1,
        width: int = -1,
        num_images_per_prompt: int = -1,
        tokenizer_max_length: int = -1,
        num_frames: int = -1,
    ):
        is_qwen_image = self.__class__.__name__.startswith("OVQwenImage")
        is_zimage = self.__class__.__name__.startswith("OVZImage")
        if batch_size == -1 or num_images_per_prompt == -1:
            batch_size = -1
        else:
            # The factor of 2 comes from the guidance scale > 1
            batch_size *= num_images_per_prompt
            # QwenImage runs the conditional and unconditional passes as separate calls (no batch doubling).
            # The img_ids check targets Flux, which folds guidance into an embedding instead of doubling the
            # batch; Z-Image also has img_ids but does double, so it is excluded from that check.
            if not is_qwen_image and (
                is_zimage or "img_ids" not in {inputs.get_any_name() for inputs in model.inputs}
            ):
                batch_size *= 2

        is_ltx = getattr(self, "_is_ltx_pipeline", False)
        is_flux2 = self.__class__.__name__.startswith("OVFlux2")
        if is_ltx:
            height = height // self.vae_spatial_compression_ratio if height > 0 else -1
            width = width // self.vae_spatial_compression_ratio if width > 0 else -1
            if num_frames > 0:
                num_frames = (num_frames - 1) // self.vae_temporal_compression_ratio + 1
            packed_height_width = width * height * num_frames if height > 0 and width > 0 and num_frames > 0 else -1
        else:
            height = height // self.vae_scale_factor if height > 0 else height
            width = width // self.vae_scale_factor if width > 0 else width
            packed_height = height // 2 if height > 0 else height
            packed_width = width // 2 if width > 0 else width
            packed_height_width = packed_width * packed_height if height > 0 and width > 0 else -1

        shapes = {}
        for inputs in model.inputs:
            shapes[inputs] = inputs.get_partial_shape()
            if inputs.get_any_name() in ["timestep", "guidance"]:
                shapes[inputs][0] = batch_size
                if is_ltx and len(shapes[inputs]) == 2:
                    shapes[inputs][1] = packed_height_width
            elif inputs.get_any_name() == "hidden_states":
                in_channels = self.transformer.config.get("in_channels", None)
                if in_channels is None:
                    in_channels = (
                        shapes[inputs][1] if inputs.get_partial_shape().rank.get_length() == 4 else shapes[inputs][2]
                    )
                    if in_channels.is_dynamic:
                        logger.warning(
                            "Could not identify `in_channels` from the unet configuration, to statically reshape the unet please provide a configuration."
                        )
                        self.is_dynamic = True
                if inputs.get_partial_shape().rank.get_length() == 4:
                    shapes[inputs] = [batch_size, in_channels, height, width]
                else:
                    shapes[inputs] = [batch_size, packed_height_width, in_channels]

            elif inputs.get_any_name() == "pooled_projections":
                shapes[inputs] = [batch_size, self.transformer.config["pooled_projection_dim"]]
            elif inputs.get_any_name() == "img_ids":
                if is_zimage:
                    # Unlike Flux, Z-Image's ids are per batch item and its image tokens are
                    # padded up to SEQ_MULTI_OF, so the sequence length is not packed_h*packed_w.
                    shapes[inputs] = [batch_size, -1, 3]
                else:
                    shapes[inputs] = (
                        [batch_size, packed_height_width, 3]
                        if is_diffusers_version("<", "0.31.0")
                        else [packed_height_width, 3]
                    )
                    if is_flux2:
                        shapes[inputs] = [batch_size, packed_height_width, 4]
            elif inputs.get_any_name() == "txt_ids":
                if is_zimage:
                    shapes[inputs] = [batch_size, -1, 3]
                else:
                    shapes[inputs] = [batch_size, -1, 3] if is_diffusers_version("<", "0.31.0") else [-1, 3]
                    if is_flux2:
                        shapes[inputs] = [batch_size, -1, 4]
            elif inputs.get_any_name() in ["height", "width", "num_frames", "rope_interpolation_scale"]:
                shapes[inputs] = inputs.get_partial_shape()
            else:
                shapes[inputs][0] = batch_size
                shapes[inputs][1] = -1  # text_encoder_3 may have vary input length
        model.reshape(shapes)
        return model

    def _reshape_text_encoder(self, model: openvino.Model, batch_size: int = -1, tokenizer_max_length: int = -1):
        if batch_size != -1:
            shapes = {input_tensor: [batch_size, tokenizer_max_length] for input_tensor in model.inputs}
            model.reshape(shapes)
        return model

    def _reshape_vae_encoder(
        self,
        model: openvino.Model,
        batch_size: int = -1,
        height: int = -1,
        width: int = -1,
        num_frames: int = -1,
    ):
        in_channels = self.vae_encoder.config.get("in_channels", None)
        if in_channels is None:
            in_channels = model.inputs[0].get_partial_shape()[1]
            if in_channels.is_dynamic:
                logger.warning(
                    "Could not identify `in_channels` from the VAE encoder configuration, to statically reshape the VAE encoder please provide a configuration."
                )
                self.is_dynamic = True
        if getattr(self, "_vae_encoder_single_frame", False):
            num_frames = 1
        shapes = {
            model.inputs[0]: (
                [batch_size, in_channels, height, width]
                if model.inputs[0].get_partial_shape().rank.get_length() == 4
                else [batch_size, in_channels, num_frames, height, width]
            )
        }
        model.reshape(shapes)
        return model

    def _reshape_vae_decoder(
        self,
        model: openvino.Model,
        height: int = -1,
        width: int = -1,
        num_images_per_prompt: int = -1,
        num_frames: int = -1,
    ):
        is_ltx = getattr(self, "_is_ltx_pipeline", False)
        is_qwen_image = self.__class__.__name__.startswith("OVQwenImage")
        if is_ltx:
            height = height // self.vae_spatial_compression_ratio if height > 0 else -1
            width = width // self.vae_spatial_compression_ratio if width > 0 else -1
            if num_frames > 0:
                num_frames = (num_frames - 1) // self.vae_temporal_compression_ratio + 1
        elif is_qwen_image:
            height = height // self.vae_scale_factor if height > 0 else -1
            width = width // self.vae_scale_factor if width > 0 else -1
        else:
            height = height // self.vae_scale_factor if height > -1 else height
            width = width // self.vae_scale_factor if width > -1 else width
        latent_channels = self.vae_decoder.config.get("latent_channels", None)
        if latent_channels is None:
            latent_channels = model.inputs[0].get_partial_shape()[1]
            if latent_channels.is_dynamic:
                logger.warning(
                    "Could not identify `latent_channels` from the VAE decoder configuration, to statically reshape the VAE decoder please provide a configuration."
                )
                self.is_dynamic = True
        if is_qwen_image and model.inputs[0].get_partial_shape().rank.get_length() == 5:
            # 3D (video-style) VAE decoder, run on a single temporal frame for images
            num_frames = num_frames if num_frames > 0 else 1
            shapes = {model.inputs[0]: [num_images_per_prompt, latent_channels, num_frames, height, width]}
        else:
            shapes = {
                model.inputs[0]: (
                    [num_images_per_prompt, latent_channels, height, width]
                    if not is_ltx
                    else [num_images_per_prompt, latent_channels, num_frames, height, width]
                )
            }
        model.reshape(shapes)
        return model

    def reshape(self, batch_size: int, height: int, width: int, num_images_per_prompt: int = -1, num_frames: int = -1):
        if self._compile_only:
            raise ValueError(
                "`reshape()` is not supported with `compile_only` mode, please initialize model without this option"
            )

        self.is_dynamic = -1 in {batch_size, height, width, num_images_per_prompt}

        if self.tokenizer is None and self.tokenizer_2 is None:
            tokenizer_max_len = -1
        else:
            if self.tokenizer is not None and "Gemma" in self.tokenizer.__class__.__name__:
                tokenizer_max_len = -1
            else:
                tokenizer_max_len = (
                    getattr(self.tokenizer, "model_max_length", -1)
                    if self.tokenizer is not None
                    else getattr(self.tokenizer_2, "model_max_length", -1)
                )

        if self.unet is not None:
            self.unet.model = self._reshape_unet(
                self.unet.model, batch_size, height, width, num_images_per_prompt, tokenizer_max_len
            )
        if self.transformer is not None:
            self.transformer.model = self._reshape_transformer(
                self.transformer.model,
                batch_size,
                height,
                width,
                num_images_per_prompt,
                tokenizer_max_len,
                num_frames=num_frames,
            )
        self.vae_decoder.model = self._reshape_vae_decoder(
            self.vae_decoder.model, height, width, num_images_per_prompt, num_frames=num_frames
        )

        if self.vae_encoder is not None:
            self.vae_encoder.model = self._reshape_vae_encoder(
                self.vae_encoder.model, batch_size, height, width, num_frames=num_frames
            )

        if self.text_encoder is not None:
            self.text_encoder.model = self._reshape_text_encoder(
                # GemmaTokenizer uses inf as model_max_length; LTX, QwenImage and Z-Image text
                # encoders do not pad their input to model_max_length (Z-Image pads to its own
                # max_sequence_length), so their sequence dimension must stay dynamic
                self.text_encoder.model,
                batch_size,
                (
                    getattr(self.tokenizer, "model_max_length", -1)
                    if "Gemma" not in self.tokenizer.__class__.__name__
                    and not self.__class__.__name__.startswith("OVLTX")
                    and not self.__class__.__name__.startswith("OVQwenImage")
                    and not self.__class__.__name__.startswith("OVZImage")
                    and not getattr(self, "_is_ltx_pipeline", False)
                    else -1
                ),
            )

        if self.text_encoder_2 is not None:
            self.text_encoder_2.model = self._reshape_text_encoder(
                self.text_encoder_2.model, batch_size, getattr(self.tokenizer_2, "model_max_length", -1)
            )

        if self.text_encoder_3 is not None:
            self.text_encoder_3.model = self._reshape_text_encoder(self.text_encoder_3.model, batch_size, -1)

        self.clear_requests()
        return self

    def half(self):
        """
        Converts all the model weights to FP16 for more efficient inference on GPU.
        """
        if self._compile_only:
            raise ValueError(
                "`half()` is not supported with `compile_only` mode, please initialize model without this option"
            )

        for ov_model in self.ov_models.values():
            compress_model_transformation(ov_model)

        self.clear_requests()

        return self

    def clear_requests(self):
        if self._compile_only:
            raise ValueError(
                "`clear_requests()` is not supported with `compile_only` mode, please initialize model without this option"
            )
        for component in self.components.values():
            component.clear_requests()

    def compile(self):
        for component in self.components.values():
            component.compile()

    @classmethod
    def _load_config(cls, config_name_or_path: Union[str, os.PathLike], **kwargs):
        return cls.load_config(config_name_or_path, **kwargs)

    def __call__(self, *args, **kwargs):
        # we do this to keep numpy random states support for now
        # TODO: deprecate and add warnings when a random state is passed

        args = list(args)
        for i in range(len(args)):
            args[i] = np_to_pt_generators(args[i], self.device)

        for k, v in kwargs.items():
            kwargs[k] = np_to_pt_generators(v, self.device)

        height, width = None, None
        height_idx, width_idx = None, None
        shapes_overridden = False
        sig = inspect.signature(self.auto_model_class.__call__)
        sig_height_idx = list(sig.parameters).index("height") if "height" in sig.parameters else len(sig.parameters)
        sig_width_idx = list(sig.parameters).index("width") if "width" in sig.parameters else len(sig.parameters)
        if "height" in kwargs:
            height = kwargs["height"]
        elif len(args) > sig_height_idx:
            height = args[sig_height_idx]
            height_idx = sig_height_idx

        if "width" in kwargs:
            width = kwargs["width"]
        elif len(args) > sig_width_idx:
            width = args[sig_width_idx]
            width_idx = sig_width_idx

        if self.height != -1:
            if height is not None and height != self.height:
                logger.warning(f"Incompatible height argument provided {height}. Pipeline only support {self.height}.")
                height = self.height
            else:
                height = self.height

            if height_idx is not None:
                args[height_idx] = height
            else:
                kwargs["height"] = height

            shapes_overridden = True

        if self.width != -1:
            if width is not None and width != self.width:
                logger.warning(f"Incompatible widtth argument provided {width}. Pipeline only support {self.width}.")
                width = self.width
            else:
                width = self.width

            if width_idx is not None:
                args[width_idx] = width
            else:
                kwargs["width"] = width
            shapes_overridden = True

        # Sana generates images in specific resolution grid size and then resize to requested size by default, it may contradict with pipeline height / width
        # Disable this behavior for static shape pipeline
        if self.auto_model_class.__name__.startswith("Sana") and shapes_overridden:
            sig_resolution_bining_idx = (
                list(sig.parameters).index("use_resolution_binning")
                if "use_resolution_binning" in sig.parameters
                else len(sig.parameters)
            )
            if len(args) > sig_resolution_bining_idx:
                args[sig_resolution_bining_idx] = False
            else:
                kwargs["use_resolution_binning"] = False
        # we use auto_model_class.__call__ here because we can't call super().__call__
        # as OptimizedModel already defines a __call__ which is the first in the MRO
        return self.auto_model_class.__call__(self, *args, **kwargs)


class OVPipelinePart(OVModelHostMixin, ConfigMixin, CacheMixin):
    config_name: str = CONFIG_NAME

    def __init__(
        self,
        model: openvino.Model,
        parent_pipeline: OVDiffusionPipeline,
        model_name: str = "",
    ):
        self.model = model
        self.model_name = model_name
        self.parent_pipeline = parent_pipeline
        self.request = None if not parent_pipeline._compile_only else self.model
        self.ov_config = parent_pipeline.ov_config

        if isinstance(parent_pipeline.model_save_dir, TemporaryDirectory):
            self.model_save_dir = Path(parent_pipeline.model_save_dir.name) / self.model_name
        else:
            self.model_save_dir = Path(parent_pipeline.model_save_dir) / self.model_name

        config_file_path = self.model_save_dir / self.config_name

        if not config_file_path.is_file():
            # config is mandatory for the model part to be used for inference
            raise ValueError(f"Configuration file for {self.__class__.__name__} not found at {config_file_path}")

        config_dict = self._dict_from_json_file(config_file_path)
        self.register_to_config(**config_dict)

    @property
    def _device(self) -> str:
        return self.parent_pipeline._device

    @property
    def device(self) -> torch.device:
        return self.parent_pipeline.device

    @property
    def dtype(self) -> torch.dtype:
        return OV_TO_PT_TYPE[self.ov_config.get("dtype", "f32")]

    def clear_requests(self):
        if self.parent_pipeline._compile_only:
            raise ValueError(
                "`clear_requests()` is not supported with `compile_only` mode, please initialize model without this option"
            )
        self.request = None

    def compile(self):
        if self.request is None:
            if (
                "CACHE_DIR" not in self.ov_config.keys()
                and not str(self.model_save_dir).startswith(gettempdir())
                and "GPU" in self._device
            ):
                self.ov_config["CACHE_DIR"] = os.path.join(self.model_save_dir, "model_cache")

            logger.info(f"Compiling the {self.model_name} to {self._device} ...")
            self.request = core.compile_model(self.model, self._device, self.ov_config)
            # OPENVINO_LOG_LEVEL can be found in https://docs.openvino.ai/2023.2/openvino_docs_OV_UG_supported_plugins_AUTO_debugging.html
            if "OPENVINO_LOG_LEVEL" in os.environ and int(os.environ["OPENVINO_LOG_LEVEL"]) > 2:
                _print_compiled_model_properties(self.request)

    def to(self, *args, device: Optional[str] = None, dtype: Optional[torch.dtype] = None):
        for arg in args:
            if isinstance(arg, str):
                device = arg
            elif isinstance(arg, torch.dtype):
                dtype = arg

        if isinstance(device, str):
            self._device = device.upper()
            self.request = None
        elif device is not None:
            raise ValueError(
                "The `device` argument should be a string representing the device on which the model should be loaded."
            )

        if dtype is not None and dtype != self.dtype:
            raise NotImplementedError(
                f"Cannot change the dtype of the model from {self.dtype} to {dtype}. "
                f"Please export the model with the desired dtype."
            )

        return self

    @abstractmethod
    def forward(self, *args, **kwargs):
        raise NotImplementedError

    def __call__(self, *args, **kwargs):
        return self.forward(*args, **kwargs)

    def modules(self):
        return []

    def named_modules(self):
        # starting from diffusers 0.35.0 some model parts inherit from `CacheMixin` which uses `named_modules` method
        # to register some hooks for attention caching, we return empty list here since it can't be used with OpenVINO
        yield from []


class OVModelTextEncoder(OVPipelinePart):
    def __init__(self, model: openvino.Model, parent_pipeline: OVDiffusionPipeline, model_name: str = ""):
        super().__init__(model, parent_pipeline, model_name)
        self.hidden_states_output_names = [
            name for out in self.model.outputs for name in out.names if name.startswith("hidden_states")
        ]
        self.input_names = [inp.get_any_name() for inp in self.model.inputs]

    def forward(
        self,
        input_ids: Union[np.ndarray, torch.Tensor],
        attention_mask: Optional[Union[np.ndarray, torch.Tensor]] = None,
        output_hidden_states: Optional[bool] = None,
        return_dict: bool = False,
        **kwargs,
    ):
        self.compile()
        model_inputs = {"input_ids": input_ids}

        if "attention_mask" in self.input_names:
            model_inputs["attention_mask"] = attention_mask

        ov_outputs = self.request(model_inputs, share_inputs=True)
        main_out = ov_outputs[0]
        model_outputs = {}
        model_outputs[self.model.outputs[0].get_any_name()] = torch.from_numpy(main_out)
        if len(self.model.outputs) > 1 and "pooler_output" in self.model.outputs[1].get_any_name():
            model_outputs["pooler_output"] = torch.from_numpy(ov_outputs[1])
        if self.hidden_states_output_names and "last_hidden_state" not in model_outputs:
            model_outputs["last_hidden_state"] = torch.from_numpy(ov_outputs[self.hidden_states_output_names[-1]])
        if self.hidden_states_output_names and (
            output_hidden_states or getattr(self.config, "output_hidden_states", False)
        ):
            hidden_states = [torch.from_numpy(ov_outputs[out_name]) for out_name in self.hidden_states_output_names]
            model_outputs["hidden_states"] = hidden_states
        elif (
            output_hidden_states or getattr(self.config, "output_hidden_states", False)
        ) and "last_hidden_state" in model_outputs:
            # For models like LTX2 where config.output_hidden_states is True but the exported model
            # only has last_hidden_state, provide it as hidden_states for compatibility
            model_outputs["hidden_states"] = (model_outputs["last_hidden_state"],)

        if return_dict:
            return model_outputs
        return ModelOutput(**model_outputs)


class OVModelUnet(OVPipelinePart):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        if not hasattr(self.config, "time_cond_proj_dim"):
            logger.warning(
                "The `time_cond_proj_dim` attribute is missing from the UNet configuration. "
                "Please re-export the model with newer version of optimum and diffusers."
            )
            self.register_to_config(time_cond_proj_dim=None)

    def forward(
        self,
        sample: Union[np.ndarray, torch.Tensor],
        timestep: Union[np.ndarray, torch.Tensor],
        encoder_hidden_states: Union[np.ndarray, torch.Tensor],
        text_embeds: Optional[Union[np.ndarray, torch.Tensor]] = None,
        time_ids: Optional[Union[np.ndarray, torch.Tensor]] = None,
        timestep_cond: Optional[Union[np.ndarray, torch.Tensor]] = None,
        cross_attention_kwargs: Optional[Dict[str, Any]] = None,
        added_cond_kwargs: Optional[Dict[str, Any]] = None,
        return_dict: bool = False,
    ):
        self.compile()

        model_inputs = {
            "sample": sample,
            "timestep": timestep,
            "encoder_hidden_states": encoder_hidden_states,
        }

        if text_embeds is not None:
            model_inputs["text_embeds"] = text_embeds
        if time_ids is not None:
            model_inputs["time_ids"] = time_ids
        if timestep_cond is not None:
            model_inputs["timestep_cond"] = timestep_cond
        if cross_attention_kwargs is not None:
            model_inputs.update(cross_attention_kwargs)
        if added_cond_kwargs is not None:
            model_inputs.update(added_cond_kwargs)

        ov_outputs = self.request(model_inputs, share_inputs=True).to_dict()

        model_outputs = {}
        for key, value in ov_outputs.items():
            model_outputs[next(iter(key.names))] = torch.from_numpy(value)

        if return_dict:
            return model_outputs

        return ModelOutput(**model_outputs)


class OVModelTransformer(OVPipelinePart):
    def forward(
        self,
        hidden_states: torch.FloatTensor,
        encoder_hidden_states: torch.FloatTensor = None,
        pooled_projections: torch.FloatTensor = None,
        timestep: torch.LongTensor = None,
        img_ids: torch.Tensor = None,
        txt_ids: torch.Tensor = None,
        guidance: torch.Tensor = None,
        block_controlnet_hidden_states: List = None,
        joint_attention_kwargs: Optional[Dict[str, Any]] = None,
        encoder_attention_mask: torch.LongTensor = None,
        num_frames: Optional[int] = None,
        height: Optional[int] = None,
        width: Optional[int] = None,
        rope_interpolation_scale: Optional[Union[Tuple[float, float, float], torch.Tensor]] = None,
        video_coords: Optional[torch.Tensor] = None,
        attention_kwargs: Optional[Dict[str, Any]] = None,
        return_dict: bool = True,
    ):
        self.compile()

        model_inputs = {
            "hidden_states": hidden_states,
            "timestep": timestep,
            "encoder_hidden_states": encoder_hidden_states,
        }

        if pooled_projections is not None:
            model_inputs["pooled_projections"] = pooled_projections
        if img_ids is not None:
            model_inputs["img_ids"] = img_ids

        if txt_ids is not None:
            model_inputs["txt_ids"] = txt_ids
        if guidance is not None:
            model_inputs["guidance"] = guidance

        if encoder_attention_mask is not None:
            model_inputs["encoder_attention_mask"] = encoder_attention_mask
        if num_frames is not None:
            model_inputs["num_frames"] = num_frames
        if height is not None:
            model_inputs["height"] = height
        if width is not None:
            model_inputs["width"] = width
        if rope_interpolation_scale is not None:
            if not isinstance(rope_interpolation_scale, torch.Tensor):
                rope_interpolation_scale = torch.tensor(rope_interpolation_scale)
            model_inputs["rope_interpolation_scale"] = rope_interpolation_scale

        ov_outputs = self.request(model_inputs, share_inputs=True).to_dict()

        model_outputs = {}
        for key, value in ov_outputs.items():
            model_outputs[next(iter(key.names))] = torch.from_numpy(value)

        if return_dict:
            return model_outputs

        return ModelOutput(**model_outputs)


class OVModelQwenImageTransformer(OVPipelinePart):
    """
    Transformer wrapper for QwenImage. The diffusers `QwenImageTransformer2DModel` computes its rotary
    position embeddings internally from python-list `img_shapes` using complex arithmetic. The exported
    OpenVINO model instead computes them inside the graph from the packed image `height`/`width` passed as
    runtime scalar tensor inputs (real-valued math), so a single exported model works for any resolution.
    This wrapper only has to translate `img_shapes` into those two scalars.
    """

    def forward(
        self,
        hidden_states: torch.FloatTensor,
        encoder_hidden_states: torch.FloatTensor = None,
        encoder_hidden_states_mask: torch.Tensor = None,
        timestep: torch.LongTensor = None,
        img_shapes: Optional[List] = None,
        txt_seq_lens: Optional[List[int]] = None,
        guidance: torch.Tensor = None,
        attention_kwargs: Optional[Dict[str, Any]] = None,
        return_dict: bool = True,
        **kwargs,
    ):
        self.compile()

        if encoder_hidden_states_mask is None:
            encoder_hidden_states_mask = torch.ones(encoder_hidden_states.shape[:2], dtype=torch.int64)

        # img_shapes is a per-batch list of (frame, height, width) blocks; the exported model supports a
        # single image block (frame == 1), which is what OVQwenImagePipeline produces.
        video_fhw = img_shapes[0]
        if not isinstance(video_fhw, list):
            video_fhw = [video_fhw]
        _, packed_height, packed_width = video_fhw[0]

        model_inputs = {
            "hidden_states": hidden_states,
            "encoder_hidden_states": encoder_hidden_states,
            "encoder_hidden_states_mask": encoder_hidden_states_mask,
            "timestep": timestep,
            "height": torch.tensor(packed_height, dtype=torch.int64),
            "width": torch.tensor(packed_width, dtype=torch.int64),
        }
        if guidance is not None:
            model_inputs["guidance"] = guidance

        ov_outputs = self.request(model_inputs, share_inputs=True).to_dict()

        model_outputs = {}
        for key, value in ov_outputs.items():
            model_outputs[next(iter(key.names))] = torch.from_numpy(value)

        sample = next(iter(model_outputs.values()))
        if return_dict:
            return {"sample": sample}
        return (sample,)


class OVModelTransformerLTX2(OVPipelinePart):
    def forward(
        self,
        hidden_states: torch.FloatTensor,
        audio_hidden_states: torch.FloatTensor = None,
        encoder_hidden_states: torch.FloatTensor = None,
        audio_encoder_hidden_states: torch.FloatTensor = None,
        timestep: torch.LongTensor = None,
        audio_timestep: torch.LongTensor = None,
        encoder_attention_mask: torch.LongTensor = None,
        audio_encoder_attention_mask: torch.LongTensor = None,
        num_frames: Optional[int] = None,
        height: Optional[int] = None,
        width: Optional[int] = None,
        fps: Optional[float] = None,
        audio_num_frames: Optional[int] = None,
        video_coords: Optional[torch.Tensor] = None,
        audio_coords: Optional[torch.Tensor] = None,
        attention_kwargs: Optional[Dict[str, Any]] = None,
        return_dict: bool = True,
        **kwargs,
    ):
        self.compile()

        # T2V leaves audio_timestep None; mirror the diffusers fallback before `timestep` is broadcast.
        if audio_timestep is None:
            audio_timestep = timestep if timestep is None or timestep.ndim == 1 else timestep[:, 0]

        # T2V passes a scalar timestep [B]; the IR expects [B, S]. Broadcast to match.
        if timestep is not None and timestep.ndim == 1 and self._timestep_rank == 2:
            timestep = timestep.unsqueeze(-1).expand(-1, hidden_states.shape[1]).contiguous()

        # `share_inputs=True` reads raw buffers, so stride-0 views (e.g. `t.expand(batch)`) must be materialized.
        if timestep is not None:
            timestep = timestep.contiguous()
        if audio_timestep is not None:
            audio_timestep = audio_timestep.contiguous()

        model_inputs = {
            "hidden_states": hidden_states,
            "timestep": timestep,
            "encoder_hidden_states": encoder_hidden_states,
        }

        # Older t2v exports have no `audio_timestep` input; only pass it when the IR declares it.
        if audio_timestep is not None and "audio_timestep" in self._ov_input_names:
            model_inputs["audio_timestep"] = audio_timestep

        if audio_hidden_states is not None:
            model_inputs["audio_hidden_states"] = audio_hidden_states
        if audio_encoder_hidden_states is not None:
            model_inputs["audio_encoder_hidden_states"] = audio_encoder_hidden_states
        if encoder_attention_mask is not None:
            model_inputs["encoder_attention_mask"] = encoder_attention_mask
        if audio_encoder_attention_mask is not None:
            model_inputs["audio_encoder_attention_mask"] = audio_encoder_attention_mask
        if num_frames is not None:
            model_inputs["num_frames"] = num_frames
        if height is not None:
            model_inputs["height"] = height
        if width is not None:
            model_inputs["width"] = width
        if fps is not None:
            if not isinstance(fps, torch.Tensor):
                fps = torch.tensor(float(fps))
            model_inputs["fps"] = fps
        if audio_num_frames is not None:
            model_inputs["audio_num_frames"] = audio_num_frames
        if video_coords is not None:
            model_inputs["video_coords"] = video_coords
        if audio_coords is not None:
            model_inputs["audio_coords"] = audio_coords

        ov_outputs = self.request(model_inputs, share_inputs=True).to_dict()

        model_outputs = {}
        for key, value in ov_outputs.items():
            model_outputs[next(iter(key.names))] = torch.from_numpy(value)

        if return_dict:
            return model_outputs

        return (model_outputs.get("out_sample"), model_outputs.get("audio_out_sample"))

    @property
    def _ov_input_names(self):
        return {inp.get_any_name() for inp in self.model.inputs}

    @property
    def _timestep_rank(self):
        # Exact match: "timestep" also matches "audio_timestep" (rank 1), which would break the T2V broadcast.
        for inp in self.model.inputs:
            if inp.get_any_name() == "timestep":
                return len(inp.partial_shape)
        return 1


class OVModelConnectors(OVPipelinePart):
    def forward(
        self,
        text_encoder_hidden_states: torch.FloatTensor,
        attention_mask: torch.FloatTensor,
        additive_mask: bool = False,
        **kwargs,
    ):
        self.compile()

        # The OV model was traced with a 2D binary mask (1=real, 0=padding).
        # If the caller provides an additive mask, convert it back to binary.
        if additive_mask:
            attention_mask = (attention_mask >= -0.5).to(attention_mask.dtype)

        # The exported model expects 2D attention_mask (B, seq_len)
        if attention_mask.ndim == 4:
            attention_mask = attention_mask.squeeze(1).squeeze(1)

        model_inputs = {
            "text_encoder_hidden_states": text_encoder_hidden_states,
            "attention_mask": attention_mask,
        }

        ov_outputs = self.request(model_inputs, share_inputs=True).to_dict()

        # Return in the fixed order expected by the diffusers pipeline unpacking:
        # connector_prompt_embeds, connector_audio_prompt_embeds, connector_attention_mask
        output_names = ["video_text_embedding", "audio_text_embedding", "connector_attention_mask"]
        named = {next(iter(k.names)): torch.from_numpy(v) for k, v in ov_outputs.items()}
        return tuple(named[name] for name in output_names)


class OVModelVaeEncoder(OVPipelinePart):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        if not hasattr(self.config, "scaling_factor"):
            logger.warning(
                "The `scaling_factor` attribute is missing from the VAE encoder configuration. "
                "Please re-export the model with newer version of optimum and diffusers."
            )
            if hasattr(self.config, "block_out_channels"):
                self.register_to_config(scaling_factor=2 ** (len(self.config.block_out_channels) - 1))

    def forward(
        self,
        sample: Union[np.ndarray, torch.Tensor],
        generator: Optional[torch.Generator] = None,
        return_dict: bool = False,
    ):
        self.compile()

        model_inputs = {"sample": sample}

        ov_outputs = self.request(model_inputs, share_inputs=True).to_dict()

        model_outputs = {}
        for key, value in ov_outputs.items():
            model_outputs[next(iter(key.names))] = torch.from_numpy(value)

        if "latent_sample" in model_outputs:
            model_outputs["latents"] = model_outputs.pop("latent_sample")

        if "latent_parameters" in model_outputs:
            model_outputs["latent_dist"] = DiagonalGaussianDistribution(
                parameters=model_outputs.pop("latent_parameters")
            )

        if return_dict:
            return model_outputs

        return ModelOutput(**model_outputs)


class OVModelAudioVaeDecoder(OVPipelinePart):
    """OV wrapper for LTX2 audio VAE decoder (mel spectrogram decoder).

    Provides the interface expected by LTX2Pipeline including latents_mean/std for normalization.
    """

    def __init__(self, *args, latents_mean=None, latents_std=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.latents_mean = latents_mean
        self.latents_std = latents_std
        self.mel_compression_ratio = getattr(self.config, "mel_compression_ratio", 4) if hasattr(self, "config") else 4
        self.temporal_compression_ratio = (
            getattr(self.config, "temporal_compression_ratio", 4) if hasattr(self, "config") else 4
        )

    def forward(self, latent_sample, return_dict=False):
        self.compile()
        model_inputs = {"latent_sample": latent_sample}
        ov_outputs = self.request(model_inputs, share_inputs=True).to_dict()
        outputs = {}
        for key, value in ov_outputs.items():
            outputs[next(iter(key.names))] = torch.from_numpy(value)
        if return_dict:
            return outputs
        return (outputs.get("sample", next(iter(outputs.values()))),)

    def decode(self, z, return_dict=False):
        result = self.forward(latent_sample=z, return_dict=False)
        if return_dict:
            return {"sample": result[0]}
        return result


class OVModelVocoder(OVPipelinePart):
    """OV wrapper for LTX2 vocoder (mel spectrogram to waveform)."""

    def forward(self, hidden_states):
        self.compile()
        model_inputs = {"hidden_states": hidden_states}
        ov_outputs = self.request(model_inputs, share_inputs=True).to_dict()
        outputs = {}
        for key, value in ov_outputs.items():
            outputs[next(iter(key.names))] = torch.from_numpy(value)
        return outputs.get("sample", next(iter(outputs.values())))

    def __call__(self, mel_spectrograms):
        return self.forward(mel_spectrograms)


class OVModelVaeDecoder(OVPipelinePart):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        # can be missing from models exported long ago
        if not hasattr(self.config, "scaling_factor"):
            logger.warning(
                "The `scaling_factor` attribute is missing from the VAE decoder configuration. "
                "Please re-export the model with newer version of optimum and diffusers."
            )
            if hasattr(self.config, "block_out_channels"):
                self.register_to_config(scaling_factor=2 ** (len(self.config.block_out_channels) - 1))

    def forward(
        self,
        latent_sample: Union[np.ndarray, torch.Tensor],
        timestep: Optional[Union[np.ndarray, torch.Tensor]] = None,
        generator: Optional[torch.Generator] = None,
        return_dict: bool = False,
    ):
        self.compile()

        model_inputs = {"latent_sample": latent_sample}

        if timestep is not None:
            model_inputs["timestep"] = timestep

        ov_outputs = self.request(model_inputs, share_inputs=True).to_dict()

        model_outputs = {}
        for key, value in ov_outputs.items():
            model_outputs[next(iter(key.names))] = torch.from_numpy(value)

        if return_dict:
            return model_outputs

        return ModelOutput(**model_outputs)


class OVModelVae(OVModelHostMixin):
    def __init__(self, decoder: OVModelVaeDecoder, encoder: OVModelVaeEncoder):
        self.decoder = decoder
        self.encoder = encoder
        self.spatial_compression_ratio, self.temporal_compression_ratio = None, None
        if hasattr(self.decoder.config, "spatio_temporal_scaling"):
            patch_size = self.decoder.config.patch_size
            patch_size_t = self.decoder.config.patch_size_t
            spatio_temporal_scaling = self.decoder.config.spatio_temporal_scaling
            self.spatial_compression_ratio = (
                self.decoder.config.spatial_compression_ratio
                if hasattr(self.decoder.config, "spatial_compression_ratio")
                and self.decoder.config.spatial_compression_ratio is not None
                else patch_size * 2 ** sum(spatio_temporal_scaling)
            )
            self.temporal_compression_ratio = (
                self.decoder.config.temporal_compression_ratio
                if hasattr(self.decoder.config, "temporal_compression_ratio")
                and self.decoder.config.temporal_compression_ratio is not None
                else patch_size_t * 2 ** sum(spatio_temporal_scaling)
            )
        self.latents_mean, self.latents_std = None, None
        if hasattr(self.decoder.config, "latents_mean_data"):
            self.latents_mean = torch.tensor(self.decoder.config.latents_mean_data)
        if hasattr(self.decoder.config, "latents_std_data"):
            self.latents_std = torch.tensor(self.decoder.config.latents_std_data)
        # QwenImage's 3D VAE exposes `temperal_downsample` as an attribute (used to derive the scale factor)
        self.temperal_downsample = getattr(self.decoder.config, "temperal_downsample", None)

        # Flux2Klein compatibility: pipeline expects self.vae.bn.running_mean/running_var/eps
        self.bn = None
        bn_mean = getattr(self.decoder.config, "bn_running_mean_data", None)
        bn_var = getattr(self.decoder.config, "bn_running_var_data", None)
        bn_eps = float(getattr(self.decoder.config, "bn_eps", 1e-5))

        if bn_mean is not None and bn_var is not None:
            self.bn = SimpleNamespace(
                running_mean=torch.tensor(bn_mean, dtype=torch.float32),
                running_var=torch.tensor(bn_var, dtype=torch.float32),
                eps=bn_eps,
            )

    @property
    def _component_names(self) -> List[str]:
        return ["encoder", "decoder"]

    @property
    def _ov_model_names(self) -> List[str]:
        return self._component_names

    @property
    def ov_models(self) -> Dict[str, Union[openvino.Model, openvino.CompiledModel]]:
        return {name: getattr(component, "model") for name, component in self.components.items()}

    @property
    def config(self):
        return self.decoder.config

    @property
    def dtype(self):
        return self.decoder.dtype

    @property
    def device(self):
        return self.decoder.device

    def decode(self, *args, **kwargs):
        return self.decoder(*args, **kwargs)

    def encode(self, *args, **kwargs):
        return self.encoder(*args, **kwargs)

    def to(self, *args, **kwargs):
        self.decoder.to(*args, **kwargs)
        if self.encoder is not None:
            self.encoder.to(*args, **kwargs)


class OVStableDiffusionPipeline(OVDiffusionPipeline, OVTextualInversionLoaderMixin, StableDiffusionPipeline):
    """
    OpenVINO-powered stable diffusion pipeline corresponding to [diffusers.StableDiffusionPipeline](https://huggingface.co/docs/diffusers/api/pipelines/stable_diffusion/stable_diffusion#diffusers.StableDiffusionPipeline).
    """

    main_input_name = "prompt"
    export_feature = "text-to-image"
    auto_model_class = StableDiffusionPipeline


class OVStableDiffusionImg2ImgPipeline(
    OVDiffusionPipeline, OVTextualInversionLoaderMixin, StableDiffusionImg2ImgPipeline
):
    """
    OpenVINO-powered stable diffusion pipeline corresponding to [diffusers.StableDiffusionImg2ImgPipeline](https://huggingface.co/docs/diffusers/api/pipelines/stable_diffusion/stable_diffusion_img2img#diffusers.StableDiffusionImg2ImgPipeline).
    """

    main_input_name = "image"
    export_feature = "image-to-image"
    auto_model_class = StableDiffusionImg2ImgPipeline


class OVStableDiffusionInpaintPipeline(
    OVDiffusionPipeline, OVTextualInversionLoaderMixin, StableDiffusionInpaintPipeline
):
    """
    OpenVINO-powered stable diffusion pipeline corresponding to [diffusers.StableDiffusionInpaintPipeline](https://huggingface.co/docs/diffusers/api/pipelines/stable_diffusion/stable_diffusion_inpaint#diffusers.StableDiffusionInpaintPipeline).
    """

    main_input_name = "image"
    export_feature = "inpainting"
    auto_model_class = StableDiffusionInpaintPipeline


class OVStableDiffusionXLPipeline(OVDiffusionPipeline, OVTextualInversionLoaderMixin, StableDiffusionXLPipeline):
    """
    OpenVINO-powered stable diffusion pipeline corresponding to [diffusers.StableDiffusionXLPipeline](https://huggingface.co/docs/diffusers/api/pipelines/stable_diffusion/stable_diffusion_xl#diffusers.StableDiffusionXLPipeline).
    """

    main_input_name = "prompt"
    export_feature = "text-to-image"
    auto_model_class = StableDiffusionXLPipeline

    def _get_add_time_ids(
        self,
        original_size,
        crops_coords_top_left,
        target_size,
        dtype,
        text_encoder_projection_dim=None,
    ):
        add_time_ids = list(original_size + crops_coords_top_left + target_size)

        add_time_ids = torch.tensor([add_time_ids], dtype=dtype)
        return add_time_ids


class OVStableDiffusionXLImg2ImgPipeline(
    OVDiffusionPipeline, OVTextualInversionLoaderMixin, StableDiffusionXLImg2ImgPipeline
):
    """
    OpenVINO-powered stable diffusion pipeline corresponding to [diffusers.StableDiffusionXLImg2ImgPipeline](https://huggingface.co/docs/diffusers/api/pipelines/stable_diffusion/stable_diffusion_xl#diffusers.StableDiffusionXLImg2ImgPipeline).
    """

    main_input_name = "image"
    export_feature = "image-to-image"
    auto_model_class = StableDiffusionXLImg2ImgPipeline

    def _get_add_time_ids(
        self,
        original_size,
        crops_coords_top_left,
        target_size,
        aesthetic_score,
        negative_aesthetic_score,
        negative_original_size,
        negative_crops_coords_top_left,
        negative_target_size,
        dtype,
        text_encoder_projection_dim=None,
    ):
        if self.config.requires_aesthetics_score:
            add_time_ids = list(original_size + crops_coords_top_left + (aesthetic_score,))
            add_neg_time_ids = list(
                negative_original_size + negative_crops_coords_top_left + (negative_aesthetic_score,)
            )
        else:
            add_time_ids = list(original_size + crops_coords_top_left + target_size)
            add_neg_time_ids = list(negative_original_size + crops_coords_top_left + negative_target_size)

        add_time_ids = torch.tensor([add_time_ids], dtype=dtype)
        add_neg_time_ids = torch.tensor([add_neg_time_ids], dtype=dtype)

        return add_time_ids, add_neg_time_ids


class OVStableDiffusionXLInpaintPipeline(
    OVDiffusionPipeline, OVTextualInversionLoaderMixin, StableDiffusionXLInpaintPipeline
):
    """
    OpenVINO-powered stable diffusion pipeline corresponding to [diffusers.StableDiffusionXLInpaintPipeline](https://huggingface.co/docs/diffusers/api/pipelines/stable_diffusion/stable_diffusion_xl#diffusers.StableDiffusionXLInpaintPipeline).
    """

    main_input_name = "image"
    export_feature = "inpainting"
    auto_model_class = StableDiffusionXLInpaintPipeline

    def _get_add_time_ids(
        self,
        original_size,
        crops_coords_top_left,
        target_size,
        aesthetic_score,
        negative_aesthetic_score,
        negative_original_size,
        negative_crops_coords_top_left,
        negative_target_size,
        dtype,
        text_encoder_projection_dim=None,
    ):
        if self.config.requires_aesthetics_score:
            add_time_ids = list(original_size + crops_coords_top_left + (aesthetic_score,))
            add_neg_time_ids = list(
                negative_original_size + negative_crops_coords_top_left + (negative_aesthetic_score,)
            )
        else:
            add_time_ids = list(original_size + crops_coords_top_left + target_size)
            add_neg_time_ids = list(negative_original_size + crops_coords_top_left + negative_target_size)

        add_time_ids = torch.tensor([add_time_ids], dtype=dtype)
        add_neg_time_ids = torch.tensor([add_neg_time_ids], dtype=dtype)

        return add_time_ids, add_neg_time_ids


class OVLatentConsistencyModelPipeline(
    OVDiffusionPipeline, OVTextualInversionLoaderMixin, LatentConsistencyModelPipeline
):
    """
    OpenVINO-powered stable diffusion pipeline corresponding to [diffusers.LatentConsistencyModelPipeline](https://huggingface.co/docs/diffusers/api/pipelines/stable_diffusion/latent_consistency#diffusers.LatentConsistencyModelPipeline).
    """

    main_input_name = "prompt"
    export_feature = "text-to-image"
    auto_model_class = LatentConsistencyModelPipeline


class OVLatentConsistencyModelImg2ImgPipeline(
    OVDiffusionPipeline, OVTextualInversionLoaderMixin, LatentConsistencyModelImg2ImgPipeline
):
    """
    OpenVINO-powered stable diffusion pipeline corresponding to [diffusers.LatentConsistencyModelImg2ImgPipeline](https://huggingface.co/docs/diffusers/api/pipelines/stable_diffusion/latent_consistency_img2img#diffusers.LatentConsistencyModelImg2ImgPipeline).
    """

    main_input_name = "image"
    export_feature = "image-to-image"
    auto_model_class = LatentConsistencyModelImg2ImgPipeline


class OVStableDiffusion3Pipeline(OVDiffusionPipeline, OVTextualInversionLoaderMixin, StableDiffusion3Pipeline):
    main_input_name = "prompt"
    export_feature = "text-to-image"
    auto_model_class = StableDiffusion3Pipeline


class OVStableDiffusion3Img2ImgPipeline(
    OVDiffusionPipeline, OVTextualInversionLoaderMixin, StableDiffusion3Img2ImgPipeline
):
    main_input_name = "image"
    export_feature = "image-to-image"
    auto_model_class = StableDiffusion3Img2ImgPipeline


class OVStableDiffusion3InpaintPipeline(
    OVDiffusionPipeline, OVTextualInversionLoaderMixin, StableDiffusion3InpaintPipeline
):
    main_input_name = "image"
    export_feature = "inpainting"
    auto_model_class = StableDiffusion3InpaintPipeline


class OVFluxPipeline(OVDiffusionPipeline, OVTextualInversionLoaderMixin, FluxPipeline):
    main_input_name = "prompt"
    export_feature = "text-to-image"
    auto_model_class = FluxPipeline


class OVFlux2KleinPipeline(OVDiffusionPipeline, OVTextualInversionLoaderMixin, Flux2KleinPipeline):
    main_input_name = "prompt"
    export_feature = "text-to-image"
    auto_model_class = Flux2KleinPipeline

    def __call__(self, *args, **kwargs):
        if args and isinstance(args[0], str) and "prompt" not in kwargs:
            user_prompt = args[0]
            raise ValueError(
                f"`prompt` must be passed as a keyword argument for Flux2Klein pipelines because the first positional "
                f"argument is `image`. Use `pipeline(prompt={user_prompt!r})`."
            )

        if "guidance_scale" in kwargs and kwargs["guidance_scale"] is not None and kwargs["guidance_scale"] != 1.0:
            kwargs["guidance_scale"] = 1.0

        return super().__call__(*args, **kwargs)


class OVFluxImg2ImgPipeline(OVDiffusionPipeline, OVTextualInversionLoaderMixin, FluxImg2ImgPipeline):
    main_input_name = "image"
    export_feature = "image-to-image"
    auto_model_class = FluxImg2ImgPipeline


class OVFluxInpaintPipeline(OVDiffusionPipeline, OVTextualInversionLoaderMixin, FluxInpaintPipeline):
    main_input_name = "image"
    export_feature = "inpainting"
    auto_model_class = FluxInpaintPipeline


class OVFluxFillPipeline(OVDiffusionPipeline, OVTextualInversionLoaderMixin, FluxFillPipeline):
    main_input_name = "image"
    export_feature = "inpainting"
    auto_model_class = FluxFillPipeline


class OVSanaPipeline(OVDiffusionPipeline, OVTextualInversionLoaderMixin, SanaPipeline):
    main_input_name = "prompt"
    export_feature = "text-to-image"
    auto_model_class = SanaPipeline


class OVSanaSprintPipeline(OVDiffusionPipeline, OVTextualInversionLoaderMixin, SanaSprintPipeline):
    main_input_name = "prompt"
    export_feature = "text-to-image"
    auto_model_class = SanaSprintPipeline


class OVModelLTXTransformer(OVModelTransformer):
    def forward(self, hidden_states, timestep=None, **kwargs):
        # T2V passes a scalar timestep [B]; the IR expects [B, S] where hidden_states is [B, S, C] and
        # S = num_frames * height * width in patch space. Broadcast so every token gets the same noise level.
        if timestep is not None and timestep.ndim == 1 and self._timestep_rank == 2:
            timestep = timestep.unsqueeze(-1).expand(-1, hidden_states.shape[1]).contiguous()
        return super().forward(hidden_states=hidden_states, timestep=timestep, **kwargs)

    @property
    def _timestep_rank(self):
        for inp in self.model.inputs:
            if "timestep" in inp.get_any_name():
                return len(inp.partial_shape)
        return 1


class OVLTXPipeline(OVDiffusionPipeline, OVTextualInversionLoaderMixin, LTXPipeline):
    main_input_name = "prompt"
    export_feature = "text-to-video"
    auto_model_class = LTXPipeline
    _is_ltx_pipeline = True

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if self.transformer is not None:
            self.transformer.__class__ = OVModelLTXTransformer


class OVLTXImageToVideoPipeline(OVDiffusionPipeline, OVTextualInversionLoaderMixin, LTXImageToVideoPipeline):
    main_input_name = "image"
    export_feature = "image-to-video"
    auto_model_class = LTXImageToVideoPipeline
    _is_ltx_pipeline = True
    _vae_encoder_single_frame = True

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if self.transformer is not None:
            self.transformer.__class__ = OVModelLTXTransformer

    def __call__(self, image=None, **kwargs):
        if image is None:
            raise ValueError("`image` is required for image-to-video generation.")
        return super().__call__(image=image, **kwargs)


class _OVLTX2Base(OVDiffusionPipeline, OVTextualInversionLoaderMixin):
    # Shared base rather than i2v subclassing t2v: LTX2ImageToVideoPipeline does not subclass
    # LTX2Pipeline, so subclassing would resolve `prepare_latents` to the text-to-video version.
    _is_ltx_pipeline = True

    @classproperty
    def _all_ov_model_paths(cls) -> Dict[str, str]:
        models_paths = {
            "transformer": os.path.join(DIFFUSION_MODEL_TRANSFORMER_SUBFOLDER, OV_XML_FILE_NAME),
            "vae_decoder": os.path.join(DIFFUSION_MODEL_VAE_DECODER_SUBFOLDER, OV_XML_FILE_NAME),
            "text_encoder": os.path.join(DIFFUSION_MODEL_TEXT_ENCODER_SUBFOLDER, OV_XML_FILE_NAME),
            "connectors": os.path.join(DIFFUSION_MODEL_CONNECTORS_SUBFOLDER, OV_XML_FILE_NAME),
            "audio_vae_decoder": os.path.join(DIFFUSION_MODEL_AUDIO_VAE_DECODER_SUBFOLDER, OV_XML_FILE_NAME),
            "vocoder": os.path.join(DIFFUSION_MODEL_VOCODER_SUBFOLDER, OV_XML_FILE_NAME),
        }
        return models_paths

    @property
    def _ov_model_names(self) -> List[str]:
        """Return list of OV submodel names for quantization."""
        return list(self._all_ov_model_paths.keys())

    @property
    def ov_models(self) -> Dict[str, Union[openvino.Model, openvino.CompiledModel]]:
        """Return dict mapping submodel names to their OV models for quantization."""
        return {name: component.model for name, component in self.components.items()}

    def __init__(
        self,
        scheduler: SchedulerMixin,
        vae_decoder: Optional[openvino.Model] = None,
        text_encoder: Optional[openvino.Model] = None,
        transformer: Optional[openvino.Model] = None,
        connectors: Optional[openvino.Model] = None,
        audio_vae_decoder: Optional[openvino.Model] = None,
        vocoder: Optional[openvino.Model] = None,
        vae_encoder: Optional[openvino.Model] = None,
        tokenizer: Optional[CLIPTokenizer] = None,
        device: str = "CPU",
        compile: bool = True,
        compile_only: bool = False,
        dynamic_shapes: bool = True,
        ov_config: Optional[Dict[str, str]] = None,
        model_save_dir: Optional[Union[str, Path, TemporaryDirectory]] = None,
        quantization_config: Optional[Union[OVWeightQuantizationConfig, Dict]] = None,
        **kwargs,
    ):
        self._device = device.upper()
        self.is_dynamic = dynamic_shapes
        self._compile_only = compile_only
        self.model_save_dir = model_save_dir
        self.ov_config = {} if ov_config is None else {**ov_config}
        self.preprocessors = kwargs.get("preprocessors", [])

        if self._compile_only:
            if not compile:
                raise ValueError("`compile_only` mode requires `compile=True`")

        self.transformer = (
            OVModelTransformerLTX2(transformer, self, DIFFUSION_MODEL_TRANSFORMER_SUBFOLDER)
            if transformer is not None
            else None
        )
        if self.transformer is None:
            raise ValueError("`transformer` model should be provided for pipeline work")

        # Create rope objects for coordinate preparation (used by pipeline, not by OV model)
        from diffusers.models.transformers.transformer_ltx2 import LTX2AudioVideoRotaryPosEmbed

        t_config = self.transformer.config
        self.transformer.rope = LTX2AudioVideoRotaryPosEmbed(
            dim=t_config.get("num_attention_heads", 32) * t_config.get("attention_head_dim", 128),
            base_num_frames=t_config.get("pos_embed_max_pos", 20),
            base_height=t_config.get("base_height", 2048),
            base_width=t_config.get("base_width", 2048),
            patch_size=t_config.get("patch_size", 1),
            patch_size_t=t_config.get("patch_size_t", 1),
            theta=t_config.get("rope_theta", 10000.0),
            causal_offset=t_config.get("causal_offset", 1),
            modality="video",
            double_precision=t_config.get("rope_double_precision", True),
            rope_type=t_config.get("rope_type", "split"),
            num_attention_heads=t_config.get("num_attention_heads", 32),
            scale_factors=tuple(t_config.get("vae_scale_factors", [8, 32, 32])),
            sampling_rate=t_config.get("audio_sampling_rate", 16000),
            hop_length=t_config.get("audio_hop_length", 160),
        )
        self.transformer.audio_rope = LTX2AudioVideoRotaryPosEmbed(
            dim=t_config.get("audio_num_attention_heads", 32) * t_config.get("audio_attention_head_dim", 64),
            base_num_frames=t_config.get("audio_pos_embed_max_pos", 20),
            base_height=t_config.get("base_height", 2048),
            base_width=t_config.get("base_width", 2048),
            patch_size=t_config.get("audio_patch_size", 1),
            patch_size_t=t_config.get("audio_patch_size_t", 1),
            theta=t_config.get("rope_theta", 10000.0),
            causal_offset=t_config.get("causal_offset", 1),
            modality="audio",
            double_precision=t_config.get("rope_double_precision", True),
            rope_type=t_config.get("rope_type", "split"),
            num_attention_heads=t_config.get("audio_num_attention_heads", 32),
            scale_factors=[t_config.get("audio_scale_factor", 4)],
            sampling_rate=t_config.get("audio_sampling_rate", 16000),
            hop_length=t_config.get("audio_hop_length", 160),
        )

        self.vae_decoder = OVModelVaeDecoder(vae_decoder, self, DIFFUSION_MODEL_VAE_DECODER_SUBFOLDER)
        # vae_encoder is exported for both tasks but only loaded for image-to-video (None otherwise).
        self.vae_encoder = (
            OVModelVaeEncoder(vae_encoder, self, DIFFUSION_MODEL_VAE_ENCODER_SUBFOLDER)
            if isinstance(vae_encoder, openvino.Model)
            else None
        )
        self.text_encoder = (
            OVModelTextEncoder(text_encoder, self, DIFFUSION_MODEL_TEXT_ENCODER_SUBFOLDER)
            if text_encoder is not None
            else None
        )
        # LTX2 requires text encoder to output hidden states for use in connectors
        if self.text_encoder is not None:
            self.text_encoder.config.output_hidden_states = True
        if not isinstance(connectors, openvino.Model):
            connectors = None
        self.connectors = (
            OVModelConnectors(connectors, self, DIFFUSION_MODEL_CONNECTORS_SUBFOLDER)
            if connectors is not None
            else None
        )

        self.vae = OVModelVae(decoder=self.vae_decoder, encoder=self.vae_encoder)
        self.scheduler = scheduler
        self.tokenizer = tokenizer

        # Get latents_mean/std from vae_decoder config or audio_vae_decoder config
        vae_cfg = self.vae_decoder.config
        _audio_mean = getattr(vae_cfg, "audio_latents_mean_data", None)
        _audio_std = getattr(vae_cfg, "audio_latents_std_data", None)

        # Create audio_vae_decoder with latents_mean/std for normalization
        audio_vae = OVModelAudioVaeDecoder(
            audio_vae_decoder,
            self,
            DIFFUSION_MODEL_AUDIO_VAE_DECODER_SUBFOLDER,
            latents_mean=torch.tensor(_audio_mean) if _audio_mean is not None else None,
            latents_std=torch.tensor(_audio_std) if _audio_std is not None else None,
        )
        # Override from audio_vae_decoder's own config if main config didn't have them
        if _audio_mean is None:
            _audio_mean = getattr(audio_vae.config, "latents_mean_data", None)
            if _audio_mean is not None:
                audio_vae.latents_mean = torch.tensor(_audio_mean)
        if _audio_std is None:
            _audio_std = getattr(audio_vae.config, "latents_std_data", None)
            if _audio_std is not None:
                audio_vae.latents_std = torch.tensor(_audio_std)

        vocoder = OVModelVocoder(vocoder, self, DIFFUSION_MODEL_VOCODER_SUBFOLDER)

        # Register the OV submodels via diffusers' pipeline init; this sets self.audio_vae,
        # self.vocoder, self.connectors, self.transformer, ... and registers them in self.config.
        diffusers_pipeline_args = {
            "scheduler": self.scheduler,
            "vae": self.vae,
            "audio_vae": audio_vae,
            "text_encoder": self.text_encoder,
            "tokenizer": self.tokenizer,
            "connectors": self.connectors,
            "transformer": self.transformer,
            "vocoder": vocoder,
        }
        self.auto_model_class.__init__(self, **diffusers_pipeline_args)

        # This must exist because properties like batch_size check them
        self.unet = None

        self._openvino_config = None
        if quantization_config:
            self._openvino_config = OVConfig(quantization_config=quantization_config)
        self._set_ov_config_parameters()

        if self.is_dynamic and not self._compile_only:
            self.reshape(batch_size=-1, height=-1, width=-1, num_images_per_prompt=-1)

        if compile and not self._compile_only:
            self.compile()

    @property
    def _execution_device(self):
        return torch.device("cpu")

    def maybe_free_model_hooks(self):
        pass

    @property
    def components(self) -> Dict[str, Any]:
        """Return dict mapping component names to OV model wrappers for quantization."""
        comp = {}
        if self.transformer is not None:
            comp["transformer"] = self.transformer
        if self.vae_decoder is not None:
            comp["vae_decoder"] = self.vae_decoder
        if self.vae_encoder is not None:
            comp["vae_encoder"] = self.vae_encoder
        if self.text_encoder is not None:
            comp["text_encoder"] = self.text_encoder
        if self.connectors is not None:
            comp["connectors"] = self.connectors
        if self.audio_vae is not None:
            comp["audio_vae_decoder"] = self.audio_vae
        if self.vocoder is not None:
            comp["vocoder"] = self.vocoder
        return comp

    def _reshape_transformer(
        self, model, batch_size, height, width, num_images_per_prompt=-1, tokenizer_max_length=-1, num_frames=-1
    ):
        if batch_size == -1 or num_images_per_prompt == -1:
            batch_size = -1
        else:
            batch_size *= num_images_per_prompt * 2

        shapes = {}
        scalar_inputs = {"height", "width", "num_frames", "fps", "audio_num_frames", "rope_interpolation_scale"}
        for inputs in model.inputs:
            shapes[inputs] = inputs.get_partial_shape()
            name = inputs.get_any_name()
            if name in scalar_inputs:
                shapes[inputs] = inputs.get_partial_shape()
            elif inputs.get_partial_shape().rank.get_length() >= 2:
                shapes[inputs][0] = batch_size
                for i in range(1, inputs.get_partial_shape().rank.get_length()):
                    shapes[inputs][i] = -1
            elif inputs.get_partial_shape().rank.get_length() == 1:
                shapes[inputs][0] = batch_size
        model.reshape(shapes)
        return model

    def reshape(self, batch_size, height, width, num_images_per_prompt=-1, num_frames=-1):
        self.is_dynamic = -1 in {batch_size, height, width, num_images_per_prompt}
        # Reshape transformer with custom logic for scalar inputs
        self.transformer.model = self._reshape_transformer(
            self.transformer.model, batch_size, height, width, num_images_per_prompt, num_frames=num_frames
        )
        # Reshape vae_decoder with proper height/width
        self.vae_decoder.model = self._reshape_vae_decoder(
            self.vae_decoder.model, height, width, num_images_per_prompt, num_frames=num_frames
        )
        # Reshape vae_encoder (image-to-video only) with pixel-space height/width; the encoder
        # treats the conditioning image as a single frame (num_frames handled inside).
        if self.vae_encoder is not None:
            self.vae_encoder.model = self._reshape_vae_encoder(
                self.vae_encoder.model, batch_size, height, width, num_frames=num_frames
            )
        # Reshape text_encoder with batch_size only (tokenizer_max_length stays dynamic for Gemma)
        if self.text_encoder is not None:
            self.text_encoder.model = self._reshape_text_encoder(self.text_encoder.model, batch_size, -1)
        # Reshape connectors, audio_vae, vocoder with the full batch (accounts for guidance scale)
        effective_batch = (
            batch_size * num_images_per_prompt * 2 if batch_size > 0 and num_images_per_prompt > 0 else -1
        )
        for ov_model_attr in [self.connectors, self.audio_vae, self.vocoder]:
            if ov_model_attr is not None:
                shapes = {}
                for inputs in ov_model_attr.model.inputs:
                    shapes[inputs] = inputs.get_partial_shape()
                    rank = inputs.get_partial_shape().rank.get_length()
                    if rank >= 1:
                        shapes[inputs][0] = effective_batch
                    for i in range(1, rank):
                        shapes[inputs][i] = -1
                ov_model_attr.model.reshape(shapes)
        self.clear_requests()


class OVLTX2Pipeline(_OVLTX2Base, LTX2Pipeline):
    main_input_name = "prompt"
    export_feature = "text-to-video"
    auto_model_class = LTX2Pipeline


class OVLTX2ImageToVideoPipeline(_OVLTX2Base, LTX2ImageToVideoPipeline):
    main_input_name = "image"
    export_feature = "image-to-video"
    auto_model_class = LTX2ImageToVideoPipeline
    _vae_encoder_single_frame = True

    @classproperty
    def _all_ov_model_paths(cls) -> Dict[str, str]:
        # Same submodels as text-to-video, plus the VAE encoder used to encode the input image.
        models_paths = _OVLTX2Base._all_ov_model_paths
        models_paths["vae_encoder"] = os.path.join(DIFFUSION_MODEL_VAE_ENCODER_SUBFOLDER, OV_XML_FILE_NAME)
        return models_paths


class OVQwenImagePipeline(OVDiffusionPipeline, OVTextualInversionLoaderMixin, QwenImagePipeline):
    main_input_name = "prompt"
    export_feature = "text-to-image"
    auto_model_class = QwenImagePipeline

    def _get_qwen_prompt_embeds(
        self,
        prompt: Union[str, List[str]] = None,
        device: Optional[torch.device] = None,
        dtype: Optional[torch.dtype] = None,
    ):
        # Mirror diffusers.QwenImagePipeline._get_qwen_prompt_embeds, but the OpenVINO text encoder directly
        # outputs the last hidden state (equivalent to `hidden_states[-1]` of the original Qwen2.5-VL model).
        device = device or self._execution_device
        dtype = dtype or torch.float32

        prompt = [prompt] if isinstance(prompt, str) else prompt

        template = self.prompt_template_encode
        drop_idx = self.prompt_template_encode_start_idx
        txt = [template.format(e) for e in prompt]
        txt_tokens = self.tokenizer(
            txt, max_length=self.tokenizer_max_length + drop_idx, padding=True, truncation=True, return_tensors="pt"
        )
        encoder_outputs = self.text_encoder(
            input_ids=txt_tokens.input_ids,
            attention_mask=txt_tokens.attention_mask,
            output_hidden_states=True,
        )
        hidden_states = encoder_outputs.last_hidden_state
        split_hidden_states = self._extract_masked_hidden(hidden_states, txt_tokens.attention_mask)
        split_hidden_states = [e[drop_idx:] for e in split_hidden_states]
        attn_mask_list = [torch.ones(e.size(0), dtype=torch.long, device=e.device) for e in split_hidden_states]
        max_seq_len = max([e.size(0) for e in split_hidden_states])
        prompt_embeds = torch.stack(
            [torch.cat([u, u.new_zeros(max_seq_len - u.size(0), u.size(1))]) for u in split_hidden_states]
        )
        encoder_attention_mask = torch.stack(
            [torch.cat([u, u.new_zeros(max_seq_len - u.size(0))]) for u in attn_mask_list]
        )

        prompt_embeds = prompt_embeds.to(dtype=dtype, device=device)

        return prompt_embeds, encoder_attention_mask


class _OVZImageTransformerAdapter:
    """Adapter that converts ZImagePipeline's transformer calling convention to OV model inputs.

    ZImagePipeline calls the transformer as:
        transformer(x_list, t, cap_feats_list, return_dict=False)
    where x_list is a list of [C,1,H,W] tensors (with frame dim) and cap_feats_list is a list
    of variable-length [seq_len, dim] tensors — ``_encode_prompt`` strips the tokenizer's
    padding, so prompts of different lengths arrive as a ragged list.

    The exported OV model takes rectangular tensors plus the pieces the graph cannot derive
    from a ragged batch:
        hidden_states [B,C,H,W], timestep [B], encoder_hidden_states [B,M,dim],
        encoder_attention_mask [B,M] (eager additive), txt_ids [B,M,3], img_ids [B,N,3]
    and returns sample [B,C,H,W]. One infer request serves the whole batch, whatever the
    prompt lengths.

    This class reproduces on the host what ZImageTransformer2DModel._pad_with_ids does
    per item: round each caption up to SEQ_MULTI_OF, number its positions from 1, and offset
    the image grid past it. That offset is why the position ids have to be computed here —
    it depends on each item's own caption length, so a ragged batch has different image
    position ids per item.
    """

    SEQ_MULTI_OF = 32
    PATCH_SIZE = 2

    def __init__(self, ov_transformer):
        self._ov_transformer = ov_transformer

    @classmethod
    def _rounded(cls, length: int) -> int:
        return length + (-length) % cls.SEQ_MULTI_OF

    def __call__(self, x, t, cap_feats, return_dict=True, **kwargs):
        batch_size = len(x)
        if not isinstance(t, torch.Tensor):
            t = torch.tensor([t])
        timestep = t.reshape(-1)
        if timestep.numel() == 1 and batch_size > 1:
            timestep = timestep.expand(batch_size)

        # x: list of [C, 1, H, W] → [B, C, H, W]
        hidden_states = torch.stack([x_item.squeeze(1) for x_item in x], dim=0)

        # Image token grid — same for every item, only its offset differs.
        height_tokens = hidden_states.shape[2] // self.PATCH_SIZE
        width_tokens = hidden_states.shape[3] // self.PATCH_SIZE
        num_img_tokens = height_tokens * width_tokens
        padded_img_tokens = self._rounded(num_img_tokens)
        img_grid = torch.stack(
            torch.meshgrid(
                torch.arange(1, dtype=torch.int32),
                torch.arange(height_tokens, dtype=torch.int32),
                torch.arange(width_tokens, dtype=torch.int32),
                indexing="ij",
            ),
            dim=-1,
        ).reshape(-1, 3)

        real_lengths = [cf.shape[0] for cf in cap_feats]
        rounded_lengths = [self._rounded(length) for length in real_lengths]
        max_cap_len = max(rounded_lengths)
        cap_dim = cap_feats[0].shape[-1]

        encoder_hidden_states = torch.zeros(batch_size, max_cap_len, cap_dim, dtype=cap_feats[0].dtype)
        # Eager additive mask: 0 on a real token, finfo.min elsewhere.
        mask_dtype = cap_feats[0].dtype
        encoder_attention_mask = torch.full((batch_size, max_cap_len), torch.finfo(mask_dtype).min, dtype=mask_dtype)
        txt_ids = torch.zeros(batch_size, max_cap_len, 3, dtype=torch.int32)
        img_ids = torch.zeros(batch_size, padded_img_tokens, 3, dtype=torch.int32)

        for i, (cap, real_len, rounded_len) in enumerate(zip(cap_feats, real_lengths, rounded_lengths)):
            encoder_hidden_states[i, :real_len] = cap
            # Only real tokens; the graph fills the rest with the learned cap_pad_token.
            encoder_attention_mask[i, :real_len] = 0.0
            # Caption positions are 1-based up to the rounded length; the batch-padded tail
            # keeps position 0, which is what marks it as masked out.
            txt_ids[i, :rounded_len, 0] = torch.arange(1, rounded_len + 1, dtype=torch.int32)
            # Image tokens sit immediately after this item's caption.
            img_ids[i, :num_img_tokens] = img_grid
            img_ids[i, :num_img_tokens, 0] += rounded_len + 1

        ov_out = self._ov_transformer(
            hidden_states=hidden_states,
            timestep=timestep,
            encoder_hidden_states=encoder_hidden_states,
            encoder_attention_mask=encoder_attention_mask,
            txt_ids=txt_ids,
            img_ids=img_ids,
            return_dict=False,
        )

        if isinstance(ov_out, (tuple, list)):
            sample = ov_out[0]
        elif hasattr(ov_out, "sample"):
            sample = ov_out.sample
        else:
            sample = list(ov_out.values())[0] if hasattr(ov_out, "values") else ov_out

        if not isinstance(sample, torch.Tensor):
            sample = torch.from_numpy(sample)

        # [B, C, H, W] → list of [C, 1, H, W], the convention ZImagePipeline expects back
        return ([s.unsqueeze(1) for s in sample.unbind(0)],)

    def __getattr__(self, name):
        return getattr(self._ov_transformer, name)


class _OVZImagePipelineMixin:
    """Behaviour shared by the OpenVINO Z-Image pipelines.

    The text-to-image and image-to-image pipelines drive the transformer with the same
    list-based convention and build prompt embeddings the same way, so the adapter
    wrapping and the ``_encode_prompt`` override live here rather than in each class.

    Listed first among the bases so these two methods win over the diffusers pipeline
    they are mixed into.
    """

    def __call__(self, *args, **kwargs):
        """Wrap transformer with ZImage-to-OV adapter before calling the pipeline.

        Delegates to OVDiffusionPipeline.__call__ rather than straight to
        auto_model_class.__call__: that is where numpy random states are converted to
        torch generators and where a statically reshaped pipeline overrides the requested
        height/width.
        """
        orig_transformer = self.transformer
        if not isinstance(orig_transformer, _OVZImageTransformerAdapter):
            self.transformer = _OVZImageTransformerAdapter(orig_transformer)
        try:
            return OVDiffusionPipeline.__call__(self, *args, **kwargs)
        finally:
            self.transformer = orig_transformer

    def _encode_prompt(self, prompt, device=None, prompt_embeds=None, max_sequence_length=512):
        """Override to use last_hidden_state from the OV text encoder.

        The OV text encoder exports hidden_states[-2] as last_hidden_state
        (see ZImageTextEncoderModelPatcher), so we read that directly instead
        of calling with output_hidden_states=True.
        """
        if prompt_embeds is not None:
            return prompt_embeds

        if isinstance(prompt, str):
            prompt = [prompt]

        # Build a new list rather than assigning back into the caller's: reusing the same
        # prompt list for a second call would otherwise wrap it in the chat template twice.
        templated_prompt = [
            self.tokenizer.apply_chat_template(
                [{"role": "user", "content": prompt_item}],
                tokenize=False,
                add_generation_prompt=True,
                enable_thinking=True,
            )
            for prompt_item in prompt
        ]

        text_inputs = self.tokenizer(
            templated_prompt,
            padding="max_length",
            max_length=max_sequence_length,
            truncation=True,
            return_tensors="pt",
        )

        text_input_ids = text_inputs.input_ids
        prompt_masks = text_inputs.attention_mask.bool()

        # OV text encoder returns last_hidden_state which is already hidden_states[-2]
        encoder_out = self.text_encoder(input_ids=text_input_ids, attention_mask=prompt_masks)
        prompt_embeds = encoder_out.last_hidden_state
        if not isinstance(prompt_embeds, torch.Tensor):
            prompt_embeds = torch.from_numpy(prompt_embeds)

        embeddings_list = []
        for i in range(len(prompt_embeds)):
            embeddings_list.append(prompt_embeds[i][prompt_masks[i]])

        return embeddings_list


class OVZImagePipeline(_OVZImagePipelineMixin, OVDiffusionPipeline, OVTextualInversionLoaderMixin, ZImagePipeline):
    """
    OpenVINO-powered pipeline corresponding to [diffusers.ZImagePipeline](https://huggingface.co/docs/diffusers/api/pipelines/z_image).
    """

    main_input_name = "prompt"
    export_feature = "text-to-image"
    auto_model_class = ZImagePipeline


class OVZImageImg2ImgPipeline(
    _OVZImagePipelineMixin, OVDiffusionPipeline, OVTextualInversionLoaderMixin, ZImageImg2ImgPipeline
):
    """
    OpenVINO-powered pipeline corresponding to [diffusers.ZImageImg2ImgPipeline](https://huggingface.co/docs/diffusers/api/pipelines/z_image).

    Reuses the text-to-image export unchanged: image-to-image only changes how the
    initial latents are built (encode the input image with the VAE, then add noise at the
    timestep selected by ``strength``) and runs the same denoising loop afterwards.
    """

    main_input_name = "image"
    export_feature = "image-to-image"
    auto_model_class = ZImageImg2ImgPipeline


class OVZImageInpaintPipeline(
    _OVZImagePipelineMixin, OVDiffusionPipeline, OVTextualInversionLoaderMixin, ZImageInpaintPipeline
):
    """
    OpenVINO-powered pipeline corresponding to [diffusers.ZImageInpaintPipeline](https://huggingface.co/docs/diffusers/api/pipelines/z_image).

    Reuses the text-to-image export unchanged, like the image-to-image pipeline: only the
    latent preparation differs, blending the VAE-encoded original back into the unmasked
    region at every denoising step.
    """

    main_input_name = "image"
    export_feature = "inpainting"
    auto_model_class = ZImageInpaintPipeline


SUPPORTED_OV_PIPELINES = [
    OVStableDiffusionPipeline,
    OVStableDiffusionImg2ImgPipeline,
    OVStableDiffusionInpaintPipeline,
    OVStableDiffusionXLPipeline,
    OVStableDiffusionXLImg2ImgPipeline,
    OVStableDiffusionXLInpaintPipeline,
    OVLatentConsistencyModelPipeline,
    OVLatentConsistencyModelImg2ImgPipeline,
]


def _get_ov_class(pipeline_class_name: str, throw_error_if_not_exist: bool = True):
    for ov_pipeline_class in SUPPORTED_OV_PIPELINES:
        if (
            ov_pipeline_class.__name__ == pipeline_class_name
            or ov_pipeline_class.auto_model_class.__name__ == pipeline_class_name
        ):
            return ov_pipeline_class

    if throw_error_if_not_exist:
        raise ValueError(f"OVDiffusionPipeline can't find a pipeline linked to {pipeline_class_name}")


OV_TEXT2IMAGE_PIPELINES_MAPPING = OrderedDict(
    [
        ("stable-diffusion", OVStableDiffusionPipeline),
        ("stable-diffusion-xl", OVStableDiffusionXLPipeline),
        ("latent-consistency", OVLatentConsistencyModelPipeline),
    ]
)

OV_IMAGE2IMAGE_PIPELINES_MAPPING = OrderedDict(
    [
        ("stable-diffusion", OVStableDiffusionImg2ImgPipeline),
        ("stable-diffusion-xl", OVStableDiffusionXLImg2ImgPipeline),
        ("latent-consistency", OVLatentConsistencyModelImg2ImgPipeline),
    ]
)

OV_INPAINT_PIPELINES_MAPPING = OrderedDict(
    [
        ("stable-diffusion", OVStableDiffusionInpaintPipeline),
        ("stable-diffusion-xl", OVStableDiffusionXLInpaintPipeline),
    ]
)

OV_TEXT2VIDEO_PIPELINES_MAPPING = OrderedDict()
OV_IMAGE2VIDEO_PIPELINES_MAPPING = OrderedDict()

if is_diffusers_version(">=", "0.32"):
    OV_TEXT2VIDEO_PIPELINES_MAPPING["ltx-video"] = OVLTXPipeline
    OV_IMAGE2VIDEO_PIPELINES_MAPPING["ltx-video"] = OVLTXImageToVideoPipeline
    SUPPORTED_OV_PIPELINES.append(OVLTXPipeline)
    SUPPORTED_OV_PIPELINES.append(OVLTXImageToVideoPipeline)

if is_diffusers_version(">=", "0.38.0"):
    OV_TEXT2VIDEO_PIPELINES_MAPPING["ltx2"] = OVLTX2Pipeline
    OV_IMAGE2VIDEO_PIPELINES_MAPPING["ltx2"] = OVLTX2ImageToVideoPipeline
    SUPPORTED_OV_PIPELINES.append(OVLTX2Pipeline)
    SUPPORTED_OV_PIPELINES.append(OVLTX2ImageToVideoPipeline)

if is_diffusers_version(">=", "0.29.0"):
    SUPPORTED_OV_PIPELINES.extend(
        [
            OVStableDiffusion3Pipeline,
            OVStableDiffusion3Img2ImgPipeline,
        ]
    )

    OV_TEXT2IMAGE_PIPELINES_MAPPING["stable-diffusion-3"] = OVStableDiffusion3Pipeline
    OV_IMAGE2IMAGE_PIPELINES_MAPPING["stable-diffusion-3"] = OVStableDiffusion3Img2ImgPipeline

if is_diffusers_version(">=", "0.30.0"):
    SUPPORTED_OV_PIPELINES.extend([OVStableDiffusion3InpaintPipeline, OVFluxPipeline])
    OV_INPAINT_PIPELINES_MAPPING["stable-diffusion-3"] = OVStableDiffusion3InpaintPipeline
    OV_TEXT2IMAGE_PIPELINES_MAPPING["flux"] = OVFluxPipeline

if is_diffusers_version(">=", "0.31.0"):
    SUPPORTED_OV_PIPELINES.extend([OVFluxImg2ImgPipeline, OVFluxInpaintPipeline])
    OV_INPAINT_PIPELINES_MAPPING["flux"] = OVFluxInpaintPipeline
    OV_IMAGE2IMAGE_PIPELINES_MAPPING["flux"] = OVFluxImg2ImgPipeline

if is_diffusers_version(">=", "0.32.0"):
    OV_INPAINT_PIPELINES_MAPPING["flux-fill"] = OVFluxFillPipeline
    SUPPORTED_OV_PIPELINES.append(OVFluxFillPipeline)
    OV_TEXT2IMAGE_PIPELINES_MAPPING["sana"] = OVSanaPipeline
    SUPPORTED_OV_PIPELINES.append(OVSanaPipeline)


if is_diffusers_version(">=", "0.33.0"):
    SUPPORTED_OV_PIPELINES.append(OVSanaSprintPipeline)
    OV_TEXT2IMAGE_PIPELINES_MAPPING["sana-sprint"] = OVSanaSprintPipeline

if is_diffusers_version(">=", "0.35.0"):
    SUPPORTED_OV_PIPELINES.append(OVQwenImagePipeline)
    OV_TEXT2IMAGE_PIPELINES_MAPPING["qwenimage"] = OVQwenImagePipeline

if is_diffusers_version(">=", "0.37.0"):
    SUPPORTED_OV_PIPELINES.append(OVFlux2KleinPipeline)
    OV_TEXT2IMAGE_PIPELINES_MAPPING["flux2-klein"] = OVFlux2KleinPipeline
    OV_IMAGE2IMAGE_PIPELINES_MAPPING["flux2-klein"] = OVFlux2KleinPipeline

if is_diffusers_version(">=", "0.37.0"):
    SUPPORTED_OV_PIPELINES.append(OVZImagePipeline)
    SUPPORTED_OV_PIPELINES.append(OVZImageImg2ImgPipeline)
    SUPPORTED_OV_PIPELINES.append(OVZImageInpaintPipeline)
    OV_TEXT2IMAGE_PIPELINES_MAPPING["z-image"] = OVZImagePipeline
    OV_IMAGE2IMAGE_PIPELINES_MAPPING["z-image"] = OVZImageImg2ImgPipeline
    OV_INPAINT_PIPELINES_MAPPING["z-image"] = OVZImageInpaintPipeline

SUPPORTED_OV_PIPELINES_MAPPINGS = [
    OV_TEXT2IMAGE_PIPELINES_MAPPING,
    OV_IMAGE2IMAGE_PIPELINES_MAPPING,
    OV_INPAINT_PIPELINES_MAPPING,
    OV_TEXT2VIDEO_PIPELINES_MAPPING,
    OV_IMAGE2VIDEO_PIPELINES_MAPPING,
]


def _get_task_ov_class(mapping, pipeline_class_name):
    def _get_model_name(pipeline_class_name):
        for ov_pipelines_mapping in SUPPORTED_OV_PIPELINES_MAPPINGS:
            for model_name, ov_pipeline_class in ov_pipelines_mapping.items():
                if (
                    ov_pipeline_class.__name__ == pipeline_class_name
                    or ov_pipeline_class.auto_model_class.__name__ == pipeline_class_name
                ):
                    return model_name

    model_name = _get_model_name(pipeline_class_name)

    if model_name is not None:
        task_class = mapping.get(model_name, None)
        if task_class is not None:
            return task_class

    raise ValueError(f"OVPipelineForTask can't find a pipeline linked to {pipeline_class_name} for {model_name}")


class OVPipelineForTask(ConfigMixin):
    auto_model_class = DiffusionPipeline
    config_name = "model_index.json"

    @classmethod
    @validate_hf_hub_args
    def from_pretrained(cls, pretrained_model_or_path, **kwargs):
        load_config_kwargs = {
            "force_download": kwargs.get("force_download", False),
            "resume_download": kwargs.get("resume_download", None),
            "local_files_only": kwargs.get("local_files_only", False),
            "cache_dir": kwargs.get("cache_dir", None),
            "revision": kwargs.get("revision", None),
            "proxies": kwargs.get("proxies", None),
            "token": kwargs.get("token", None),
        }
        config = cls.load_config(pretrained_model_or_path, **load_config_kwargs)
        config = config[0] if isinstance(config, tuple) else config
        class_name = config["_class_name"]

        ov_pipeline_class = _get_task_ov_class(cls.ov_pipelines_mapping, class_name)

        return ov_pipeline_class.from_pretrained(pretrained_model_or_path, **kwargs)


class OVPipelineForText2Image(OVPipelineForTask):
    auto_model_class = AutoPipelineForText2Image
    ov_pipelines_mapping = OV_TEXT2IMAGE_PIPELINES_MAPPING
    export_feature = "text-to-image"


class OVPipelineForImage2Image(OVPipelineForTask):
    auto_model_class = AutoPipelineForImage2Image
    ov_pipelines_mapping = OV_IMAGE2IMAGE_PIPELINES_MAPPING
    export_feature = "image-to-image"


class OVPipelineForInpainting(OVPipelineForTask):
    auto_model_class = AutoPipelineForInpainting
    ov_pipelines_mapping = OV_INPAINT_PIPELINES_MAPPING
    export_feature = "inpainting"


class OVPipelineForText2Video(OVPipelineForTask):
    auto_model_class = DiffusionPipeline
    ov_pipelines_mapping = OV_TEXT2VIDEO_PIPELINES_MAPPING
    export_feature = "text-to-video"


class OVPipelineForImage2Video(OVPipelineForTask):
    auto_model_class = DiffusionPipeline
    ov_pipelines_mapping = OV_IMAGE2VIDEO_PIPELINES_MAPPING
    export_feature = "image-to-video"
