#  Copyright 2024 The HuggingFace Team. All rights reserved.
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.

import contextlib
from typing import Dict, Optional, Tuple

import transformers.pipelines
from transformers import AutoConfig, PretrainedConfig

from optimum.intel.openvino import (
    OVModelForAudioClassification,
    OVModelForAudioFrameClassification,
    OVModelForAudioXVector,
    OVModelForCausalLM,
    OVModelForCTC,
    OVModelForFeatureExtraction,
    OVModelForImageClassification,
    OVModelForImageTextToText,
    OVModelForMaskedLM,
    OVModelForMultimodalLM,
    OVModelForQuestionAnswering,
    OVModelForSeq2SeqLM,
    OVModelForSequenceClassification,
    OVModelForSpeechSeq2Seq,
    OVModelForTextToSpeechSeq2Seq,
    OVModelForTokenClassification,
    OVModelForVisualCausalLM,
    OVModelForZeroShotImageClassification,
)
from optimum.intel.openvino.modeling_base import OVBaseModel
from optimum.intel.utils import is_transformers_version
from optimum.utils.logging import get_logger


logger = get_logger(__name__)


OV_TASKS_MAPPING = {
    "audio-classification": (OVModelForAudioClassification,),
    "audio-frame-classification": (OVModelForAudioFrameClassification,),
    "audio-xvector": (OVModelForAudioXVector,),
    "automatic-speech-recognition": (OVModelForCTC, OVModelForSpeechSeq2Seq, OVModelForMultimodalLM),
    "feature-extraction": (OVModelForFeatureExtraction,),
    "fill-mask": (OVModelForMaskedLM,),
    "image-classification": (OVModelForImageClassification,),
    "image-text-to-text": (OVModelForVisualCausalLM, OVModelForMultimodalLM),
    "image-to-text": (OVModelForImageTextToText,),
    "question-answering": (OVModelForQuestionAnswering,),
    "summarization": (OVModelForSeq2SeqLM,),
    "text2text-generation": (OVModelForSeq2SeqLM,),
    "text-classification": (OVModelForSequenceClassification,),
    "text-generation": (OVModelForCausalLM,),
    "text-to-audio": (OVModelForTextToSpeechSeq2Seq, OVModelForMultimodalLM),
    "token-classification": (OVModelForTokenClassification,),
    "translation": (OVModelForSeq2SeqLM,),
    "zero-shot-image-classification": (OVModelForZeroShotImageClassification,),
}


def get_openvino_model_class(
    task: str, config: Optional["PretrainedConfig"] = None, model_id: Optional[str] = None, **model_kwargs
):
    if task.startswith("translation_"):
        task = "translation"

    if task not in OV_TASKS_MAPPING:
        raise KeyError(
            f"Task '{task}' is not supported by OpenVINO. Only {list(OV_TASKS_MAPPING.keys())} are supported."
        )

    if task == "automatic-speech-recognition":
        if config is None:
            hub_kwargs = {
                "trust_remote_code": model_kwargs.pop("trust_remote_code", False),
                "revision": model_kwargs.pop("revision", None),
                "token": model_kwargs.pop("token", None),
            }
            config = AutoConfig.from_pretrained(model_id, **hub_kwargs)
        if any(arch.endswith("ForCTC") for arch in config.architectures):
            ov_model_class = OV_TASKS_MAPPING[task][0]
        elif getattr(config, "model_type", None) == "qwen3_omni_moe":
            ov_model_class = OV_TASKS_MAPPING[task][2]
        else:
            ov_model_class = OV_TASKS_MAPPING[task][1]
    else:
        task_classes = OV_TASKS_MAPPING[task]
        if len(task_classes) > 1 and OVModelForMultimodalLM in task_classes:
            if config is None:
                hub_kwargs = {
                    "trust_remote_code": model_kwargs.pop("trust_remote_code", False),
                    "revision": model_kwargs.pop("revision", None),
                    "token": model_kwargs.pop("token", None),
                }
                config = AutoConfig.from_pretrained(model_id, **hub_kwargs)
            if getattr(config, "model_type", None) == "qwen3_omni_moe":
                ov_model_class = OVModelForMultimodalLM
            else:
                ov_model_class = task_classes[0]
        else:
            ov_model_class = task_classes[0]

    return ov_model_class


# a modified transformers.pipelines.base.infer_framework_load_model that loads OpenVINO models
def openvino_infer_framework_load_model(
    model,
    config: Optional["PretrainedConfig"] = None,
    model_classes: Optional[Dict[str, Tuple[type]]] = None,
    task: Optional[str] = None,
    framework: Optional[str] = None,
    **model_kwargs,
):
    if isinstance(model, str):
        model_kwargs.pop("_commit_hash", None)  # not supported for OVModel
        ov_model_class = get_openvino_model_class(task, config, model, **model_kwargs)
        ov_model = ov_model_class.from_pretrained(model, **model_kwargs)
    elif isinstance(model, OVBaseModel):
        ov_model = model
    else:
        raise TypeError(
            f"""Model {model} is not supported. Please provide a valid model either as string or OVBaseModel.
            You can also provide None as the model to use a default one."""
        )

    if is_transformers_version("<", "5"):
        return "pt", ov_model

    return ov_model


@contextlib.contextmanager
def patch_pipelines_to_load_accelerator_model(accelerator: str):
    target_fn = "infer_framework_load_model" if is_transformers_version("<", "5") else "load_model"

    original_infer_framework_load_model = getattr(transformers.pipelines, target_fn)

    if accelerator == "openvino":
        setattr(transformers.pipelines, target_fn, openvino_infer_framework_load_model)
    else:
        raise ValueError(f"Accelerator '{accelerator}' is not supported. Only 'openvino' is supported.")

    try:
        yield
    finally:
        setattr(transformers.pipelines, target_fn, original_infer_framework_load_model)
