__version__ = '0.29.2+cpu'
git_version = 'f12281517f1b2f6255904639b027c9436f3e5008'
from torchvision.extension import _check_cuda_version
if _check_cuda_version() > 0:
    cuda = _check_cuda_version()
